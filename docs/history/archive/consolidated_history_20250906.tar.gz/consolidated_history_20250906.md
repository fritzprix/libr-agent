# refactoring_20251101_1557.md

# Refactoring Plan: App Performance & Responsiveness Optimization

**Date:** 2025-11-01  
**Author:** GitHub Copilot  
**Related Branch:** feat/on-board  
**Priority:** High

---

## 1. 작업의 목적

LibrAgent 애플리케이션의 응답성과 사용자 경험을 개선하기 위해 App.tsx 및 하위 컴포넌트들의 성능 최적화를 수행한다.

**목표:**

- UI 응답성 30% 이상 개선
- 불필요한 리렌더링 최소화
- 이벤트 처리 최적화 (스크롤, 타이핑 등)
- 메모리 사용량 감소

---

## 2. 현재의 상태 / 문제점

### 2.1 Context Provider 과도한 중첩 (Critical)

**현황:**

```
App.tsx에 11단계 Context Provider 중첩
├─ SettingsProvider
├─ MCPServerRegistryProvider
├─ MCPServerProvider
├─ SystemPromptProvider
├─ AssistantContextProvider
├─ SessionContextProvider
├─ BuiltInToolProvider
├─ SessionHistoryProvider
├─ ResourceAttachmentProvider
├─ ModelOptionsProvider
└─ SidebarProvider
```

**문제점:**

- 한 Provider의 상태 변경 시 전체 트리 재평가 가능성
- Context 간 의존성 불명확
- 불필요한 리렌더링 체인 발생
- 초기 로딩 성능 저하

**영향 파일:**

- `src/app/App.tsx` (11개 Provider 중첩)

---

### 2.2 AssistantContext 비효율적 상태 관리 (High)

**문제 코드 위치:** `src/context/AssistantContext.tsx`

#### Issue 1: 불필요한 Toast 알림

```tsx
// Line 183-187
useEffect(() => {
  if (currentAssistant) {
    toast(`Assistant switched: ${currentAssistant.name}`);
  }
}, [currentAssistant]);
```

- 초기 로드, 리로드 시에도 토스트 표시
- 사용자가 명시적으로 전환하지 않아도 알림 발생

#### Issue 2: 중복 에러 처리

```tsx
// Line 270-280
useEffect(() => {
  if (saveError) setError(saveError);
  else if (deleteError) setError(deleteError);
  else if (loadError) setError(loadError);
}, [saveError, deleteError, loadError]);
```

- 3개의 useEffect로 분산된 에러 처리
- 매번 새로운 useEffect 실행

#### Issue 3: MCP 서버 즉시 연결

```tsx
// Line 306-313
useEffect(() => {
  if (currentAssistant && activeServers.length > 0) {
    connectServersFromAssistant(currentAssistant);
  }
}, [currentAssistant, activeServers, connectServersFromAssistant]);
```

- Assistant 전환 시 즉시 서버 재연결 (네트워크 오버헤드)
- Debounce 없이 실행

**영향:**

- Assistant 전환 시 UI 지연
- 불필요한 네트워크 요청
- 사용자 경험 저하

---

### 2.3 SessionContext 비효율적 데이터 구조 (High)

**문제 코드 위치:** `src/context/SessionContext.tsx`

#### Issue 1: 매번 flatMap 실행

```tsx
// Line 153-155
useEffect(() => {
  sessionsRef.current = sessions.flatMap((page) => page.items);
}, [sessions]);
```

- SWR 데이터 변경 시마다 전체 배열 재생성
- O(n) 연산이 매 렌더링마다 실행

#### Issue 2: 불필요한 useMemo 체이닝

```tsx
// Line 136
const sessions = useMemo(() => data ?? [], [data]);

// Line 138-141
const hasNextPage = useMemo(
  () => !(sessions.length > 0 && !sessions[sessions.length - 1].hasNextPage),
  [sessions],
);
```

- sessions → hasNextPage로 이어지는 메모 체인
- 중간 값 변경 시 전체 체인 재계산

**영향:**

- 세션 목록이 많을 경우 성능 저하
- 메모리 사용량 증가

---

### 2.4 ChatMessages 스크롤 이벤트 미최적화 (High)

**문제 코드 위치:** `src/features/chat/components/ChatMessages.tsx`

```tsx
// Line 30-41
useEffect(() => {
  const container = scrollContainerRef.current;
  if (!container) return;

  const handleScroll = () => {
    const { scrollTop, scrollHeight, clientHeight } = container;
    const atBottom = scrollHeight - scrollTop - clientHeight < 10;
    setAutoScrollEnabled(atBottom); // 매 스크롤마다 setState!
  };

  container.addEventListener('scroll', handleScroll);
  return () => container.removeEventListener('scroll', handleScroll);
}, []);
```

**문제점:**

- Throttle/Debounce 없이 스크롤 이벤트 처리
- 초당 수백 번의 `setState` 호출
- 메시지가 많을 경우 심각한 성능 저하

**영향:**

- 스크롤 시 UI 버벅임
- CPU 사용률 증가

---

### 2.5 SessionList 검색 미최적화 (Medium)

**문제 코드 위치:** `src/features/session/SessionList.tsx`

```tsx
// Line 23-42
const filteredSessions = useMemo(() => {
  if (!searchQuery.trim()) {
    return sessions;
  }

  const query = searchQuery.toLowerCase();
  return sessions.filter((session) => {
    const name = session.name?.toLowerCase() || '';
    const description = session.description?.toLowerCase() || '';
    const assistantNames = session.assistants
      .map((a) => a.name.toLowerCase())
      .join(' ');

    return (
      name.includes(query) ||
      description.includes(query) ||
      assistantNames.includes(query)
    );
  });
}, [sessions, searchQuery]);
```

**문제점:**

- 타이핑 중 Debounce 없이 즉시 필터링
- `searchQuery` 변경 시마다 전체 배열 순회
- 세션이 많을 경우 타이핑 지연 발생

---

### 2.6 ChatInput 이벤트 핸들러 (Medium)

**문제 코드 위치:** `src/features/chat/components/ChatInput.tsx`

```tsx
// Line 99-103
const handleAgentInputChange = React.useCallback(
  (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
  },
  [],
);
```

**문제점:**

- 의존성 배열이 비어있어 불필요한 리렌더링 방지는 되지만, 최적화 여지 존재
- Drag & Drop 이벤트 처리가 복잡하게 구성됨

---

## 3. 관련 코드 구조 및 동작 방식 (Bird's Eye View)

### 3.1 Context 의존성 그래프

```
Settings (독립)
    ↓
MCPServerRegistry → MCPServer
    ↓                    ↓
SystemPrompt      Assistant → BuiltInTool
    ↓                    ↓
Session ← SessionHistory
    ↓
ResourceAttachment
    ↓
ModelOptions
    ↓
Sidebar (UI Layer)
```

**의존성 분석:**

- **Settings**: 모든 Context의 기반 (API Keys, Window Size 등)
- **MCP 관련**: MCPServerRegistry ← MCPServer ← Assistant
- **세션 관련**: Session ← SessionHistory ← ResourceAttachment
- **UI 관련**: Sidebar, DnD (독립적)

### 3.2 주요 컴포넌트 렌더링 플로우

```
App.tsx (11 Providers)
    ↓
AppSidebar (SessionList)
    ↓
ChatContainer (WebMCP Providers)
    ↓
Chat (ChatProvider)
    ├─ ChatMessages (스크롤 이벤트)
    └─ ChatInput (타이핑 이벤트)
```

---

## 4. 변경 이후의 상태 / 해결 판정 기준

### 4.1 성능 지표

| 항목                | 현재 (예상) | 목표   | 측정 방법               |
| ------------------- | ----------- | ------ | ----------------------- |
| Context Provider 수 | 11개        | 4-5개  | 코드 리뷰               |
| Assistant 전환 시간 | ~500ms      | <200ms | React DevTools Profiler |
| 스크롤 FPS          | ~30fps      | 60fps  | Chrome Performance Tab  |
| 검색 타이핑 지연    | ~300ms      | <50ms  | User Input Latency      |
| 초기 로딩 시간      | ~2s         | <1.5s  | Lighthouse Performance  |

### 4.2 해결 판정 기준

- [ ] Provider 수가 6개 이하로 감소
- [ ] AssistantContext의 useEffect가 5개 이하로 감소
- [ ] 스크롤 이벤트에 Throttle 적용 (100ms)
- [ ] 검색 입력에 Debounce 적용 (300ms)
- [ ] SessionContext의 불필요한 flatMap 제거
- [ ] React DevTools Profiler에서 리렌더링 경고 50% 감소

---

## 5. 수정이 필요한 코드 및 수정 부분

### 5.1 Context Provider 통합

#### 파일: `src/context/CoreContext.tsx` (신규 생성)

**목적:** Settings, MCP, SystemPrompt을 하나의 Provider로 통합

```tsx
import React, { createContext, useContext, useMemo } from 'react';
import { SettingsProvider, useSettings } from './SettingsContext';
import {
  MCPServerRegistryProvider,
  useMCPServerRegistry,
} from './MCPServerRegistryContext';
import { MCPServerProvider, useMCPServer } from './MCPServerContext';
import { SystemPromptProvider, useSystemPrompt } from './SystemPromptContext';

interface CoreContextValue {
  settings: ReturnType<typeof useSettings>;
  mcpRegistry: ReturnType<typeof useMCPServerRegistry>;
  mcpServer: ReturnType<typeof useMCPServer>;
  systemPrompt: ReturnType<typeof useSystemPrompt>;
}

const CoreContext = createContext<CoreContextValue | undefined>(undefined);

export function CoreProvider({ children }: { children: React.ReactNode }) {
  return (
    <SettingsProvider>
      <MCPServerRegistryProvider>
        <MCPServerProvider>
          <SystemPromptProvider>
            <CoreContextInner>{children}</CoreContextInner>
          </SystemPromptProvider>
        </MCPServerProvider>
      </MCPServerRegistryProvider>
    </SettingsProvider>
  );
}

function CoreContextInner({ children }: { children: React.ReactNode }) {
  const settings = useSettings();
  const mcpRegistry = useMCPServerRegistry();
  const mcpServer = useMCPServer();
  const systemPrompt = useSystemPrompt();

  const value = useMemo<CoreContextValue>(
    () => ({
      settings,
      mcpRegistry,
      mcpServer,
      systemPrompt,
    }),
    [settings, mcpRegistry, mcpServer, systemPrompt],
  );

  return <CoreContext.Provider value={value}>{children}</CoreContext.Provider>;
}

export function useCoreContext() {
  const context = useContext(CoreContext);
  if (!context) {
    throw new Error('useCoreContext must be used within CoreProvider');
  }
  return context;
}

// Backward compatibility hooks
export function useSettings() {
  return useCoreContext().settings;
}

export function useMCPServerRegistry() {
  return useCoreContext().mcpRegistry;
}

export function useMCPServer() {
  return useCoreContext().mcpServer;
}

export function useSystemPrompt() {
  return useCoreContext().systemPrompt;
}
```

#### 파일: `src/app/App.tsx` (수정)

**변경 전:**

```tsx
<SettingsProvider>
  <MCPServerRegistryProvider>
    <MCPServerProvider>
      <SystemPromptProvider>
        <AssistantContextProvider>{/* ... */}</AssistantContextProvider>
      </SystemPromptProvider>
    </MCPServerProvider>
  </MCPServerRegistryProvider>
</SettingsProvider>
```

**변경 후:**

```tsx
import { CoreProvider } from '../context/CoreContext';

<CoreProvider>
  <AssistantContextProvider>{/* ... */}</AssistantContextProvider>
</CoreProvider>;
```

---

### 5.2 AssistantContext 최적화

#### 파일: `src/context/AssistantContext.tsx`

**수정 1: Toast 알림 개선 (Line 183-187)**

```tsx
// 변경 전
useEffect(() => {
  if (currentAssistant) {
    toast(`Assistant switched: ${currentAssistant.name}`);
  }
}, [currentAssistant]);

// 변경 후
const prevAssistantIdRef = useRef<string | null>(null);

useEffect(() => {
  if (currentAssistant?.id) {
    // 초기 로드 시 (null → assistant) 제외
    if (
      prevAssistantIdRef.current !== null &&
      prevAssistantIdRef.current !== currentAssistant.id
    ) {
      toast(`Assistant switched: ${currentAssistant.name}`);
    }
    prevAssistantIdRef.current = currentAssistant.id;
  }
}, [currentAssistant?.id, currentAssistant?.name]);
```

**수정 2: 에러 처리 통합 (Line 270-280)**

```tsx
// 변경 전
const [error, setError] = useState<Error | null>(null);

useEffect(() => {
  if (saveError) setError(saveError);
  else if (deleteError) setError(deleteError);
  else if (loadError) setError(loadError);
}, [saveError, deleteError, loadError]);

// 변경 후
const error = useMemo<Error | null>(() => {
  return saveError || deleteError || loadError || null;
}, [saveError, deleteError, loadError]);

// setError 호출 제거 (자동으로 계산됨)
```

**수정 3: MCP 서버 연결 Debounce (Line 306-313)**

```tsx
// 파일 상단에 import 추가
import { useMemo, useEffect, useCallback, useRef } from 'react';

// 변경 전
useEffect(() => {
  if (currentAssistant && activeServers.length > 0) {
    connectServersFromAssistant(currentAssistant);
  }
}, [currentAssistant, activeServers, connectServersFromAssistant]);

// 변경 후
const debouncedConnectRef = useRef<NodeJS.Timeout | null>(null);

useEffect(() => {
  // 이전 타이머 취소
  if (debouncedConnectRef.current) {
    clearTimeout(debouncedConnectRef.current);
  }

  if (currentAssistant && activeServers.length > 0) {
    // 500ms 후 연결 시도
    debouncedConnectRef.current = setTimeout(() => {
      connectServersFromAssistant(currentAssistant);
    }, 500);
  }

  return () => {
    if (debouncedConnectRef.current) {
      clearTimeout(debouncedConnectRef.current);
    }
  };
}, [currentAssistant, activeServers, connectServersFromAssistant]);
```

---

### 5.3 SessionContext 최적화

#### 파일: `src/context/SessionContext.tsx`

**수정 1: flatMap 제거 (Line 153-155)**

```tsx
// 변경 전
const sessions = useMemo(() => data ?? [], [data]);

useEffect(() => {
  sessionsRef.current = sessions.flatMap((page) => page.items);
}, [sessions]);

// 변경 후
const sessions = useMemo(() => data ?? [], [data]);

const flatSessions = useMemo(
  () => sessions.flatMap((page) => page.items),
  [sessions],
);

useEffect(() => {
  sessionsRef.current = flatSessions;
}, [flatSessions]);

// 또는 ref 업데이트를 제거하고 직접 useMemo 값 사용
const handleGetSessions = useCallback(() => {
  return flatSessions;
}, [flatSessions]);
```

**수정 2: hasNextPage 계산 최적화 (Line 138-141)**

```tsx
// 변경 전
const hasNextPage = useMemo(
  () => !(sessions.length > 0 && !sessions[sessions.length - 1].hasNextPage),
  [sessions],
);

// 변경 후
const hasNextPage = useMemo(() => {
  if (sessions.length === 0) return false;
  const lastPage = sessions[sessions.length - 1];
  return lastPage.hasNextPage;
}, [sessions]);
```

---

### 5.4 ChatMessages 스크롤 최적화

#### 파일: `src/features/chat/components/ChatMessages.tsx`

**의존성 추가:**

```bash
pnpm add lodash-es
pnpm add -D @types/lodash-es
```

**코드 수정 (Line 30-41):**

```tsx
// 파일 상단 import 추가
import { throttle } from 'lodash-es';

// 변경 전
useEffect(() => {
  const container = scrollContainerRef.current;
  if (!container) return;

  const handleScroll = () => {
    const { scrollTop, scrollHeight, clientHeight } = container;
    const atBottom = scrollHeight - scrollTop - clientHeight < 10;
    setAutoScrollEnabled(atBottom);
  };

  container.addEventListener('scroll', handleScroll);
  return () => container.removeEventListener('scroll', handleScroll);
}, []);

// 변경 후
const handleScroll = useMemo(
  () =>
    throttle(() => {
      const container = scrollContainerRef.current;
      if (!container) return;

      const { scrollTop, scrollHeight, clientHeight } = container;
      const atBottom = scrollHeight - scrollTop - clientHeight < 10;
      setAutoScrollEnabled(atBottom);
    }, 100), // 100ms throttle
  [],
);

useEffect(() => {
  const container = scrollContainerRef.current;
  if (!container) return;

  container.addEventListener('scroll', handleScroll, { passive: true });

  return () => {
    handleScroll.cancel(); // lodash throttle cleanup
    container.removeEventListener('scroll', handleScroll);
  };
}, [handleScroll]);
```

---

### 5.5 SessionList 검색 최적화

#### 파일: `src/features/session/SessionList.tsx`

**방법 1: React 18 내장 useDeferredValue 사용**

```tsx
// 파일 상단 import 추가
import { useMemo, useState, useDeferredValue } from 'react';

// Line 19-20 수정
const [searchQuery, setSearchQuery] = useState('');
const deferredQuery = useDeferredValue(searchQuery);

// Line 23 수정
const filteredSessions = useMemo(() => {
  if (!deferredQuery.trim()) {
    return sessions;
  }

  const query = deferredQuery.toLowerCase();
  return sessions.filter((session) => {
    const name = session.name?.toLowerCase() || '';
    const description = session.description?.toLowerCase() || '';
    const assistantNames = session.assistants
      .map((a) => a.name.toLowerCase())
      .join(' ');

    return (
      name.includes(query) ||
      description.includes(query) ||
      assistantNames.includes(query)
    );
  });
}, [sessions, deferredQuery]); // searchQuery → deferredQuery
```

**방법 2: lodash debounce 사용 (더 정밀한 제어)**

```tsx
// 의존성 추가
// pnpm add lodash-es

import { debounce } from 'lodash-es';
import { useMemo, useState, useCallback } from 'react';

const [searchQuery, setSearchQuery] = useState('');
const [debouncedQuery, setDebouncedQuery] = useState('');

const updateDebouncedQuery = useMemo(
  () =>
    debounce((value: string) => {
      setDebouncedQuery(value);
    }, 300),
  [],
);

const handleSearchChange = useCallback(
  (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value); // 즉시 input 값 업데이트 (UX)
    updateDebouncedQuery(value); // debounced 필터링
  },
  [updateDebouncedQuery],
);

// cleanup
useEffect(() => {
  return () => {
    updateDebouncedQuery.cancel();
  };
}, [updateDebouncedQuery]);

// filteredSessions는 debouncedQuery 사용
const filteredSessions = useMemo(() => {
  // ... (debouncedQuery 사용)
}, [sessions, debouncedQuery]);
```

---

## 6. 재사용 가능한 연관 코드

### 6.1 공통 Hooks 생성

#### 파일: `src/hooks/use-throttle.ts` (신규 생성)

```typescript
import { useCallback, useEffect, useRef } from 'react';

/**
 * Throttle hook for event handlers
 * @param callback - Function to throttle
 * @param delay - Delay in milliseconds
 * @returns Throttled callback
 */
export function useThrottle<T extends (...args: unknown[]) => void>(
  callback: T,
  delay: number,
): T {
  const lastRun = useRef(Date.now());
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const throttledCallback = useCallback(
    (...args: Parameters<T>) => {
      const now = Date.now();
      const timeSinceLastRun = now - lastRun.current;

      if (timeSinceLastRun >= delay) {
        callback(...args);
        lastRun.current = now;
      } else {
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }
        timeoutRef.current = setTimeout(() => {
          callback(...args);
          lastRun.current = Date.now();
        }, delay - timeSinceLastRun);
      }
    },
    [callback, delay],
  ) as T;

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return throttledCallback;
}
```

#### 파일: `src/hooks/use-debounce.ts` (신규 생성)

```typescript
import { useEffect, useState } from 'react';

/**
 * Debounce hook for values
 * @param value - Value to debounce
 * @param delay - Delay in milliseconds
 * @returns Debounced value
 */
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}
```

### 6.2 Context 통합 패턴

#### 파일: `src/context/SessionManagementContext.tsx` (신규 생성)

**목적:** Session, SessionHistory, ResourceAttachment 통합

```typescript
import React, { createContext, useContext, useMemo } from 'react';
import { SessionContextProvider, useSessionContext } from './SessionContext';
import { SessionHistoryProvider, useSessionHistory } from './SessionHistoryContext';
import { ResourceAttachmentProvider, useResourceAttachment } from './ResourceAttachmentContext';

interface SessionManagementContextValue {
  session: ReturnType<typeof useSessionContext>;
  history: ReturnType<typeof useSessionHistory>;
  attachment: ReturnType<typeof useResourceAttachment>;
}

const SessionManagementContext = createContext<SessionManagementContextValue | undefined>(
  undefined
);

export function SessionManagementProvider({ children }: { children: React.ReactNode }) {
  return (
    <SessionContextProvider>
      <SessionHistoryProvider>
        <ResourceAttachmentProvider>
          <SessionManagementInner>{children}</SessionManagementInner>
        </ResourceAttachmentProvider>
      </SessionHistoryProvider>
    </SessionContextProvider>
  );
}

function SessionManagementInner({ children }: { children: React.ReactNode }) {
  const session = useSessionContext();
  const history = useSessionHistory();
  const attachment = useResourceAttachment();

  const value = useMemo<SessionManagementContextValue>(
    () => ({
      session,
      history,
      attachment,
    }),
    [session, history, attachment]
  );

  return (
    <SessionManagementContext.Provider value={value}>
      {children}
    </SessionManagementContext.Provider>
  );
}

export function useSessionManagement() {
  const context = useContext(SessionManagementContext);
  if (!context) {
    throw new Error('useSessionManagement must be used within SessionManagementProvider');
  }
  return context;
}

// Backward compatibility
export function useSessionContext() {
  return useSessionManagement().session;
}

export function useSessionHistory() {
  return useSessionManagement().history;
}

export function useResourceAttachment() {
  return useSessionManagement().attachment;
}
```

---

## 7. Test Code 추가 및 수정 가이드

### 7.1 Context 통합 테스트

#### 파일: `src/context/__tests__/CoreContext.test.tsx` (신규)

```typescript
import { renderHook, waitFor } from '@testing-library/react';
import { CoreProvider, useCoreContext } from '../CoreContext';

describe('CoreContext', () => {
  it('should provide all core contexts', () => {
    const { result } = renderHook(() => useCoreContext(), {
      wrapper: CoreProvider,
    });

    expect(result.current.settings).toBeDefined();
    expect(result.current.mcpRegistry).toBeDefined();
    expect(result.current.mcpServer).toBeDefined();
    expect(result.current.systemPrompt).toBeDefined();
  });

  it('should throw error when used outside provider', () => {
    expect(() => {
      renderHook(() => useCoreContext());
    }).toThrow('useCoreContext must be used within CoreProvider');
  });
});
```

### 7.2 Throttle Hook 테스트

#### 파일: `src/hooks/__tests__/use-throttle.test.ts` (신규)

```typescript
import { renderHook, act } from '@testing-library/react';
import { useThrottle } from '../use-throttle';

describe('useThrottle', () => {
  jest.useFakeTimers();

  it('should throttle function calls', () => {
    const callback = jest.fn();
    const { result } = renderHook(() => useThrottle(callback, 100));

    act(() => {
      result.current();
      result.current();
      result.current();
    });

    expect(callback).toHaveBeenCalledTimes(1);

    act(() => {
      jest.advanceTimersByTime(100);
    });

    act(() => {
      result.current();
    });

    expect(callback).toHaveBeenCalledTimes(2);
  });
});
```

### 7.3 AssistantContext 리렌더링 테스트

#### 파일: `src/context/__tests__/AssistantContext.performance.test.tsx` (신규)

```typescript
import { renderHook } from '@testing-library/react';
import {
  AssistantContextProvider,
  useAssistantContext,
} from '../AssistantContext';

describe('AssistantContext Performance', () => {
  it('should not trigger toast on initial load', async () => {
    const toastSpy = jest.spyOn(require('sonner'), 'toast');

    renderHook(() => useAssistantContext(), {
      wrapper: AssistantContextProvider,
    });

    // Initial load should not trigger toast
    expect(toastSpy).not.toHaveBeenCalled();
  });

  it('should debounce MCP server connections', async () => {
    const connectSpy = jest.fn();
    jest.mock('@/hooks/use-mcp-server', () => ({
      useMCPServer: () => ({
        connectServersFromAssistant: connectSpy,
        availableTools: [],
      }),
    }));

    const { result, rerender } = renderHook(() => useAssistantContext(), {
      wrapper: AssistantContextProvider,
    });

    // Multiple rapid changes should only trigger one connection
    act(() => {
      // Simulate multiple assistant changes
    });

    // Should only connect once after debounce period
    await waitFor(() => {
      expect(connectSpy).toHaveBeenCalledTimes(1);
    });
  });
});
```

---

## 8. 추가 분석 과제

### 8.1 Virtual Scrolling 검토

**목적:** 메시지가 100개 이상일 때 스크롤 성능 개선

**검토 항목:**

- `@tanstack/react-virtual` 라이브러리 도입 검토
- 메시지 높이 동적 계산 방식
- 이미지/첨부파일이 포함된 메시지 처리

**예상 파일:**

- `src/features/chat/components/ChatMessages.tsx`

**분석 방법:**

```bash
# 성능 프로파일링
pnpm tauri dev
# Chrome DevTools → Performance → Record 후 스크롤 테스트
```

---

### 8.2 Bundle Size 분석

**목적:** 초기 로딩 성능 개선

**분석 도구:**

```bash
pnpm add -D rollup-plugin-visualizer
```

**vite.config.ts 수정:**

```typescript
import { visualizer } from 'rollup-plugin-visualizer';

export default defineConfig({
  plugins: [
    // ... existing plugins
    visualizer({
      open: true,
      gzipSize: true,
      brotliSize: true,
    }),
  ],
});
```

**검토 항목:**

- 큰 번들 크기를 차지하는 라이브러리 식별
- Tree-shaking이 제대로 동작하는지 확인
- Lazy loading 추가 적용 가능성

---

### 8.3 React DevTools Profiler 분석

**목적:** 실제 리렌더링 패턴 파악

**분석 단계:**

1. 개발 환경 실행: `pnpm tauri dev`
2. React DevTools Profiler 활성화
3. 다음 시나리오 기록:
   - Assistant 전환
   - 세션 생성 및 전환
   - 메시지 입력 및 전송
   - 설정 변경
4. Flame Graph에서 렌더링 시간 분석
5. 불필요한 리렌더링 식별

**문서화:**

- 스크린샷 캡처
- 병목 지점 식별
- 개선 전후 비교 데이터

---

## 9. 작업 단계 및 순서

### Phase 1: 즉시 적용 가능한 최적화 (1-2일)

**우선순위: High, 난이도: Low**

1. ✅ **ChatMessages 스크롤 Throttle** (1시간)
   - 파일: `ChatMessages.tsx`
   - lodash-es 의존성 추가
   - 즉각적인 UX 개선 효과

2. ✅ **SessionList 검색 Debounce** (30분)
   - 파일: `SessionList.tsx`
   - `useDeferredValue` 또는 lodash debounce 적용
   - 타이핑 지연 해소

3. ✅ **AssistantContext Toast 개선** (30분)
   - 파일: `AssistantContext.tsx`
   - prevRef 패턴 적용
   - 사용자 불편 해소

### Phase 2: Context 최적화 (2-3일)

**우선순위: High, 난이도: Medium**

4. ✅ **AssistantContext 에러 처리 통합** (1시간)
   - useEffect → useMemo 변경
   - 불필요한 리렌더링 제거

5. ✅ **AssistantContext MCP Debounce** (1-2시간)
   - 500ms debounce 적용
   - 네트워크 요청 최적화

6. ✅ **SessionContext flatMap 최적화** (2시간)
   - useMemo 체인 개선
   - 메모리 사용량 감소

### Phase 3: Context Provider 통합 (3-4일)

**우선순위: Medium, 난이도: High**

7. ✅ **CoreContext 생성** (4시간)
   - Settings, MCP, SystemPrompt 통합
   - 신규 파일 생성 및 테스트

8. ✅ **SessionManagementContext 생성** (4시간)
   - Session, History, Attachment 통합
   - Backward compatibility 보장

9. ✅ **App.tsx 리팩토링** (2시간)
   - Provider 구조 단순화
   - 전체 통합 테스트

### Phase 4: 검증 및 문서화 (1-2일)

10. ✅ **성능 측정** (2시간)
    - React DevTools Profiler
    - Chrome Performance Tab
    - 개선 전후 비교

11. ✅ **테스트 코드 작성** (4시간)
    - Unit tests for hooks
    - Integration tests for contexts
    - Performance regression tests

12. ✅ **문서 업데이트** (1시간)
    - 변경 사항 README 업데이트
    - Migration guide 작성

---

## 10. Rollback Plan

각 Phase마다 Git branch 생성으로 롤백 가능성 확보:

```bash
# Phase 1
git checkout -b perf/phase1-event-optimization

# Phase 2
git checkout -b perf/phase2-context-optimization

# Phase 3
git checkout -b perf/phase3-provider-integration
```

**Rollback 기준:**

- 빌드 실패
- 기존 기능 동작 불가
- 성능 지표 악화
- 테스트 실패율 10% 이상 증가

---

## 11. Clarification Q-List

### Q1: Context Provider 통합 범위

**질문:** AssistantContextProvider와 BuiltInToolProvider도 통합해야 하는가?

**고려사항:**

- 현재 AssistantContext는 BuiltInTool을 사용
- 순환 의존성 가능성
- 독립성 유지 vs 통합의 trade-off

**제안:**

- Phase 3에서 성능 측정 후 결정
- 우선 CoreContext와 SessionManagementContext만 통합
- 추가 통합은 성능 이득이 확인된 후 진행

---

### Q2: Virtual Scrolling 도입 시점

**질문:** 메시지 목록에 Virtual Scrolling을 지금 도입할 것인가?

**고려사항:**

- 구현 복잡도 증가
- 기존 스크롤 동작 변경
- 이미지/첨부파일 높이 동적 계산 필요

**제안:**

- Phase 1에서 Throttle 적용 후 성능 재측정
- 여전히 성능 이슈가 있다면 Phase 4에서 도입
- 메시지 100개 이상 시나리오로 테스트

---

### Q3: lodash-es vs 자체 구현

**질문:** Throttle/Debounce를 lodash-es로 할지, 자체 hook으로 구현할지?

**Trade-off:**

- **lodash-es 장점:** 검증된 라이브러리, 다양한 옵션
- **lodash-es 단점:** 번들 크기 증가 (~24KB)
- **자체 구현 장점:** 번들 크기 최소화, 커스터마이징 용이
- **자체 구현 단점:** 버그 가능성, 유지보수 부담

**제안:**

- Phase 1에서는 lodash-es 사용 (빠른 검증)
- Phase 4에서 번들 분석 후, 필요시 자체 hook으로 교체
- Tree-shaking이 제대로 동작하는지 확인

---

### Q4: Backward Compatibility 유지 범위

**질문:** Context 통합 시 기존 hook 이름을 모두 유지해야 하는가?

**현황:**

- 현재 `useSettings()`, `useMCPServer()` 등 개별 hook 사용
- 통합 후 `useCoreContext().settings` 형태로 변경 가능

**제안:**

- 기존 hook 이름 유지 (re-export)
- 점진적 마이그레이션 지원
- Deprecation warning 추가
- 2-3개 버전 후 제거

```typescript
/**
 * @deprecated Use useCoreContext().settings instead
 * This hook will be removed in v2.0.0
 */
export function useSettings() {
  console.warn('useSettings is deprecated, use useCoreContext().settings');
  return useCoreContext().settings;
}
```

---

## 12. 참고 자료

### 12.1 관련 문서

- [React 18 Performance Optimization](https://react.dev/learn/render-and-commit)
- [React Context Performance](https://github.com/facebook/react/issues/15156)
- [Tauri Performance Best Practices](https://tauri.app/v1/guides/debugging/performance/)

### 12.2 관련 라이브러리

- [lodash-es](https://www.npmjs.com/package/lodash-es)
- [@tanstack/react-virtual](https://tanstack.com/virtual/latest)
- [use-debounce](https://www.npmjs.com/package/use-debounce)

### 12.3 성능 측정 도구

- React DevTools Profiler
- Chrome Performance Tab
- Lighthouse
- Bundle Analyzer

---

## 13. 성공 지표

### 13.1 정량적 지표

| 항목                       | 현재 (추정) | 목표     | 측정 완료 |
| -------------------------- | ----------- | -------- | --------- |
| Context Provider 수        | 11개        | 4-5개    | [ ]       |
| AssistantContext useEffect | 8개         | 5개 이하 | [ ]       |
| 스크롤 FPS                 | ~30fps      | 60fps    | [ ]       |
| 검색 응답 시간             | ~300ms      | <50ms    | [ ]       |
| 번들 크기                  | TBD         | -10%     | [ ]       |
| 초기 로딩                  | ~2s         | <1.5s    | [ ]       |

### 13.2 정성적 지표

- [ ] 사용자가 느끼는 UI 반응성 개선
- [ ] 스크롤 시 버벅임 없음
- [ ] 타이핑 지연 없음
- [ ] Assistant 전환 즉각 반응
- [ ] 메모리 누수 없음

---

**Document Version:** 1.0  
**Last Updated:** 2025-11-01  
**Review Required:** After Phase 2 completion


---

# refactoring_20251010_0900.md

# Refactoring Plan: AI Service Tool Use Forcing

## 1. 작업의 목적 (Purpose of the Task)

- **Agent Mode 구현**: AI가 응답 시 반드시 도구를 사용하도록 강제하는 "에이전트 모드"의 기반을 마련합니다.
- **AI Service 기능 확장**: `streamChat` 메소드에 `forceToolUse` 옵션을 추가하여, 각 AI 제공업체(OpenAI, Anthropic, Gemini)의 API에 맞게 도구 사용을 강제하는 기능을 구현합니다.
- **예측 가능한 에이전트 행동**: AI가 특정 작업에 대해 항상 도구를 사용하도록 하여, 보다 예측 가능하고 안정적인 에이전트 워크플로우를 구축합니다.

## 2. 현재의 상태 / 문제점 (Current State / Problems)

- 현재 AI 서비스 계층(`base-service.ts` 및 그 구현체)에는 AI 모델이 도구를 사용하도록 강제하는 기능이 없습니다.
- 모델은 자체적으로 판단하여 도구 사용 여부를 결정하므로(`auto` 모드), 특정 시나리오에서 도구 사용을 보장할 수 없습니다.
- 이로 인해, 도구 사용이 필수적인 에이전트의 안정적인 동작을 구현하기 어렵습니다.

## 3. 관련 코드의 구조 및 동작 방식 Summary (Bird's-eye View)

- **`IAIService` (`src/lib/ai-service/types.ts`)**: 모든 AI 서비스가 구현해야 하는 공통 인터페이스입니다.
- **`BaseAIService` (`src/lib/ai-service/base-service.ts`)**: 공통 로직을 제공하는 추상 클래스입니다. `streamChat` 메소드가 스트리밍 채팅 요청의 진입점 역할을 합니다.
- **Provider-specific Services (`src/lib/ai-service/*.ts`)**: `OpenAIService`, `AnthropicService`, `GeminiService` 등 각 제공업체별 구체적인 구현체입니다. 각 서비스는 `streamChat` 메소드 내에서 제공업체별 SDK를 호출하여 API와 통신합니다.
- **`tool_use_summary.md`**: 각 AI 제공업체별로 도구 사용을 강제하는 구체적인 API 파라미터와 동작 방식이 기술적으로 분석되어 있습니다.
  - **OpenAI**: `tool_choice: "required"`를 사용하여 하나 이상의 도구 사용을 강제합니다.
  - **Anthropic**: `tool_choice: "any"`를 사용하여 제공된 도구 중 하나를 사용하도록 강제합니다.
  - **Gemini**: `function_calling_config.mode: "ANY"`를 설정하여 도구 호출을 강제합니다.

## 4. 변경 이후의 상태 / 해결 판정 기준 (State After Change / Resolution Criteria)

- `BaseAIService`의 `streamChat` 메소드와 그 구현체들은 `forceToolUse: boolean` 옵션을 받게 됩니다.
- `forceToolUse: true`로 호출 시, 각 서비스는 AI 제공업체의 API 명세에 맞게 도구 사용을 강제하는 파라미터를 설정하여 요청을 보냅니다.
- **해결 판정 기준**: `streamChat`을 `forceToolUse: true`와 함께 호출했을 때, AI의 응답이 일반 텍스트가 아닌 반드시 `tool_calls`를 포함하는지 여부로 판정합니다. 이는 단위 테스트 및 통합 테스트를 통해 검증할 수 있습니다.

## 5. 수정이 필요한 코드 및 수정 부분의 코드 스니핏 (Code to be Modified & Snippets)

### `src/lib/ai-service/base-service.ts`

`streamChat` 메소드의 시그니처에 `forceToolUse` 옵션을 추가합니다.

```typescript
  abstract streamChat(
    messages: Message[],
    options?: {
      modelName?: string;
      systemPrompt?: string;
      availableTools?: MCPTool[];
      config?: AIServiceConfig;
      forceToolUse?: boolean; // <--- 추가
    },
  ): AsyncGenerator<string, void, void>;
```

### `src/lib/ai-service/openai.ts`

`streamChat` 내부에서 `tool_choice`를 동적으로 설정합니다.

```typescript
// ... in streamChat method
const completion = await this.withRetry(() =>
  this.openai.chat.completions.create(
    {
      model: modelName,
      messages: openaiMessages,
      max_completion_tokens: config.maxTokens,
      stream: true,
      tools: tools as OpenAIChatCompletionTool[],
      // vvvvvv 수정 vvvvvv
      tool_choice: !options.availableTools?.length
        ? undefined
        : options.forceToolUse
          ? 'required'
          : 'auto',
      // ^^^^^^ 수정 ^^^^^^
    },
    { signal: this.getAbortSignal() },
  ),
);
// ...
```

### `src/lib/ai-service/anthropic.ts`

`streamChat` 내부에서 `tool_choice`를 동적으로 추가합니다.

```typescript
// ... in streamChat method
const stream = this.anthropic.messages.stream(
  {
    model:
      options.modelName || config.defaultModel || 'claude-3-sonnet-20240229',
    max_tokens: config.maxTokens!,
    messages: anthropicMessages,
    ...(shouldEnableThinking && {
      thinking: {
        budget_tokens: 1024,
        type: 'enabled',
      },
    }),
    system: options.systemPrompt,
    tools: tools as AnthropicTool[],
    // vvvvvv 추가 vvvvvv
    ...(options.forceToolUse && { tool_choice: 'any' }),
    // ^^^^^^ 추가 ^^^^^^
  },
  { signal: this.getAbortSignal() },
);
// ...
```

### `src/lib/ai-service/gemini.ts`

`GeminiServiceConfig` 인터페이스를 수정하고, `streamChat`에서 `functionCallingConfig`를 설정합니다.

```typescript
// GeminiServiceConfig 인터페이스 수정
interface GeminiServiceConfig {
  responseMimeType: string;
  tools?: Array<{ functionDeclarations: FunctionDeclaration[] }>;
  systemInstruction?: Array<{ text: string }>;
  maxOutputTokens?: number;
  temperature?: number;
  functionCallingConfig?: { mode: 'AUTO' | 'ANY' | 'NONE' }; // <--- 추가
}

// ... in streamChat method
if (geminiTools) {
  geminiConfig.tools = geminiTools;
  // vvvvvv 추가 vvvvvv
  if (options.forceToolUse) {
    geminiConfig.functionCallingConfig = { mode: 'ANY' };
  }
  // ^^^^^^ 추가 ^^^^^^
}
// ...
```

## 6. 재사용 가능한 연관 코드 (Reusable Related Code)

- **`src/lib/ai-service/tool-converters.ts`**: `convertMCPToolsToProviderTools` 함수는 MCP 표준 도구를 각 AI 제공업체 형식으로 변환하는 데 계속 사용됩니다.
- **`src/lib/ai-service/utils.ts`**: `formatToolCall`과 같은 유틸리티 함수는 응답 포맷팅에 재사용됩니다.

## 7. Test Code 추가 및 수정 필요 부분에 대한 가이드 (Testing Guide)

- 각 서비스(`openai.ts`, `anthropic.ts`, `gemini.ts`)에 대한 단위 테스트를 추가해야 합니다.
- 각 테스트는 제공업체의 API 클라이언트를 모킹(mocking)하고, `streamChat`이 `forceToolUse: true`로 호출될 때 API 요청에 올바른 파라미터가 포함되었는지 확인해야 합니다.
  - **`OpenAIService`**: `tool_choice`가 `'required'`인지 검증합니다.
  - **`AnthropicService`**: `tool_choice`가 `'any'`인지 검증합니다.
  - **`GeminiService`**: `functionCallingConfig.mode`가 `'ANY'`인지 검증합니다.
- `useAIService.ts` 또는 상위 컴포넌트에서 `forceToolUse` 옵션이 서비스 계층까지 올바르게 전달되는지 확인하는 통합 테스트를 고려할 수 있습니다.


---

# refactoring_20251012_1445.md

# OpenAI Tool Call Pairing Validation Fix

## 작업의 목적

OpenAI provider에서 발생하는 "messages with role 'tool' must be a response to a preceeding message with 'tool_calls'" 400 에러를 해결하기 위해, OpenAI family provider 전용 tool-call/tool-response 페어링 검증 로직을 `MessageNormalizer`에 추가한다.

**핵심 목표:**

- OpenAI provider의 tool message 페어링 요구사항 충족
- 고아(orphaned) tool message 자동 제거
- 불완전한 tool_calls 제거
- 기존 정상 동작 중인 provider(Anthropic, Gemini)는 절대 건드리지 않음

## 현재의 상태 / 문제점

### 문제 상황

OpenAI streaming 요청 시 다음 에러 발생:

```text
400 Invalid parameter: messages with role 'tool' must be a response to a preceeding message with 'tool_calls'
```

### 근본 원인

**OpenAI provider path의 검증 부재:**

- `message-normalizer.ts`의 `sanitizeMessagesForProvider()`에서 OpenAI family는 Anthropic처럼 tool-call chain 검증을 수행하지 않음
- `sanitizeForOpenAIFamily()`는 단순히 thinking 필드 제거와 `tool_use` → `tool_calls` 변환만 수행
- Assistant의 `tool_calls`와 tool response의 `tool_call_id` 페어링 검증 없음
- 고아(orphaned) tool message가 API로 전송되면 OpenAI가 400 반환

### 현재 코드 흐름 (Birdeye View)

```text
User Request
    ↓
BaseService.prepareStreamChat()
    ↓
MessageNormalizer.sanitizeMessagesForProvider(messages, provider)
    ↓
    ├─ provider === 'anthropic' → fixAnthropicToolCallChain()
    │                              ✅ assistant tool_calls ↔ tool responses 페어링 검증
    │
    ├─ provider in OpenAI-family → (검증 없음!)
    │                              → sanitizeForOpenAIFamily() per message
    │                              ⚠️ 페어링 검증 없음 → 400 에러 발생
    │
    └─ provider === 'gemini' → (검증 없지만 tool→user 변환으로 회피)
                               ✅ Gemini SDK 권고사항 준수
    ↓
Provider-specific conversion (convertToOpenAIMessages, etc.)
    ↓
Provider API 호출
```

### Provider별 현재 상태

1. **✅ Anthropic**: 정상 동작
   - `fixAnthropicToolCallChain()`으로 견고한 페어링 검증
   - 불완전한 tool call chain 자동 제거

2. **✅ Gemini**: 정상 동작
   - `validateGeminiMessageStack()`에서 tool → user 변환
   - Gemini SDK 공식 권고사항 준수
   - 페어링 에러 발생 안 함

3. **❌ OpenAI**: 문제 발생
   - 페어링 검증 없음
   - 고아 tool message 전송 시 400 에러

4. **❓ Groq, Cerebras, Fireworks**: 미확인
   - OpenAI-compatible API 사용
   - 동일한 페어링 요구사항 예상

### 주요 코드 위치

- `src/lib/ai-service/message-normalizer.ts`:
  - `sanitizeMessagesForProvider()`: Provider 분기 지점
  - `fixAnthropicToolCallChain()`: Anthropic용 검증 (참조 구현)
  - `sanitizeForOpenAIFamily()`: OpenAI-family용 (검증 부재)
- `src/lib/ai-service/openai.ts`:
  - `convertToOpenAIMessages()`: 내부 Message → OpenAI 메시지 변환
  - `streamChat()`: Streaming 진입점
- `src/models/chat.ts`:
  - `Message` 타입 정의
  - `ToolCall` 타입 정의 (`id`, `type`, `function` 포함)

## 변경 이후의 상태 / 해결 판정 기준

### 목표 상태

1. **OpenAI provider 안전성:**
   - 모든 `tool` 메시지가 대응되는 assistant `tool_calls` 보유
   - 고아 tool message 자동 제거
   - 부분 매칭 시 유효한 페어만 보존

2. **기존 Provider 무영향:**
   - Anthropic: 기존 검증 로직 그대로 유지
   - Gemini: SDK 권고사항 준수 로직 그대로 유지
   - 다른 provider: 기존 동작 유지

3. **중앙화된 검증:**
   - `MessageNormalizer`에서 OpenAI family 검증 책임
   - Anthropic과 동일한 수준의 견고성

### 성공 판정 기준

#### 기능 검증

- [ ] OpenAI streaming 요청 시 400 에러 미발생
- [ ] 고아 tool message 자동 제거 동작
- [ ] Assistant 다중 tool_calls 중 부분 매칭 시 유효한 것만 보존
- [ ] Anthropic 검증 로직 영향 없음 (regression 없음)
- [ ] Gemini provider 정상 동작 (변경 없음)

#### 코드 품질

- [ ] `pnpm refactor:validate` 통과 (lint, format, build, dead-code)
- [ ] 단위 테스트 커버리지: 신규 함수 100%, edge case 포함
- [ ] ESLint 규칙 준수 (`any` 사용 없음, 명시적 타입)
- [ ] 중앙 logger 사용 (`console.*` 없음)

#### 안전성

- [ ] 기존 provider 동작 변경 없음
- [ ] 잘못된 메시지 형식에 대한 graceful degradation
- [ ] 로깅을 통한 디버깅 가능성 확보

## 수정이 필요한 코드 및 수정 부분

### 1. MessageNormalizer에 OpenAI-family 검증 추가

**File:** `src/lib/ai-service/message-normalizer.ts`

#### 새 함수 추가: `ensureToolCallPairing`

```typescript
/**
 * Ensures tool-call/tool-response pairing for OpenAI-family providers.
 * Similar to fixAnthropicToolCallChain but tailored for OpenAI API requirements.
 *
 * OpenAI API requires that every 'tool' role message must correspond to
 * a tool_call in a preceding assistant message. This function:
 * 1. Collects all tool_call ids from assistant messages
 * 2. Maps tool responses by tool_call_id
 * 3. Removes orphaned tool messages (no matching tool_call)
 * 4. Removes unmatched tool_calls from assistant messages
 * 5. Preserves message ordering and role semantics
 *
 * @param messages - Array of messages to validate
 * @returns Sanitized array with valid tool-call pairings only
 * @private
 */
private static ensureToolCallPairing(messages: Message[]): Message[] {
  const result: Message[] = [];
  const validToolCallIds = new Set<string>();
  const completedToolCallIds = new Set<string>();

  // Step 1: Collect all tool_call ids from assistant messages
  for (const msg of messages) {
    if (msg.role === 'assistant' && msg.tool_calls?.length) {
      msg.tool_calls.forEach((tc) => {
        if (tc.id) {
          validToolCallIds.add(tc.id);
        }
      });
    }
  }

  // Step 2: Identify completed tool_calls by finding matching tool responses
  for (const msg of messages) {
    if (
      msg.role === 'tool' &&
      msg.tool_call_id &&
      validToolCallIds.has(msg.tool_call_id)
    ) {
      completedToolCallIds.add(msg.tool_call_id);
    }
  }

  // Step 3: Reconstruct message list with only valid pairings
  for (const msg of messages) {
    const processedMsg = { ...msg };

    if (msg.role === 'assistant' && msg.tool_calls?.length) {
      // Keep only tool_calls that have matching tool responses
      const completedToolCalls = msg.tool_calls.filter((tc) =>
        completedToolCallIds.has(tc.id)
      );

      if (completedToolCalls.length !== msg.tool_calls.length) {
        const removedIds = msg.tool_calls
          .filter((tc) => !completedToolCallIds.has(tc.id))
          .map((tc) => tc.id);

        logger.warn(
          'Removing incomplete tool_calls from assistant message for OpenAI',
          {
            messageId: msg.id,
            removedToolIds: removedIds,
            completedCount: completedToolCalls.length,
            totalCount: msg.tool_calls.length,
          }
        );
      }

      if (completedToolCalls.length > 0) {
        processedMsg.tool_calls = completedToolCalls;
      } else {
        // No valid tool_calls, remove the field but keep message
        delete processedMsg.tool_calls;
      }
    } else if (msg.role === 'tool') {
      // Only include tool messages that have matching tool_calls
      if (!msg.tool_call_id || !completedToolCallIds.has(msg.tool_call_id)) {
        logger.debug('Skipping orphaned tool message for OpenAI', {
          messageId: msg.id,
          toolCallId: msg.tool_call_id,
        });
        continue;
      }
    }

    result.push(processedMsg);
  }

  // Remove any tool messages from the beginning of conversation
  while (result.length > 0 && result[0].role === 'tool') {
    logger.warn(
      'Removing tool message from beginning of conversation for OpenAI',
      {
        messageId: result[0].id,
      }
    );
    result.shift();
  }

  logger.info('OpenAI tool call pairing validation completed', {
    originalMessages: messages.length,
    processedMessages: result.length,
    validToolCalls: validToolCallIds.size,
    completedToolCalls: completedToolCallIds.size,
  });

  return result;
}
```

#### `sanitizeMessagesForProvider` 수정

```typescript
static sanitizeMessagesForProvider(
  messages: Message[],
  targetProvider: AIServiceProvider,
): Message[] {
  let processedMessages = messages;

  // Anthropic: 기존 검증 유지 (변경 없음)
  if (targetProvider === AIServiceProvider.Anthropic) {
    processedMessages = this.fixAnthropicToolCallChain(messages);
  }

  // ✅ NEW: OpenAI-family providers에 페어링 검증 추가
  if (
    [
      AIServiceProvider.OpenAI,
      AIServiceProvider.Groq,
      AIServiceProvider.Cerebras,
      AIServiceProvider.Fireworks,
    ].includes(targetProvider)
  ) {
    processedMessages = this.ensureToolCallPairing(processedMessages);
  }

  // Gemini: 기존 동작 유지 (변경 없음)
  // 다른 provider: 기존 동작 유지

  // Second pass: sanitize individual messages
  return processedMessages
    .map((msg) => this.sanitizeSingleMessage(msg, targetProvider))
    .filter((msg) => msg !== null) as Message[];
}
```

### 2. 변경하지 않는 파일들

**절대 수정하지 않음:**

- ❌ `src/lib/ai-service/gemini.ts`: Gemini SDK 권고사항 준수 중, 정상 동작
- ❌ `src/lib/ai-service/anthropic.ts`: 이미 완벽한 검증 로직 보유
- ❌ `src/lib/ai-service/openai.ts`: 변환 로직은 그대로 (검증은 MessageNormalizer가 담당)

## 재사용 가능한 연관 코드

### 참조 구현: Anthropic Tool Chain Fixer

**File:** `src/lib/ai-service/message-normalizer.ts`

기존 `fixAnthropicToolCallChain()` 함수가 동일한 패턴을 사용:

```typescript
private static fixAnthropicToolCallChain(messages: Message[]): Message[] {
  const result: Message[] = [];
  const pendingToolUseIds = new Set<string>();
  const completedToolUseIds = new Set<string>();

  // Step 1: Collect tool_calls
  for (const msg of messages) {
    if (msg.role === 'assistant' && msg.tool_calls) {
      msg.tool_calls.forEach((tc) => pendingToolUseIds.add(tc.id));
    }
  }

  // Step 2: Identify completed tool_uses
  for (const msg of messages) {
    if (msg.role === 'tool' && msg.tool_call_id && pendingToolUseIds.has(msg.tool_call_id)) {
      completedToolUseIds.add(msg.tool_call_id);
    }
  }

  // Step 3: Reconstruct with valid pairs only
  // ... (filter logic)

  return result;
}
```

**활용 방법:**

- OpenAI 검증 로직의 구조적 참조
- 3-phase 접근법 (수집 → 매칭 → 필터링) 재사용
- Logging 패턴 참고

### 타입 정의

**File:** `src/models/chat.ts`

```typescript
export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  tool_calls?: ToolCall[];
  tool_call_id?: string;
  tool_use?: ToolCall; // Anthropic legacy field
  // ... other fields
}

export interface ToolCall {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string;
  };
}
```

### Logger 사용 패턴

```typescript
import { getLogger } from '@/lib/logger';

const logger = getLogger('MessageNormalizer');

// Debug level: 정상 동작 추적
logger.debug('Skipping orphaned tool message', { messageId: 'abc' });

// Warn level: 예상치 못한 상황 (치명적이지 않음)
logger.warn('Removing incomplete tool_calls', {
  removedToolIds: ['call_1'],
});

// Info level: 주요 동작 완료
logger.info('OpenAI tool call pairing validation completed', {
  originalMessages: 10,
  processedMessages: 8,
});
```

## Test Code 추가 가이드

### 단위 테스트 파일 생성

**File:** `src/lib/ai-service/__tests__/message-normalizer.openai.test.ts`

```typescript
import { describe, it, expect } from 'vitest';
import { MessageNormalizer } from '../message-normalizer';
import { AIServiceProvider } from '../types';
import type { Message } from '@/models/chat';

describe('MessageNormalizer - OpenAI Tool Call Pairing', () => {
  it('should preserve valid tool-call/tool-response pairs', () => {
    const messages: Message[] = [
      {
        id: '1',
        role: 'assistant',
        content: '',
        tool_calls: [
          {
            id: 'call_1',
            type: 'function',
            function: { name: 'test', arguments: '{}' },
          },
        ],
      },
      {
        id: '2',
        role: 'tool',
        content: 'result',
        tool_call_id: 'call_1',
      },
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.OpenAI,
    );

    expect(result).toHaveLength(2);
    expect(result[0].tool_calls).toHaveLength(1);
    expect(result[1].role).toBe('tool');
  });

  it('should remove orphaned tool messages', () => {
    const messages: Message[] = [
      {
        id: '1',
        role: 'assistant',
        content: 'response',
      },
      {
        id: '2',
        role: 'tool',
        content: 'result',
        tool_call_id: 'call_999', // No matching tool_call
      },
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.OpenAI,
    );

    expect(result).toHaveLength(1);
    expect(result[0].role).toBe('assistant');
  });

  it('should handle partial tool_calls matching', () => {
    const messages: Message[] = [
      {
        id: '1',
        role: 'assistant',
        content: '',
        tool_calls: [
          {
            id: 'call_1',
            type: 'function',
            function: { name: 'test1', arguments: '{}' },
          },
          {
            id: 'call_2',
            type: 'function',
            function: { name: 'test2', arguments: '{}' },
          },
        ],
      },
      {
        id: '2',
        role: 'tool',
        content: 'result1',
        tool_call_id: 'call_1',
      },
      // call_2 has no tool response
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.OpenAI,
    );

    expect(result[0].tool_calls).toHaveLength(1);
    expect(result[0].tool_calls![0].id).toBe('call_1');
    expect(result).toHaveLength(2);
  });

  it('should remove all tool_calls when none match', () => {
    const messages: Message[] = [
      {
        id: '1',
        role: 'assistant',
        content: 'I will call functions',
        tool_calls: [
          {
            id: 'call_1',
            type: 'function',
            function: { name: 'test', arguments: '{}' },
          },
        ],
      },
      // No tool response
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.OpenAI,
    );

    expect(result).toHaveLength(1);
    expect(result[0].tool_calls).toBeUndefined();
    expect(result[0].content).toBe('I will call functions'); // Content preserved
  });

  it('should preserve non-tool messages', () => {
    const messages: Message[] = [
      { id: '1', role: 'user', content: 'Hello' },
      { id: '2', role: 'assistant', content: 'Hi' },
      { id: '3', role: 'system', content: 'You are helpful' },
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.OpenAI,
    );

    expect(result).toEqual(messages);
  });

  it('should remove tool messages from conversation start', () => {
    const messages: Message[] = [
      {
        id: '1',
        role: 'tool',
        content: 'orphan',
        tool_call_id: 'call_orphan',
      },
      { id: '2', role: 'user', content: 'Hello' },
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.OpenAI,
    );

    expect(result[0].role).toBe('user');
    expect(result).toHaveLength(1);
  });

  it('should not affect Anthropic provider behavior', () => {
    const messages: Message[] = [
      {
        id: '1',
        role: 'assistant',
        content: '',
        tool_calls: [
          {
            id: 'call_1',
            type: 'function',
            function: { name: 'test', arguments: '{}' },
          },
        ],
      },
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.Anthropic,
    );

    // Anthropic의 fixAnthropicToolCallChain 로직이 적용되어야 함
    expect(result).toBeDefined();
  });

  it('should apply to Groq provider', () => {
    const messages: Message[] = [
      {
        id: '1',
        role: 'tool',
        content: 'orphan',
        tool_call_id: 'call_999',
      },
    ];

    const result = MessageNormalizer.sanitizeMessagesForProvider(
      messages,
      AIServiceProvider.Groq,
    );

    expect(result).toHaveLength(0); // Orphan removed
  });
});
```

### 테스트 실행 및 검증

```bash
# 단위 테스트
pnpm test message-normalizer

# 전체 테스트
pnpm test

# 커버리지
pnpm test:coverage

# Validation pipeline
pnpm refactor:validate
```

## 추가 분석 과제

### 1. Ollama Provider 검증

**상황:** Ollama가 OpenAI-compatible API를 사용하는지 확인 필요.

**조사 항목:**

- Ollama의 tool/function calling 지원 여부
- 지원 시 OpenAI와 동일한 페어링 요구사항인지 확인

**조사 방법:**

- `src/lib/ai-service/ollama.ts` 코드 검토
- Ollama 공식 문서 확인
- 필요 시 `ensureToolCallPairing` 적용 provider 목록에 추가

### 2. Groq/Cerebras/Fireworks 실제 동작 검증

**상황:** OpenAI-compatible이라 가정하고 검증 로직 적용 예정이나, 실제 API 동작 미확인.

**조사 방법:**

- 각 provider로 tool calling 테스트
- 페어링 에러 발생 여부 확인
- 필요 시 provider별 예외 처리 추가

### 3. Edge Case: Out-of-Order Tool Messages

**상황:** Tool message가 assistant tool_call보다 먼저 오는 경우 처리 방식.

**조사 항목:**

- OpenAI API가 순서에 민감한지 확인
- 현재 구현이 순서 무관하게 id 매칭만으로 처리하는 것이 안전한지 검증

## 작업 순서 (High-Level)

1. **코드 구현** (30분)
   - `ensureToolCallPairing` 함수 추가
   - `sanitizeMessagesForProvider`에 OpenAI family 분기 추가

2. **단위 테스트 작성** (45분)
   - 7개 핵심 테스트 케이스 구현
   - Edge case 커버리지 확보

3. **Validation 실행** (10분)
   - `pnpm refactor:validate` 실행
   - Lint/format/build 에러 수정

4. **기존 Provider Regression 테스트** (15분)
   - Anthropic, Gemini 동작 변경 없음 확인
   - 기존 테스트 suite 실행

5. **문서화 및 커밋** (15분)
   - CHANGELOG 업데이트
   - 커밋 메시지 작성 (conventional commits)

## Rollback Plan

변경 후 문제 발생 시:

1. **즉시 대응:**
   - OpenAI family 분기만 제거하면 원상복구
   - 다른 provider는 영향 없음

2. **Git Revert:**
   - 단일 커밋으로 관리하여 쉬운 revert 가능

3. **Monitoring:**
   - Logger 출력으로 sanitization 동작 추적
   - OpenAI provider 에러율 모니터링

---

**예상 소요 시간:** 1.5 - 2 시간  
**우선순위:** High (OpenAI 400 에러는 사용자 경험에 직접적 영향)  
**리스크:** Very Low (OpenAI family만 수정, 다른 provider 무영향)  
**영향 범위:** OpenAI, Groq, Cerebras, Fireworks (4개 provider만)


---

# refactoring_20251109_1430.md

# Refactoring Plan: Web MCP Server Metadata Decentralization

**Date:** 2025-11-09 14:30  
**Target:** WebMCPServiceRegistry metadata management  
**Status:** Planning

---

## 작업의 목적

Web MCP 서버의 메타데이터(displayName, description, category)를 각 서버 모듈이 직접 소유하도록 변경하여 유지보수성, 확장성, 타입 안전성을 개선한다.

**핵심 목표:**

- 서버 추가/수정 시 한 곳만 변경하면 되도록 개선
- 서버와 메타데이터 간의 물리적 결합도 증가
- Registry의 책임을 등록/관리로 제한 (메타데이터 정의 책임 제거)
- 타입 안전성 향상 및 오타/불일치 방지

---

## 현재의 상태 / 문제점

### 현재 구조

```
WebMCPServiceRegistry.tsx (117줄~165줄)
├── servers 배열 순회
├── 각 서버명에 대해 if-else 체인으로 메타데이터 하드코딩
│   ├── content_store → 'Content Store'
│   ├── workspace → 'Workspace'
│   ├── planning → 'Task Planning'
│   ├── playbook → 'Playbook'
│   ├── mcp_manager → 'MCP Server Manager'
│   ├── ui → 'UI Tools'
│   └── bootstrap → 'Bootstrap'
└── 기본값: serverName 그대로 사용
```

### 주요 문제점

1. **단일 책임 원칙(SRP) 위반**
   - Registry가 등록/관리 + 메타데이터 정의 두 가지 책임
   - 서버 모듈과 메타데이터가 물리적으로 분리됨

2. **유지보수성 저하**
   - 새 서버 추가 시: 서버 모듈 구현 + Registry if문 추가 (2곳 수정)
   - 서버명 변경 시: 서버 모듈 + Registry 조건문 (2곳 수정)
   - 메타데이터 수정 시: Registry만 수정 (서버 모듈과 무관)

3. **타입 안전성 부족**
   - 문자열 리터럴로만 서버명 매칭 (오타 가능)
   - 서버와 메타데이터 간 타입 수준 연결 없음
   - 컴파일 타임에 불일치 감지 불가

4. **확장성 제한**
   - 외부 Web MCP 서버 추가 시 Registry 수정 필수
   - 동적 서버 로딩/플러그인 아키텍처 불가능

5. **코드 중복**
   - 7개 서버에 대해 동일한 패턴의 if-else 반복
   - 메타데이터 구조가 동일함에도 각각 정의

---

## 관련 코드의 구조 및 동작 방식 Summary

### 현재 아키텍처 (Bird's Eye View)

```
┌─────────────────────────────────────────────────────────────┐
│ WebMCPServiceRegistry.tsx                                   │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ useMemo(() => {                                         │ │
│ │   servers.forEach(serverName => {                       │ │
│ │     // ❌ Registry가 메타데이터 하드코딩               │ │
│ │     if (serverName === 'planning') {                    │ │
│ │       metadata = { displayName: 'Task Planning', ... }  │ │
│ │     } else if ...                                       │ │
│ │     register(serverName, { metadata, ... })             │ │
│ │   })                                                    │ │
│ │ })                                                      │ │
│ └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                        ↓ register()
┌─────────────────────────────────────────────────────────────┐
│ BuiltInToolContext                                          │
│ - serviceEntriesRef.set(serviceId, { service })             │
│ - aliasToIdTableRef.set(alias, serviceId)                   │
└─────────────────────────────────────────────────────────────┘
                        ↓ getServiceMetadata(alias)
┌─────────────────────────────────────────────────────────────┐
│ BuiltInToolsEditor.tsx                                      │
│ - displayName으로 UI 렌더링                                 │
└─────────────────────────────────────────────────────────────┘

각 서버 모듈 (별도 디렉터리)
├── src/lib/web-mcp/modules/planning-server/
│   ├── server.ts (WebMCPServer 구현)
│   ├── tools.ts
│   └── index.ts (export default)
├── src/lib/web-mcp/modules/bootstrap-server/
├── src/lib/web-mcp/modules/workspace-server/ (content_store, workspace)
└── ... (기타 서버)

❌ 문제: 서버 모듈과 메타데이터가 물리적으로 분리
```

### 데이터 흐름

1. `WebMCPServiceRegistry` → `servers` prop으로 서버명 배열 수신
2. 각 서버명에 대해 if-else로 메타데이터 결정
3. `BuiltInService` 객체 생성 (metadata 포함)
4. `register(serviceId, service)` 호출 → Context에 저장
5. `BuiltInToolsEditor`가 `getServiceMetadata(alias)` 호출
6. UI에 `displayName` 렌더링

---

## 변경 이후의 상태 / 해결 판정 기준

### 목표 아키텍처

```
각 서버 모듈이 메타데이터 소유
├── src/lib/web-mcp/modules/planning-server/
│   ├── server.ts
│   ├── tools.ts
│   ├── metadata.ts (✅ 신규)
│   │   export const metadata: ServiceMetadata = { ... }
│   └── index.ts
│       export { metadata } from './metadata';
├── src/lib/web-mcp/modules/bootstrap-server/
│   └── (동일 구조)
└── ...

중앙 설정 파일 (Fallback)
└── src/lib/web-mcp/server-metadata-registry.ts (✅ 신규)
    - 알려지지 않은 서버의 기본 메타데이터
    - 외부 서버 오버라이드용

WebMCPServiceRegistry.tsx
└── 메타데이터 조회 로직:
    1. 서버 모듈에서 import한 metadata 우선
    2. server-metadata-registry에서 조회
    3. 기본값 생성 (serverName 그대로)
```

### 해결 판정 기준

**필수 충족 조건:**

1. ✅ 각 Web MCP 서버 모듈(`src/lib/web-mcp/modules/*/`)에 `metadata.ts` 파일 존재
2. ✅ `WebMCPServiceRegistry.tsx`에서 if-else 체인 제거
3. ✅ 서버 추가 시 Registry 수정 불필요 (모듈에만 metadata 추가)
4. ✅ 기존 UI 동작 유지 (displayName, description, category 동일)
5. ✅ 타입 안전성: `ServiceMetadata` 타입 준수

**검증 방법:**

- `BuiltInToolsEditor`에서 모든 서버 메타데이터가 올바르게 표시
- 새 서버 추가 시나리오: 모듈만 구현하고 Registry 무수정으로 동작
- TypeScript 컴파일 에러 없음
- Lint 통과

---

## 수정이 필요한 코드 및 수정 부분

### 1. 각 서버 모듈에 `metadata.ts` 추가

**파일:** `src/lib/web-mcp/modules/*/metadata.ts` (7개 서버)

#### 예시: `planning-server/metadata.ts`

```typescript
import type { ServiceMetadata } from '@/features/tools';

export const metadata: ServiceMetadata = {
  displayName: 'Task Planning',
  description: 'Goal setting, task planning',
  category: 'planning',
};
```

#### 예시: `bootstrap-server/metadata.ts`

```typescript
import type { ServiceMetadata } from '@/features/tools';

export const metadata: ServiceMetadata = {
  displayName: 'Bootstrap',
  description: 'Platform detection and environment setup',
  category: 'automation',
};
```

**적용 대상 서버:**

- `planning-server` → displayName: 'Task Planning', category: 'planning'
- `bootstrap-server` → displayName: 'Bootstrap', category: 'automation'
- `playbook-store` → displayName: 'Playbook', category: 'execution'
- `mcp-manager` → displayName: 'MCP Server Manager', category: 'automation'
- `ui-tools` → displayName: 'UI Tools', category: 'automation'
- `workspace-server` (content_store) → displayName: 'Content Store', category: 'storage'
- `workspace-server` (workspace) → displayName: 'Workspace', category: 'storage'

**주의:** `workspace-server`는 두 개의 서버(content_store, workspace)를 포함하므로 별도 처리 필요 (아래 참조)

---

### 2. 각 서버의 `index.ts`에서 metadata export

**파일:** `src/lib/web-mcp/modules/*/index.ts` (7개 서버)

#### 현재 (예: planning-server/index.ts)

```typescript
export { default } from './server.ts';
export { planningTools } from './tools.ts';
export type { PlanningServerProxy, PlanningState, Memo } from './server.ts';
```

#### 변경 후

```typescript
export { default } from './server.ts';
export { planningTools } from './tools.ts';
export { metadata } from './metadata'; // ✅ 추가
export type { PlanningServerProxy, PlanningState, Memo } from './server.ts';
```

**적용:** 모든 서버 모듈의 `index.ts`

---

### 3. Fallback 메타데이터 레지스트리 생성

**파일:** `src/lib/web-mcp/server-metadata-registry.ts` (신규)

```typescript
import type { ServiceMetadata } from '@/features/tools';

/**
 * Fallback metadata for Web MCP servers.
 * Used when server module doesn't export metadata or for external servers.
 */
export const SERVER_METADATA_REGISTRY: Record<string, ServiceMetadata> = {
  // External or dynamically loaded servers can be registered here
  // Example:
  // 'custom-external-server': {
  //   displayName: 'Custom Server',
  //   description: 'External MCP server',
  //   category: 'automation',
  // },
};

/**
 * Get default metadata for unknown servers
 */
export function getDefaultMetadata(serverName: string): ServiceMetadata {
  return {
    displayName: serverName,
    description: `Web MCP server: ${serverName}`,
    category: 'automation',
  };
}
```

---

### 4. `WebMCPServiceRegistry.tsx` 리팩토링

**파일:** `src/features/tools/WebMCPServiceRegistry.tsx`

#### 변경 전 (117~165줄)

```typescript
// Create BuiltInService instances for each server
const services: Record<string, BuiltInService> = useMemo(() => {
  if (isLoading || !initialized) {
    return {};
  }
  return servers.reduce<Record<string, BuiltInService>>((acc, s) => {
    // Determine metadata based on server name
    let metadata: {
      displayName: string;
      description: string;
      category: 'automation' | 'storage' | 'planning' | 'execution';
    } = {
      displayName: s,
      description: `Web MCP server: ${s}`,
      category: 'automation',
    };

    // Override metadata for known servers
    if (s === 'content_store') {
      metadata = {
        displayName: 'Content Store',
        description: 'File storage, search, BM25 indexing',
        category: 'storage',
      };
    } else if (s === 'workspace') {
      // ... 7개 if-else 체인
    }

    acc[s] = {
      metadata,
      // ...
    };
    return acc;
  }, {});
}, [servers, executeTool, loadServer, isLoading, initialized, proxy]);
```

#### 변경 후

```typescript
import * as bootstrapServer from '@/lib/web-mcp/modules/bootstrap-server';
import * as planningServer from '@/lib/web-mcp/modules/planning-server';
import * as playbookServer from '@/lib/web-mcp/modules/playbook-store';
import * as mcpManagerServer from '@/lib/web-mcp/modules/mcp-manager';
import * as uiToolsServer from '@/lib/web-mcp/modules/ui-tools';
// workspace-server는 content_store와 workspace 두 개의 서버를 제공
// 별도 처리 필요 (아래 SERVER_MODULE_MAP 참조)

import {
  SERVER_METADATA_REGISTRY,
  getDefaultMetadata,
} from '@/lib/web-mcp/server-metadata-registry';

// Map server names to their module exports
const SERVER_MODULE_MAP: Record<string, { metadata?: ServiceMetadata }> = {
  bootstrap: bootstrapServer,
  planning: planningServer,
  playbook: playbookServer,
  mcp_manager: mcpManagerServer,
  ui: uiToolsServer,
  // workspace-server는 두 서버를 제공하므로 수동 매핑
  // (workspace-server/index.ts에서 별도 export 필요)
  content_store: {
    metadata: {
      displayName: 'Content Store',
      description: 'File storage, search, BM25 indexing',
      category: 'storage',
    },
  },
  workspace: {
    metadata: {
      displayName: 'Workspace',
      description: 'File read/write, code execution, search',
      category: 'storage',
    },
  },
};

// Create BuiltInService instances for each server
const services: Record<string, BuiltInService> = useMemo(() => {
  if (isLoading || !initialized) {
    return {};
  }

  return servers.reduce<Record<string, BuiltInService>>((acc, serverName) => {
    // Priority: Module export > Registry > Default
    const moduleMetadata = SERVER_MODULE_MAP[serverName]?.metadata;
    const registryMetadata = SERVER_METADATA_REGISTRY[serverName];
    const metadata =
      moduleMetadata || registryMetadata || getDefaultMetadata(serverName);

    acc[serverName] = {
      metadata,
      executeTool: (tc) => executeTool(serverName, tc),
      listTools: () => serverStatesRef.current[serverName]?.tools || [],
      unloadService: async () => {},
      loadService: async () => loadServer(serverName),
      getServiceContext: async (
        options?: ServiceContextOptions,
      ): Promise<ServiceContext<unknown>> => {
        if (!proxy) {
          return { contextPrompt: '', structuredState: undefined };
        }
        return await proxy.getServiceContext(serverName, options);
      },
      switchContext: async (options?: ServiceContextOptions) => {
        if (proxy && proxy.switchContext) {
          await proxy.switchContext(
            serverName,
            (options || {}) as ServiceContextOptions,
          );
        }
      },
    };
    return acc;
  }, {});
}, [servers, executeTool, loadServer, isLoading, initialized, proxy]);
```

**변경 포인트:**

1. 모든 서버 모듈 import 추가
2. `SERVER_MODULE_MAP` 정의 (서버명 → 모듈 매핑)
3. if-else 체인 제거
4. 3단계 fallback 로직: 모듈 → 레지스트리 → 기본값

---

## 재사용 가능한 연관 코드

### 기존 타입 정의 재사용

**파일:** `src/features/tools/index.tsx` (43~48줄)

```typescript
export interface ServiceMetadata {
  displayName: string;
  description: string;
  category?: 'automation' | 'storage' | 'planning' | 'execution';
  icon?: string;
}
```

**용도:** 모든 `metadata.ts` 파일에서 import하여 타입 준수

### 서버 모듈 구조 참조

**파일:** `src/lib/web-mcp/modules/*/index.ts`

**현재 패턴:**

```typescript
export { default } from './server';
export { toolsSchema } from './tools';
export type { ... } from './server';
```

**적용:** `metadata` export 추가

### WebMCPServer 인터페이스

**파일:** `src/lib/mcp-types.ts`

```typescript
export interface WebMCPServer {
  name: string;
  version: string;
  description: string;
  tools: MCPTool[];
  callTool(name: string, args: unknown): Promise<MCPResponse<unknown>>;
  // ...
}
```

**참고:** 향후 `metadata?: ServiceMetadata` 필드 추가 고려 가능

---

## Test Code 추가 및 수정 가이드

### 단위 테스트 추가 (권장)

**파일:** `src/lib/web-mcp/modules/__tests__/metadata.test.ts` (신규)

```typescript
import { describe, it, expect } from 'vitest';
import { metadata as planningMetadata } from '../planning-server';
import { metadata as bootstrapMetadata } from '../bootstrap-server';
// ... 기타 서버

describe('Web MCP Server Metadata', () => {
  it('should export valid metadata from planning-server', () => {
    expect(planningMetadata).toBeDefined();
    expect(planningMetadata.displayName).toBe('Task Planning');
    expect(planningMetadata.category).toBe('planning');
  });

  it('should export valid metadata from bootstrap-server', () => {
    expect(bootstrapMetadata).toBeDefined();
    expect(bootstrapMetadata.displayName).toBe('Bootstrap');
    expect(bootstrapMetadata.category).toBe('automation');
  });

  // 모든 서버에 대해 반복

  it('all metadata should conform to ServiceMetadata interface', () => {
    const allMetadata = [planningMetadata, bootstrapMetadata /* ... */];

    allMetadata.forEach((meta) => {
      expect(meta).toHaveProperty('displayName');
      expect(meta).toHaveProperty('description');
      expect(meta).toHaveProperty('category');
      expect(['automation', 'storage', 'planning', 'execution']).toContain(
        meta.category,
      );
    });
  });
});
```

### 통합 테스트 수정

**파일:** `src/features/tools/__tests__/WebMCPServiceRegistry.test.tsx` (신규 또는 수정)

```typescript
import { describe, it, expect, vi } from 'vitest';
import { render } from '@testing-library/react';
import { WebMCPServiceRegistry } from '../WebMCPServiceRegistry';

describe('WebMCPServiceRegistry', () => {
  it('should use module metadata for known servers', async () => {
    // Mock WebMCPContext
    const mockProxy = { /* ... */ };

    // Render with known servers
    render(
      <WebMCPContext.Provider value={{ proxy: mockProxy, isLoading: false, initialized: true }}>
        <WebMCPServiceRegistry servers={['planning', 'bootstrap']} />
      </WebMCPContext.Provider>
    );

    // Verify registration with correct metadata
    expect(mockRegister).toHaveBeenCalledWith(
      'planning',
      expect.objectContaining({
        metadata: expect.objectContaining({
          displayName: 'Task Planning',
          category: 'planning',
        }),
      })
    );
  });

  it('should use default metadata for unknown servers', async () => {
    render(
      <WebMCPContext.Provider value={{ proxy: mockProxy, isLoading: false, initialized: true }}>
        <WebMCPServiceRegistry servers={['unknown-server']} />
      </WebMCPContext.Provider>
    );

    expect(mockRegister).toHaveBeenCalledWith(
      'unknown-server',
      expect.objectContaining({
        metadata: expect.objectContaining({
          displayName: 'unknown-server',
          category: 'automation',
        }),
      })
    );
  });
});
```

### E2E 테스트 시나리오

**파일:** `src/features/assistant/__tests__/BuiltInToolsEditor.e2e.test.tsx`

```typescript
describe('BuiltInToolsEditor with refactored metadata', () => {
  it('should display correct server names from module metadata', async () => {
    const { getByText } = render(<BuiltInToolsEditor />);

    // Verify all server display names are shown
    expect(getByText('Task Planning')).toBeInTheDocument();
    expect(getByText('Bootstrap')).toBeInTheDocument();
    expect(getByText('Content Store')).toBeInTheDocument();
    // ...
  });

  it('should show correct descriptions', async () => {
    const { getByText } = render(<BuiltInToolsEditor />);

    expect(getByText(/Goal setting, task planning/i)).toBeInTheDocument();
    expect(getByText(/Platform detection/i)).toBeInTheDocument();
  });
});
```

### 수동 테스트 체크리스트

1. **서버 목록 확인**
   - Settings → Built-in Tools에서 모든 서버 표시 확인
   - displayName이 올바른지 확인

2. **새 서버 추가 시뮬레이션**
   - 테스트용 더미 서버 모듈 생성 (metadata 포함)
   - `WebMCPServiceRegistry`에 서버명만 추가
   - Registry 코드 수정 없이 UI에 표시되는지 확인

3. **기존 기능 회귀 테스트**
   - Assistant 생성/편집 시 Built-in Tools 토글 동작
   - Chat에서 도구 호출 정상 동작
   - Service Context 조회 정상 동작

---

## 작업 단계별 가이드

### Phase 1: 메타데이터 파일 생성 (우선순위: 높음)

**작업 항목:**

1. 각 서버 모듈에 `metadata.ts` 생성 (7개 서버)
2. 각 `index.ts`에서 metadata export 추가
3. Fallback 레지스트리 파일 생성 (`server-metadata-registry.ts`)

**예상 소요:** 1~2시간  
**리스크:** 낮음 (기존 코드 영향 없음)

### Phase 2: Registry 리팩토링 (우선순위: 높음)

**작업 항목:**

1. `WebMCPServiceRegistry.tsx`에 모듈 import 추가
2. `SERVER_MODULE_MAP` 정의
3. if-else 체인을 fallback 로직으로 교체
4. 기존 동작 유지 확인 (수동 테스트)

**예상 소요:** 2~3시간  
**리스크:** 중간 (UI 영향 가능, 충분한 테스트 필요)

### Phase 3: 테스트 코드 작성 (우선순위: 중간)

**작업 항목:**

1. 메타데이터 단위 테스트 작성
2. Registry 통합 테스트 작성
3. E2E 시나리오 테스트

**예상 소요:** 2~3시간  
**리스크:** 낮음

### Phase 4: 문서화 및 정리 (우선순위: 낮음)

**작업 항목:**

1. 각 서버 모듈 README 업데이트 (metadata 언급)
2. 아키텍처 문서 업데이트
3. 기존 주석 정리

**예상 소요:** 1시간  
**리스크:** 없음

---

## Clarification Q-list

### Q1: workspace-server의 두 서버(content_store, workspace) 처리 방식

**현황:**  
`workspace-server` 디렉터리가 `content_store`와 `workspace` 두 개의 논리적 서버를 제공하는 것으로 추정됨.

**옵션:**

- **A)** `workspace-server/metadata.ts`에 두 서버의 메타데이터를 객체로 export
  ```typescript
  export const metadata = {
    content_store: { displayName: 'Content Store', ... },
    workspace: { displayName: 'Workspace', ... },
  };
  ```
- **B)** `workspace-server/content-store-metadata.ts`와 `workspace-metadata.ts` 분리
- **C)** 현재처럼 Registry에서 수동 매핑 유지

**질문:** 어떤 방식을 선호하시나요? (추천: A 또는 B)

### Q2: 외부/동적 서버 메타데이터 오버라이드 방식

**현황:**  
사용자가 외부 MCP 서버를 추가할 경우 메타데이터를 어떻게 관리할지 불명확.

**옵션:**

- **A)** `server-metadata-registry.ts`에 수동 추가 (개발자가 코드 수정)
- **B)** 런타임에 설정 파일(JSON/YAML)에서 로드
- **C)** UI에서 메타데이터 입력 받아 DB 저장

**질문:** 외부 서버의 메타데이터는 어떻게 관리할 예정인가요?

### Q3: ServiceMetadata 타입 확장 계획

**현황:**  
현재 `icon?: string` 필드가 정의되어 있으나 사용되지 않음.

**질문:**

- 아이콘 사용 계획이 있나요?
- 추가 필드(tags, version, author 등) 필요 여부?
- 필요 없다면 icon 필드 제거?

### Q4: 마이그레이션 전략

**현황:**  
리팩토링 중 기존 기능이 중단되면 안 됨.

**옵션:**

- **A)** Feature flag로 신/구 방식 전환 가능하게 구현
- **B)** 모든 서버 메타데이터 준비 후 한 번에 전환
- **C)** 서버별 순차 마이그레이션

**질문:** 어떤 마이그레이션 전략을 선호하시나요? (추천: B)

### Q5: 테스트 커버리지 목표

**질문:**

- 단위 테스트만 작성?
- 통합/E2E 테스트도 포함?
- 목표 커버리지 %는?

---

## 예상 리스크 및 대응 방안

### 리스크 1: Registry 리팩토링 시 UI 깨짐

**확률:** 중간  
**영향:** 높음  
**대응:**

- Phase 2 진입 전 충분한 수동 테스트
- 모든 서버의 메타데이터 값이 기존과 동일한지 검증
- Rollback 계획 수립 (Git 브랜치 보존)

### 리스크 2: workspace-server 구조 파악 불충분

**확률:** 낮음  
**영향:** 중간  
**대응:**

- workspace-server 코드 사전 분석
- Q1 질문 답변 받고 진행

### 리스크 3: 외부 서버 메타데이터 처리 미정

**확률:** 중간  
**영향:** 낮음 (현재 외부 서버 없음)  
**대응:**

- Q2 답변 받아 설계 확정
- 확장성 확보를 위해 fallback 메커니즘 유지

---

## 성공 기준

1. ✅ 모든 기존 서버의 displayName/description이 UI에서 동일하게 표시
2. ✅ `WebMCPServiceRegistry.tsx`에서 if-else 체인 완전 제거
3. ✅ 새 서버 추가 시 Registry 수정 불필요
4. ✅ 타입 체크 통과 (tsc --noEmit)
5. ✅ Lint 통과 (pnpm lint)
6. ✅ 단위 테스트 커버리지 > 80% (메타데이터 관련 코드)
7. ✅ 수동 E2E 테스트 체크리스트 100% 통과

---

## 참고 자료

- [Single Responsibility Principle](https://en.wikipedia.org/wiki/Single-responsibility_principle)
- [TypeScript Module Resolution](https://www.typescriptlang.org/docs/handbook/module-resolution.html)
- Existing: `src/features/tools/BrowserToolProvider.tsx` (metadata 하드코딩 예시)
- Existing: `src/features/tools/RustMCPToolProvider.tsx` (동적 메타데이터 생성 예시)

---

**작성자 노트:**  
이 리팩토링은 코드 품질 개선과 확장성 확보를 위한 중요한 작업입니다. 단계별로 진행하며 각 단계 완료 후 충분한 검증을 권장합니다. 특히 Phase 2 진행 전 Q-list 답변을 받아 불확실성을 제거하는 것이 중요합니다.


---

# refactoring_20251019_1600.md

# Thread-Based Message Grouping Implementation Plan

**Created**: 2025-10-19 16:00
**Author**: Claude Code
**Status**: Ready for Implementation
**Type**: Fresh Implementation (Not Refactoring)

---

## 1. Purpose of the Task

Support multiple independent conversation contexts (Threads) within a Session, allowing users to manage multiple conversation topics in parallel within a single session.

### Core Objectives

- Sessions can contain multiple Threads (1:N relationship)
- Each Thread has an independent message history
- Threads exist in parallel without switching
- Backend manages state via (sessionId, threadId) tuples
- threadId is explicitly passed during tool execution

---

## 2. Current State / Problems

### 2.1 Current Structure

```typescript
// Current Message Model
interface Message {
  id: string;
  sessionId: string; // ✅ 있음
  threadId?: string; // ❌ 없음
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  // ...
}

// Current Session Model
interface Session {
  id: string;
  type: 'single' | 'group';
  assistants: Assistant[];
  name?: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
  // ❌ thread 관련 필드 없음
}
```

### 2.2 문제점

1. **메시지 그룹핑 불가**
   - 모든 메시지가 session 레벨에서만 관리됨
   - 다중 대화 맥락 지원 불가

2. **Tool Context 격리 불가**
   - Tool 실행 결과가 전체 session에 영향
   - 독립적인 작업 맥락 유지 어려움

3. **확장성 제한**
   - Multi-agent orchestration 시 agent별 thread 분리 불가
   - 복잡한 워크플로우 구성 어려움

---

## 3. 관련 코드의 구조 및 동작 방식 Summary

### 3.1 Bird's Eye View

```text
Frontend (React)
├── SessionContext
│   ├── current: Session | null       // 현재 선택된 세션
│   ├── select(sessionId): void       // 세션 전환
│   └── start(...): Promise<void>     // 새 세션 생성
│
├── SessionHistoryContext
│   ├── messages: Page<Message>[]     // 메시지 페이지네이션
│   ├── addMessages(messages): void   // 메시지 추가
│   └── SWR Key: [sessionId, 'messages', page]
│
└── ChatContext
    ├── sendMessage(content): void    // 메시지 전송
    └── Tool Execution Flow

Backend (Rust + Tauri)
├── messages_get_page(sessionId, page, pageSize)
├── messages_upsert(messages[])
└── State: Dexie (IndexedDB)
    ├── sessions: &id
    └── messages: &id, sessionId, createdAt
```

### 3.2 현재 데이터 흐름

```text
1. User sends message
   ↓
2. ChatContext.sendMessage()
   ↓
3. SessionHistoryContext.addMessages([message])
   ↓
4. Backend: messages_upsert({ sessionId, content, ... })
   ↓
5. Dexie: messages.add({ sessionId, ... })
   ↓
6. SWR revalidation: [sessionId, 'messages', page]
```

### 3.3 주요 파일 및 책임

| 파일                                    | 책임                                        |
| --------------------------------------- | ------------------------------------------- |
| `src/models/chat.ts`                    | 데이터 모델 정의 (Session, Message, Thread) |
| `src/context/SessionContext.tsx`        | 세션 생명주기 관리                          |
| `src/context/SessionHistoryContext.tsx` | 메시지 CRUD 및 페이지네이션                 |
| `src/features/tools/index.tsx`          | ServiceContextOptions 정의                  |
| `src/hooks/use-unified-mcp.ts`          | Tool 실행 로직                              |
| `src/lib/rust-backend-client.ts`        | Tauri 백엔드 API 클라이언트                 |
| `src/lib/db/service.ts`                 | Dexie 스키마 및 마이그레이션                |

---

## 4. 변경 이후의 상태 / 해결 판정 기준

### 4.1 목표 구조

```typescript
// New Message Model
interface Message {
  id: string;
  sessionId: string;
  threadId: string; // ✅ 필수 필드
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  // ...
}

// New Session Model
interface Session {
  id: string;
  type: 'single' | 'group';
  assistants: Assistant[];
  name?: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
  sessionThread: Thread; // ✅ Top-level thread metadata
}

// New Thread Model
interface Thread {
  /** Unique thread identifier */
  id: string;

  /** Parent session ID */
  sessionId: string;

  /** Assistant ID for this thread (optional) */
  assistantId?: string;

  /** Initial query or context for this thread (optional) */
  initialQuery?: string;

  /** Thread creation timestamp */
  createdAt: Date;
}
```

### 4.2 목표 데이터 흐름

```text
1. User sends message to specific thread
   ↓
2. ChatContext.sendMessage(content, threadId)  // ✅ threadId 명시
   ↓
3. SessionHistoryContext.addMessages([message], threadId)
   ↓
4. Backend: messages_upsert({ sessionId, threadId, content, ... })
   ↓
5. Dexie: messages.add({ sessionId, threadId, ... })
   ↓
6. SWR revalidation: [sessionId, threadId, 'messages', page]  // ✅ threadId 포함
```

### 4.3 해결 판정 기준

- [ ] Session 생성 시 자동으로 top thread (id === sessionId) 생성됨
- [ ] Message에 threadId 필드가 필수로 포함됨
- [ ] 같은 session 내 여러 threadId로 메시지 저장 가능
- [ ] SWR key에 threadId 포함되어 thread별 독립적인 캐싱
- [ ] Tool 실행 시 ServiceContextOptions에 threadId 전달됨
- [ ] Backend API가 (sessionId, threadId) 튜플로 데이터 조회
- [ ] 기존 데이터는 threadId = sessionId로 자동 마이그레이션
- [ ] TypeScript 컴파일 에러 없음
- [ ] 기존 테스트 통과 및 새 테스트 추가

---

## 5. 수정이 필요한 코드 및 수정 부분의 코드 스니핏

### 5.1 Data Models (`src/models/chat.ts`)

#### 5.1.1 Thread Interface 추가

**위치**: `AttachmentReference` 인터페이스 다음

```typescript
/**
 * Thread represents a logical conversation thread within a session.
 * - Top thread: id === sessionId (always exists)
 * - Sub threads: id !== sessionId (optional, created by user)
 *
 * All threads exist in parallel (no switching concept).
 * Backend manages state via (sessionId, threadId) tuples.
 */
export interface Thread {
  /** Unique thread identifier */
  id: string;

  /** Parent session ID */
  sessionId: string;

  /** Assistant ID for this thread (optional) */
  assistantId?: string;

  /** Initial query or context for this thread (optional) */
  initialQuery?: string;

  /** Thread creation timestamp */
  createdAt: Date;
}
```

#### 5.1.2 Message Interface Update

**Location**: `Message` interface

```typescript
export interface Message {
  id: string;
  sessionId: string;

  /**
   * Thread ID this message belongs to.
   * REQUIRED: Must always be specified.
   * For top-level thread: threadId === sessionId
   */
  threadId: string; // ✅ string (not optional)

  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  // ... 나머지 필드 유지
}
```

#### 5.1.3 Session Interface 수정

**위치**: `Session` 인터페이스

```typescript
export interface Session {
  id: string;
  type: 'single' | 'group';
  assistants: Assistant[];
  name?: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;

  /**
   * Session's top-level thread metadata.
   * This is the only Thread object stored in Session.
   * - id === sessionId (identifies this as the top thread)
   *
   * Other threads exist only in backend state.
   */
  sessionThread: Thread;
}
```

### 5.2 SessionContext (`src/context/SessionContext.tsx`)

#### 5.2.1 Context Type 수정

```typescript
interface SessionContextType {
  // Existing fields (unchanged)
  sessions: Page<Session>[] | undefined;
  current: Session | null;
  select: (id?: string) => void;
  start: (
    assistants: Assistant[],
    description?: string,
    name?: string,
  ) => Promise<void>;
  delete: (id: string) => Promise<void>;
  updateSession: (session: Session) => Promise<void>;
  getSessions: () => Promise<void>;
  getCurrentSession: () => Session | null;
  loadMore: () => Promise<void>;
  clearAllSessions: () => Promise<void>;
  isLoading: boolean;
  isValidating: boolean;
  error: Error | null;
  clearError: () => void;
  retryLastOperation: () => Promise<void>;
  hasNextPage: boolean;
  isAgenticMode: boolean;
  toggleAgenticMode: () => void;

  /**
   * NEW: Session's top-level thread metadata (read-only).
   * Derived from current.sessionThread.
   * Returns null if no session is selected.
   */
  sessionThread: Thread | null;
}
```

#### 5.2.2 Provider 구현 - sessionThread 추가

```typescript
function SessionContextProvider({ children }: { children: ReactNode }) {
  // ... existing state ...

  // ✅ Derive sessionThread from current session
  const sessionThread = useMemo(
    () => current?.sessionThread ?? null,
    [current],
  );

  // ... rest of implementation
}
```

#### 5.2.3 start() 메서드 수정 - Top Thread 생성

```typescript
const handleStartNew = useCallback(
  async (assistants: Assistant[], description?: string, name?: string) => {
    const operation = async () => {
      if (!assistants.length) {
        throw new Error(
          'At least one assistant is required to start a session.',
        );
      }

      const sessionId = createId();

      // ✅ Create top thread with id === sessionId
      const sessionThread: Thread = {
        id: sessionId,
        sessionId,
        createdAt: new Date(),
      };

      const session: Session = {
        id: sessionId,
        assistants: [...assistants],
        type: assistants.length > 1 ? 'group' : 'single',
        createdAt: new Date(),
        updatedAt: new Date(),
        description: generateSessionDescription(assistants, description),
        name: generateSessionName(assistants, name),
        sessionThread, // ✅ Include top thread
      };

      logger.info('Creating new session with top thread', {
        sessionId: session.id,
        topThreadId: sessionThread.id,
      });

      // Optimistic update
      setCurrent(session);

      // ... rest of optimistic update logic

      try {
        await dbService.sessions.upsert(session);
      } catch (error) {
        setCurrent(null);
        await mutate();
        throw error;
      }
    };

    // ... error handling
  },
  [mutate],
);
```

#### 5.2.4 Context Value 수정

```typescript
const contextValue: SessionContextType = useMemo(
  () => ({
    // ... existing fields ...
    sessionThread, // ✅ Add derived sessionThread
  }),
  [
    // ... existing dependencies ...
    sessionThread,
  ],
);
```

### 5.3 SessionHistoryContext (`src/context/SessionHistoryContext.tsx`)

#### 5.3.1 SWR Key 수정 - ThreadId 포함

**현재**:

```typescript
const { data, error, isLoading, setSize, mutate } = useSWRInfinite<
  Page<Message>
>(
  (pageIndex, previousPageData) => {
    if (!currentSession?.id) return null;
    if (previousPageData && !previousPageData.hasNextPage) return null;
    return [currentSession.id, 'messages', pageIndex + 1];
  },
  async ([sessionId, , page]: [string, string, number]) => {
    return backend.getMessagesPageForSession(sessionId, page, PAGE_SIZE);
  },
  // ...
);
```

**수정 후**:

```typescript
export function SessionHistoryProvider({
  children,
  threadId, // ✅ NEW: Accept threadId as prop
}: {
  children: ReactNode;
  threadId?: string; // Optional, defaults to top thread
}) {
  const { current: currentSession } = useSessionContext();

  // ✅ Determine effective threadId
  const effectiveThreadId = useMemo(
    () => threadId || currentSession?.id || '',
    [threadId, currentSession?.id],
  );

  const { data, error, isLoading, setSize, mutate } = useSWRInfinite<
    Page<Message>
  >(
    (pageIndex, previousPageData) => {
      if (!currentSession?.id || !effectiveThreadId) return null;
      if (previousPageData && !previousPageData.hasNextPage) return null;

      // ✅ Include threadId in key
      return [currentSession.id, effectiveThreadId, 'messages', pageIndex + 1];
    },
    async ([sessionId, threadId, , page]: [string, string, string, number]) => {
      // ✅ Pass both sessionId and threadId
      return backend.getMessagesPageForSession(
        sessionId,
        threadId,
        page,
        PAGE_SIZE,
      );
    },
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: true,
      revalidateIfStale: false,
    },
  );

  // ... rest of implementation
}
```

#### 5.3.2 addMessages 수정 - Explicit ThreadId

```typescript
const addMessages = useCallback(
  /**
   * Add messages to a specific thread.
   * @param messagesToAdd Messages to add
   * @param threadId Target thread ID (defaults to current effectiveThreadId)
   */
  (messagesToAdd: Message[], targetThreadId?: string): Promise<Message[]> => {
    if (!currentSession) throw new Error('No active session.');

    const threadId = targetThreadId || effectiveThreadId;
    if (!threadId) throw new Error('threadId is required');

    messagesToAdd.forEach(validateMessage);

    // ✅ Ensure all messages have correct threadId
    const messagesWithContext = messagesToAdd.map((m) => ({
      ...m,
      sessionId: currentSession.id,
      threadId, // ✅ Explicit threadId
    }));

    const previousData = data;

    return mutate(
      (currentData) => {
        if (!currentData || currentData.length === 0) {
          return [
            {
              items: messagesWithContext,
              page: 1,
              pageSize: PAGE_SIZE,
              totalItems: messagesWithContext.length,
              totalPages: 1,
              hasNextPage: false,
              hasPreviousPage: false,
            },
          ];
        }
        const newData = [...currentData];
        const last = { ...newData[newData.length - 1] };
        last.items = [...last.items, ...messagesWithContext];
        newData[newData.length - 1] = last;
        return newData;
      },
      { revalidate: false },
    )
      .then(() => backend.upsertMessages(messagesWithContext))
      .then(() => messagesWithContext)
      .catch((e) => {
        mutate(previousData, { revalidate: false });
        throw e;
      });
  },
  [currentSession, effectiveThreadId, mutate, data, validateMessage],
);
```

### 5.4 ServiceContextOptions (`src/features/tools/index.tsx`)

```typescript
export interface ServiceContextOptions {
  sessionId?: string;
  assistantId?: string;

  /**
   * Thread ID for tool context isolation.
   * Tools executed with the same threadId share context.
   *
   * OPTIONAL: If not provided, defaults to sessionId (top thread).
   * This allows backward compatibility with existing services.
   */
  threadId?: string; // ✅ Optional field with fallback
}
```

**Migration Strategy**: To ensure backward compatibility, all built-in services should use this pattern:

```typescript
// In any service's getServiceContext() or executeTool() method
getServiceContext(options?: ServiceContextOptions): Promise<ServiceContext> {
  // ✅ Fallback to sessionId if threadId not provided
  const effectiveThreadId = options?.threadId || options?.sessionId || '';

  if (!effectiveThreadId) {
    throw new Error('Either threadId or sessionId must be provided');
  }

  // Use effectiveThreadId for context isolation
  const state = this.stateManager.get(options?.sessionId || '', effectiveThreadId);
  // ...
}
```

**Affected Services**: The following built-in services need to be updated to use the fallback pattern:

- `planning-server` (Web MCP) - State management by (sessionId, threadId)
- `workspace-service` - File operations scoped to thread
- `browser-service` - Browser automation context per thread
- `content-store-service` - Content indexing per thread
- `playbook-service` - Playbook execution per thread

### 5.5 Tool Execution (`src/hooks/use-unified-mcp.ts`)

#### 5.5.1 executeToolCall Signature Update

```typescript
const executeToolCall = useCallback(
  /**
   * Execute a tool call with thread context.
   * @param toolCall Tool call to execute
   * @param threadId Thread where tool executes (optional, defaults to sessionId)
   */
  async (
    toolCall: ToolCall,
    threadId?: string, // ✅ OPTIONAL PARAMETER with fallback
  ): Promise<MCPResponse<unknown>> => {
    const { current: currentSession } = useSessionContext();
    const { currentAssistant } = useAssistantContext();

    // ✅ Determine effective threadId with fallback
    const effectiveThreadId = threadId || currentSession?.id || '';

    if (!effectiveThreadId) {
      throw new Error(
        'Cannot determine threadId: no active session or thread specified',
      );
    }

    // ... tool resolution logic ...

    // ✅ Inject ServiceContextOptions with threadId (supports fallback)
    let toolCallToExecute: ToolCall = actualToolCall;
    if (toolType === 'BuiltInRust') {
      const serviceContextOptions: ServiceContextOptions = {
        sessionId: currentSession?.id ?? '',
        assistantId: currentAssistant?.id ?? '',
        threadId: effectiveThreadId, // ✅ Use effective threadId
      };
      toolCallToExecute = {
        ...actualToolCall,
        serviceContextOptions,
      } as ToolCall & { serviceContextOptions: ServiceContextOptions };
    }

    // ... execution logic ...
  },
  [
    /* dependencies without threadId */
  ],
);
```

### 5.6 Backend Client (`src/lib/rust-backend-client.ts`)

#### 5.6.1 getMessagesPageForSession 수정

```typescript
/**
 * Get messages for a specific thread in a session.
 * @param sessionId Session ID
 * @param threadId Thread ID (REQUIRED)
 * @param page Page number (1-indexed)
 * @param pageSize Number of messages per page
 */
export async function getMessagesPageForSession(
  sessionId: string,
  threadId: string, // ✅ REQUIRED parameter
  page: number,
  pageSize: number,
): Promise<Page<Message>> {
  if (!sessionId || !threadId) {
    throw new Error('sessionId and threadId are required');
  }

  const result = await safeInvoke<Page<Record<string, unknown>>>(
    'messages_get_page',
    {
      sessionId,
      threadId, // ✅ Pass threadId to backend
      page,
      pageSize,
    },
  );

  // Deserialize result
  return {
    items: result.items.map((item) => ({
      id: item.id as string,
      sessionId: item.sessionId as string,
      threadId: item.threadId as string, // ✅ Deserialize threadId
      role: item.role as Message['role'],
      content: item.content as string,
      createdAt: new Date(item.createdAt as string),
      // ... other fields
    })),
    page: result.page,
    pageSize: result.pageSize,
    totalItems: result.totalItems,
    totalPages: result.totalPages,
    hasNextPage: result.hasNextPage,
    hasPreviousPage: result.hasPreviousPage,
  };
}
```

#### 5.6.2 upsertMessages 수정

```typescript
/**
 * Upsert messages with thread context.
 */
export async function upsertMessages(messages: Message[]): Promise<Message[]> {
  if (!messages.length) return [];

  // ✅ Verify all messages have threadId
  messages.forEach((m) => {
    if (!m.threadId) {
      throw new Error(`Message ${m.id} missing required threadId`);
    }
  });

  const result = await safeInvoke<Record<string, unknown>[]>(
    'messages_upsert',
    messages,
  );

  return result.map((r) => ({
    id: r.id as string,
    sessionId: r.sessionId as string,
    threadId: r.threadId as string, // ✅ Deserialize threadId
    role: r.role as Message['role'],
    content: r.content as string,
    createdAt: new Date(r.createdAt as string),
    // ... other fields
  }));
}
```

### 5.7 Database Schema (`src/lib/db/service.ts`)

#### 5.7.1 Schema Update - Composite Index

```typescript
export class DatabaseService extends Dexie {
  sessions!: Dexie.Table<Session, string>;
  messages!: Dexie.Table<Message, string>;

  constructor() {
    super('LibrAgentDB');

    // ... existing versions ...

    // ✅ NEW VERSION: Add composite index for (sessionId, threadId)
    this.version(8).stores({
      sessions: '&id, createdAt, updatedAt',
      messages: '&id, sessionId, [sessionId+threadId], createdAt', // ✅ Composite index
    });
  }
}
```

#### 5.7.2 Migration - Add threadId to existing data

```typescript
this.version(8)
  .stores({
    sessions: '&id, createdAt, updatedAt',
    messages: '&id, sessionId, [sessionId+threadId], createdAt',
  })
  .upgrade(async (tx) => {
    logger.info('Migrating to version 8: Adding threadId support');

    // ✅ Add threadId to existing messages (default to sessionId)
    const messages = await tx.table('messages').toArray();
    for (const msg of messages) {
      if (!msg.threadId) {
        await tx.table('messages').update(msg.id, {
          threadId: msg.sessionId, // Default to top thread
        });
      }
    }

    // ✅ Add sessionThread to existing sessions
    const sessions = await tx.table('sessions').toArray();
    for (const session of sessions) {
      if (!session.sessionThread) {
        await tx.table('sessions').update(session.id, {
          sessionThread: {
            id: session.id,
            sessionId: session.id,
            assistantId: session.assistants?.[0]?.id,
            initialQuery: undefined,
            createdAt: session.createdAt,
          },
        });
      }
    }

    logger.info('Migration to version 8 complete');
  });
```

#### 5.7.3 Post-Migration: SWR Cache Invalidation

**Problem**: After migration, SWR cache keys change from `[sessionId, 'messages', page]` to `[sessionId, threadId, 'messages', page]`, causing stale data to be served temporarily.

**Solution**: Add explicit cache invalidation after successful migration:

**File**: `src/lib/db/service.ts` (within the upgrade function)

```typescript
this.version(8)
  .stores({
    sessions: '&id, createdAt, updatedAt',
    messages: '&id, sessionId, [sessionId+threadId], createdAt',
  })
  .upgrade(async (tx) => {
    logger.info('Migrating to version 8: Adding threadId support');

    // ... migration logic ...

    logger.info('Migration to version 8 complete');

    // ✅ IMPORTANT: Clear SWR caches after migration
    // This ensures old cache keys don't serve stale data
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        // Dispatch custom event to signal cache invalidation needed
        window.dispatchEvent(
          new CustomEvent('database-migrated', {
            detail: { version: 8, feature: 'threadId' },
          }),
        );
        logger.info(
          'Dispatched database-migrated event for cache invalidation',
        );
      } catch (e) {
        logger.warn('Failed to dispatch migration event', e);
      }
    }
  });
```

**File**: `src/context/SessionHistoryContext.tsx` (add effect to listen for migration events)

```typescript
export function SessionHistoryProvider({
  children,
  threadId,
}: {
  children: ReactNode;
  threadId?: string;
}) {
  // ... existing code ...

  // ✅ Listen for database migration events and invalidate caches
  useEffect(() => {
    const handleMigration = (event: CustomEvent) => {
      logger.info(
        'Database migration detected, invalidating SWR caches',
        event.detail,
      );

      // Clear all SWR caches for this context
      mutate(() => true); // Invalidate all keys matching the fetcher

      logger.info('SWR caches invalidated successfully');
    };

    window.addEventListener(
      'database-migrated',
      handleMigration as EventListener,
    );

    return () => {
      window.removeEventListener(
        'database-migrated',
        handleMigration as EventListener,
      );
    };
  }, [mutate]);

  // ... rest of implementation
}
```

**Alternative Strategy** (if above is too aggressive):

Use targeted cache invalidation based on the old key pattern:

```typescript
// In the migration event handler
const handleMigration = () => {
  // Invalidate only message-related caches
  mutate(
    (key) => {
      if (!Array.isArray(key)) return false;
      // Match old pattern: [sessionId, 'messages', page]
      return key.length === 3 && key[1] === 'messages';
    },
    undefined,
    { revalidate: true },
  );
};
```

### 5.8 Rust Backend Commands (`src-tauri/src/commands/messages.rs`)

The Rust backend must be updated to handle `threadId` parameters. All message query and storage operations need to filter by the (sessionId, threadId) tuple.

#### 5.8.1 messages_get_page Command Update

**Current Signature**:

```rust
#[tauri::command]
pub async fn messages_get_page(
    session_id: String,
    page: usize,
    page_size: usize,
) -> Result<Page<Message>, String> {
    // Current implementation only filters by session_id
}
```

**Updated Signature**:

```rust
#[tauri::command]
pub async fn messages_get_page(
    session_id: String,
    thread_id: String, // ✅ NEW: Thread ID parameter
    page: usize,
    page_size: usize,
) -> Result<Page<Message>, String> {
    // Validate inputs
    if session_id.is_empty() {
        return Err("session_id cannot be empty".to_string());
    }
    if thread_id.is_empty() {
        return Err("thread_id cannot be empty".to_string());
    }

    // Database query must filter by BOTH session_id AND thread_id
    let messages = db::query_messages()
        .filter("sessionId", &session_id)
        .filter("threadId", &thread_id) // ✅ Add thread filter
        .order_by("createdAt", Order::Desc)
        .paginate(page, page_size)
        .await
        .map_err(|e| format!("Failed to query messages: {}", e))?;

    Ok(messages)
}
```

#### 5.8.2 messages_upsert Command Update

**Current Signature**:

```rust
#[tauri::command]
pub async fn messages_upsert(
    messages: Vec<Message>,
) -> Result<Vec<Message>, String> {
    // Current implementation
}
```

**Updated Signature** (with validation):

```rust
#[tauri::command]
pub async fn messages_upsert(
    messages: Vec<Message>,
) -> Result<Vec<Message>, String> {
    // ✅ Validate all messages have threadId
    for msg in &messages {
        if msg.session_id.is_empty() {
            return Err(format!("Message {} missing sessionId", msg.id));
        }
        if msg.thread_id.is_none() || msg.thread_id.as_ref().unwrap().is_empty() {
            return Err(format!("Message {} missing required threadId", msg.id));
        }
    }

    // Proceed with upsert - threadId is now persisted
    db::upsert_messages(messages)
        .await
        .map_err(|e| format!("Failed to upsert messages: {}", e))
}
```

#### 5.8.3 Message Struct Update

**File**: `src-tauri/src/models/message.rs`

```rust
use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Message {
    pub id: String,
    pub session_id: String,

    /// Thread ID this message belongs to.
    /// REQUIRED: Must always be specified.
    /// For top-level thread: thread_id == session_id
    pub thread_id: String, // ✅ NEW required field

    pub role: MessageRole,
    pub content: Vec<McpContent>,
    pub tool_calls: Option<Vec<ToolCall>>,
    pub tool_call_id: Option<String>,
    pub assistant_id: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: Option<DateTime<Utc>>,
    // ... other fields
}
```

#### 5.8.4 Database Query Functions

If using a database abstraction layer (e.g., Dexie-like wrapper in Rust), ensure queries support the composite filter:

```rust
// Example query helper
pub async fn get_messages_for_thread(
    session_id: &str,
    thread_id: &str,
    page: usize,
    page_size: usize,
) -> Result<Page<Message>, DbError> {
    let offset = (page - 1) * page_size;

    // Query with composite filter
    let messages: Vec<Message> = sqlx::query_as!(
        Message,
        r#"
        SELECT * FROM messages
        WHERE session_id = $1 AND thread_id = $2
        ORDER BY created_at DESC
        LIMIT $3 OFFSET $4
        "#,
        session_id,
        thread_id,
        page_size as i64,
        offset as i64
    )
    .fetch_all(&pool)
    .await?;

    let total_count: i64 = sqlx::query_scalar!(
        r#"
        SELECT COUNT(*) FROM messages
        WHERE session_id = $1 AND thread_id = $2
        "#,
        session_id,
        thread_id
    )
    .fetch_one(&pool)
    .await?;

    Ok(Page {
        items: messages,
        page,
        page_size,
        total_items: total_count as usize,
        total_pages: ((total_count as usize + page_size - 1) / page_size),
        has_next_page: (page * page_size) < total_count as usize,
        has_previous_page: page > 1,
    })
}
```

#### 5.8.5 Error Handling

Add specific error types for thread-related failures:

```rust
#[derive(Debug, thiserror::Error)]
pub enum MessageError {
    #[error("Thread ID is required but was not provided")]
    MissingThreadId,

    #[error("Thread {0} does not belong to session {1}")]
    ThreadSessionMismatch(String, String),

    #[error("Database error: {0}")]
    DatabaseError(#[from] sqlx::Error),
}
```

#### 5.8.6 Integration Notes

- **Backward Compatibility**: If there are existing messages without `thread_id`, a migration script should set `thread_id = session_id` for all existing records
- **Validation**: Ensure `thread_id` matches the expected pattern (either equals `session_id` for top threads, or is a valid sub-thread ID)
- **Indexing**: Add a composite index on `(session_id, thread_id, created_at)` for optimal query performance

---

## 6. Reusable Related Code

### 6.1 Thread 관련 Utility Functions

**파일**: `src/lib/utils/thread-utils.ts` (NEW)

```typescript
import type { Thread, Session } from '@/models/chat';

/**
 * Get the top-level thread for a session.
 */
export function getTopThread(session: Session): Thread {
  return session.sessionThread;
}

/**
 * Check if a threadId is the top thread.
 */
export function isTopThread(threadId: string, sessionId: string): boolean {
  return threadId === sessionId;
}

/**
 * Create a new thread object.
 */
export function createThread(
  sessionId: string,
  assistantId?: string,
  initialQuery?: string,
): Thread {
  return {
    id: createId(),
    sessionId,
    assistantId,
    initialQuery,
    createdAt: new Date(),
  };
}

/**
 * Create the default top thread for a session.
 */
export function createTopThread(
  sessionId: string,
  assistantId?: string,
  initialQuery?: string,
): Thread {
  return {
    id: sessionId,
    sessionId,
    assistantId,
    initialQuery,
    createdAt: new Date(),
  };
}
```

### 6.2 Thread Validation

**파일**: `src/lib/validation/thread-validation.ts` (NEW)

```typescript
import type { Thread, Message } from '@/models/chat';

export class ThreadValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ThreadValidationError';
  }
}

/**
 * Validate that a thread belongs to a session.
 */
export function validateThreadOwnership(
  thread: Thread,
  sessionId: string,
): void {
  if (thread.sessionId !== sessionId) {
    throw new ThreadValidationError(
      `Thread ${thread.id} does not belong to session ${sessionId}`,
    );
  }
}

/**
 * Validate that a message belongs to a thread.
 */
export function validateMessageThreadOwnership(
  message: Message,
  threadId: string,
): void {
  if (message.threadId !== threadId) {
    throw new ThreadValidationError(
      `Message ${message.id} does not belong to thread ${threadId}`,
    );
  }
}

/**
 * Validate that all messages belong to the same thread.
 */
export function validateMessagesConsistency(
  messages: Message[],
  threadId: string,
): void {
  messages.forEach((msg) => {
    validateMessageThreadOwnership(msg, threadId);
  });
}
```

### 6.3 기존 재사용 가능 코드

| 파일 경로                           | 주요 기능    | 재사용 포인트                |
| ----------------------------------- | ------------ | ---------------------------- |
| `src/lib/logger.ts`                 | 로깅 시스템  | Thread 작업 로깅에 활용      |
| `src/lib/create-id.ts`              | ID 생성      | Thread ID 생성               |
| `src/lib/db/service.ts`             | Dexie 래퍼   | Thread 데이터 저장           |
| `src/hooks/use-session-context.tsx` | Session 접근 | sessionThread 접근           |
| `src/models/pagination.ts`          | 페이지네이션 | Thread별 메시지 페이지네이션 |

---

## 7. Test Code 추가 및 수정 필요 부분에 대한 가이드

### 7.1 Unit Tests

#### 7.1.1 Thread Utils Test

**파일**: `src/lib/utils/thread-utils.test.ts`

```typescript
import { describe, it, expect } from 'vitest';
import {
  getTopThread,
  isTopThread,
  createThread,
  createTopThread,
} from './thread-utils';
import type { Session } from '@/models/chat';

describe('Thread Utils', () => {
  const mockSession: Session = {
    id: 'session-1',
    type: 'single',
    assistants: [],
    createdAt: new Date(),
    updatedAt: new Date(),
    sessionThread: {
      id: 'session-1',
      sessionId: 'session-1',
      createdAt: new Date(),
    },
  };

  describe('getTopThread', () => {
    it('should return the session thread', () => {
      const topThread = getTopThread(mockSession);
      expect(topThread.id).toBe('session-1');
      expect(topThread.id).toBe(topThread.sessionId); // Top thread: id === sessionId
    });
  });

  describe('isTopThread', () => {
    it('should return true when threadId equals sessionId', () => {
      expect(isTopThread('session-1', 'session-1')).toBe(true);
    });

    it('should return false when threadId does not equal sessionId', () => {
      expect(isTopThread('thread-2', 'session-1')).toBe(false);
    });
  });

  describe('createThread', () => {
    it('should create a non-top thread', () => {
      const thread = createThread('session-1', 'assistant-1', 'Test query');
      expect(thread.sessionId).toBe('session-1');
      expect(thread.id).not.toBe(thread.sessionId); // Sub thread: id !== sessionId
      expect(thread.assistantId).toBe('assistant-1');
      expect(thread.initialQuery).toBe('Test query');
    });
  });

  describe('createTopThread', () => {
    it('should create a top thread with id === sessionId', () => {
      const topThread = createTopThread('session-1');
      expect(topThread.id).toBe('session-1');
      expect(topThread.sessionId).toBe('session-1');
      expect(topThread.id).toBe(topThread.sessionId); // Top thread indicator
    });
  });
});
```

#### 7.1.2 Thread Validation Test

**파일**: `src/lib/validation/thread-validation.test.ts`

```typescript
import { describe, it, expect } from 'vitest';
import {
  validateThreadOwnership,
  validateMessageThreadOwnership,
  validateMessagesConsistency,
  ThreadValidationError,
} from './thread-validation';
import type { Thread, Message } from '@/models/chat';

describe('Thread Validation', () => {
  const mockThread: Thread = {
    id: 'thread-1',
    sessionId: 'session-1',
    createdAt: new Date(),
  };

  const mockMessage: Message = {
    id: 'msg-1',
    sessionId: 'session-1',
    threadId: 'thread-1',
    role: 'user',
    content: 'Test',
    createdAt: new Date(),
  };

  describe('validateThreadOwnership', () => {
    it('should not throw when thread belongs to session', () => {
      expect(() =>
        validateThreadOwnership(mockThread, 'session-1'),
      ).not.toThrow();
    });

    it('should throw when thread does not belong to session', () => {
      expect(() => validateThreadOwnership(mockThread, 'session-2')).toThrow(
        ThreadValidationError,
      );
    });
  });

  describe('validateMessageThreadOwnership', () => {
    it('should not throw when message belongs to thread', () => {
      expect(() =>
        validateMessageThreadOwnership(mockMessage, 'thread-1'),
      ).not.toThrow();
    });

    it('should throw when message does not belong to thread', () => {
      expect(() =>
        validateMessageThreadOwnership(mockMessage, 'thread-2'),
      ).toThrow(ThreadValidationError);
    });
  });

  describe('validateMessagesConsistency', () => {
    it('should not throw when all messages belong to thread', () => {
      const messages = [mockMessage, { ...mockMessage, id: 'msg-2' }];
      expect(() =>
        validateMessagesConsistency(messages, 'thread-1'),
      ).not.toThrow();
    });

    it('should throw when any message does not belong to thread', () => {
      const messages = [
        mockMessage,
        { ...mockMessage, id: 'msg-2', threadId: 'thread-2' },
      ];
      expect(() => validateMessagesConsistency(messages, 'thread-1')).toThrow(
        ThreadValidationError,
      );
    });
  });
});
```

### 7.2 Integration Tests

#### 7.2.1 SessionContext Integration Test

**파일**: `src/context/SessionContext.test.tsx`

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, waitFor } from '@testing-library/react';
import { SessionContextProvider, useSessionContext } from './SessionContext';
import type { Assistant } from '@/models/chat';

describe('SessionContext - Thread Integration', () => {
  const mockAssistant: Assistant = {
    id: 'assistant-1',
    name: 'Test Assistant',
    // ... other fields
  };

  beforeEach(() => {
    // Clear database before each test
  });

  it('should create session with top thread', async () => {
    const { result } = renderHook(() => useSessionContext(), {
      wrapper: SessionContextProvider,
    });

    await waitFor(async () => {
      await result.current.start([mockAssistant]);
    });

    const session = result.current.current;
    expect(session).toBeDefined();
    expect(session?.sessionThread).toBeDefined();
    expect(session?.sessionThread.id).toBe(session?.id); // Top thread: id === sessionId
    expect(session?.sessionThread.sessionId).toBe(session?.id);
  });

  it('should expose sessionThread in context', async () => {
    const { result } = renderHook(() => useSessionContext(), {
      wrapper: SessionContextProvider,
    });

    await waitFor(async () => {
      await result.current.start([mockAssistant]);
    });

    expect(result.current.sessionThread).toBeDefined();
    expect(result.current.sessionThread?.id).toBe(result.current.current?.id);
  });
});
```

#### 7.2.2 SessionHistoryContext Integration Test

**파일**: `src/context/SessionHistoryContext.test.tsx`

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, waitFor } from '@testing-library/react';
import { SessionHistoryProvider, useSessionHistoryContext } from './SessionHistoryContext';
import type { Message } from '@/models/chat';

describe('SessionHistoryContext - Thread Support', () => {
  const sessionId = 'session-1';
  const threadId = 'thread-1';

  const mockMessage: Message = {
    id: 'msg-1',
    sessionId,
    threadId,
    role: 'user',
    content: 'Test message',
    createdAt: new Date(),
  };

  it('should add messages with explicit threadId', async () => {
    const { result } = renderHook(
      () => useSessionHistoryContext(),
      {
        wrapper: ({ children }) => (
          <SessionHistoryProvider threadId={threadId}>
            {children}
          </SessionHistoryProvider>
        ),
      },
    );

    await waitFor(async () => {
      await result.current.addMessages([mockMessage], threadId);
    });

    expect(result.current.messages).toHaveLength(1);
    expect(result.current.messages[0].threadId).toBe(threadId);
  });

  it('should filter messages by threadId via SWR key', async () => {
    // Test that SWR key includes threadId and fetches correct messages
    // This requires mocking backend.getMessagesPageForSession
  });
});
```

### 7.3 E2E Test Scenarios

#### 7.3.1 Multi-Thread Message Flow

```typescript
describe('E2E: Multi-Thread Message Flow', () => {
  it('should support messages in multiple threads within same session', async () => {
    // 1. Create session
    // 2. Send message to top thread (threadId === sessionId)
    // 3. Create new thread
    // 4. Send message to new thread
    // 5. Verify both threads have independent message histories
    // 6. Verify SWR caches are independent
  });
});
```

#### 7.3.2 Tool Execution with ThreadId

```typescript
describe('E2E: Tool Execution with ThreadId', () => {
  it('should execute tools with correct thread context', async () => {
    // 1. Create session with thread
    // 2. Execute tool with explicit threadId
    // 3. Verify ServiceContextOptions contains correct threadId
    // 4. Verify tool results are associated with correct thread
  });
});
```

### 7.4 수정이 필요한 기존 테스트

| 테스트 파일                                  | 수정 필요 사항                               |
| -------------------------------------------- | -------------------------------------------- |
| `src/context/SessionContext.test.tsx`        | Session 생성 시 sessionThread 검증 추가      |
| `src/context/SessionHistoryContext.test.tsx` | addMessages에 threadId 파라미터 추가         |
| `src/lib/rust-backend-client.test.ts`        | getMessagesPageForSession 시그니처 변경 반영 |
| Tool execution 관련 테스트                   | executeToolCall에 threadId 파라미터 추가     |

---

## 8. Web MCP Server State Cleanup 및 Lifecycle 관리

### 8.1 planning-server.ts의 상태 구조 (Thread 지원)

**현재 상태 구조 (단일 session)**:

```typescript
Map<sessionId, EphemeralState>;
```

**변경 후 (다중 thread 지원)**:

```typescript
Map<sessionId, Map<threadId, EphemeralState>>;
```

### 8.2 Session 전환 시 Cleanup 패턴

**요구사항**: Session A → Session B로 전환할 때, Session A의 모든 thread state(goals, todos, notes, thoughts)가 메모리에서 제거되어야 함.

**구현 방식**:

```typescript
class SessionStateManager {
  private sessions: Map<string, Map<string, EphemeralState>> = new Map();
  private currentSessionId: string | null = null;

  /**
   * Switch to a new session and clean up the previous session's state.
   * ✅ Old session: all threads' states are removed from memory
   * ✅ New session: states are lazily created on first tool call
   */
  setSession(sessionId: string): void {
    // ✅ CLEANUP: Remove previous session's all thread states
    if (this.currentSessionId && this.currentSessionId !== sessionId) {
      const oldThreadMap = this.sessions.get(this.currentSessionId);
      if (oldThreadMap) {
        // ✅ Clear all threads in old session
        oldThreadMap.clear();
      }
      // ✅ Remove the session entry entirely
      this.sessions.delete(this.currentSessionId);
    }

    // ✅ Set new session (lazy initialization)
    this.currentSessionId = sessionId;
    // Don't create new session entry here; it's created on first tool call
  }

  /**
   * Get or create state for (sessionId, threadId) pair.
   * ✅ Lazy initialization: state is only created when a tool is called
   */
  private getState(sessionId: string, threadId: string): EphemeralState {
    if (!this.sessions.has(sessionId)) {
      this.sessions.set(sessionId, new Map());
    }
    const threadMap = this.sessions.get(sessionId)!;
    if (!threadMap.has(threadId)) {
      threadMap.set(threadId, new EphemeralState());
    }
    return threadMap.get(threadId)!;
  }

  /**
   * Clear all sessions (for testing or complete reset).
   */
  clearAllSessions(): void {
    // ✅ Cleanup all sessions and their threads
    for (const [sessionId, threadMap] of this.sessions.entries()) {
      threadMap.clear();
      this.sessions.delete(sessionId);
    }
    this.currentSessionId = null;
  }
}
```

### 8.3 switchContext 구현 (planning-server에서)

```typescript
async switchContext(context: ServiceContextOptions): Promise<void> {
  const sessionId = context.sessionId;
  if (sessionId) {
    // ✅ This triggers cleanup of previous session's all threads
    stateManager.setSession(sessionId);
    console.info(
      `[PlanningServer] switchContext -> session: ${sessionId} (previous session cleaned up)`,
    );
  }
}
```

### 8.4 상태 Lifecycle

```text
1. Session A Active
   ├── Thread-1: EphemeralState (goal, todos, notes)
   ├── Thread-2: EphemeralState
   └── Thread-3: EphemeralState

2. switchContext(sessionId: B) Called
   └── ✅ ALL states in Session A cleared from memory
       ├── Thread-1 state deleted
       ├── Thread-2 state deleted
       └── Thread-3 state deleted

3. Session B Active (Lazy Initialization)
   ├── No states loaded yet
   └── States created on first tool call

4. Tool call on Session B, Thread-1
   └── ✅ New EphemeralState created for (B, Thread-1)
```

### 8.5 메모리 효율성

**장점**:

- 이전 session의 모든 메모리가 명시적으로 해제됨
- GC 압력 감소 (Map 자체도 제거)
- Session 전환 시 깔끔한 상태 전이

**특징**:

- **Lazy initialization**: 필요할 때만 state 생성
- **Explicit cleanup**: Session 변경 시점에 명시적으로 제거
- **No leaks**: 이전 session state가 메모리에 남지 않음

### 8.6 Backend State 관리 전략

**분석 필요**:

- Rust backend에서 (sessionId, threadId) 튜플을 key로 사용하는 구조 설계
- 현재 Tauri 명령어들이 threadId를 어떻게 받고 처리해야 하는지
- Dexie는 메시지 저장소이고, planning-server의 상태는 메모리 전용 (cleanup됨)

**가이드**:

1. `src-tauri/src/commands/messages.rs` 파일 확인
2. `messages_get_page` 명령어에 threadId 파라미터 추가 필요 여부 확인
3. Rust 측에서 별도 메모리 캐시가 필요한지 검토

### 8.2 Full UI Implementation for Thread Management

This section provides a complete UI implementation plan for thread management, including component designs, state management, and user workflows.

#### 8.2.1 Thread Context Provider

**File**: `src/context/ThreadContext.tsx` (NEW)

```typescript
import { createContext, useContext, useState, useCallback, useMemo, useEffect, ReactNode } from 'react';
import { Thread } from '@/models/chat';
import { useSessionContext } from './SessionContext';
import { getLogger } from '@/lib/logger';

const logger = getLogger('ThreadContext');

interface ThreadContextType {
  /** Currently active thread (or null if session has no thread) */
  currentThread: Thread | null;

  /** Set the active thread for message viewing/sending */
  selectThread: (threadId: string) => void;

  /** Get the effective threadId (current or fallback to session top thread) */
  getEffectiveThreadId: () => string;
}

const ThreadContext = createContext<ThreadContextType | null>(null);

export function useThreadContext(): ThreadContextType {
  const context = useContext(ThreadContext);
  if (!context) {
    throw new Error('useThreadContext must be used within ThreadContextProvider');
  }
  return context;
}

export function ThreadContextProvider({ children }: { children: ReactNode }) {
  const { current: currentSession, sessionThread } = useSessionContext();
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);

  // Derive current thread from selection or default to session's top thread
  const currentThread = useMemo(() => {
    if (!currentSession) return null;

    // If a specific thread is selected, use it (in future, fetch from backend/cache)
    // For now, only sessionThread exists
    if (selectedThreadId && selectedThreadId === currentSession.id) {
      return sessionThread;
    }

    // Default to top thread
    return sessionThread;
  }, [currentSession, sessionThread, selectedThreadId]);

  const selectThread = useCallback((threadId: string) => {
    logger.info('Selecting thread', { threadId });
    setSelectedThreadId(threadId);
  }, []);

  const getEffectiveThreadId = useCallback(() => {
    return currentThread?.id || currentSession?.id || '';
  }, [currentThread, currentSession]);

  // Auto-select session's top thread when session changes
  useEffect(() => {
    if (currentSession && sessionThread) {
      setSelectedThreadId(sessionThread.id);
    } else {
      setSelectedThreadId(null);
    }
  }, [currentSession, sessionThread]);

  const contextValue = useMemo(
    () => ({
      currentThread,
      selectThread,
      getEffectiveThreadId,
    }),
    [currentThread, selectThread, getEffectiveThreadId],
  );

  return (
    <ThreadContext.Provider value={contextValue}>
      {children}
    </ThreadContext.Provider>
  );
}
```

#### 8.2.2 Thread Selector Component

**File**: `src/components/ThreadSelector.tsx` (NEW)

```typescript
import { useThreadContext } from '@/context/ThreadContext';
import { useSessionContext } from '@/context/SessionContext';
import { Button } from '@/components/ui/button';
import { PlusIcon, MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ThreadSelector() {
  const { currentThread, selectThread } = useThreadContext();
  const { current: currentSession, sessionThread } = useSessionContext();

  if (!currentSession || !sessionThread) {
    return null;
  }

  // For Phase 1: Only show top thread
  // In future phases, fetch and display sub-threads here

  return (
    <div className="flex items-center gap-2 px-4 py-2 border-b">
      <MessageSquare className="h-4 w-4 text-muted-foreground" />
      <span className="text-sm font-medium">
        {sessionThread.id === currentSession.id ? 'Main Thread' : sessionThread.id}
      </span>

      {/* Future: Add thread creation button */}
      {/* <Button
        variant="ghost"
        size="sm"
        onClick={handleCreateThread}
        className="ml-auto"
      >
        <PlusIcon className="h-4 w-4" />
        New Thread
      </Button> */}
    </div>
  );
}
```

#### 8.2.3 Integration with SessionHistoryProvider

Update `SessionHistoryProvider` usage to pass `threadId`:

**File**: `src/app/chat/page.tsx` (or wherever SessionHistoryProvider is used)

```typescript
import { SessionHistoryProvider } from '@/context/SessionHistoryContext';
import { ThreadContextProvider, useThreadContext } from '@/context/ThreadContext';
import { ThreadSelector } from '@/components/ThreadSelector';

function ChatPageContent() {
  const { getEffectiveThreadId } = useThreadContext();
  const effectiveThreadId = getEffectiveThreadId();

  return (
    <SessionHistoryProvider threadId={effectiveThreadId}>
      <div className="flex flex-col h-full">
        <ThreadSelector />
        {/* Chat messages and input */}
        <ChatMessages />
        <ChatInput />
      </div>
    </SessionHistoryProvider>
  );
}

export default function ChatPage() {
  return (
    <ThreadContextProvider>
      <ChatPageContent />
    </ThreadContextProvider>
  );
}
```

#### 8.2.4 Chat Input Integration

Update chat input to send messages to the current thread:

**File**: `src/components/ChatInput.tsx` (modifications)

```typescript
import { useThreadContext } from '@/context/ThreadContext';
import { useSessionHistory } from '@/context/SessionHistoryContext';

function ChatInput() {
  const { getEffectiveThreadId } = useThreadContext();
  const { addMessage } = useSessionHistory();
  const [input, setInput] = useState('');

  const handleSend = async () => {
    const threadId = getEffectiveThreadId();

    if (!input.trim() || !threadId) return;

    const message: Message = {
      id: createId(),
      sessionId: currentSession.id,
      threadId, // ✅ Use current thread
      role: 'user',
      content: [{ type: 'text', text: input }],
      createdAt: new Date(),
    };

    await addMessage(message);
    setInput('');
  };

  return (
    <div className="flex gap-2 p-4">
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        placeholder="Type a message..."
        className="flex-1 px-3 py-2 border rounded"
      />
      <Button onClick={handleSend}>Send</Button>
    </div>
  );
}
```

#### 8.2.5 Phase 2: Thread List Sidebar (Future Enhancement)

For future iterations when sub-threads are supported:

**File**: `src/components/ThreadListSidebar.tsx` (FUTURE)

```typescript
import { Thread } from '@/models/chat';
import { useThreadContext } from '@/context/ThreadContext';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { MessageSquare, Plus } from 'lucide-react';

interface ThreadListSidebarProps {
  threads: Thread[]; // Fetched from backend
  onCreateThread: () => void;
}

export function ThreadListSidebar({ threads, onCreateThread }: ThreadListSidebarProps) {
  const { currentThread, selectThread } = useThreadContext();

  return (
    <div className="w-64 border-r flex flex-col">
      <div className="p-4 border-b">
        <Button onClick={onCreateThread} className="w-full">
          <Plus className="h-4 w-4 mr-2" />
          New Thread
        </Button>
      </div>

      <ScrollArea className="flex-1">
        {threads.map((thread) => (
          <button
            key={thread.id}
            onClick={() => selectThread(thread.id)}
            className={cn(
              'w-full p-3 flex items-start gap-2 hover:bg-accent transition',
              currentThread?.id === thread.id && 'bg-accent',
            )}
          >
            <MessageSquare className="h-4 w-4 mt-1 text-muted-foreground" />
            <div className="flex-1 text-left">
              <div className="text-sm font-medium">
                {thread.id === thread.sessionId
                  ? 'Main Thread'
                  : thread.initialQuery || `Thread ${thread.id.slice(0, 8)}`}
              </div>
              {thread.assistantId && (
                <div className="text-xs text-muted-foreground">
                  with {thread.assistantId}
                </div>
              )}
            </div>
          </button>
        ))}
      </ScrollArea>
    </div>
  );
}
```

#### 8.2.6 UI/UX Workflow

**Phase 1 (Current Implementation)**:

1. User selects a session
2. ThreadContext auto-selects the session's top thread (id === sessionId)
3. SessionHistoryProvider receives threadId and loads messages
4. User sends messages to the top thread
5. No UI for thread switching (only one thread exists)

**Phase 2 (Future with Sub-threads)**:

1. User selects a session
2. ThreadListSidebar displays all threads (top + sub-threads)
3. User can click "New Thread" to create a sub-thread with initial query
4. Selecting a thread updates ThreadContext
5. SessionHistoryProvider reloads messages for the new thread
6. Chat UI updates to show the selected thread's messages

**Phase 3 (Advanced Features)**:

- Thread renaming/metadata editing
- Thread archiving (hide but don't delete)
- Thread merging (combine multiple threads)
- Unread message counts per thread
- Thread search/filtering

### 8.3 Migration 전략 세부화

**분석 필요**:

- 대량의 기존 메시지가 있을 경우 마이그레이션 성능
- 마이그레이션 중 오류 처리
- 롤백 전략

**가이드**:

1. Dexie migration hook에서 progress tracking 추가
2. 마이그레이션 실패 시 복구 로직 설계
3. 마이그레이션 전 백업 자동화

### 8.4 Thread 생명주기 관리

**분석 필요**:

- Thread 생성/삭제 API 필요 여부
- Thread 메타데이터 업데이트 방법
- Thread 아카이빙/비활성화 전략

**가이드**:

1. Thread CRUD 연산이 필요한지 검토 (현재는 top thread만 자동 생성)
2. 향후 사용자가 sub-thread를 생성할 수 있는지 결정
3. Thread 삭제 시 관련 메시지 처리 방법 정의

---

## 9. 구현 체크리스트

### Phase 1: Data Models (2-3시간)

- [ ] Thread 인터페이스 추가 (`src/models/chat.ts`)
- [ ] Message 인터페이스에 threadId 필수 필드 추가
- [ ] Session 인터페이스에 sessionThread 필드 추가
- [ ] ServiceContextOptions에 threadId 필수 필드 추가
- [ ] TypeScript 컴파일 확인

### Phase 2: Context Layer (4-5시간)

- [ ] SessionContext에 sessionThread 파생 필드 추가
- [ ] start() 메서드에서 top thread 생성 로직 추가
- [ ] SessionHistoryContext에 threadId prop 추가
- [ ] SWR key에 threadId 포함
- [ ] addMessages에 threadId 파라미터 추가
- [ ] Context 통합 테스트

### Phase 3: Backend Integration (3-4시간)

- [ ] rust-backend-client.ts API 시그니처 변경
- [ ] getMessagesPageForSession에 threadId 파라미터 추가
- [ ] upsertMessages threadId 검증 추가
- [ ] Tauri 명령어 수정 (필요 시)
- [ ] Backend integration 테스트

### Phase 4: Database (2-3시간)

- [ ] Dexie 스키마에 composite index 추가
- [ ] Migration 로직 작성 (v8)
- [ ] 기존 데이터에 threadId 추가
- [ ] 기존 세션에 sessionThread 추가
- [ ] Migration 테스트

### Phase 5: Tool Execution (2-3시간)

- [ ] executeToolCall에 threadId 파라미터 추가
- [ ] ServiceContextOptions 주입 시 threadId 포함
- [ ] Tool 호출 지점에서 threadId 전달
- [ ] Tool execution 테스트

### Phase 6: Testing (4-6시간)

- [ ] Thread utils unit tests
- [ ] Thread validation unit tests
- [ ] SessionContext integration tests
- [ ] SessionHistoryContext integration tests
- [ ] E2E multi-thread scenarios
- [ ] Migration tests
- [ ] 기존 테스트 수정 및 통과 확인

### Phase 7: Validation (2-3시간)

- [ ] `pnpm refactor:validate` 통과
- [ ] 수동 UI 테스트
- [ ] 기존 기능 회귀 테스트
- [ ] 성능 검증
- [ ] 문서 업데이트

---

## 10. 예상 소요 시간

| Phase     | 작업 내용           | 예상 시간     |
| --------- | ------------------- | ------------- |
| Phase 1   | Data Models         | 2-3시간       |
| Phase 2   | Context Layer       | 4-5시간       |
| Phase 3   | Backend Integration | 3-4시간       |
| Phase 4   | Database            | 2-3시간       |
| Phase 5   | Tool Execution      | 2-3시간       |
| Phase 6   | Testing             | 4-6시간       |
| Phase 7   | Validation          | 2-3시간       |
| **Total** |                     | **19-27시간** |

---

## 11. 리스크 및 완화 전략

| 리스크                                | 영향 | 완화 전략                                |
| ------------------------------------- | ---- | ---------------------------------------- |
| 기존 데이터 마이그레이션 실패         | 높음 | 백업 자동화, 롤백 로직, 단계적 migration |
| Backend API 변경으로 인한 호환성 문제 | 중간 | Backward compatibility 유지, 점진적 배포 |
| SWR 캐시 동기화 문제                  | 중간 | 명확한 key 전략, 테스트 강화             |
| Tool execution context 버그           | 높음 | 철저한 integration test, 로깅 강화       |
| 성능 저하 (composite index)           | 낮음 | 성능 벤치마크, 인덱스 최적화             |

---

## 12. 성공 기준

- [ ] 모든 TypeScript 컴파일 에러 해결
- [ ] `pnpm refactor:validate` 통과
- [ ] 단위 테스트 커버리지 80% 이상
- [ ] 통합 테스트 모두 통과
- [ ] 기존 기능 회귀 없음
- [ ] 신규 thread 기능 정상 동작
- [ ] 마이그레이션 성공률 100%
- [ ] 문서 업데이트 완료

---

**다음 단계**: Phase 1 - Data Models부터 시작


---

# refactoring_20251101_1400.md

# MCP Server Management Architecture Refactoring

**Date:** 2025-11-01 14:00  
**Author:** Development Team  
**Status:** Planning

---

## 목적 (Purpose)

MCP 서버 설정을 독립적인 엔티티로 분리하여 관리의 유연성과 재사용성을 향상시킨다. 현재 Assistant가 MCP 설정을 직접 embedding하는 구조를 개선하여, MCP 서버를 중앙에서 관리하고 Assistant는 참조만 하도록 변경한다.

**주요 목표:**

- MCP 서버 설정의 중복 제거 및 중앙 관리
- Assistant 편집 UI 단순화 (MCP 설정 분리)
- MCP 서버 관리 전용 UI 제공 (Settings)
- 확장 가능한 MCP 서버 선택 인터페이스

---

## 현재 상태 / 문제점

### 현재 구조

```typescript
// Assistant가 MCPConfig를 직접 포함
interface Assistant {
  id?: string;
  name: string;
  systemPrompt: string;
  mcpConfig: MCPConfig; // ❌ 전체 설정 embedding
  // ...
}

interface MCPConfig {
  mcpServers?: Record<string, MCPServerConfigV2 | LegacyMCPServerConfig>;
}
```

### 문제점

1. **중복 저장**: 여러 Assistant가 동일한 MCP 서버 설정을 중복 저장

   ```typescript
   // Assistant A
   { mcpConfig: { mcpServers: { filesystem: {...} } } }

   // Assistant B (동일한 filesystem 설정 중복)
   { mcpConfig: { mcpServers: { filesystem: {...} } } }
   ```

2. **유지보수 어려움**: MCP 서버 설정 변경 시 모든 Assistant를 찾아 업데이트 필요

3. **UI 복잡도**: Assistant 편집 = MCP 전체 설정 편집
   - `MCPConfigEditor` 컴포넌트가 JSON 텍스트 편집
   - 사용자가 MCP 프로토콜 스펙을 이해해야 함

4. **관리 기능 부족**:
   - MCP 서버 목록 조회 불가
   - 서버별 활성화/비활성화 불가
   - 서버 재사용 어려움

### 데이터 흐름 (현재)

```
AssistantEditor
  ├─ MCPConfigEditor (JSON 텍스트)
  │   └─ assistant.mcpConfig 직접 수정
  │
  └─ AssistantContext.saveAssistant()
      └─ IndexedDB에 전체 assistant 저장 (mcpConfig 포함)

ChatContext
  └─ MCPServerContext.connectServers(assistant.mcpConfig)
      └─ Rust Backend: list_tools_from_config()
          └─ MCP 서버 프로세스 spawn
```

---

## 변경 후 상태 / 해결 판정 기준

### 새로운 구조

```typescript
// MCP 서버를 독립적인 엔티티로
interface MCPServerEntity {
  // DB metadata
  id: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;

  // MCP protocol spec
  name: string;
  transport: TransportConfig;
  authentication?: OAuthConfig;
  metadata?: ServerMetadata;
}

// Assistant는 MCP 서버 ID만 참조
interface Assistant {
  id?: string;
  name: string;
  systemPrompt: string;
  mcpServerIds?: string[]; // ✅ ID 배열만 저장
  // ...
}
```

### 데이터 흐름 (변경 후)

```
Settings > MCPServerManagement
  ├─ MCP 서버 목록 표시 (pagination)
  ├─ MCPServerDialog로 개별 서버 편집
  └─ MCPServerRegistryContext
      └─ IndexedDB mcpServers 테이블

AssistantEditor
  ├─ 활성 MCP 서버 목록 조회
  ├─ Checkbox로 서버 선택/해제
  └─ assistant.mcpServerIds 업데이트

ChatContext
  └─ MCPServerContext.connectServersFromAssistant(assistant)
      ├─ assistant.mcpServerIds로 DB 조회
      ├─ MCPServerEntity[] → MCPConfig 변환
      └─ Rust Backend: list_tools_from_config()
```

### 성공 판정 기준

✅ **기능적 요구사항**

- [ ] Settings에서 MCP 서버 CRUD 가능
- [ ] MCP 서버 활성화/비활성화 토글 가능
- [ ] Assistant 편집 시 활성 서버 목록에서 선택 가능
- [ ] 선택된 MCP 서버들이 Chat에서 정상 작동
- [ ] Pagination으로 다수의 MCP 서버 관리 가능

✅ **비기능적 요구사항**

- [ ] 중복 데이터 제거 (MCP 설정 단일 저장소)
- [ ] Assistant 편집 UI 단순화 (JSON 편집 제거)
- [ ] 검색 기능으로 서버 필터링 가능
- [ ] DB Schema 단일 버전으로 단순화

---

## 관련 코드 구조 및 동작 방식 (Birdeye View)

### 현재 아키텍처

```
Frontend (React)
├─ Context Layer
│   ├─ AssistantContext
│   │   ├─ currentAssistant (includes mcpConfig)
│   │   └─ saveAssistant() → IndexedDB
│   │
│   └─ MCPServerContext
│       ├─ connectServers(mcpConfig)
│       └─ executeToolCall()
│
├─ UI Layer
│   ├─ AssistantEditor
│   │   ├─ MCPConfigEditor (JSON 텍스트)
│   │   └─ EditorContext
│   │
│   └─ SettingsPage
│       └─ API Key Settings only
│
└─ Database Layer
    └─ IndexedDB (Dexie)
        ├─ assistants (includes mcpConfig)
        ├─ sessions
        └─ messages

Backend (Rust)
└─ MCP Commands
    └─ list_tools_from_config(MCPConfig)
        ├─ Parse V1/V2 configs
        ├─ Spawn MCP server processes
        └─ List tools from servers
```

### 새로운 아키텍처

```
Frontend (React)
├─ Context Layer
│   ├─ MCPServerRegistryContext ✅ NEW
│   │   ├─ allServers, activeServers
│   │   ├─ Pagination support (SWRInfinite 패턴 재사용)
│   │   └─ CRUD operations
│   │
│   ├─ AssistantContext (modified)
│   │   ├─ currentAssistant (mcpServerIds only)
│   │   └─ saveAssistant()
│   │
│   └─ MCPServerContext (modified)
│       ├─ connectServersFromAssistant(assistant)
│       │   └─ Load MCPServerEntity by IDs
│       └─ executeToolCall()
│
├─ UI Layer
│   ├─ Settings
│   │   └─ MCPServerManagement ✅ NEW
│   │       ├─ Server list (pagination)
│   │       ├─ Add/Edit/Delete buttons
│   │       └─ MCPServerDialog
│   │           └─ Transport-specific forms
│   │
│   └─ AssistantEditor (simplified)
│       ├─ Server selection (checkboxes)
│       ├─ Search filter
│       └─ NO MCPConfigEditor
│
└─ Database Layer
    └─ IndexedDB (Dexie)
        ├─ assistants (mcpServerIds only)
        ├─ mcpServers ✅ NEW
        ├─ sessions
        └─ messages

Backend (Rust)
└─ MCP Commands (unchanged)
    └─ list_tools_from_config(MCPConfig)
```

---

## 수정이 필요한 코드 및 코드 스니핏

### Phase 1: 타입 정의

#### 1.1 MCPServerEntity 추가

**파일:** `src/models/chat.ts`

```typescript
// 추가: MCP 서버 엔티티
export interface MCPServerEntity {
  // Database metadata
  id: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;

  // MCP Protocol spec (from MCPServerConfigV2)
  name: string;
  transport: TransportConfig;
  authentication?: OAuthConfig;
  metadata?: ServerMetadata;
}
```

#### 1.2 Assistant 타입 수정

**파일:** `src/models/chat.ts`

```typescript
// 수정: mcpConfig 제거, mcpServerIds 추가
export interface Assistant {
  id?: string;
  name: string;
  description?: string;
  avatar?: string;
  systemPrompt: string;

  mcpServerIds?: string[]; // ✅ 추가
  // mcpConfig: MCPConfig;  // ❌ 제거

  localServices?: string[];
  allowedBuiltInServiceAliases?: string[];
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
}
```

### Phase 2: Database Schema

#### 2.1 Schema 단순화 및 mcpServers 테이블 추가

**파일:** `src/lib/db/service.ts`

````typescript
// 수정: 단일 버전으로 squash
constructor() {
  super('MCPAgentDB');

  this.version(1).stores({
    assistants: '&id, createdAt, updatedAt, name',
    mcpServers: '&id, name, createdAt, updatedAt, isActive',  // ✅ 추가
    sessions: '&id, createdAt, updatedAt',
    messages: '&id, sessionId, [sessionId+threadId], createdAt',
    playbooks: '&id, agentId, createdAt, updatedAt, goal',
    objects: '&key, createdAt, updatedAt',
  });
}

// Table 선언 추가
#### 4.1 MCPServerManagement 생성
**파일:** `src/features/settings/MCPServerManagement.tsx` (신규)

```typescript
import { useMemo, useState } from 'react';
import useSWRInfinite from 'swr/infinite';
import { Plus } from 'lucide-react';
import { createId } from '@paralleldrive/cuid2';
import { MCPServerEntity } from '@/models/chat';
import { dbService } from '@/lib/db/service';
import { useMCPServerRegistry } from '@/context/MCPServerRegistryContext';
import { Button, Card, CardHeader, CardTitle, CardContent } from '@/components/ui';
import { MCPServerDialog } from './MCPServerDialog';

export function MCPServerManagement() {
  const { saveServer, deleteServer, toggleActive } = useMCPServerRegistry();

  // Follow SessionContext pattern: useSWRInfinite + Page<T>
  const { data, isLoading, isValidating, setSize } = useSWRInfinite(
    (pageIndex) => ['mcpServers', pageIndex],
    async ([, pageIndex]) => {
      // getPage is 1-based; pass pageIndex + 1
      return dbService.mcpServers.getPage(pageIndex + 1, 10);
    },
  );

  const pages = data ?? [];
  const servers = useMemo(() => pages.flatMap((p) => p.items), [pages]);
  const hasNextPage = useMemo(
    () => !(pages.length > 0 && !pages[pages.length - 1].hasNextPage),
    [pages],
  );

  const [editingServer, setEditingServer] = useState<MCPServerEntity | null>(
    null,
  );

  const handleCreateNew = () => {
    const newServer: MCPServerEntity = {
      id: createId(),
      name: 'New Server',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      transport: {
        type: 'stdio',
        command: 'npx',
        args: [],
      },
    };
    setEditingServer(newServer);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">MCP Server Management</h2>
        <Button onClick={handleCreateNew}>
          <Plus className="w-4 h-4 mr-2" />
          Add Server
        </Button>
      </div>

      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <>
          <div className="grid gap-4">
            {servers.map((server) => (
              <Card key={server.id}>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div className="flex-1">
                    <CardTitle>{server.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {server.metadata?.description || 'No description'}
                    </p>
                  </div>
                  <Switch
                    checked={server.isActive}
                    onCheckedChange={(checked) =>
                      toggleActive(server.id, checked)
                    }
                  />
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingServer(server)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (confirm(`Delete server "${server.name}"?`)) {
                          deleteServer(server.id);
                        }
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {hasNextPage && (
            <div className="flex justify-center pt-2">
              <Button
                variant="outline"
                disabled={isValidating}
                onClick={() => setSize((s) => s + 1)}
              >
                {isValidating ? 'Loading…' : 'Load more'}
              </Button>
            </div>
          )}
        </>
      )}

      {editingServer && (
        <MCPServerDialog
          server={editingServer}
          onSave={async (server) => {
            await saveServer(server);
            setEditingServer(null);
          }}
          onCancel={() => setEditingServer(null)}
        />
      )}
    </div>
  );
}
````

// Pagination (Settings용)
servers: MCPServerEntity[];
currentPage: number;
totalPages: number;
pageSize: number;
loading: boolean;
error?: string;

// Actions
loadPage: (page: number) => Promise<void>;
saveServer: (server: MCPServerEntity) => Promise<void>;
deleteServer: (id: string) => Promise<void>;
toggleActive: (id: string, active: boolean) => Promise<void>;
refreshAll: () => Promise<void>;
}

const MCPServerRegistryContext = createContext<MCPServerRegistryContextType | undefined>(undefined);

export const MCPServerRegistryProvider = ({ children }: { children: React.ReactNode }) => {
const [allServers, setAllServers] = useState<MCPServerEntity[]>([]);
const [servers, setServers] = useState<MCPServerEntity[]>([]);
const [currentPage, setCurrentPage] = useState(1);
const [pageSize] = useState(10);
const [loading, setLoading] = useState(false);
const [error, setError] = useState<string>();

// 전체 서버 로드 (캐시)
const refreshAll = useCallback(async () => {
try {
const all = await dbUtils.getAllMCPServers();
setAllServers(all);
} catch (err) {
logger.error('Failed to load all servers', err);
setError(err instanceof Error ? err.message : 'Unknown error');
}
}, []);

// Pagination 로드
const loadPage = useCallback(async (page: number) => {
setLoading(true);
try {
const result = await dbService.mcpServers.getPage(page, pageSize);
setServers(result.items);
setCurrentPage(page);
setError(undefined);
} catch (err) {
logger.error('Failed to load page', err);
setError(err instanceof Error ? err.message : 'Unknown error');
} finally {
setLoading(false);
}
}, [pageSize]);

const saveServer = useCallback(async (server: MCPServerEntity) => {
await dbService.mcpServers.upsert(server);
await refreshAll();
await loadPage(currentPage);
}, [refreshAll, loadPage, currentPage]);

const deleteServer = useCallback(async (id: string) => {
await dbService.mcpServers.delete(id);
await refreshAll();
await loadPage(currentPage);
}, [refreshAll, loadPage, currentPage]);

const toggleActive = useCallback(async (id: string, active: boolean) => {
const server = allServers.find(s => s.id === id);
if (server) {
await saveServer({ ...server, isActive: active });
}
}, [allServers, saveServer]);

const activeServers = useMemo(
() => allServers.filter(s => s.isActive),
[allServers]
);

const totalPages = useMemo(
() => Math.ceil(allServers.length / pageSize),
[allServers.length, pageSize]
);

// 초기 로드
useEffect(() => {
refreshAll();
loadPage(1);
}, [refreshAll, loadPage]);

return (
<MCPServerRegistryContext.Provider value={{
      allServers,
      activeServers,
      servers,
      currentPage,
      totalPages,
      pageSize,
      loading,
      error,
      loadPage,
      saveServer,
      deleteServer,
      toggleActive,
      refreshAll,
    }}>
{children}
</MCPServerRegistryContext.Provider>
);
};

export function useMCPServerRegistry() {
const context = useContext(MCPServerRegistryContext);
if (!context) {
throw new Error('useMCPServerRegistry must be used within MCPServerRegistryProvider');
}
return context;
}

````

#### 3.x 캐시 무효화 전략 (SWR + 이벤트)

레지스트리 변경 시 다음을 수행해 목록/선택/연결 상태를 일관성 있게 갱신합니다.

- 목록 UI(Settings): SWR 키 `['mcpServers', pageIndex]` 전역 무효화 → useSWRInfinite가 재검증
- 선택 UI(AssistantEditor): 레지스트리 컨텍스트의 `allServers/activeServers`를 즉시 새로고침
- 연결 상태(Chat): 현재 Assistant가 참조하는 서버에 영향이 있는 경우 재연결 트리거

구현 요지:

```typescript
// src/context/MCPServerRegistryContext.tsx
import { mutate } from 'swr';

const invalidateMCPServerPages = async () => {
  await mutate((key) => Array.isArray(key) && key[0] === 'mcpServers');
};

const broadcastChange = () => {
  if (typeof window !== 'undefined') {
    try {
      window.dispatchEvent(new CustomEvent('libragent:mcp-servers-changed'));
    } catch {}
  }
};

const saveServer = useCallback(async (server: MCPServerEntity) => {
  await dbService.mcpServers.upsert(server);
  await refreshAll();
  await invalidateMCPServerPages();
  broadcastChange();
}, [refreshAll]);

const deleteServer = useCallback(async (id: string) => {
  await dbService.mcpServers.delete(id);
  await refreshAll();
  await invalidateMCPServerPages();
  broadcastChange();
}, [refreshAll]);

const toggleActive = useCallback(async (id: string, active: boolean) => {
  const found = allServers.find((s) => s.id === id);
  if (!found) return;
  await saveServer({ ...found, isActive: active });
  await invalidateMCPServerPages();
  broadcastChange();
}, [allServers, saveServer]);
````

```typescript
// src/context/AssistantContext.tsx (연결 재시도)
useEffect(() => {
  const handler = () => {
    const cur = currentAssistantRef.current;
    if (cur) {
      connectServersFromAssistant(cur);
    }
  };
  window.addEventListener('libragent:mcp-servers-changed', handler);
  return () =>
    window.removeEventListener('libragent:mcp-servers-changed', handler);
}, [connectServersFromAssistant]);
```

```typescript
// src/features/settings/MCPServerManagement.tsx
// 별도 무효화 호출 불필요 — RegistryContext가 mutate 전파, 여기서는 useSWRInfinite가 자동 재검증
```

#### 3.2 MCPServerContext 수정

**파일:** `src/context/MCPServerContext.tsx`

```typescript
// 수정: connectServers 대신 connectServersFromAssistant
const connectServersFromAssistant = useCallback(
  async (assistant: Assistant) => {
    setError(undefined);

    if (!assistant.mcpServerIds || assistant.mcpServerIds.length === 0) {
      setAvailableTools([]);
      setServerStatus({});
      return;
    }

    try {
      // 1. DB에서 서버 엔티티 조회
      const entities = await dbUtils.getMCPServersByIds(assistant.mcpServerIds);

      // 2. 활성화된 서버만 필터링
      const activeEntities = entities.filter((e) => e.isActive);

      if (activeEntities.length === 0) {
        setAvailableTools([]);
        setServerStatus({});
        return;
      }

      // 3. MCPConfig 구성 (DB metadata 제외)
      const mcpConfig: MCPConfig = {
        mcpServers: Object.fromEntries(
          activeEntities.map((entity) => [
            entity.name,
            {
              name: entity.name,
              transport: entity.transport,
              authentication: entity.authentication,
              metadata: entity.metadata,
            } as MCPServerConfigV2,
          ]),
        ),
      };

      // 4. 기존 로직 실행
      const serverStatus: Record<string, boolean> = {};
      Object.keys(mcpConfig.mcpServers).forEach((name) => {
        serverStatus[name] = false;
      });

      setServerStatus(serverStatus);
      const rawToolsByServer = await listToolsFromConfig(mcpConfig);
      toolsByServer.current = rawToolsByServer;

      const availableTools: MCPTool[] = Object.entries(
        rawToolsByServer,
      ).flatMap(([serverName, tools]) => {
        if (!aliasToIdTableRef.current.has(serverName)) {
          aliasToIdTableRef.current.set(toValidJsName(serverName), serverName);
        }
        return tools.map((t) => ({
          ...t,
          name: `${toValidJsName(serverName)}__${t.name}`,
        }));
      });

      setAvailableTools(availableTools);

      const connectedServers = await getConnectedServers();
      for (const serverName of connectedServers) {
        if (Object.prototype.hasOwnProperty.call(serverStatus, serverName)) {
          serverStatus[serverName] = true;
        }
      }
      setServerStatus({ ...serverStatus });

      logger.debug(
        `Total tools loaded: ${availableTools.length} across ${Object.keys(rawToolsByServer).length} servers`,
      );
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      setError(errorMessage);
      logger.error('Error connecting servers from assistant:', { error });
      setAvailableTools([]);
      setServerStatus({});
    }
  },
  [listToolsFromConfig, getConnectedServers],
);

// Context value 업데이트
const value: MCPServerContextType = useMemo(
  () => ({
    availableTools,
    isLoading,
    error,
    getAvailableTools,
    status: serverStatus,
    connectServersFromAssistant, // ✅ 변경
    executeToolCall,
    sampleFromModel,
  }),
  [
    availableTools,
    isLoading,
    error,
    serverStatus,
    getAvailableTools,
    connectServersFromAssistant, // ✅ 변경
    executeToolCall,
    sampleFromModel,
  ],
);
```

#### 3.3 AssistantContext 수정

**파일:** `src/context/AssistantContext.tsx`

```typescript
// 수정: connectServers → connectServersFromAssistant
const { connectServersFromAssistant } = useMCPServer();

useEffect(() => {
  currentAssistantRef.current = currentAssistant;
  if (currentAssistant) {
    connectServersFromAssistant(currentAssistant); // ✅ 변경
  }
}, [currentAssistant, connectServersFromAssistant]);
```

### Phase 4: UI Components

#### 4.1 MCPServerManagement 생성

**파일:** `src/features/settings/MCPServerManagement.tsx` (신규)

```typescript
import { useState } from 'react';
import { Plus } from 'lucide-react';
import { createId } from '@paralleldrive/cuid2';
import { MCPServerEntity } from '@/models/chat';
import { useMCPServerRegistry } from '@/context/MCPServerRegistryContext';
import { Button, Card, CardHeader, CardTitle, CardContent } from '@/components/ui';
import { MCPServerDialog } from './MCPServerDialog';
import { Pagination } from '@/components/ui/pagination';

export function MCPServerManagement() {
  const {
    servers,
    currentPage,
    totalPages,
    loading,
    loadPage,
    saveServer,
    deleteServer,
    toggleActive,
  } = useMCPServerRegistry();

  const [editingServer, setEditingServer] = useState<MCPServerEntity | null>(null);

  const handleCreateNew = () => {
    const newServer: MCPServerEntity = {
      id: createId(),
      name: 'New Server',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      transport: {
        type: 'stdio',
        command: 'npx',
        args: [],
      },
    };
    setEditingServer(newServer);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">MCP Server Management</h2>
        <Button onClick={handleCreateNew}>
          <Plus className="w-4 h-4 mr-2" />
          Add Server
        </Button>
      </div>

      {loading ? (
        <div>Loading...</div>
      ) : (
        <>
          <div className="grid gap-4">
            {servers.map(server => (
              <Card key={server.id}>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div className="flex-1">
                    <CardTitle>{server.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {server.metadata?.description || 'No description'}
                    </p>
                  </div>
                  <Switch
                    checked={server.isActive}
                    onCheckedChange={(checked) => toggleActive(server.id, checked)}
                  />
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingServer(server)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (confirm(`Delete server "${server.name}"?`)) {
                          deleteServer(server.id);
                        }
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {totalPages > 1 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={loadPage}
            />
          )}
        </>
      )}

      {editingServer && (
        <MCPServerDialog
          server={editingServer}
          onSave={async (server) => {
            await saveServer(server);
            setEditingServer(null);
          }}
          onCancel={() => setEditingServer(null)}
        />
      )}
    </div>
  );
}
```

#### 4.2 MCPServerDialog 생성

**파일:** `src/features/settings/MCPServerDialog.tsx` (신규)

```typescript
import { useState } from 'react';
import { MCPServerEntity } from '@/models/chat';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  Button,
  InputWithLabel,
  TextareaWithLabel,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui';

interface MCPServerDialogProps {
  server: MCPServerEntity;
  onSave: (server: MCPServerEntity) => Promise<void>;
  onCancel: () => void;
}

export function MCPServerDialog({ server, onSave, onCancel }: MCPServerDialogProps) {
  const [draft, setDraft] = useState(server);

  return (
    <Dialog open onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {server.id ? 'Edit MCP Server' : 'Add MCP Server'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <InputWithLabel
            label="Server Name *"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            placeholder="e.g., filesystem, github"
          />

          <TextareaWithLabel
            label="Description"
            value={draft.metadata?.description || ''}
            onChange={(e) => setDraft({
              ...draft,
              metadata: { ...draft.metadata, description: e.target.value }
            })}
            placeholder="Optional description for this server"
          />

          <div>
            <label className="block text-sm font-medium mb-2">Transport Type *</label>
            <Select
              value={draft.transport.type}
              onValueChange={(type: 'stdio' | 'http') => {
                if (type === 'stdio') {
                  setDraft({
                    ...draft,
                    transport: { type: 'stdio', command: '', args: [] }
                  });
                } else {
                  setDraft({
                    ...draft,
                    transport: { type: 'http', url: '' }
                  });
                }
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stdio">stdio</SelectItem>
                <SelectItem value="http">http</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {draft.transport.type === 'stdio' && (
            <>
              <InputWithLabel
                label="Command *"
                value={draft.transport.command}
                onChange={(e) => setDraft({
                  ...draft,
                  transport: { ...draft.transport, command: e.target.value }
                })}
                placeholder="e.g., npx, node, python"
              />

              <InputWithLabel
                label="Arguments"
                value={draft.transport.args?.join(' ') || ''}
                onChange={(e) => setDraft({
                  ...draft,
                  transport: {
                    ...draft.transport,
                    args: e.target.value.split(' ').filter(Boolean)
                  }
                })}
                placeholder="e.g., -y @modelcontextprotocol/server-filesystem /tmp"
              />
            </>
          )}

          {draft.transport.type === 'http' && (
            <InputWithLabel
              label="URL *"
              value={draft.transport.url}
              onChange={(e) => setDraft({
                ...draft,
                transport: { ...draft.transport, url: e.target.value }
              })}
              placeholder="https://api.example.com/mcp"
            />
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            onClick={() => onSave(draft)}
            disabled={!draft.name || (draft.transport.type === 'stdio' && !draft.transport.command)}
          >
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
```

#### 4.3 AssistantEditor 수정

**파일:** `src/features/assistant/AssistantEditor.tsx`

```typescript
// 수정: MCPConfigEditor 제거, 서버 선택 UI 추가
import { useState, useEffect } from 'react';
import { useEditor } from '@/context/EditorContext';
import { Assistant } from '@/models/chat';
import { useMCPServerRegistry } from '@/context/MCPServerRegistryContext';
import { Checkbox, Input } from '@/components/ui';

export default function AssistantEditor() {
  const { draft, update } = useEditor<Assistant>();
  const { activeServers } = useMCPServerRegistry();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredServers = activeServers.filter(s =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.metadata?.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleServerToggle = (serverId: string, enabled: boolean) => {
    update((draft) => {
      if (!draft.mcpServerIds) draft.mcpServerIds = [];

      if (enabled) {
        if (!draft.mcpServerIds.includes(serverId)) {
          draft.mcpServerIds.push(serverId);
        }
      } else {
        draft.mcpServerIds = draft.mcpServerIds.filter(id => id !== serverId);
      }
    });
  };

  return (
    <div className="w-full p-4 space-y-4">
      <InputWithLabel
        label="Assistant Name *"
        value={draft?.name || ''}
        onChange={(e) => update((draft) => { draft.name = e.target.value; })}
        placeholder="Enter assistant name..."
      />

      <TextareaWithLabel
        label="System Prompt *"
        value={draft?.systemPrompt || ''}
        onChange={(e) => update((draft) => { draft.systemPrompt = e.target.value; })}
        placeholder="Describe the AI's role and behavior..."
        className="h-32"
      />

      <BuiltInToolsEditor />
      <LocalServicesEditor />

      {/* ✅ MCP 서버 선택 UI (MCPConfigEditor 대체) */}
      <div>
        <label className="block text-sm font-medium mb-2">
          MCP Servers
        </label>

        {activeServers.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No active MCP servers. <Link to="/settings">Add servers in Settings</Link>
          </p>
        ) : (
          <>
            <Input
              placeholder="Search servers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="mb-2"
            />

            <div className="max-h-64 overflow-y-auto border rounded-md p-2 space-y-2">
              {filteredServers.map(server => (
                <div
                  key={server.id}
                  className="flex items-start gap-2 p-2 hover:bg-accent rounded"
                >
                  <Checkbox
                    checked={draft.mcpServerIds?.includes(server.id) || false}
                    onCheckedChange={(checked) =>
                      handleServerToggle(server.id, checked as boolean)
                    }
                  />
                  <div className="flex-1">
                    <div className="font-medium">{server.name}</div>
                    {server.metadata?.description && (
                      <div className="text-xs text-muted-foreground">
                        {server.metadata.description}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ❌ MCPConfigEditor 컴포넌트 사용 제거
```

#### 4.4 SettingsPage 탭 추가

**파일:** `src/features/settings/SettingsPage.tsx`

```typescript
// 추가: MCP Servers 탭
import { MCPServerManagement } from './MCPServerManagement';

<Tabs defaultValue="api-key">
  <TabsList>
    <TabsTrigger value="api-key">API Keys</TabsTrigger>
    <TabsTrigger value="mcp-servers">MCP Servers</TabsTrigger>  {/* ✅ 추가 */}
    <TabsTrigger value="conversation-model">Conversation & Model</TabsTrigger>
    <TabsTrigger value="data-reset">Data & Reset</TabsTrigger>
  </TabsList>

  <TabsContent value="mcp-servers">
    <MCPServerManagement />  {/* ✅ 추가 */}
  </TabsContent>

  {/* ... 기존 탭들 */}
</Tabs>
```

### Phase 5: Provider 구조 업데이트

#### 5.1 App.tsx Provider 추가

**파일:** `src/app/App.tsx`

```typescript
// 추가: MCPServerRegistryProvider
import { MCPServerRegistryProvider } from '@/context/MCPServerRegistryContext';

<MCPServerRegistryProvider>  {/* ✅ 추가 */}
  <AssistantContextProvider>
    <MCPServerProvider>
      <WebMCPProvider>
        {/* ... 기존 컴포넌트들 */}
      </WebMCPProvider>
    </MCPServerProvider>
  </AssistantContextProvider>
</MCPServerRegistryProvider>
```

##### 권장 Provider 스택 (현재 구조 기반)

아래 순서는 현재 `App.tsx`의 실제 구성(첨부 코드 기준)을 따르며, `MCPServerRegistryProvider`의 정확한 위치를 명시합니다.

```
SettingsProvider
  └─ MCPServerRegistryProvider   ← 신규 (Registry CRUD/활성 목록/무효화 이벤트 제공)
      └─ MCPServerProvider       ← 런타임 MCP 연결(도구 로드/호출)
          └─ SystemPromptProvider
              └─ AssistantContextProvider
                  └─ SessionContextProvider
                      └─ BuiltInToolProvider
                          └─ WebMCPProvider
                              ├─ WebMCPServiceRegistry (servers=["planning","playbook","ui"])
                              ├─ BrowserToolProvider
                              └─ RustMCPToolProvider
                                  └─ SessionHistoryProvider
                                      └─ ResourceAttachmentProvider
                                          └─ ModelOptionsProvider
                                              └─ SidebarProvider
                                                  └─ DnDContextProvider
                                                      └─ App UI (Sidebar, Header, Routes, Toaster)
```

이유:

- Settings > MCP 서버 관리와 Assistant 서버 선택 UI가 레지스트리 컨텍스트를 사용하므로 앱 전반에서 접근 가능해야 합니다.
- AssistantContext는 `libragent:mcp-servers-changed` 이벤트를 구독해 재연결을 트리거하므로, 레지스트리와 MCPServerProvider 모두 상위에 존재해야 합니다.
- MCPServerProvider는 런타임 연결/도구 로딩을 담당하므로 레지스트리 변경(활성/비활성, CRUD) 이후 재연결 시나리오에 대응합니다.

##### App.tsx 적용 예시 (발췌)

```typescript
// src/app/App.tsx (excerpt)
import { MCPServerRegistryProvider } from '@/context/MCPServerRegistryContext';

function App() {
  return (
    <div className="h-screen w-full">
      <SettingsProvider>
        {/* ✅ 신규 Provider: 레지스트리 */}
        <MCPServerRegistryProvider>
          <MCPServerProvider>
            <SystemPromptProvider>
              <AssistantContextProvider>
                <SessionContextProvider>
                  <BuiltInToolProvider>
                    <WebMCPProvider>
                      <WebMCPServiceRegistry servers={["planning", "playbook", "ui"]} />
                      <BrowserToolProvider />
                      <RustMCPToolProvider />
                      <SessionHistoryProvider>
                        <ResourceAttachmentProvider>
                          <ModelOptionsProvider>
                            <SidebarProvider>
                              <DnDContextProvider>
                                {/* ... Sidebar, Header, Routes ... */}
                              </DnDContextProvider>
                            </SidebarProvider>
                            <Toaster />
                          </ModelOptionsProvider>
                        </ResourceAttachmentProvider>
                      </SessionHistoryProvider>
                    </WebMCPProvider>
                  </BuiltInToolProvider>
                </SessionContextProvider>
              </AssistantContextProvider>
            </SystemPromptProvider>
          </MCPServerProvider>
        </MCPServerRegistryProvider>
      </SettingsProvider>
    </div>
  );
}
```

---

## 재사용 가능한 연관 코드

### 기존 컴포넌트 재사용

**1. Pagination Component**

- **경로:** `src/components/ui/pagination.tsx` (필요시 생성)
- **용도:** MCPServerManagement에서 페이지네이션 UI

**2. Card Components**

- **경로:** `src/components/ui/card.tsx`
- **용도:** 서버 목록 표시

**3. Dialog Components**

- **경로:** `src/components/ui/dialog.tsx`
- **용도:** MCPServerDialog

**4. Form Components**

- **경로:** `src/components/ui/`
- **컴포넌트:** Input, Textarea, Select, Checkbox, Switch
- **용도:** 서버 편집 폼

### 유틸리티 함수

**1. ID 생성**

```typescript
import { createId } from '@paralleldrive/cuid2';
```

**2. Logger**

```typescript
import { getLogger } from '@/lib/logger';
const logger = getLogger('ComponentName');
```

**3. 이름 변환**

```typescript
import { toValidJsName } from '@/lib/utils';
```

---

## Test Code 가이드

### 단위 테스트

**1. CRUD Operations**

```typescript
// src/lib/db/crud.test.ts
describe('mcpServersCRUD', () => {
  it('should create a new MCP server', async () => {
    const server: MCPServerEntity = {
      id: 'test-id',
      name: 'test-server',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      transport: { type: 'stdio', command: 'test' },
    };

    await mcpServersCRUD.upsert(server);
    const retrieved = await mcpServersCRUD.read('test-id');

    expect(retrieved).toBeDefined();
    expect(retrieved?.name).toBe('test-server');
  });

  it('should support pagination', async () => {
    const page = await mcpServersCRUD.getPage(1, 10);
    expect(page.items).toBeInstanceOf(Array);
    expect(page.page).toBe(1);
  });
});
```

**2. Context Operations**

```typescript
// src/context/MCPServerRegistryContext.test.tsx
describe('MCPServerRegistryContext', () => {
  it('should load all servers on mount', async () => {
    const { result } = renderHook(() => useMCPServerRegistry(), {
      wrapper: MCPServerRegistryProvider,
    });

    await waitFor(() => {
      expect(result.current.allServers).toBeDefined();
    });
  });

  it('should filter active servers', async () => {
    const { result } = renderHook(() => useMCPServerRegistry(), {
      wrapper: MCPServerRegistryProvider,
    });

    await waitFor(() => {
      const active = result.current.activeServers;
      expect(active.every((s) => s.isActive)).toBe(true);
    });
  });
});
```

### 통합 테스트

**1. Assistant MCP Server Connection**

```typescript
// src/context/AssistantContext.integration.test.tsx
describe('Assistant MCP Server Integration', () => {
  it('should connect MCP servers from assistant', async () => {
    // 1. MCP 서버 생성
    const server: MCPServerEntity = {
      /* ... */
    };
    await dbService.mcpServers.upsert(server);

    // 2. Assistant 생성 (서버 참조)
    const assistant: Assistant = {
      /* ... */
      mcpServerIds: [server.id],
    };

    // 3. Assistant 활성화
    const { result } = renderHook(() => useAssistantContext());
    act(() => {
      result.current.setCurrentAssistant(assistant);
    });

    // 4. MCP 도구 로드 확인
    await waitFor(() => {
      const { availableTools } = useMCPServer();
      expect(availableTools.length).toBeGreaterThan(0);
    });
  });
});
```

### E2E 테스트 시나리오

**1. MCP Server Management Flow**

```typescript
test('should manage MCP servers end-to-end', async () => {
  // 1. Settings 이동
  await page.goto('/settings');
  await page.click('[data-testid="mcp-servers-tab"]');

  // 2. 서버 추가
  await page.click('[data-testid="add-server-btn"]');
  await page.fill('[data-testid="server-name"]', 'test-server');
  await page.fill('[data-testid="command"]', 'npx');
  await page.click('[data-testid="save-btn"]');

  // 3. 서버 목록 확인
  const serverCard = await page.waitForSelector(
    '[data-testid="server-card-test-server"]',
  );
  expect(serverCard).toBeTruthy();

  // 4. Assistant에서 서버 선택
  await page.goto('/assistants');
  await page.click('[data-testid="create-assistant"]');
  await page.click('[data-testid="server-checkbox-test-server"]');
  await page.click('[data-testid="save-assistant"]');

  // 5. Chat에서 도구 사용 가능 확인
  // ...
});
```

---

## Clarification Q-list

### Q1: 기존 Assistant의 mcpConfig 마이그레이션

**질문:** 기존에 저장된 Assistant들의 `mcpConfig` 데이터를 어떻게 처리할 것인가?

**옵션:**

- A) 앱 시작 시 자동 마이그레이션 (한 번만 실행)
- B) 사용자에게 마이그레이션 프롬프트 표시
- C) 기존 데이터 무시 (새로 설정 필요)

**권장:** Option A (자동 마이그레이션)

- localStorage에 마이그레이션 완료 플래그 저장
- 한 번만 실행되도록 보장

**답변:** C 기존 데이터 무시

### Q2: MCP 서버 중복 처리

**질문:** 동일한 name을 가진 MCP 서버가 여러 개 생성될 수 있는가?

**옵션:**

- A) name을 unique constraint로 지정 (중복 불가)
- B) 중복 허용 (사용자 책임)
- C) 경고만 표시 (저장은 가능)

**권장:** Option A (중복 불가)

- DB schema에 unique index 추가
- 저장 시 중복 체크 및 에러 표시

**답변:** A 중복 불가

### Q3: MCP 서버 삭제 시 Assistant 처리

**질문:** 어떤 Assistant가 참조하는 MCP 서버를 삭제하려 할 때?

**옵션:**

- A) 삭제 불가 (참조 있음 경고)
- B) 강제 삭제 + Assistant의 참조 자동 제거
- C) Cascade delete (Assistant도 삭제)

**권장:** Option B (강제 삭제 + 참조 제거)

- 삭제 전 경고 메시지 표시
- 삭제 후 Assistant의 mcpServerIds에서 해당 ID 제거

**답변:** A 삭제 불가 / 참조 있음 경고

### Q4: Transport 타입별 세부 설정 UI

**질문:** HTTP Transport의 OAuth, SSE 등 고급 설정을 모두 UI로 제공할 것인가?

**옵션:**

- A) 모든 필드 UI 제공 (복잡)
- B) 기본 필드만 UI, 고급 설정은 JSON 편집
- C) Phase 1은 stdio만, Phase 2에서 HTTP 추가

**권장:** Option C (단계적 구현)

- Phase 1: stdio transport만 완전 지원
- Phase 2: HTTP transport 기본 필드
- Phase 3: OAuth/SSE 등 고급 기능

**답변:** C 우선 stdio만 지원

### Q5: Pagination vs Infinite Scroll

**질문:** MCP 서버 목록 UI에서 어떤 방식을 사용할 것인가?

**옵션:**

- A) Pagination (페이지 번호)
- B) Infinite Scroll
- C) Load More 버튼

**권장:** Option A (Pagination)

- 사용자가 현재 위치 파악 쉬움
- Settings 화면 특성상 적합
- 구현 단순
  **답변:** A Pagination

---

## 작업 순서 제안

1. **Phase 1-2 (Database)** - 1일
   - 타입 정의
   - DB Schema 추가
   - CRUD 구현

2. **Phase 3 (Context)** - 1일

- MCPServerRegistryContext
- MCPServerContext 수정
- AssistantContext 수정

3. **Phase 4 (UI - Settings)** - 1일
   - MCPServerManagement
   - MCPServerDialog
   - SettingsPage 탭 추가

4. **Phase 4 (UI - Assistant)** - 0.5일
   - AssistantEditor 수정
   - MCPConfigEditor 제거

5. **Phase 5 (Integration)** - 0.5일
   - Provider 구조 업데이트
   - 통합 테스트

6. **Testing & Polish** - 1일
   - 단위 테스트
   - 통합 테스트
   - 버그 수정

**총 예상 기간:** 5일

---

## 성공 메트릭

- [ ] MCP 서버 CRUD 동작 확인
- [ ] Assistant 편집에서 서버 선택 가능
- [ ] Chat에서 선택된 서버의 도구 사용 가능
- [ ] 중복 데이터 제거 확인 (DB 크기 감소)
- [ ] UI 복잡도 감소 (JSON 편집 제거)
- [ ] 모든 테스트 통과

---

## 추가 고려사항

### 성능

- IndexedDB 조회 최적화 (인덱스 활용)
- Context에서 불필요한 re-render 방지 (useMemo, useCallback)

### 보안

- MCP 서버 설정에 민감한 정보(API 키) 포함 시 암호화 고려

### UX

- 로딩 상태 표시 (Skeleton, Spinner)
- 에러 메시지 명확화
- 성공/실패 Toast 알림

### 확장성

- Future: MCP 서버 공유/Export 기능
- Future: 서버 템플릿 (preset configurations)
- Future: 서버 검색 및 필터링 (태그 시스템)


---

# refactoring_20251011_1430.md

# Playbook Store 리팩토링 계획: list_playbooks와 show_playbooks 분리 + Pagination 추가

## 작업의 목적

현재 `list_playbooks` 툴은 텍스트 프롬프트와 UI 리소스(HTML)를 함께 반환하는 multipart 응답을 생성합니다. 이는 두 가지 서로 다른 책임을 하나의 툴에서 처리하고 있어 다음과 같은 문제가 있습니다:

1. **책임의 혼재**: AI 에이전트가 텍스트 프롬프트만 필요한 경우에도 UI 리소스가 함께 생성됨
2. **유연성 부족**: 클라이언트가 텍스트 전용 응답 또는 UI 전용 응답을 선택할 수 없음
3. **성능 오버헤드**: 불필요한 HTML 생성 및 UIResource 객체 생성 비용
4. **에이전트 실행 중단**: UIResource 포함 시 에이전트 실행이 일시 중지되어, 자율적인 playbook 조회 불가

본 리팩토링의 목적은:

- `list_playbooks`: 텍스트 프롬프트 전용 응답으로 단순화 (AI 에이전트가 작업 중단 없이 조회 가능)
- `show_playbooks`: UI 리소스 생성 전용 툴로 분리 (사용자 인터랙션용, 에이전트 일시 중지)
- `get_playbook_page`: 페이지네이션 내비게이션 전용 툴 추가 (UI 버튼 클릭용)
- **Agent Context 최적화**: 모든 텍스트 응답이 명확한 맥락 정보 제공 (도구명, 결과 요약, 다음 액션 힌트)
- 관심사의 분리(Separation of Concerns)를 통한 코드 유지보수성 향상

## 현재 상태 / 문제점

### 현재 코드 구조 (Birdeye View)

`playbook-store.ts`는 WebMCP 서버로서 다음과 같은 구조를 가지고 있습니다:

```
playbookStore (WebMCPServer)
├── tools: MCPTool[] (6개 툴 정의)
│   ├── create_playbook
│   ├── list_playbooks  ⚠️ (리팩토링 대상)
│   ├── get_playbook
│   ├── select_playbook
│   ├── update_playbook
│   └── delete_playbook
├── callTool(name, args) -> MCPResponse
│   └── switch-case로 각 툴 처리
└── switchContext(context) -> void
    └── currentAssistantId 설정
```

### Helper Functions (재사용 가능 컴포넌트)

```typescript
// 텍스트 포맷팅
formatPlaybooksList(items: PlaybookRecord[]): string
  - 목록을 번호가 매겨진 텍스트로 변환

// UI 생성
buildListItemsHtml(items: PlaybookRecord[]): string
  - HTML 카드 목록 생성 (Select/Delete 버튼 포함)

buildUiHtml(listItemsHtml: string): string
  - 완전한 HTML 문서 생성 (스크립트 포함)

createUiResourceFromHtml(html: string): UIResource
  - HTML을 UIResource로 래핑 (serviceInfo 포함)

makeListMultipartResponse(items, text, structured): MCPResponse
  - 텍스트 + UIResource multipart 응답 생성
```

### 현재 list_playbooks의 동작 방식

#### 입력

- `page?: number` (default: 1)
- `pageSize?: number` (default: -1, 모든 항목)
- 암묵적: `currentAssistantId` (컨텍스트에서 설정)

#### 처리 로직

1. `currentAssistantId` 검증 (없으면 에러 반환)
2. DB/In-memory 분기 처리
3. 페이징 적용 (`getPage` 또는 배열 전체)
4. `agentId` 필터링 (**문제점: DB에서는 페이징 후 필터링**)
5. 결과가 없으면 텍스트 응답 반환
6. 결과가 있으면:
   - `formatPlaybooksList(items)` -> 텍스트 생성
   - `makeListMultipartResponse(...)` -> multipart 응답 생성
     - 텍스트 파트
     - UIResource 파트 (HTML + 이벤트 핸들러)

#### 출력

- 성공 (항목 있음): `MCPResponse<multipart>` with [text, UIResource]
- 성공 (항목 없음): `MCPResponse<structured>` with text only
- 실패: `MCPResponse<text>` with error message

### 식별된 문제점

#### 1. 페이징/필터링 버그 (Critical)

```typescript
// DB 분기의 현재 코드
const pageResult = await dbService.playbooks.getPage(page, pageSize);
let items = pageResult.items as PlaybookRecord[];
items = items.filter((p) => p.agentId === currentAssistantId);
```

**문제**:

- 전체 데이터에서 페이징한 후 필터링하므로 부정확한 결과
- 예: page=1에 다른 agent의 playbook만 있으면 현재 agent는 빈 페이지 받음
- `pageResult.totalItems` 등의 메타데이터가 필터링 전 값이라 부정확

**영향도**: High - 멀티 에이전트 환경에서 데이터 손실 가능성

#### 2. DB와 In-memory 분기 불일치 (Medium)

```typescript
// In-memory 분기
let items = [...inMemory];
items = items.filter((p) => p.agentId === currentAssistantId);
// 페이징 로직 없음 - 모든 항목 반환
```

**문제**:

- DB 모드는 페이징 시도, In-memory는 페이징 무시
- 응답 구조 불일치: `{ page: {...} }` vs `{ playbooks: [...] }`

**영향도**: Medium - 개발/프로덕션 환경 간 동작 차이

#### 3. 책임의 혼재 + 에이전트 실행 중단 (High)

```typescript
return makeListMultipartResponse(items, formatted, { ... });
```

**문제**:

- AI 에이전트는 텍스트만 필요한데 UI 생성 비용 발생
- **UIResource 포함 시 에이전트 실행이 일시 중지됨**
- 에이전트가 자율적으로 playbook 목록을 조회하고 분석할 수 없음
- 단일 책임 원칙(SRP) 위반

**영향도**: High - 에이전트 자율성 저해 및 성능 오버헤드

#### 4. Agent Context에 불명확한 정보 전달 (Critical - 신규)

**문제**:

- 현재 텍스트 응답에 도구명, 맥락 정보 없음
- Agent가 "어떤 도구의 응답인지", "왜 이 데이터가 왔는지" 파악 불가
- 페이지 정보, 전체 개수 등 메타데이터가 텍스트에 포함되지 않음
- 다음 액션에 대한 힌트 없음

**예시 (현재)**:

```
1. id:123 goal:"Deploy" steps:5 createdAt:2025-01-01
2. id:456 goal:"Fix bug" steps:3 createdAt:2025-01-02
```

→ **맥락 없음, Agent가 이해하기 어려움**

**영향도**: Critical - Agent의 의사결정 능력 저하

#### 5. 페이지네이션 UI 부재 (Medium)

**문제**:

- `show_playbooks`가 UI를 제공하지만 페이지 이동 방법 없음
- Previous/Next 버튼 없음
- 페이지 정보 표시 없음

**영향도**: Medium - UX 불완전

#### 6. 보안 취약점 (Low)

```typescript
window.parent.postMessage({...}, '*');  // targetOrigin: '*'
```

**문제**: 모든 origin에 메시지 전송 가능

**영향도**: Low - 제한된 컨텍스트에서 실행되므로 현재는 위험 낮음

## 변경 이후의 상태 / 해결 판정 기준

### 목표 아키텍처

```
playbookStore (WebMCPServer)
├── tools: MCPTool[] (8개 툴)
│   ├── create_playbook
│   ├── list_playbooks  ✅ (텍스트 전용, Agent 자율 조회)
│   ├── show_playbooks  ✨ (신규: 초기 UI 표시)
│   ├── get_playbook_page ✨ (신규: 페이지 내비게이션)
│   ├── get_playbook
│   ├── select_playbook
│   ├── update_playbook
│   └── delete_playbook
└── callTool(name, args) -> MCPResponse
    ├── case 'list_playbooks': -> structured response (text only)
    ├── case 'show_playbooks': -> multipart response (text + UI)
    └── case 'get_playbook_page': -> multipart response (text + UI)
```

### 도구별 역할 분리

| Tool                | Response Type     | Purpose         | Agent Behavior | Context Text         |
| ------------------- | ----------------- | --------------- | -------------- | -------------------- |
| `list_playbooks`    | Text + Structured | Agent 자율 쿼리 | ✅ 계속 실행   | 명확한 맥락 + 힌트   |
| `show_playbooks`    | Text + UIResource | 초기 UI 표시    | ⏸️ 일시 중지   | 데이터 + 상태 표시   |
| `get_playbook_page` | Text + UIResource | 페이지 이동     | ⏸️ 일시 중지   | 페이지 정보 + 데이터 |

### list_playbooks (변경 후)

#### API 계약

```typescript
// Input
interface ListPlaybooksInput {
  page?: number; // default: 1
  pageSize?: number; // default: -1 (all)
}

// Output (성공)
interface ListPlaybooksOutput {
  content: [{ type: 'text'; text: string }];
  structured: {
    page: {
      page: number;
      pageSize: number;
      totalItems: number;
      totalPages: number;
      items: PlaybookRecord[];
    };
    formattedText: string;
  };
}
```

#### 동작

1. Context 검증
2. DB/In-memory 분기
   - **DB**: `getPageForAgent(assistantId, page, pageSize)` 호출 (필터링 후 페이징)
   - **In-memory**: 필터링 후 `slice()`로 페이징 적용
3. 일관된 페이지 메타데이터 생성
4. `formatPlaybooksList(items)` 텍스트 생성
5. **Agent Context 친화적 텍스트 응답 생성** (도구명, 요약, 힌트 포함)
6. `createMCPStructuredResponse(text, structured)` 반환

#### 예시 응답 (Agent Context에 추가됨)

```
[list_playbooks] Found 25 playbook(s) for agent abc-123.
Showing page 1 of 3 (10 items on this page):

1. id:123 goal:"Deploy app" initial:"deploy production" steps:5 createdAt:2025-01-01
2. id:456 goal:"Fix bug" initial:"fix auth issue" steps:3 createdAt:2025-01-02
...

Note: Use 'get_playbook' to view details or 'select_playbook' to execute a playbook.
```

### show_playbooks (신규)

#### API 계약

```typescript
// Input
interface ShowPlaybooksInput {
  page?: number; // default: 1
  pageSize?: number; // default: -1 (all)
}

// Output (성공)
interface ShowPlaybooksOutput {
  content: [
    { type: 'text'; text: string },
    { type: 'resource'; resource: UIResource },
  ];
  structured: {
    page: { page; pageSize; totalItems; totalPages; items };
    formattedText: string;
  };
}
```

#### 동작

1. `list_playbooks`와 동일한 필터링/페이징 로직 재사용
2. **Agent Context 친화적 텍스트 응답 생성** (UI 표시 상태 포함)
3. **페이지네이션 UI 포함한 HTML 생성**
4. `makeListMultipartResponse(items, text, structured, pageInfo)` 호출
5. UIResource에 `serviceInfo.toolName = 'show_playbooks'` 설정

#### 예시 응답 (Agent Context에 추가됨)

```
[show_playbooks] Displaying 25 playbook(s) in interactive UI.
Current page: 1 of 3

Playbooks on this page:
1. id:123 goal:"Deploy app" steps:5 createdAt:2025-01-01
2. id:456 goal:"Fix bug" steps:3 createdAt:2025-01-02
...

Status: Agent paused for user interaction (Select/Delete/Navigate buttons available).
```

### get_playbook_page (신규)

#### API 계약

```typescript
// Input
interface GetPlaybookPageInput {
  page: number; // required: 이동할 페이지 번호 (1-based)
  pageSize?: number; // optional: 페이지 크기 (이전 값 유지)
}

// Output
interface GetPlaybookPageOutput {
  content: [
    { type: 'text'; text: string },
    { type: 'resource'; resource: UIResource },
  ];
  structured: {
    page: { page; pageSize; totalItems; totalPages; items };
    formattedText: string;
  };
}
```

#### 동작

1. `show_playbooks`와 동일한 로직 (코드 재사용: `getPlaybooksWithUI()`)
2. 페이지 내비게이션 전용 (UI 버튼 클릭으로 호출됨)
3. Agent는 일시 중지 상태 유지

#### 예시 응답 (Agent Context에 추가됨)

```
[get_playbook_page] Navigated to page 2 of 3.
Displaying 10 of 25 total playbook(s):

1. id:789 goal:"Update deps" steps:2 createdAt:2025-01-03
...

Status: Agent paused for user interaction.
```

### 페이지네이션 UI 설계

#### HTML 구조

```html
<div class="pagination">
  <button data-page="1" class="nav-page-btn" [disabled]>← Previous</button>
  <span class="page-info">Page 2 of 3 (25 total)</span>
  <button data-page="3" class="nav-page-btn">Next →</button>
</div>
```

#### 이벤트 처리

```javascript
if (btn.classList.contains('nav-page-btn') && !btn.disabled) {
  const page = parseInt(btn.getAttribute('data-page'));
  window.parent.postMessage(
    {
      type: 'tool',
      payload: { toolName: 'get_playbook_page', params: { page } },
    },
    '*',
  );
}
```

### Agent Context 최적화 원칙

**모든 텍스트 응답은 다음을 포함:**

1. **도구 식별**: `[tool_name]` prefix
2. **액션 결과**: "Found ...", "Successfully ...", "Displaying ..."
3. **핵심 데이터**: 실제 내용 (포맷팅된 목록/상세정보)
4. **맥락 정보**: 페이지 번호, 총 개수, 에이전트 ID 등
5. **다음 액션 힌트**: "Use 'xxx' to ...", "You may now ..."
6. **상태 표시** (UI 도구): "Agent paused for user interaction"

### 해결 판정 기준

#### 필수 기준 (Must)

1. ✅ `Page<T>` 인터페이스에 `totalPages` 필드 추가
2. ✅ `list_playbooks`는 UI 리소스 없이 텍스트만 반환
3. ✅ `show_playbooks`는 텍스트 + UI 리소스를 multipart로 반환
4. ✅ `get_playbook_page`는 페이지 내비게이션 제공
5. ✅ DB 분기에서 필터링 후 페이징 적용 (정확한 페이지 메타데이터)
6. ✅ In-memory 분기도 페이징 로직 적용
7. ✅ DB와 In-memory의 응답 구조 일치 (`page` 객체)
8. ✅ **모든 텍스트 응답에 명확한 맥락 정보 포함** (도구명, 요약, 힌트)
9. ✅ **페이지네이션 UI 구현** (Previous/Next 버튼)
10. ✅ 기존 테스트 통과 유지

#### 권장 기준 (Should)

1. 🎯 `show_playbooks`, `get_playbook_page`의 `serviceInfo.toolName` 정확히 설정
2. 🎯 페이지 메타데이터에 `totalPages` 계산 포함
3. 🎯 postMessage targetOrigin 주석으로 보안 리스크 문서화
4. 🎯 버전 증가: `playbookStore.version = '0.1.1'`
5. 🎯 공통 로직 함수 추출: `getPlaybooksWithUI()`

#### 테스트 기준

1. Context 없을 때 에러 반환
2. 빈 목록일 때 적절한 응답
3. 페이징 동작 검증 (page=1, pageSize=5)
4. DB/In-memory 결과 동등성
5. `list_playbooks`는 UIResource 없음 확인
6. `show_playbooks`는 UIResource + 페이지네이션 버튼 포함 확인
7. `get_playbook_page`는 페이지 이동 정상 동작 확인
8. HTML XSS 방어 (escapeHtml) 검증
9. **텍스트 응답이 Agent Context에서 이해 가능한지 검증**
10. Previous 버튼이 첫 페이지에서 disabled
11. Next 버튼이 마지막 페이지에서 disabled

## 수정이 필요한 코드 및 수정 부분의 코드 스니핏

### 0. DB Service 확장 (우선 작업)

#### 0-1. DB 스키마에 agentId 인덱스 추가

**파일**: `src/lib/db/service.ts`
**위치**: LocalDatabase 생성자 내 version 정의 섹션

```typescript
// 기존 version 6
this.version(6).stores({
  playbooks: '&id, createdAt, updatedAt, goal',
});

// 기존 version 7 (그대로 유지)
this.version(7)
  .stores({})
  .upgrade(async (tx) => {
    await tx
      .table('assistants')
      .toCollection()
      .modify((assistant) => {
        if (
          Array.isArray(assistant.allowedBuiltInServiceAliases) &&
          assistant.allowedBuiltInServiceAliases.length === 0
        ) {
          delete assistant.allowedBuiltInServiceAliases;
        }
      });
  });

// 새로 추가: version 8 (agentId 인덱스 추가)
this.version(8).stores({
  playbooks: '&id, agentId, createdAt, updatedAt, goal',
});
```

#### 0-2. Page<T> 인터페이스에 totalPages 추가

**파일**: `src/lib/db/types.ts`
**위치**: Page 인터페이스 정의 (line ~90)

```typescript
export interface Page<T> {
  /** The array of items for the current page. */
  items: T[];
  /** The current page number. */
  page: number;
  /** The number of items per page. */
  pageSize: number;
  /** The total number of items across all pages. */
  totalItems: number;
  /** The total number of pages. */
  totalPages: number; // ✨ 추가
  /** A boolean indicating if there is a next page. */
  hasNextPage: boolean;
  /** A boolean indicating if there is a previous page. */
  hasPreviousPage: boolean;
}
```

#### 0-3. createPage 헬퍼 함수 업데이트

**파일**: `src/lib/db/crud.ts`
**위치**: createPage 함수 (line ~23)

```typescript
export const createPage = <T>(
  items: T[],
  page: number,
  pageSize: number,
  totalItems: number,
): Page<T> => {
  if (pageSize === -1) {
    return {
      items,
      page: 1,
      pageSize: totalItems,
      totalItems,
      totalPages: 1, // ✨ 추가
      hasNextPage: false,
      hasPreviousPage: false,
    };
  }

  const totalPages = Math.ceil(totalItems / pageSize); // ✨ 계산

  return {
    items,
    page,
    pageSize,
    totalItems,
    totalPages, // ✨ 추가
    hasNextPage: page * pageSize < totalItems,
    hasPreviousPage: page > 1,
  };
};
```

#### 0-4. PlaybookCRUD 인터페이스 정의

**파일**: `src/lib/db/types.ts`
**위치**: 파일 끝부분 (DatabaseService 인터페이스 앞)

```typescript
/**
 * Extends the basic CRUD interface with additional methods specific to `Playbook`.
 */
export interface PlaybookCRUD extends CRUD<Playbook & { id: string }> {
  /**
   * Retrieves a paginated list of playbooks filtered by agent ID.
   * This method uses an indexed query for optimal performance.
   *
   * @param agentId The ID of the agent/assistant to filter by.
   * @param page The page number to retrieve (1-based).
   * @param pageSize The number of items per page. Use -1 to retrieve all items.
   * @returns A promise that resolves to a `Page` of playbooks for the specified agent.
   */
  getPageForAgent: (
    agentId: string,
    page: number,
    pageSize: number,
  ) => Promise<Page<Playbook & { id: string }>>;
}
```

그리고 `DatabaseService` 인터페이스 업데이트:

```typescript
export interface DatabaseService {
  /** CRUD operations for `Assistant` objects. */
  assistants: CRUD<Assistant>;
  /** Generic CRUD operations for `DatabaseObject`s. */
  objects: CRUD<DatabaseObject<unknown>, DatabaseObject<unknown>>;
  /** CRUD operations for `Session` objects. */
  sessions: CRUD<Session>;
  /** CRUD operations for `Message` objects. */
  messages: CRUD<Message>;
  /** Extended CRUD operations for persisted Playbook objects. */
  playbooks?: PlaybookCRUD; // CRUD에서 PlaybookCRUD로 변경
}
```

#### 0-5. playbooksCRUD에 getPageForAgent 메서드 구현

**파일**: `src/lib/db/crud.ts`
**위치**: playbooksCRUD 객체 정의 (count 메서드 다음)

```typescript
/** CRUD for persisted Task records stored in the LocalDatabase.tasks table. */
export const playbooksCRUD: CRUD<PlaybookRecord> & {
  getPageForAgent: (
    agentId: string,
    page: number,
    pageSize: number,
  ) => Promise<Page<PlaybookRecord>>;
} = {
  upsert: async (playbook) => {
    // ... 기존 코드 유지 ...
  },
  upsertMany: async (playbooksArr) => {
    // ... 기존 코드 유지 ...
  },
  read: async (id) => {
    // ... 기존 코드 유지 ...
  },
  delete: async (id) => {
    // ... 기존 코드 유지 ...
  },
  getPage: async (page, pageSize) => {
    // ... 기존 코드 유지 ...
  },
  count: async () => {
    return LocalDatabase.getInstance().table('playbooks').count();
  },

  // 신규 메서드: agentId로 필터링된 페이징
  getPageForAgent: async (agentId, page, pageSize) => {
    const db = LocalDatabase.getInstance();
    const table = db.table('playbooks');

    // agentId로 필터링된 항목 수 계산
    const totalItems = await table.where('agentId').equals(agentId).count();

    if (pageSize === -1) {
      // 모든 항목 반환
      const items = await table.where('agentId').equals(agentId).toArray();
      return createPage(items as PlaybookRecord[], page, pageSize, totalItems);
    }

    // 페이징 적용
    const offset = (page - 1) * pageSize;
    const items = await table
      .where('agentId')
      .equals(agentId)
      .offset(offset)
      .limit(pageSize)
      .toArray();

    return createPage(items as PlaybookRecord[], page, pageSize, totalItems);
  },
};
```

### 1. tools 배열에 show_playbooks, get_playbook_page 추가

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: `tools` 배열 (line ~220)

```typescript
const tools: MCPTool[] = [
  // ... 기존 툴들 ...
  {
    name: 'list_playbooks',
    description:
      'List playbooks with optional paging (text-only, non-interrupting for agent autonomous use)',
    inputSchema: {
      type: 'object',
      properties: {
        page: {
          type: 'number',
          description: 'Page number to retrieve (1-based)',
        },
        pageSize: {
          type: 'number',
          description: 'Number of items per page; -1 for all',
        },
      },
    },
  },
  {
    name: 'show_playbooks',
    description:
      'Display playbooks with interactive UI (includes HTML UI resource for frontend, pauses agent)',
    inputSchema: {
      type: 'object',
      properties: {
        page: {
          type: 'number',
          description: 'Page number to retrieve (1-based)',
        },
        pageSize: {
          type: 'number',
          description: 'Number of items per page; -1 for all',
        },
      },
    },
  },
  {
    name: 'get_playbook_page',
    description:
      'Navigate to a specific page of playbooks with interactive UI (for pagination buttons, pauses agent)',
    inputSchema: {
      type: 'object',
      properties: {
        page: {
          type: 'number',
          description: 'Page number to navigate to (1-based)',
        },
        pageSize: {
          type: 'number',
          description:
            'Number of items per page (optional, keeps previous size)',
        },
      },
      required: ['page'],
    },
  },
  // ... 나머지 툴들 ...
];
```

### 2. 공통 페이징 로직 헬퍼 함수 추가

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: Helper functions 섹션 (formatPlaybook 아래)

```typescript
// --- Helpers to reduce duplication between DB and in-memory branches ---

interface PageResult {
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
  items: PlaybookRecord[];
}

/**
 * Apply pagination to filtered items (in-memory mode)
 */
function paginateItems(
  items: PlaybookRecord[],
  page: number,
  pageSize: number,
): PageResult {
  const totalItems = items.length;

  if (pageSize === -1) {
    // Return all items
    return {
      page: 1,
      pageSize: -1,
      totalItems,
      totalPages: 1,
      items,
    };
  }

  const totalPages = Math.ceil(totalItems / pageSize);
  const startIdx = (page - 1) * pageSize;
  const endIdx = startIdx + pageSize;
  const paginatedItems = items.slice(startIdx, endIdx);

  return {
    page,
    pageSize,
    totalItems,
    totalPages,
    items: paginatedItems,
  };
}

/**
 * Create consistent structured response for list operations
 */
function createListStructuredResponse(
  pageResult: PageResult,
  formattedText: string,
): unknown {
  return {
    page: pageResult,
    formattedText,
  };
}

/**
 * Create context-aware text response for list_playbooks
 */
function createListTextResponse(
  agentId: string,
  pageResult: PageResult,
  formattedList: string,
): string {
  if (pageResult.totalItems === 0) {
    return `[list_playbooks] No playbooks found for agent ${agentId}.`;
  }

  return `[list_playbooks] Found ${pageResult.totalItems} playbook(s) for agent ${agentId}.
Showing page ${pageResult.page} of ${pageResult.totalPages} (${pageResult.items.length} items on this page):

${formattedList}

Note: Use 'get_playbook' to view details or 'select_playbook' to execute a playbook.`;
}

/**
 * Create context-aware text response for UI-based tools (show_playbooks, get_playbook_page)
 */
function createUITextResponse(
  toolName: string,
  pageResult: PageResult,
  formattedList: string,
  isNavigation = false,
): string {
  const action = isNavigation
    ? `Navigated to page ${pageResult.page}`
    : `Displaying ${pageResult.totalItems} playbook(s) in interactive UI`;

  return `[${toolName}] ${action}.
Current page: ${pageResult.page} of ${pageResult.totalPages}

Playbooks on this page:
${formattedList}

Status: Agent paused for user interaction (Select/Delete/Navigate buttons available).`;
}
```

### 3. HTML UI 업데이트 (페이지네이션 추가)

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: buildUiHtml 함수 (line ~76)

```typescript
function buildUiHtml(listItemsHtml: string, pageInfo: PageResult): string {
  const prevDisabled = pageInfo.page <= 1 ? 'disabled' : '';
  const nextDisabled = pageInfo.page >= pageInfo.totalPages ? 'disabled' : '';

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body {
      font-family: system-ui, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 12px;
    }
    .pb-item {
      padding: 8px;
      border-bottom: 1px solid #eee;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .pagination {
      margin-top: 16px;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      padding: 12px;
      border-top: 1px solid #eee;
    }
    button {
      padding: 6px 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      background: white;
      cursor: pointer;
      font-size: 14px;
    }
    button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    button:hover:not(:disabled) {
      background: #f5f5f5;
    }
    .delete-pb-btn {
      background-color: #dc3545;
      color: white;
      border: none;
    }
    .delete-pb-btn:hover:not(:disabled) {
      background-color: #c82333;
    }
    .page-info {
      padding: 6px 12px;
      color: #666;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <h3>Playbooks</h3>
  <div id="pb-list">${listItemsHtml}</div>

  <!-- Pagination UI -->
  <div class="pagination">
    <button data-page="${pageInfo.page - 1}" class="nav-page-btn" ${prevDisabled}>
      ← Previous
    </button>
    <span class="page-info">
      Page ${pageInfo.page} of ${pageInfo.totalPages} (${pageInfo.totalItems} total)
    </span>
    <button data-page="${pageInfo.page + 1}" class="nav-page-btn" ${nextDisabled}>
      Next →
    </button>
  </div>

  <script>
document.addEventListener('click', function(e) {
  const btn = e.target;
  if (btn && btn.classList) {
    const id = btn.getAttribute('data-pbid');
    const page = btn.getAttribute('data-page');

    if (btn.classList.contains('select-pb-btn')) {
      console.log('Select button clicked for id:', id);
      // Security note: Using '*' as targetOrigin for compatibility.
      // In production, consider restricting to specific origin if parent context is known.
      window.parent.postMessage({type:'tool', payload:{toolName:'select_playbook', params:{id}}}, '*');
    } else if (btn.classList.contains('delete-pb-btn')) {
      console.log('Delete button clicked for id:', id);
      window.parent.postMessage({type:'tool', payload:{toolName:'delete_playbook', params:{id}}}, '*');
    } else if (btn.classList.contains('nav-page-btn') && !btn.disabled) {
      console.log('Navigate to page:', page);
      window.parent.postMessage({type:'tool', payload:{toolName:'get_playbook_page', params:{page: parseInt(page)}}}, '*');
    }
  }
});
</script>
</body>
</html>`;
}
```

### 4. createUiResourceFromHtml 수정 (toolName 동적 설정)

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: createUiResourceFromHtml 함수 (line ~94)

```typescript
function createUiResourceFromHtml(html: string, toolName = 'show_playbooks') {
  const res = createUIResource({
    uri: `ui://playbooks/list/${Date.now()}`,
    content: { type: 'rawHtml', htmlString: html },
    encoding: 'text',
  }) as UIResource & { serviceInfo?: ServiceInfo };

  // Attach serviceInfo so the frontend can resolve tool names correctly
  // Use the canonical server name ('playbook') and mark this as a built-in web server
  res.serviceInfo = {
    serverName: 'playbook',
    toolName, // 동적으로 설정
    backendType: 'BuiltInWeb',
  };

  return res;
}
```

### 5. makeListMultipartResponse 시그니처 업데이트

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: makeListMultipartResponse 함수 (line ~112)

```typescript
function makeListMultipartResponse(
  items: PlaybookRecord[],
  formattedText: string,
  structured: unknown,
  pageInfo: PageResult, // ✨ 추가
  toolName = 'show_playbooks', // ✨ 추가
) {
  const textPart: MCPContent = {
    type: 'text',
    text: formattedText,
  } as unknown as MCPContent;

  const uiHtml = buildUiHtml(buildListItemsHtml(items), pageInfo); // ✨ pageInfo 전달
  const uiResource = {
    ...createUiResourceFromHtml(uiHtml, toolName), // ✨ toolName 전달
  };

  return createMCPStructuredMultipartResponse(
    [textPart, uiResource],
    structured,
  );
}
```

### 6. getPlaybooksWithUI 공통 함수 추가

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: Helper functions 섹션 (makeListMultipartResponse 아래)

```typescript
/**
 * Common logic for UI-based playbook listing (show_playbooks, get_playbook_page)
 */
async function getPlaybooksWithUI(
  agentId: string,
  page: number,
  pageSize: number,
  hasDB: boolean,
  toolName: string,
  isNavigation = false,
): Promise<MCPResponse<unknown>> {
  if (hasDB && dbService.playbooks) {
    // DB branch: use indexed query
    const dbPageResult = await dbService.playbooks.getPageForAgent(
      agentId,
      page,
      pageSize,
    );

    // Convert Page<T> to PageResult
    const pageResult: PageResult = {
      page: dbPageResult.page,
      pageSize: dbPageResult.pageSize,
      totalItems: dbPageResult.totalItems,
      totalPages: dbPageResult.totalPages, // Now available from updated Page<T>
      items: dbPageResult.items as PlaybookRecord[],
    };

    if (pageResult.items.length === 0) {
      const emptyText = `[${toolName}] No playbooks found for agent ${agentId}.`;
      return createMCPStructuredResponse(emptyText, {
        page: pageResult,
      });
    }

    const formattedList = formatPlaybooksList(pageResult.items);
    const textResponse = createUITextResponse(
      toolName,
      pageResult,
      formattedList,
      isNavigation,
    );
    const structured = createListStructuredResponse(pageResult, formattedList);
    return makeListMultipartResponse(
      pageResult.items,
      textResponse,
      structured,
      pageResult,
      toolName,
    );
  }

  // In-memory branch
  const filtered = inMemory.filter((p) => p.agentId === agentId);
  const pageResult = paginateItems(filtered, page, pageSize);

  if (pageResult.items.length === 0) {
    const emptyText = `[${toolName}] No playbooks found (in-memory) for agent ${agentId}.`;
    return createMCPStructuredResponse(emptyText, {
      page: pageResult,
    });
  }

  const formattedList = formatPlaybooksList(pageResult.items);
  const textResponse = createUITextResponse(
    toolName,
    pageResult,
    formattedList,
    isNavigation,
  );
  const structured = createListStructuredResponse(pageResult, formattedList);
  return makeListMultipartResponse(
    pageResult.items,
    textResponse,
    structured,
    pageResult,
    toolName,
  );
}
```

### 7. list_playbooks case 수정 (텍스트 전용)

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: callTool switch-case 내 'list_playbooks' (line ~415)

```typescript
case 'list_playbooks': {
  if (!currentAssistantId) {
    return createMCPTextResponse(
      '[list_playbooks] Error: Assistant ID not set. Please set context first.',
    );
  }

  const page = Number(a.page || 1);
  const pageSize = Number(a.pageSize || -1);

  if (hasDB && dbService.playbooks) {
    // DB: Use indexed query for filtered pagination
    const dbPageResult = await dbService.playbooks.getPageForAgent(
      currentAssistantId,
      page,
      pageSize
    );

    // Convert Page<T> to PageResult
    const pageResult: PageResult = {
      page: dbPageResult.page,
      pageSize: dbPageResult.pageSize,
      totalItems: dbPageResult.totalItems,
      totalPages: dbPageResult.totalPages,
      items: dbPageResult.items as PlaybookRecord[],
    };

    const formattedList = formatPlaybooksList(pageResult.items);
    const textResponse = createListTextResponse(currentAssistantId, pageResult, formattedList);
    const structured = createListStructuredResponse(pageResult, formattedList);
    return createMCPStructuredResponse(textResponse, structured);
  }

  // In-memory branch
  const filtered = inMemory.filter((p) => p.agentId === currentAssistantId);
  const pageResult = paginateItems(filtered, page, pageSize);

  const formattedList = formatPlaybooksList(pageResult.items);
  const textResponse = createListTextResponse(currentAssistantId, pageResult, formattedList);
  const structured = createListStructuredResponse(pageResult, formattedList);
  return createMCPStructuredResponse(textResponse, structured);
}
```

### 8. show_playbooks case 추가 (UI 포함)

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: callTool switch-case 내 (list_playbooks 다음)

```typescript
case 'show_playbooks': {
  if (!currentAssistantId) {
    return createMCPTextResponse(
      '[show_playbooks] Error: Assistant ID not set. Please set context first.',
    );
  }

  const page = Number(a.page || 1);
  const pageSize = Number(a.pageSize || -1);

  return getPlaybooksWithUI(currentAssistantId, page, pageSize, hasDB, 'show_playbooks', false);
}
```

### 9. get_playbook_page case 추가 (페이지 내비게이션)

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: callTool switch-case 내 (show_playbooks 다음)

```typescript
case 'get_playbook_page': {
  if (!currentAssistantId) {
    return createMCPTextResponse(
      '[get_playbook_page] Error: Assistant ID not set. Please set context first.',
    );
  }

  const page = Number(a.page || 1);
  const pageSize = Number(a.pageSize || 10); // Default to 10 if not specified

  return getPlaybooksWithUI(currentAssistantId, page, pageSize, hasDB, 'get_playbook_page', true);
}
```

### 10. 다른 도구들의 텍스트 응답 개선

#### get_playbook

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: get_playbook case (line ~486)

```typescript
case 'get_playbook': {
  const id = String(a.id);
  if (hasDB && dbService.playbooks) {
    const existing = await dbService.playbooks.read(id as string);
    if (!existing) {
      return createMCPTextResponse(`[get_playbook] Error: Playbook ${id} not found.`);
    }
    const rec = existing as PlaybookRecord;
    const formatted = formatPlaybookDetailed(rec);

    const textResponse = `[get_playbook] Retrieved playbook details for ID: ${id}

${formatted}

Note: Use 'select_playbook' to execute this playbook, or 'update_playbook' to modify it.`;

    return createMCPStructuredResponse(textResponse, {
      playbook: existing,
    });
  }

  const existing = inMemory.find((p) => p.id === String(a.id));
  if (!existing) {
    return createMCPTextResponse(`[get_playbook] Error: Playbook ${String(a.id)} not found (in-memory).`);
  }
  const formatted = formatPlaybookDetailed(existing);

  const textResponse = `[get_playbook] Retrieved playbook details for ID: ${String(a.id)} (in-memory)

${formatted}

Note: Use 'select_playbook' to execute this playbook, or 'update_playbook' to modify it.`;

  return createMCPStructuredResponse(textResponse, { playbook: existing });
}
```

#### select_playbook

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: select_playbook case (line ~562)

```typescript
case 'select_playbook': {
  const id = String(a.id);
  let existing: PlaybookRecord | undefined;
  if (hasDB && dbService.playbooks) {
    existing = (await dbService.playbooks.read(id)) as
      | PlaybookRecord
      | undefined;
  } else {
    existing = inMemory.find((p) => p.id === id);
  }

  if (!existing) {
    return createMCPTextResponse(`[select_playbook] Error: Playbook ${id} not found.`);
  }

  // Permission check
  if (currentAssistantId && existing.agentId !== currentAssistantId) {
    return createMCPTextResponse(
      `[select_playbook] Error: Playbook ${id} does not belong to the current assistant (${currentAssistantId}).`,
    );
  }

  // Build detailed text
  const formattedText = formatPlaybookDetailed(existing);

  const agentPrompt = `[select_playbook] Playbook "${existing.goal}" (ID: ${existing.id}) has been selected for execution.

Playbook Details:
---
${formattedText}
---

Instructions:
1. Review the workflow steps and success criteria above
2. Establish todos based on the workflow steps
3. Begin executing the tasks according to the defined steps
4. Track progress and verify against success criteria

You may now proceed with execution.`;

  return createMCPStructuredResponse(agentPrompt, {
    playbook: existing,
  });
}
```

#### create_playbook

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: create_playbook case (line ~365)

```typescript
case 'create_playbook': {
  if (!currentAssistantId) {
    return createMCPTextResponse(
      '[create_playbook] Error: Assistant ID not set. Please set context first.',
    );
  }

  const id = String(Date.now()) + '-' + String(nextId++);
  const playbook: PlaybookRecord = {
    id,
    agentId: currentAssistantId,
    goal: String(a.goal || ''),
    initialCommand: String(a.initialCommand || ''),
    workflow: ((a.workflow as Playbook['workflow']) || []).map(
      (s, i) => ({
        stepId: s?.stepId ?? `${id}-step-${i + 1}`,
        description: s?.description ?? '',
        action: s?.action ?? { toolName: '', purpose: '' },
        requiredData: s?.requiredData ?? [],
        outputVariable: s?.outputVariable ?? '',
      }),
    ),
    successCriteria:
      (a.successCriteria as Playbook['successCriteria']) || {
        description: '',
      },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  if (hasDB && dbService.playbooks) {
    await dbService.playbooks.upsert(playbook as PlaybookRecord);
    const saved = await dbService.playbooks.read(id);
    const formatted = saved
      ? formatPlaybook(saved as PlaybookRecord)
      : `Playbook ${id} created`;

    const textResponse = `[create_playbook] Successfully created new playbook.
ID: ${id}
Goal: ${playbook.goal}
Steps: ${playbook.workflow.length}

${formatted}

The playbook is now available. Use 'list_playbooks' to see all playbooks, or 'select_playbook' with ID ${id} to execute it.`;

    return createMCPStructuredResponse(textResponse, {
      success: true,
      playbook: saved,
    });
  }

  inMemory.push(playbook);
  const formattedInMemory = formatPlaybook(playbook);

  const textResponse = `[create_playbook] Successfully created new playbook (in-memory).
ID: ${id}
Goal: ${playbook.goal}
Steps: ${playbook.workflow.length}

${formattedInMemory}

The playbook is now available. Use 'list_playbooks' to see all playbooks, or 'select_playbook' with ID ${id} to execute it.`;

  return createMCPStructuredResponse(textResponse, {
    success: true,
    playbook,
  });
}
```

#### update_playbook

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: update_playbook case (line ~505)

```typescript
case 'update_playbook': {
  const id = String(a.id);
  const patch = (a.playbook as Partial<Playbook>) || {};
  if (hasDB && dbService.playbooks) {
    const existing = await dbService.playbooks.read(id as string);
    if (!existing) {
      return createMCPTextResponse(`[update_playbook] Error: Playbook ${id} not found.`);
    }
    const updatedWorkflow = (patch.workflow as Playbook['workflow'])
      ? (patch.workflow as Playbook['workflow']).map((s, i) => ({
          stepId: s?.stepId ?? `${id}-step-${i + 1}`,
          description: s?.description ?? '',
          action: s?.action ?? { toolName: '', purpose: '' },
          requiredData: s?.requiredData ?? [],
          outputVariable: s?.outputVariable ?? '',
        }))
      : existing.workflow;

    const updated: PlaybookRecord = {
      ...existing,
      ...patch,
      workflow: updatedWorkflow,
      updatedAt: new Date(),
    } as PlaybookRecord;
    await dbService.playbooks.upsert(updated);
    const saved = await dbService.playbooks.read(id);
    const formatted = saved
      ? formatPlaybook(saved as PlaybookRecord)
      : `Playbook ${id} updated`;

    const textResponse = `[update_playbook] Successfully updated playbook ID: ${id}

Updated Details:
${formatted}

The playbook has been modified. Changes are immediately available.`;

    return createMCPStructuredResponse(textResponse, {
      success: true,
      playbook: saved
    });
  }

  const existing = inMemory.find((p) => p.id === id);
  if (!existing) {
    return createMCPTextResponse(`[update_playbook] Error: Playbook ${id} not found (in-memory).`);
  }
  if (patch.workflow) {
    existing.workflow = (patch.workflow as Playbook['workflow']).map(
      (s, i) => ({
        stepId: s?.stepId ?? `${id}-step-${i + 1}`,
        description: s?.description ?? '',
        action: s?.action ?? { toolName: '', purpose: '' },
        requiredData: s?.requiredData ?? [],
        outputVariable: s?.outputVariable ?? '',
      }),
    );
  }
  Object.assign(existing, patch);
  existing.updatedAt = new Date().toISOString();
  const formattedExisting = formatPlaybook(existing);

  const textResponse = `[update_playbook] Successfully updated playbook ID: ${id} (in-memory)

Updated Details:
${formattedExisting}

The playbook has been modified. Changes are immediately available.`;

  return createMCPStructuredResponse(textResponse, {
    success: true,
    playbook: existing,
  });
}
```

#### delete_playbook

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: delete_playbook case (line ~463)

```typescript
case 'delete_playbook': {
  const id = String(a.id);
  if (hasDB && dbService.playbooks) {
    const existing = await dbService.playbooks.read(id);
    if (!existing) {
      return createMCPTextResponse(`[delete_playbook] Error: Playbook ${id} not found.`);
    }
    await dbService.playbooks.delete(id);
    const formatted = formatPlaybook(existing as PlaybookRecord);

    const textResponse = `[delete_playbook] Successfully deleted playbook ID: ${id}

Deleted Playbook:
${formatted}

This playbook is no longer available. Use 'list_playbooks' to see remaining playbooks.`;

    return createMCPStructuredResponse(textResponse, {
      success: true,
      id
    });
  }
  const idx = inMemory.findIndex((p) => p.id === id);
  if (idx === -1) {
    return createMCPTextResponse(`[delete_playbook] Error: Playbook ${id} not found (in-memory).`);
  }
  const removed = inMemory.splice(idx, 1)[0];
  const formattedRemoved = formatPlaybook(removed);

  const textResponse = `[delete_playbook] Successfully deleted playbook ID: ${id} (in-memory)

Deleted Playbook:
${formattedRemoved}

This playbook is no longer available. Use 'list_playbooks' to see remaining playbooks.`;

  return createMCPStructuredResponse(textResponse, {
    success: true,
    id,
  });
}
```

### 11. 버전 업데이트

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`
**위치**: playbookStore 객체 정의 (line ~352)

```typescript
const playbookStore: WebMCPServer = {
  name: 'playbook',
  version: '0.1.1', // 0.1.0 -> 0.1.1
  description:
    'Persisted playbook store for agent workflows (create/list/show/navigate/update/delete)',
  tools,
  // ...
};
```

## 재사용 가능한 연관 코드

### DB Service Interface

**파일**: `src/lib/db/types.ts`

현재 사용 중인 인터페이스:

```typescript
interface CRUD<T, U = T> {
  upsert: (object: T) => Promise<void>;
  upsertMany: (objects: T[]) => Promise<void>;
  read: (key: string) => Promise<U | undefined>;
  delete: (key: string) => Promise<void>;
  getPage: (page: number, pageSize: number) => Promise<Page<U>>;
  count: () => Promise<number>;
}

interface Page<T> {
  items: T[];
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number; // ✨ 추가됨
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}
```

확장된 PlaybookCRUD:

```typescript
interface PlaybookCRUD extends CRUD<Playbook & { id: string }> {
  getPageForAgent: (
    agentId: string,
    page: number,
    pageSize: number,
  ) => Promise<Page<Playbook & { id: string }>>;
}
```

### Dexie 사용 패턴

**파일**: `src/lib/db/service.ts`, `src/lib/db/crud.ts`

```typescript
// Dexie 테이블 접근
const db = LocalDatabase.getInstance();
const table = db.table('playbooks');

// 인덱스를 사용한 필터링 + 페이징
const items = await table
  .where('agentId')
  .equals(targetAgentId)
  .offset((page - 1) * pageSize)
  .limit(pageSize)
  .toArray();

// 카운트
const count = await table.where('agentId').equals(targetAgentId).count();
```

### MCP Response Utilities (재사용)

**파일**: `src/lib/mcp-response-utils.ts`

```typescript
// 이미 사용 중인 유틸리티
export function createMCPTextResponse(text: string): MCPResponse<unknown>;
export function createMCPStructuredResponse(
  text: string,
  structured: unknown,
): MCPResponse<unknown>;
export function createMCPStructuredMultipartResponse(
  content: MCPContent[],
  structured: unknown,
): MCPResponse<unknown>;
```

### Type Definitions (재사용)

**파일**: `src/types/playbook.ts`

```typescript
export interface Playbook {
  agentId: string;
  goal: string;
  initialCommand?: string;
  workflow: PlaybookStep[];
  successCriteria?: {
    description: string;
    requiredArtifacts?: string[];
  };
}

export interface PlaybookStep {
  stepId?: string;
  description: string;
  action: {
    toolName: string;
    purpose: string;
  };
  requiredData: string[];
  outputVariable: string;
}
```

## Test Code 추가 및 수정 필요 부분에 대한 가이드

### 테스트 파일 생성

**파일**: `src/lib/web-mcp/modules/__tests__/playbook-store.test.ts` (신규)

### 테스트 카테고리

#### 0. DB Service 테스트 (신규)

**파일**: `src/lib/db/__tests__/crud.test.ts` (기존 파일에 추가 또는 신규)

```typescript
describe('playbooksCRUD.getPageForAgent', () => {
  beforeEach(async () => {
    // DB 초기화
    const db = LocalDatabase.getInstance();
    await db.table('playbooks').clear();
  });

  it('should filter playbooks by agentId', async () => {
    // agent-1의 playbooks 3개 생성
    await playbooksCRUD.upsert({
      agentId: 'agent-1',
      goal: 'Goal 1',
      workflow: [],
    });
    await playbooksCRUD.upsert({
      agentId: 'agent-1',
      goal: 'Goal 2',
      workflow: [],
    });
    await playbooksCRUD.upsert({
      agentId: 'agent-1',
      goal: 'Goal 3',
      workflow: [],
    });

    // agent-2의 playbooks 2개 생성
    await playbooksCRUD.upsert({
      agentId: 'agent-2',
      goal: 'Goal A',
      workflow: [],
    });
    await playbooksCRUD.upsert({
      agentId: 'agent-2',
      goal: 'Goal B',
      workflow: [],
    });

    // agent-1의 playbooks만 조회
    const result = await playbooksCRUD.getPageForAgent('agent-1', 1, -1);

    expect(result.totalItems).toBe(3);
    expect(result.items).toHaveLength(3);
    expect(result.items.every((p) => p.agentId === 'agent-1')).toBe(true);
  });

  it('should paginate correctly for specific agent', async () => {
    // agent-1의 playbooks 5개 생성
    for (let i = 0; i < 5; i++) {
      await playbooksCRUD.upsert({
        agentId: 'agent-1',
        goal: `Goal ${i}`,
        workflow: [],
      });
    }

    // 첫 페이지 (2개)
    const page1 = await playbooksCRUD.getPageForAgent('agent-1', 1, 2);
    expect(page1.items).toHaveLength(2);
    expect(page1.page).toBe(1);
    expect(page1.totalItems).toBe(5);
    expect(page1.totalPages).toBe(3);
    expect(page1.hasNextPage).toBe(true);
    expect(page1.hasPreviousPage).toBe(false);

    // 두 번째 페이지 (2개)
    const page2 = await playbooksCRUD.getPageForAgent('agent-1', 2, 2);
    expect(page2.items).toHaveLength(2);
    expect(page2.page).toBe(2);
    expect(page2.hasNextPage).toBe(true);
    expect(page2.hasPreviousPage).toBe(true);

    // 마지막 페이지 (1개)
    const page3 = await playbooksCRUD.getPageForAgent('agent-1', 3, 2);
    expect(page3.items).toHaveLength(1);
    expect(page3.hasNextPage).toBe(false);
  });

  it('should return all items when pageSize is -1', async () => {
    for (let i = 0; i < 10; i++) {
      await playbooksCRUD.upsert({
        agentId: 'test-agent',
        goal: `Goal ${i}`,
        workflow: [],
      });
    }

    const result = await playbooksCRUD.getPageForAgent('test-agent', 1, -1);

    expect(result.items).toHaveLength(10);
    expect(result.pageSize).toBe(-1);
    expect(result.totalPages).toBe(1);
    expect(result.hasNextPage).toBe(false);
  });

  it('should return empty page when no playbooks match agentId', async () => {
    await playbooksCRUD.upsert({
      agentId: 'other-agent',
      goal: 'Other goal',
      workflow: [],
    });

    const result = await playbooksCRUD.getPageForAgent('target-agent', 1, 10);

    expect(result.items).toHaveLength(0);
    expect(result.totalItems).toBe(0);
    expect(result.totalPages).toBe(0);
  });
});
```

#### 1. Context 관리 테스트

```typescript
describe('Context Management', () => {
  it('should reject list_playbooks when assistantId is not set', async () => {
    // switchContext 호출 없이 list_playbooks 호출
    const result = await playbookStore.callTool('list_playbooks', {});
    expect(result.content[0].text).toContain(
      '[list_playbooks] Error: Assistant ID not set',
    );
  });

  it('should accept valid assistantId via switchContext', async () => {
    await playbookStore.switchContext({ assistantId: 'agent-1' });
    // 이후 호출들이 정상 동작해야 함
  });
});
```

#### 2. list_playbooks (텍스트 전용) 테스트

```typescript
describe('list_playbooks (text-only)', () => {
  beforeEach(async () => {
    await playbookStore.switchContext({ assistantId: 'test-agent' });
  });

  it('should return empty list with correct structure and context', async () => {
    const result = await playbookStore.callTool('list_playbooks', {});
    expect(result.content).toHaveLength(1); // 텍스트만
    expect(result.content[0].type).toBe('text');
    expect(result.content[0].text).toContain('[list_playbooks]');
    expect(result.content[0].text).toContain('No playbooks found');
    expect(result.structured.page).toBeDefined();
    expect(result.structured.page.totalItems).toBe(0);
  });

  it('should return text-only response without UIResource', async () => {
    // Playbook 생성
    await playbookStore.callTool('create_playbook', {
      goal: 'Test goal',
      workflow: [
        {
          /* ... */
        },
      ],
    });

    const result = await playbookStore.callTool('list_playbooks', {});

    // UIResource가 없어야 함
    expect(result.content).toHaveLength(1);
    expect(result.content.every((c) => c.type !== 'resource')).toBe(true);

    // 구조화된 데이터 검증
    expect(result.structured.page.items).toHaveLength(1);
    expect(result.structured.formattedText).toContain('Test goal');

    // Agent context 친화적 텍스트 검증
    expect(result.content[0].text).toContain('[list_playbooks]');
    expect(result.content[0].text).toContain('Found 1 playbook(s)');
    expect(result.content[0].text).toContain('Note: Use');
  });

  it('should apply pagination correctly (in-memory)', async () => {
    // 5개 playbook 생성
    for (let i = 0; i < 5; i++) {
      await playbookStore.callTool('create_playbook', {
        goal: `Goal ${i}`,
        workflow: [],
      });
    }

    const result = await playbookStore.callTool('list_playbooks', {
      page: 1,
      pageSize: 2,
    });

    expect(result.structured.page.items).toHaveLength(2);
    expect(result.structured.page.totalItems).toBe(5);
    expect(result.structured.page.totalPages).toBe(3);
    expect(result.structured.page.page).toBe(1);

    // Text includes pagination info
    expect(result.content[0].text).toContain('page 1 of 3');
  });

  it('should filter by assistantId correctly', async () => {
    // agent-1의 playbook
    await playbookStore.switchContext({ assistantId: 'agent-1' });
    await playbookStore.callTool('create_playbook', {
      goal: 'Agent 1 goal',
      workflow: [],
    });

    // agent-2의 playbook
    await playbookStore.switchContext({ assistantId: 'agent-2' });
    await playbookStore.callTool('create_playbook', {
      goal: 'Agent 2 goal',
      workflow: [],
    });

    // agent-1로 전환하여 조회
    await playbookStore.switchContext({ assistantId: 'agent-1' });
    const result = await playbookStore.callTool('list_playbooks', {});

    expect(result.structured.page.totalItems).toBe(1);
    expect(result.structured.formattedText).toContain('Agent 1 goal');
    expect(result.structured.formattedText).not.toContain('Agent 2 goal');
  });
});
```

#### 3. show_playbooks (UI 포함) 테스트

```typescript
describe('show_playbooks (with UI and pagination)', () => {
  beforeEach(async () => {
    await playbookStore.switchContext({ assistantId: 'test-agent' });
  });

  it('should return multipart response with text and UIResource', async () => {
    await playbookStore.callTool('create_playbook', {
      goal: 'Test UI goal',
      workflow: [],
    });

    const result = await playbookStore.callTool('show_playbooks', {});

    // Multipart 검증
    expect(result.content).toHaveLength(2);
    expect(result.content[0].type).toBe('text');
    expect(result.content[1].type).toBe('resource');

    // Text includes context info
    expect(result.content[0].text).toContain('[show_playbooks]');
    expect(result.content[0].text).toContain('Agent paused');

    // UIResource 검증
    const uiResource = result.content[1].resource;
    expect(uiResource.uri).toMatch(/^ui:\/\/playbooks\/list\//);
    expect(uiResource.serviceInfo?.serverName).toBe('playbook');
    expect(uiResource.serviceInfo?.toolName).toBe('show_playbooks');
    expect(uiResource.serviceInfo?.backendType).toBe('BuiltInWeb');
  });

  it('should generate HTML with Select, Delete, and Navigation buttons', async () => {
    // Multiple playbooks for pagination
    for (let i = 0; i < 3; i++) {
      await playbookStore.callTool('create_playbook', {
        goal: `Button test ${i}`,
        workflow: [],
      });
    }

    const result = await playbookStore.callTool('show_playbooks', {
      page: 1,
      pageSize: 2,
    });
    const uiResource = result.content[1].resource;
    const htmlContent = uiResource.content.htmlString;

    expect(htmlContent).toContain('class="select-pb-btn"');
    expect(htmlContent).toContain('class="delete-pb-btn"');
    expect(htmlContent).toContain('class="nav-page-btn"');
    expect(htmlContent).toContain('data-pbid=');
    expect(htmlContent).toContain('data-page=');
    expect(htmlContent).toContain('window.parent.postMessage');
    expect(htmlContent).toContain('Page 1 of 2');
  });

  it('should disable Previous button on first page', async () => {
    for (let i = 0; i < 3; i++) {
      await playbookStore.callTool('create_playbook', {
        goal: `Goal ${i}`,
        workflow: [],
      });
    }

    const result = await playbookStore.callTool('show_playbooks', {
      page: 1,
      pageSize: 2,
    });
    const htmlContent = result.content[1].resource.content.htmlString;

    expect(htmlContent).toMatch(
      /<button[^>]*data-page="0"[^>]*disabled[^>]*>← Previous/,
    );
  });

  it('should disable Next button on last page', async () => {
    for (let i = 0; i < 3; i++) {
      await playbookStore.callTool('create_playbook', {
        goal: `Goal ${i}`,
        workflow: [],
      });
    }

    const result = await playbookStore.callTool('show_playbooks', {
      page: 2,
      pageSize: 2,
    });
    const htmlContent = result.content[1].resource.content.htmlString;

    expect(htmlContent).toMatch(
      /<button[^>]*data-page="3"[^>]*disabled[^>]*>Next →/,
    );
  });

  it('should escape HTML in playbook goal', async () => {
    await playbookStore.callTool('create_playbook', {
      goal: '<script>alert("xss")</script>',
      workflow: [],
    });

    const result = await playbookStore.callTool('show_playbooks', {});
    const htmlContent = result.content[1].resource.content.htmlString;

    expect(htmlContent).not.toContain('<script>alert("xss")</script>');
    expect(htmlContent).toContain('&lt;script&gt;');
  });
});
```

#### 4. get_playbook_page (페이지네이션) 테스트

```typescript
describe('get_playbook_page (pagination)', () => {
  beforeEach(async () => {
    await playbookStore.switchContext({ assistantId: 'test-agent' });

    // Create test data
    for (let i = 0; i < 5; i++) {
      await playbookStore.callTool('create_playbook', {
        goal: `Page test ${i}`,
        workflow: [],
      });
    }
  });

  it('should navigate to specified page', async () => {
    const result = await playbookStore.callTool('get_playbook_page', {
      page: 2,
      pageSize: 2,
    });

    expect(result.content).toHaveLength(2); // text + UI
    expect(result.content[0].text).toContain('[get_playbook_page]');
    expect(result.content[0].text).toContain('Navigated to page 2');
    expect(result.structured.page.page).toBe(2);
  });

  it('should generate UI with correct page buttons', async () => {
    const result = await playbookStore.callTool('get_playbook_page', {
      page: 2,
      pageSize: 2,
    });

    const htmlContent = result.content[1].resource.content.htmlString;
    expect(htmlContent).toContain('Page 2 of 3');
    expect(htmlContent).toContain('data-page="1"'); // Previous
    expect(htmlContent).toContain('data-page="3"'); // Next
  });

  it('should set serviceInfo.toolName to get_playbook_page', async () => {
    const result = await playbookStore.callTool('get_playbook_page', {
      page: 1,
    });

    const uiResource = result.content[1].resource;
    expect(uiResource.serviceInfo?.toolName).toBe('get_playbook_page');
  });
});
```

#### 5. 페이징 일관성 테스트

```typescript
describe('Pagination Consistency', () => {
  it('should have identical page structure between list and show', async () => {
    await playbookStore.switchContext({ assistantId: 'test-agent' });

    for (let i = 0; i < 3; i++) {
      await playbookStore.callTool('create_playbook', {
        goal: `Goal ${i}`,
        workflow: [],
      });
    }

    const listResult = await playbookStore.callTool('list_playbooks', {
      page: 1,
      pageSize: 2,
    });
    const showResult = await playbookStore.callTool('show_playbooks', {
      page: 1,
      pageSize: 2,
    });

    // 페이지 구조 동일성 검증
    expect(listResult.structured.page.page).toBe(
      showResult.structured.page.page,
    );
    expect(listResult.structured.page.totalItems).toBe(
      showResult.structured.page.totalItems,
    );
    expect(listResult.structured.page.totalPages).toBe(
      showResult.structured.page.totalPages,
    );
  });

  it('should handle pageSize=-1 (all items) correctly', async () => {
    await playbookStore.switchContext({ assistantId: 'test-agent' });

    for (let i = 0; i < 10; i++) {
      await playbookStore.callTool('create_playbook', {
        goal: `Goal ${i}`,
        workflow: [],
      });
    }

    const result = await playbookStore.callTool('list_playbooks', {
      pageSize: -1,
    });

    expect(result.structured.page.items).toHaveLength(10);
    expect(result.structured.page.pageSize).toBe(-1);
    expect(result.structured.page.totalPages).toBe(1);
  });
});
```

#### 6. Agent Context 텍스트 응답 테스트

```typescript
describe('Agent Context-Aware Text Responses', () => {
  beforeEach(async () => {
    await playbookStore.switchContext({ assistantId: 'test-agent' });
  });

  it('list_playbooks should include tool name and context', async () => {
    await playbookStore.callTool('create_playbook', {
      goal: 'Test',
      workflow: [],
    });

    const result = await playbookStore.callTool('list_playbooks', {});
    const text = result.content[0].text;

    expect(text).toContain('[list_playbooks]');
    expect(text).toContain('Found 1 playbook(s)');
    expect(text).toContain('page 1 of 1');
    expect(text).toContain('Note: Use');
  });

  it('get_playbook should include tool name and action hints', async () => {
    const createResult = await playbookStore.callTool('create_playbook', {
      goal: 'Test',
      workflow: [],
    });
    const id = createResult.structured.playbook.id;

    const result = await playbookStore.callTool('get_playbook', { id });
    const text = result.content[0].text;

    expect(text).toContain('[get_playbook]');
    expect(text).toContain(`Retrieved playbook details for ID: ${id}`);
    expect(text).toContain('Note: Use');
  });

  it('select_playbook should include execution instructions', async () => {
    const createResult = await playbookStore.callTool('create_playbook', {
      goal: 'Test Execution',
      workflow: [
        {
          description: 'Step 1',
          action: { toolName: 'test', purpose: 'test' },
          requiredData: [],
          outputVariable: 'out',
        },
      ],
    });
    const id = createResult.structured.playbook.id;

    const result = await playbookStore.callTool('select_playbook', { id });
    const text = result.content[0].text;

    expect(text).toContain('[select_playbook]');
    expect(text).toContain('has been selected for execution');
    expect(text).toContain('Instructions:');
    expect(text).toContain('You may now proceed');
  });

  it('create_playbook should include success confirmation and next steps', async () => {
    const result = await playbookStore.callTool('create_playbook', {
      goal: 'New Playbook',
      workflow: [],
    });
    const text = result.content[0].text;

    expect(text).toContain('[create_playbook]');
    expect(text).toContain('Successfully created');
    expect(text).toContain('ID:');
    expect(text).toContain("Use 'list_playbooks'");
  });

  it('update_playbook should confirm changes', async () => {
    const createResult = await playbookStore.callTool('create_playbook', {
      goal: 'Original',
      workflow: [],
    });
    const id = createResult.structured.playbook.id;

    const result = await playbookStore.callTool('update_playbook', {
      id,
      playbook: { goal: 'Updated' },
    });
    const text = result.content[0].text;

    expect(text).toContain('[update_playbook]');
    expect(text).toContain('Successfully updated');
    expect(text).toContain('Changes are immediately available');
  });

  it('delete_playbook should confirm deletion', async () => {
    const createResult = await playbookStore.callTool('create_playbook', {
      goal: 'To Delete',
      workflow: [],
    });
    const id = createResult.structured.playbook.id;

    const result = await playbookStore.callTool('delete_playbook', { id });
    const text = result.content[0].text;

    expect(text).toContain('[delete_playbook]');
    expect(text).toContain('Successfully deleted');
    expect(text).toContain('no longer available');
  });
});
```

#### 7. Helper Functions 단위 테스트

```typescript
describe('Helper Functions', () => {
  describe('paginateItems', () => {
    const mockItems = Array.from({ length: 10 }, (_, i) => ({
      id: `${i}`,
      agentId: 'test',
      goal: `Goal ${i}`,
      workflow: [],
    }));

    it('should paginate correctly', () => {
      const result = paginateItems(mockItems, 2, 3);
      expect(result.items).toHaveLength(3);
      expect(result.items[0].id).toBe('3'); // 두 번째 페이지 시작
      expect(result.page).toBe(2);
      expect(result.totalPages).toBe(4);
    });

    it('should return all items when pageSize=-1', () => {
      const result = paginateItems(mockItems, 1, -1);
      expect(result.items).toHaveLength(10);
      expect(result.totalPages).toBe(1);
    });

    it('should handle empty array', () => {
      const result = paginateItems([], 1, 10);
      expect(result.items).toHaveLength(0);
      expect(result.totalItems).toBe(0);
      expect(result.totalPages).toBe(0);
    });
  });

  describe('formatPlaybooksList', () => {
    it('should format items with numbering', () => {
      const items = [
        { id: '1', goal: 'Goal 1', workflow: [], createdAt: '2025-01-01' },
        { id: '2', goal: 'Goal 2', workflow: [], createdAt: '2025-01-02' },
      ];
      const result = formatPlaybooksList(items);

      expect(result).toContain('1. id:1 goal:"Goal 1"');
      expect(result).toContain('2. id:2 goal:"Goal 2"');
    });
  });

  describe('escapeHtml', () => {
    it('should escape HTML entities', () => {
      expect(escapeHtml('<script>')).toBe('&lt;script&gt;');
      expect(escapeHtml('a & b')).toBe('a &amp; b');
      expect(escapeHtml('"quote"')).toBe('&quot;quote&quot;');
    });
  });
});
```

### 테스트 실행 가이드

```bash
# 단일 테스트 파일 실행
pnpm test src/lib/web-mcp/modules/__tests__/playbook-store.test.ts

# Watch 모드로 개발
pnpm test:watch playbook-store

# Coverage 확인
pnpm test:coverage
```

### Mock 설정 가이드

```typescript
// DB service mock (필요 시)
jest.mock('@/lib/db', () => ({
  dbService: {
    playbooks: {
      read: jest.fn(),
      upsert: jest.fn(),
      delete: jest.fn(),
      getPage: jest.fn(),
      getPageForAgent: jest.fn(), // ✨ 추가
      count: jest.fn(),
    },
  },
}));
```

## 구현 단계 (권장 순서)

### Phase 0: DB Service 확장 (최우선)

1. **Page<T> 인터페이스 업데이트**
   - `src/lib/db/types.ts`에 `totalPages` 필드 추가
   - 로컬 테스트로 타입 체크 확인

2. **createPage 헬퍼 업데이트**
   - `src/lib/db/crud.ts`에서 `totalPages` 계산 로직 추가
   - 기존 사용처 영향 없는지 확인

3. **DB 스키마 업데이트**
   - `src/lib/db/service.ts`에 version 8 추가
   - `playbooks` 테이블에 `agentId` 인덱스 추가
   - 로컬 테스트로 마이그레이션 동작 확인

4. **타입 정의 확장**
   - `src/lib/db/types.ts`에 `PlaybookCRUD` 인터페이스 추가
   - `DatabaseService.playbooks` 타입 변경

5. **playbooksCRUD 확장**
   - `src/lib/db/crud.ts`에 `getPageForAgent` 메서드 구현
   - 단위 테스트 작성 (agentId 필터링 + 페이징 검증)

### Phase 1: 기반 작업 + show_playbooks + get_playbook_page (Breaking Change 없음)

1. Helper functions 추가
   - `paginateItems()`: In-memory 페이징
   - `createListStructuredResponse()`: 일관된 구조 생성
   - `createListTextResponse()`: Agent context 친화적 텍스트 (list_playbooks용)
   - `createUITextResponse()`: Agent context 친화적 텍스트 (UI 도구용)
   - `getPlaybooksWithUI()`: 공통 UI 생성 로직

2. HTML UI 업데이트
   - `buildUiHtml()` 시그니처 변경 (pageInfo 추가)
   - 페이지네이션 버튼 추가 (Previous/Next)
   - CSS 스타일 추가
   - 이벤트 핸들러 업데이트 (get_playbook_page 호출)

3. `show_playbooks` 툴 추가
   - tools 배열에 정의 추가
   - case 구현 (`getPlaybooksWithUI()` 호출)

4. `get_playbook_page` 툴 추가
   - tools 배열에 정의 추가
   - case 구현 (`getPlaybooksWithUI()` 호출)

5. Helper functions 단위 테스트 작성 및 실행

6. `show_playbooks`, `get_playbook_page` 통합 테스트

### Phase 2: list_playbooks 수정 + 모든 도구 텍스트 개선 (Potentially Breaking)

1. `list_playbooks` case 수정
   - Text-only 응답으로 변경 (UIResource 제거)
   - `getPageForAgent()` 사용 (DB 분기)
   - `paginateItems()` 사용 (in-memory 분기)
   - Agent context 친화적 텍스트 생성
   - In-memory 빈 응답 구조 통일

2. 다른 도구들의 텍스트 응답 개선
   - `get_playbook`: 도구명 + 액션 힌트 추가
   - `select_playbook`: 실행 지침 명확화
   - `create_playbook`: 생성 확인 + 다음 액션
   - `update_playbook`: 업데이트 확인
   - `delete_playbook`: 삭제 확인 + 결과

3. 기존 `list_playbooks` 테스트 업데이트

4. Agent context 텍스트 응답 테스트 추가

### Phase 3: 통합 및 문서화

1. 버전 업데이트 (`0.1.1`)

2. `pnpm refactor:validate` 실행
   - Lint 체크
   - Format 체크
   - TypeScript 컴파일
   - Build 검증

3. 수동 테스트
   - 페이지네이션 UI 동작 확인
   - Previous/Next 버튼 disabled 상태 확인
   - Select/Delete 버튼 정상 동작 확인
   - Agent context에 추가되는 텍스트 확인

4. CHANGELOG 작성 (간단히)

### Phase 4: 릴리즈 (생략 가능 - 비프로덕션)

1. Feature branch merge (선택 사항)
2. 릴리즈 노트 발행 (선택 사항)

## 롤백 계획 (간소화 - 비프로덕션)

### 롤백 트리거

- 치명적 버그 발견
- 빌드 실패
- 테스트 대량 실패

### 롤백 절차

1. Git revert로 이전 커밋으로 복귀
2. `pnpm refactor:validate` 재실행
3. 문제 분석 및 재시도

## 참고 문서

- [MCP Protocol Specification](https://modelcontextprotocol.io/docs)
- [Playbook Type Definition](./src/types/playbook.ts)
- [Web MCP Server Architecture](./docs/architecture/web-mcp-architecture.md) (존재 시)
- [Frontend MCP Integration Guide](./docs/guides/mcp-integration.md) (존재 시)

---

**작성자**: Claude (Anthropic)
**작성일**: 2025-01-11 (updated)
**최종 수정일**: 2025-01-11 23:45
**버전**: 2.0
**리뷰 필요 항목**: Agent Context 텍스트 응답 가독성, 페이지네이션 UI UX

**주요 변경사항 (v2.0)**:

- ✅ `Page<T>` 인터페이스에 `totalPages` 필드 추가
- ✅ `get_playbook_page` 도구 추가 (페이지네이션 내비게이션)
- ✅ **Agent Context 최적화**: 모든 텍스트 응답에 명확한 맥락 정보 추가 (도구명, 요약, 힌트)
- ✅ 페이지네이션 UI 구현 (Previous/Next 버튼, 페이지 정보 표시)
- ✅ 공통 로직 함수 추가 (`getPlaybooksWithUI()`, `createListTextResponse()`, `createUITextResponse()`)
- ✅ `buildUiHtml()` 시그니처 변경 (페이지 정보 전달)
- ✅ 모든 도구의 텍스트 응답 개선 (create, update, delete, get, select)
- ✅ Agent Context 텍스트 응답 테스트 케이스 추가
- ✅ 페이지네이션 UI 테스트 케이스 추가


---

# refactoring_20251101_1735.md

# Refactoring Plan: Taming Over-Complicated Modules

Date: 2025-11-01 17:35  
Branch: feat/on-board  
Author: Copilot

---

## 1) 작업의 목적

대형/복잡 모듈의 응집도를 높이고 결합도를 낮춰서 유지보수성을 개선하고, 렌더/실행 경로 최적화를 통해 응답성 및 안정성을 향상한다.

목표:

- 파일 단위 크기: 1000+ → < 400 LOC 단위로 분리 (최소 2~4개 서브모듈)
- 컨텍스트/서비스 레이어: 역할/경계 명확화, 단방향 의존성 유지
- 성능: 중요 경로(채팅, MCP 호출) 10~30% 지연 감소
- 테스트: 단위/계약 테스트 커버리지 확대 (핵심 경로 70%+)

---

## 2) 현재의 상태 / 문제점

최근 스캔 결과(./scripts/find_large_files.sh):

- 1063 LOC: `src/lib/web-mcp/modules/playbook-store.ts`
- 1023 LOC: `src/lib/web-mcp/modules/planning-server.ts`
- 986 LOC: `src/lib/rust-backend-client.ts`
- 983 LOC: `src/lib/web-mcp/modules/ui-tools.ts`
- 849 LOC: `src-tauri/src/mcp/server.rs`
- 843 LOC: `src/lib/mcp-types.ts`
- 724 LOC: `src/components/ui/sidebar.tsx`
- 705 LOC: `src/context/ResourceAttachmentContext.tsx`
- 622 LOC: `src/context/ChatContext.tsx`
- 578 LOC: `src/context/SessionContext.tsx`
- 561 LOC: `src/lib/logger.ts`
- 556 LOC: `src/features/chat/components/WorkspaceFilesPanel.tsx`

공통 문제 패턴:

- 단일 파일에서 여러 책임(로딩/비즈니스로직/상태/뷰)을 처리 → 응집도 저하
- 직접 의존이 복잡하게 얽혀 테스트/교체 어려움
- 거대한 타입/스키마 파일에서 재사용 어려움 (`mcp-types.ts`)
- 컨텍스트 파일에 I/O와 계산 로직 혼재 → 리렌더링 전파와 병목 발생

---

## 3) Birdeye View (구조/동작 요약)

도메인별 레이어:

- Web MCP 모듈: planning-server, playbook-store, ui-tools → 브라우저 워커/프록시, 명령 처리, 캐시/검색/검증, 도메인 로직.
- Service Layer: `rust-backend-client.ts` → Tauri 명령 래퍼, 안전 호출(safeInvoke), 결과 변환.
- Context Layer: Chat/Session/ResourceAttachment → 상태 분배, I/O 혼재, 파생 상태 계산.
- Types: `mcp-types.ts` → 프로토콜/콘텐츠/툴 정의가 단일 파일에 집중.

흐름 요약:

User → React UI → Context/Service → (Web Worker MCP or Tauri) → 도메인 모듈 → 응답/업데이트 → UI 반영

현재 단위 경계가 명확하지 않아 상호 침투(침식)가 발생하고, 테스트하기 힘든 구조.

---

## 4) 변경 이후의 상태 / 해결 판정 기준

바람직한 상태:

- 각 모듈은 단일 책임 기반으로 2~4개 서브모듈로 분리
- 컨텍스트는 얇게: 파생 상태/구독/액션만, I/O는 서비스로 위임
- 타입/스키마는 작은 단위로 분리, 재사용/트리쉐이킹 용이
- 공통 유틸/어댑터로 의존성 역전 (테스트 더블 주입 쉬움)

판정 기준:

- [ ] 상위 6개 대형 파일 각각 2개 이상 서브파일로 분리, 최대 파일 < 400 LOC
- [ ] 컨텍스트에서 서비스 호출/비즈니스 로직 70% 이상 분리
- [ ] MCP 호출/채팅 경로 벤치마크(로딩/응답) 10~30% 개선
- [ ] 핵심 경로 테스트 커버리지 70%+
- [ ] `pnpm refactor:validate` 전 과정 PASS

---

## 5) 수정이 필요한 코드 및 스니핏 (핵심 제안)

### 5.1 web-mcp: planning-server.ts (1023 LOC)

제안 분리:

- transport.ts: 워커/프록시, 메시지 전송/수신 어댑터
- commands.ts: 계획/세션/스텝 관리 명령 핸들러
- state.ts: 세션 스냅샷, 메모리/캐시 레이어
- schema.ts: zod 스키마/타입 내보내기

예시 스니핏:

```ts
// src/lib/web-mcp/modules/planning-server/commands.ts
import { z } from 'zod';
import { send } from './transport';
import { planSchema } from './schema';

export const createPlan = async (input: unknown) => {
  const parsed = planSchema.parse(input);
  return send('planning.create', parsed);
};
```

```ts
// src/lib/web-mcp/modules/planning-server/index.ts
export * from './commands';
export * from './state';
```

마이그레이션: 기존 `import { PlanningServerProxy } from .../planning-server` → `.../planning-server` (index 리에스크포트).

### 5.2 web-mcp: playbook-store.ts (1063 LOC)

제안 분리:

- repository.ts: 저장/로드/인덱싱
- search.ts: BM25 등 검색 전용 로직
- validator.ts: 스키마 검증, 마이그레이션
- cache.ts: 메모리 캐시/무효화 규칙

예시 스니핏:

```ts
// src/lib/web-mcp/modules/playbook-store/repository.ts
export interface PlaybookRecord {
  id: string;
  title: string;
  body: string;
}
export class PlaybookRepository {
  async save(pb: PlaybookRecord) {
    /* ... */
  }
  async fetch(id: string) {
    /* ... */
  }
}
```

### 5.3 web-mcp: ui-tools.ts (983 LOC)

제안 분리:

- tools/
  - navigation.ts (navigate, back, forward)
  - input.ts (type, click)
  - content.ts (extract, list)
- registry.ts: 툴 등록/검색, 공통 스키마

예시 스니핏:

```ts
// src/lib/web-mcp/modules/ui-tools/registry.ts
export interface Tool {
  name: string;
  run: (args: unknown) => Promise<unknown>;
}
export const toolRegistry = new Map<string, Tool>();
export function registerTool(tool: Tool) {
  toolRegistry.set(tool.name, tool);
}
```

### 5.4 lib: rust-backend-client.ts (986 LOC)

제안 분리:

- invoker.ts: safeInvoke, 공통 오류/리트라이, 결과 역직렬화
- fs.ts, mcp.ts, browser.ts: 도메인별 커맨드 래퍼
- types.ts: 커맨드/결과 타입들 분리

예시 스니핏:

```ts
// src/lib/rust-backend/invoker.ts
import { invoke } from '@tauri-apps/api/core';

export async function safeInvoke<T>(cmd: string, payload: unknown): Promise<T> {
  try {
    return await invoke<T>(cmd, payload as Record<string, unknown>);
  } catch (e) {
    /* normalize & rethrow */ throw e;
  }
}
```

### 5.5 lib: mcp-types.ts (843 LOC)

제안 분리:

- protocol.ts: 코어 프로토콜 타입 (messages, tools, resources)
- content.ts: Content/Attachment 타입
- schema.ts: zod 스키마 정의, from JSON schema (가능 시)

예시 스니핏:

```ts
// src/lib/mcp/types/protocol.ts
export interface MCPMessage {
  role: 'user' | 'assistant';
  content: unknown[];
}
```

### 5.6 context: ChatContext.tsx (622), SessionContext.tsx (578), ResourceAttachmentContext.tsx (705)

제안 분리(공통):

- services/ 디렉토리로 I/O/비즈니스 로직 이전
- context는 파생 상태와 액션 디스패치만 유지
- 이벤트(스크롤/입력) 최적화는 공용 hooks 로 이전 (`useThrottle`, `useDebounce`)

예시 스니핏:

```ts
// src/context/chat/chat-service.ts
export class ChatService {
  // pure async methods: buildPrompt, send, parse, etc.
}
```

```tsx
// src/context/ChatContext.tsx (간결화)
const service = useMemo(() => new ChatService(), []);
const submit = useCallback((msgs) => service.send(msgs), [service]);
```

### 5.7 components/ui/sidebar.tsx (724)

제안:

- Sidebar.tsx → 작은 컴포넌트(Section, Item, Footer)로 분할
- 데이터 계산(useMemo) vs 렌더링 분리, memo + key 안정화

---

## 6) 재사용 가능한 연관 코드

- `src/hooks/useThrottle.ts` (완료): 고빈도 이벤트 성능 안정화
- `src/hooks/useDebounce.ts` (신규 제안): 입력/검색 지연 처리
- `src/lib/services/*`: invoker, repository, validator, registry, cache 등의 공통 패턴
- `src/lib/types/*`: 작은 모듈로 타입/스키마 구성

---

## 7) Test Code 추가/수정 가이드

전략:

- 계약 테스트(Contract): transport/invoker 레벨에서 성공/오류 경로 검증
- 단위 테스트(Unit): repository, validator, registry 로직 커버
- 컨텍스트 통합 테스트: 얇아진 컨텍스트가 서비스에 위임되는지

예시:

```ts
// src/lib/rust-backend/__tests__/invoker.test.ts
import { safeInvoke } from '../invoker';

test('safeInvoke propagates normalized errors', async () => {
  // mock invoke → throw, expect normalized
});
```

```ts
// src/lib/web-mcp/modules/planning-server/__tests__/commands.test.ts
import { createPlan } from '../commands';

test('createPlan validates input and dispatches', async () => {
  // zod parse ok, transport called with proper channel
});
```

커버리지 목표: 핵심 경로 70%+, 실패 경로/엣지 케이스 1~2개 포함.

---

## 8) 작업 단계 (Phased Plan)

Phase 0 — 안전한 인프라 정리 (0.5일)

- 디렉토리 스캐폴드 추가: `src/lib/web-mcp/modules/{planning-server,playbook-store,ui-tools}/...`
- index 리에스크포트 준비, 타입 모듈 디렉토리 생성(`src/lib/mcp/types/*`)

Phase 1 — Services/Types 추출 (1~2일)

- `rust-backend-client.ts` → invoker + 도메인 래퍼 분리
- `mcp-types.ts` → protocol/content/schema 로 분리

Phase 2 — Web MCP 모듈 분할 (2~3일)

- planning-server, playbook-store, ui-tools 각각 3~4개 파일로 분리
- 레거시 import 호환을 위해 index.ts 유지

Phase 3 — Context 얇게 (1~2일)

- Chat/Session/ResourceAttachment의 I/O/로직 서비스 이전
- 컨텍스트는 파생 상태 + 액션 위임 유지, 이벤트 최적화 적용

Phase 4 — UI 컴포넌트 분리 (0.5~1일)

- `components/ui/sidebar.tsx` 소형 컴포넌트로 분할, memoization

Phase 5 — 검증/정리 (0.5~1일)

- `pnpm refactor:validate` 전체 통과
- 프로파일링(React DevTools, Performance): 개선 수치 기록

---

## 9) 성공 지표

- 대형 파일 6개 분리 완료, 최대 파일 < 400 LOC
- MCP/채팅 주요 경로에서 10~30% 응답 개선(프로파일링 기준)
- 테스트 70%+ 커버리지, CI 안정화
- 문서/디렉토리 구조 일관성 확보

---

## 10) 롤백 플랜

- 각 Phase 별 브랜치 분리: `refactor/phase-x-*`
- index 리에스크포트로 점진 마이그레이션 가능
- 문제 발생 시 이전 태그로 리버트, import 경로 영향 최소화

---

## 11) Clarification Q-list

1. Web MCP 모듈에서 브라우저/워커 분리 수준

- 워커/메인 스레드 교차가 잦은 부분을 어떤 기준으로 나눌지? (전송량/빈도 기반)

2. mcp-types 분해 범위

- 외부 MCP 서버 통합 시 호환성 이슈 고려해 zod 스키마 생성까지 진행할지?

3. Context 경량화 시 상태 관리 대안

- 현재 React Context 유지 vs 내부적으로 Zustand 래핑 도입(외부 API 동일)

4. 리팩토링 순서

- 가장 영향 큰 `rust-backend-client.ts` 우선 분리 vs Web MCP 모듈부터 분리 — 우선순위 확인 필요

---

## 12) 추가 참고

- 문서 규칙: `./docs/history/refactoring_{yyyyMMdd_hhmm}.md`
- 실행: `pnpm refactor:validate` (lint/format/Rust/build/dead-code)
- 성능 측정: React DevTools Profiler, Chrome Performance, Lighthouse


---

# refactoring_20251009_1610.md

---
title: 'Refactor: 메시지 BM25 인덱싱 및 검색 도입'
date: 2025-10-09
author: libr-agent/dev
---

# 목적

메시지 저장소를 Rust 백엔드(SQLite)로 이관한 상태에서, 메시지에 대해 BM25 기반의 검색 기능을 추가한다. 검색 결과는 반드시 해당 메시지가 속한 세션을 참조(sessionId)를 포함해야 하며, 인덱스는 점진적으로 확장(near-batch)하도록 설계한다. 프론트엔드에서는 `search_messages`(또는 `messages_search`) API만 노출한다.

요구 요약:

- 메시지 추가 시 인덱스는 즉시 재구성하지 않고 점진적으로(비실시간) 업데이트
- 검색 API 구현 및 페이지네이션 지원
- 인덱스의 디스크 퍼시스턴시(저장/로드) 지원
- 프론트엔드 클라이언트(`src/lib/rust-backend-client.ts`)는 `searchMessages` 단 하나의 호출만 제공

## 현재 상태 / 문제점

- 기존: 메시지 CRUD는 `src-tauri/src/commands/messages_commands.rs` 와 관련 DB 함수가 구현되어 있음. (Message 모델, get_page, upsert, delete 등)
- 아직: 검색 인덱스/검색 로직, 인덱스 저장/로드, 검색용 Tauri 명령이 없음.
- 프론트엔드는 `src/lib/rust-backend-client.ts`에서 메시지 CRUD wrapper를 제공함. 검색 wrapper는 미구현.

## 목표 후 상태 / 성공 판정 기준

- 백엔드에 세션 단위 BM25 인덱스 구현 및 파일 퍼시스턴시 존재
- `messages_search` Tauri 명령이 제공되며 `Page<SearchResult>`를 반환한다. `SearchResult`는 messageId와 sessionId를 포함한다.
- 메시지 업서트 후 일정 시간 내(설정가능) 인덱스에 반영되며, 대용량 세션에서도 부분/증분 재색인 전략으로 성능 저하가 적음
- 프론트엔드에서 `searchMessages`를 호출하여 정상 동작(정확성, 페이지네이션) 확인

## 관련 코드 (Birdseye view)

- `src-tauri/src/commands/messages_commands.rs` - Message 모델 및 메시지 CRUD 현재 위치. (첨부 참조)
- `src/lib/rust-backend-client.ts` - 기존 safeInvoke 기반 wrapper들. 여기서 `searchMessages`만 추가
- 새로 추가될/변경될 항목(권장):
  - `src-tauri/src/search/mod.rs` (검색/인덱스 관리)
  - `src-tauri/src/search/index_storage.rs` (인덱스 파일 입출력, atomic write)
  - `src-tauri/src/commands/messages_search.rs` (Tauri 명령/노출) 또는 기존 `messages_commands.rs`에 명령 추가
  - DB migration: `message_index_meta` 테이블 추가

## 상세 설계

### 데이터 구조

Rust side

```rust
#[derive(Debug, Serialize, Deserialize)]
pub struct SearchResult {
  pub message_id: String,
  pub session_id: String,
  pub score: f32,
  pub snippet: Option<String>,
  pub created_at: i64,
}

// 기존의 Page<T> 타입을 재사용
```

TS side

```ts
export interface SearchResultTS {
  id: string; // messageId
  sessionId: string;
  score: number;
  snippet?: string;
  createdAt: Date;
}
```

### 인덱스 메타 테이블 (SQLite)

테이블: `message_index_meta`

```sql
CREATE TABLE IF NOT EXISTS message_index_meta (
  session_id TEXT PRIMARY KEY,
  index_path TEXT,
  last_indexed_at INTEGER DEFAULT 0,
  doc_count INTEGER DEFAULT 0
);
```

설명: 각 세션별로 인덱스 파일 경로와 마지막 인덱싱 시각을 보관한다. `last_indexed_at`은 메시지의 최신 `created_at`보다 작으면 재색인이 필요함을 의미한다.

### 인덱스 저장 포맷

- 권장: `bincode`(Rust serde)로 이진 직렬화 후 파일 저장(빠른 로드와 작은 용량)
- 저장 방식: 임시 파일에 직렬화 후 atomic rename으로 교체

### 인덱스 빌드 전략 (점진적 확장)

조합 전략: "Lazy build on demand" + "Background worker incremental rebuild"

- 메시지 upsert 시: DB에 저장만 수행. (현재 구현을 유지)
- Upsert 작업은 `message_index_meta`의 `last_indexed_at` 대비 최신 메시지가 있으면 'dirty' 상태로 남김.
- 검색 요청(`messages_search`) 시:
  - 세션 인덱스가 없거나 `dirty`이면, 작은 세션의 경우 동기적으로(요청 내) 인덱스를 빌드하고 검색 실행.
  - 큰 세션의 경우 인덱스 빌드를 백그라운드에서 실행하고, 요청에는 부분 검색(가능한 경우) 또는 "인덱스 빌드 중" 상태를 반환.
- 주기적 백그라운드 worker: dirty 세션들을 탐지하여 배치로 재색인(토큰화+인덱스 추가 또는 전체 재빌드). 이 worker는 토큰화/색인 비용을 분산한다.

대상별 고려사항

- 삭제/업데이트: tombstone 처리 대신 세션 단위 재빌드 권장(단순성)
- 동시성: 빌드 시 snapshot(쿼리 시점 메시지 목록)을 사용하고, 빌드 완료 후 atomic swap

### 인덱스 규모 제한 및 환경변수

운영 환경에서 인덱스의 최대 규모를 고정하면 메모리·성능 관리에 도움이 된다. 이 계획에서는 기본값을 **10,000**으로 제안하되, 런타임에서 쉽게 조정할 수 있도록 환경변수로 노출하도록 한다.

- 환경변수 이름: `MESSAGE_INDEX_MAX_DOCS` (정수, 기본 10000)
- 재색인 배치 크기(옵션): `REINDEX_BATCH_SIZE` (정수, 기본 1000)
- 동작: 인덱스 빌드 시 최신 N개 메시지만 포함한다(N은 `MESSAGE_INDEX_MAX_DOCS`). N을 초과하는 오래된 메시지는 hot 인덱스에서 제외된다. 필요 시 cold 인덱스 또는 전체 검색 경로를 별도로 제공한다.

장점 요약:

- 메모리 사용량과 검색 응답 시간을 안정적으로 제어할 수 있음
- 대규모 세션에서 인덱스 빌드 및 재구성 비용을 제한함

단점/주의:

- 오래된 메시지에 대한 검색 결과가 누락될 수 있음 → UI에 제한 안내 및 전체 검색 옵션 필요
- 삭제/버림 로직은 배치로 처리해야 하며, 메시지 추가마다 즉시 재빌드는 피해야 함

예: Rust에서 환경변수를 읽어 사용하는 간단한 코드 스니펫

```rust
fn max_hot_messages_from_env() -> usize {
  std::env::var("MESSAGE_INDEX_MAX_DOCS")
  .ok()
  .and_then(|s| s.parse::<usize>().ok())
  .filter(|&v| v > 0)
  .unwrap_or(10_000)
}

async fn build_hot_index(session_id: &str) -> Result<BM25Index, String> {
  let max_docs = max_hot_messages_from_env();
  let messages = sqlx::query("SELECT * FROM messages WHERE session_id = ? ORDER BY created_at DESC LIMIT ?")
    .bind(session_id)
    .bind(max_docs as i64)
    .fetch_all(pool)
    .await
    .map_err(|e| format!("db error: {e}"))?;

  // 오래된 것부터 추가하려면 반전
  let docs: Vec<_> = messages.into_iter().rev().map(|m| (m.id, tokenize(&m.content))).collect();
  let index = BM25Index::new(docs);
  Ok(index)
}
```

### 검색 API (Tauri command)

명령 이름: `messages_search`

시그니처(Rust):

```rust
#[command]
pub async fn messages_search(
  query: String,
  session_id: Option<String>,
  page: usize,
  page_size: usize,
) -> Result<Page<SearchResult>, String> { ... }
```

동작 요약:

- 요청 들어오면 세션별 인덱스 로드(메모리 캐시 우선)
- 인덱스가 없거나 dirty이면 동기/비동기 빌드 전략을 적용
- bm25로 쿼리 실행 -> (message_id, score) 리스트 획득
- 필요한 메타(생성시간, session_id) 조회 후 `Page<SearchResult>` 반환

### 프론트엔드 노출

파일: `src/lib/rust-backend-client.ts`

추가 함수(한 개만):

```ts
export async function searchMessages(
  query: string,
  sessionId?: string,
  page = 1,
  pageSize = 25,
): Promise<Page<SearchResultTS>> { ... }
```

요청 파라미터: { query, sessionId?, page, pageSize }

주의: 프론트엔드에는 이 함수만 추가한다(사용자 요구).

## 수정해야 할 파일 목록 (구체적)

- Add: `src-tauri/src/search/mod.rs` (검색 엔진 래퍼, index manager)
- Add: `src-tauri/src/search/index_storage.rs` (파일 IO 및 atomic write)
- Update: `src-tauri/src/commands/messages_commands.rs` or add `src-tauri/src/commands/messages_search.rs` (Tauri command 노출)
- Update: `src-tauri/src/main.rs` (앱 시작 시 인덱스 디렉터리 생성/백그라운드 worker 시작)
- Update: `src-tauri/Cargo.toml` (bm25 crate, bincode, optionally parking_lot or dashmap for in-memory cache)
- Update: `src/lib/rust-backend-client.ts` (add `searchMessages` wrapper)

## 코드 스니펫(참고)

Rust: 메시지 검색 명령(핵심 골격)

```rust
#[command]
pub async fn messages_search(
  query: String,
  session_id: Option<String>,
  page: usize,
  page_size: usize,
) -> Result<Page<SearchResult>, String> {
  // 1. ensure index loaded or build
  // 2. run bm25 search
  // 3. for results, query messages table for created_at (and session_id)
  // 4. create Page<SearchResult> and return
}
```

TS: client wrapper

```ts
export async function searchMessages(
  query,
  sessionId?,
  page = 1,
  pageSize = 25,
) {
  const res = await safeInvoke<Page<Record<string, unknown>>>(
    'messages_search',
    { query, sessionId, page, pageSize },
  );
  return {
    ...res,
    items: res.items.map((r) => ({
      id: r.messageId,
      sessionId: r.sessionId,
      score: r.score,
      snippet: r.snippet,
      createdAt: new Date(r.createdAt),
    })),
  };
}
```

## 테스트 계획

Rust 단위 테스트

- 인덱스 빌드 테스트: 주어진 메시지 집합으로 빌드 시 doc_count 일치
- 검색 정확도 테스트: 키워드를 포함한 메시지에서 높은 점수 부여
- persistence test: build -> store file -> load -> search

통합 테스트

- messages_upsert -> mark dirty -> reindex background -> messages_search에 반영

프론트엔드

- `searchMessages` wrapper 직렬화/역직렬화 검증

명령

```bash
# run rust tests
cd src-tauri && cargo test

# run frontend tests
pnpm test
```

## 롤아웃 계획 및 운영 고려

1. 개발 모드에서 먼저 활성화: 소규모 세션으로 동작 확인
2. 모니터링: 인덱스 빌드 시간, 검색 응답시간, doc_count, 오류율
3. 점진 롤아웃: config 플래그로 켜고 사용자에게 인덱싱 상태 노출
4. 인덱스 재구성이나 대량 업서트의 경우 사전 알림 및 백업(인덱스 파일 + SQLite DB) 권장

## 위험과 완화

- 대량 세션 재빌드 비용: 백그라운드 배치/샤딩으로 완화
- 토크나이저 다국어 문제: 한국어 등에서는 별도 토크나이저(형태소분석기) 도입 검토
- 인덱스 일관성 이슈: 빌드 시 snapshot 사용 및 atomic swap으로 해결

## 작업 우선순위 및 단계별 체크리스트

1. (핵심) `Cargo.toml`에 `bm25` 및 직렬화 의존성 추가
2. `message_index_meta` 테이블 생성 코드 추가 (existing create function 확장)
3. `src-tauri/src/search` 디렉터리와 `mod.rs` 생성: 인덱스 빌드 / load / store / search 구현
4. Tauri 명령 `messages_search` 구현 및 `src/lib/rust-backend-client.ts`에 `searchMessages` 추가
5. Rust 단위/통합 테스트 추가
6. 백그라운드 incremental reindex worker 추가 (옵션)
7. 문서/모니터링/롤아웃

## 참고 (도구, 버전)

- bm25 crate: 권장 v2.3.2 (기능: tokenizer, scorer, serializing 지원 여부 확인)
- 직렬화: `bincode + serde`


---

# refactoring_20251027_0000.md

# Refactoring Plan: SQLx를 Repository Pattern으로 추상화

## 작업의 목적

현재 Commands 레이어에 분산되어 있는 SQLx 직접 호출 및 `db::` 모듈을 Repository Pattern으로 추상화하여 다음을 달성:

1. **관심사의 분리**: Commands는 비즈니스 로직, Repository는 데이터 접근 로직으로 명확히 분리
2. **테스트 용이성**: Repository를 Mock으로 대체 가능하도록 하여 유닛 테스트 작성 지원
3. **재사용성 향상**: 동일한 쿼리 로직을 여러 Commands에서 재사용 가능
4. **타입 안전성**: 구조화된 에러 타입(`DbError`)으로 에러 처리 개선
5. **유지보수성**: DB 쿼리 로직을 중앙 집중화하여 변경 시 영향 범위 최소화

---

## 현재의 상태 / 문제점

### 1. 현재 구조

```
commands/
├── messages_commands.rs
│   ├── pub mod db { ... }      # SQLx 직접 호출 (9개 함수)
│   └── Tauri commands          # db:: 모듈 호출
├── content_store_commands.rs   # SQLx 직접 호출
└── session_commands.rs         # SQLx 직접 호출

lib.rs                          # db::create_messages_table() 호출
search/background_worker.rs     # db::is_index_dirty(), update_index_meta() 호출
```

### 2. 주요 문제점

#### **A. 관심사 미분리**

- Commands 파일 내부에 `pub mod db { ... }` 형태로 데이터 접근 로직이 혼재
- `content_store_commands.rs`와 `session_commands.rs`는 함수 내에서 직접 `sqlx::query()` 호출

#### **B. 테스트 어려움**

- DB 로직을 Mock으로 대체할 수 없어 통합 테스트만 가능
- 유닛 테스트 작성 불가

#### **C. 코드 중복 및 재사용 불가**

- 동일한 쿼리 패턴을 여러 곳에서 반복 작성
- 예: `content_store_commands.rs`에서 매번 `SqlitePool::connect()` 수행

#### **D. 에러 처리 일관성 부족**

- 모든 에러를 `String`으로 반환하여 타입 안전성 저하
- 에러 종류 구분 불가 (NotFound vs QueryFailed 등)

#### **E. 의존성 결합도 높음**

- Commands가 SQLx에 직접 의존
- 나중에 다른 DB로 변경 시 Commands 전체 수정 필요

---

## 관련 코드의 구조 및 동작 방식 Summary

### 현재 SQLx 사용 패턴

```
┌─────────────────────────────────────────┐
│         Tauri Commands                   │
│  - messages_get_page()                   │
│  - messages_upsert()                     │
│  - delete_content_store()                │
│  - remove_session()                      │
└─────────────────┬───────────────────────┘
                  │ (직접 호출)
                  ▼
┌─────────────────────────────────────────┐
│      db:: 모듈 또는 인라인 코드          │
│  - sqlx::query(...)                      │
│  - SqlitePool::connect()                 │
└─────────────────┬───────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│         sqlx::SqlitePool                 │
│  (Low-level database access)             │
└─────────────────────────────────────────┘
```

### SQLx 사용 위치 (총 3개 파일)

#### 1. `commands/messages_commands.rs`

- **`pub mod db`**: 9개 함수
  - `create_messages_table()` - 테이블 초기화
  - `get_messages_page()` - 페이지네이션 조회
  - `upsert_message()` - 단일 메시지 저장
  - `upsert_messages()` - 다중 메시지 저장 (트랜잭션)
  - `delete_message()` - 메시지 삭제
  - `delete_all_for_session()` - 세션 전체 삭제
  - `update_index_meta()` - 인덱스 메타데이터 업데이트
  - `get_last_indexed_at()` - 마지막 인덱싱 시간 조회
  - `is_index_dirty()` - 인덱스 갱신 필요 여부 확인

- **Tauri Commands**: 5개 함수가 `db::` 호출
- **내부 함수**: `get_or_build_index()`가 `db::` 호출

#### 2. `commands/content_store_commands.rs`

- `delete_content_store()` 함수 내에서 직접 SQLx 호출
  - `SqlitePool::connect()` - DB 연결
  - `sqlx::query("DELETE FROM chunks ...")` - 3개 테이블 삭제

#### 3. `commands/session_commands.rs`

- `remove_session()` 함수 내에서 직접 SQLx 호출
  - `sqlx::query("DELETE FROM message_index_meta ...")`

### 외부 호출 지점

#### 1. `lib.rs`

```rust
commands::messages_commands::db::create_messages_table(&pool).await
```

#### 2. `search/background_worker.rs`

```rust
use crate::commands::messages_commands::db::{is_index_dirty, update_index_meta};
```

---

## 변경 이후의 상태 / 해결 판정 기준

### 목표 아키텍처

```
┌─────────────────────────────────────────┐
│         Tauri Commands                   │
│  (Business logic only)                   │
└─────────────────┬───────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│      Repository Layer                    │
│  - MessageRepository trait               │
│  - SqliteMessageRepository               │
│  - ContentStoreRepository trait          │
│  - SqliteContentStoreRepository          │
│  - SessionRepository trait               │
│  - SqliteSessionRepository               │
└─────────────────┬───────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│         sqlx::SqlitePool                 │
└─────────────────────────────────────────┘
```

### 변경 후 파일 구조

```
src-tauri/src/
├── repositories/
│   ├── mod.rs                          [수정] - 모듈 export
│   ├── error.rs                        [수정] - DbError 타입
│   ├── message_repository.rs           [수정] - Trait + Impl
│   ├── content_store_repository.rs     [수정] - Trait + Impl
│   └── session_repository.rs           [수정] - Trait + Impl
│
├── commands/
│   ├── messages_commands.rs            [수정] - db:: 모듈 제거, Repository 사용
│   ├── content_store_commands.rs       [수정] - Repository 사용
│   └── session_commands.rs             [수정] - Repository 사용
│
├── lib.rs                              [수정] - Repository 사용
└── search/background_worker.rs         [수정] - Repository 사용
```

### 해결 판정 기준

#### ✅ 필수 조건

1. `pub mod db` 모듈이 완전히 제거됨
2. 모든 Commands에서 Repository를 통해 DB 접근
3. `cargo check` 및 `cargo clippy` 통과
4. 기존 통합 테스트 모두 통과
5. 에러 타입이 `DbError`로 통일 (Commands는 String 변환)

#### ✅ 선택 조건

1. Repository 유닛 테스트 추가 (Mock 기반)
2. 성능 테스트 (Repository 추상화 오버헤드 확인)

---

## 수정이 필요한 코드 및 수정부분 코드 스니핏

### 1. repositories/error.rs

#### 현재 상태

```rust
// 빈 파일
```

#### 수정 후

```rust
use thiserror::Error;

#[derive(Debug, Error)]
pub enum DbError {
    #[error("Database query failed: {0}")]
    QueryFailed(#[from] sqlx::Error),

    #[error("Record not found: {0}")]
    NotFound(String),

    #[error("Invalid input: {0}")]
    InvalidInput(String),

    #[error("Transaction failed: {0}")]
    TransactionFailed(String),
}

// Tauri commands 호환성을 위한 String 변환
impl From<DbError> for String {
    fn from(err: DbError) -> String {
        err.to_string()
    }
}
```

---

### 2. repositories/message_repository.rs

#### 현재 상태

```rust
// 빈 파일
```

#### 수정 후 (핵심 구조)

```rust
use async_trait::async_trait;
use sqlx::{Row, SqlitePool};
use crate::commands::messages_commands::{Message, Page};
use super::error::DbError;

/// Message repository trait for abstraction
#[async_trait]
pub trait MessageRepository: Send + Sync {
    async fn create_table(&self) -> Result<(), DbError>;
    async fn get_page(&self, session_id: &str, page: usize, page_size: usize) -> Result<Page<Message>, DbError>;
    async fn insert(&self, message: &Message) -> Result<(), DbError>;
    async fn insert_many(&self, messages: Vec<Message>) -> Result<(), DbError>;
    async fn delete_by_id(&self, message_id: &str) -> Result<(), DbError>;
    async fn delete_by_session(&self, session_id: &str) -> Result<(), DbError>;
    async fn update_index_meta(&self, session_id: &str, index_path: &str, doc_count: usize, rebuild_duration_ms: i64) -> Result<(), DbError>;
    async fn get_last_indexed_at(&self, session_id: &str) -> Result<i64, DbError>;
    async fn is_index_dirty(&self, session_id: &str) -> Result<bool, DbError>;
}

/// SQLite implementation of MessageRepository
pub struct SqliteMessageRepository {
    pool: SqlitePool,
}

impl SqliteMessageRepository {
    pub fn new(pool: SqlitePool) -> Self {
        Self { pool }
    }
}

#[async_trait]
impl MessageRepository for SqliteMessageRepository {
    async fn create_table(&self) -> Result<(), DbError> {
        // db::create_messages_table() 로직 이동
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL CHECK(session_id <> ''),
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                tool_calls TEXT,
                tool_call_id TEXT,
                is_streaming INTEGER,
                thinking TEXT,
                thinking_signature TEXT,
                assistant_id TEXT,
                attachments TEXT,
                tool_use TEXT,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                source TEXT,
                error TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_messages_session_created
            ON messages(session_id, created_at);

            CREATE INDEX IF NOT EXISTS idx_messages_session_id
            ON messages(session_id);

            CREATE TABLE IF NOT EXISTS message_index_meta (
                session_id TEXT PRIMARY KEY,
                index_path TEXT,
                last_indexed_at INTEGER DEFAULT 0,
                doc_count INTEGER DEFAULT 0,
                index_version INTEGER DEFAULT 1,
                last_rebuild_duration_ms INTEGER
            );
            "#,
        )
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    async fn get_page(&self, session_id: &str, page: usize, page_size: usize) -> Result<Page<Message>, DbError> {
        // db::get_messages_page() 로직 이동
        if page_size == 0 {
            return Err(DbError::InvalidInput("page_size must be > 0".into()));
        }

        let offset = (page.saturating_sub(1)) as i64 * page_size as i64;

        let row = sqlx::query("SELECT COUNT(1) as count FROM messages WHERE session_id = ?")
            .bind(session_id)
            .fetch_one(&self.pool)
            .await?;
        let total: i64 = row.get("count");

        let rows = sqlx::query(
            r#"
            SELECT
                id, session_id, role, content, tool_calls, tool_call_id,
                is_streaming, thinking, thinking_signature, assistant_id,
                attachments, tool_use, created_at, updated_at, source, error
            FROM messages
            WHERE session_id = ?
            ORDER BY created_at ASC
            LIMIT ? OFFSET ?
            "#,
        )
        .bind(session_id)
        .bind(page_size as i64)
        .bind(offset)
        .fetch_all(&self.pool)
        .await?;

        let messages: Vec<Message> = rows
            .into_iter()
            .map(|row| Message {
                id: row.get("id"),
                session_id: row.get("session_id"),
                role: row.get("role"),
                content: row.get("content"),
                tool_calls: row.get("tool_calls"),
                tool_call_id: row.get("tool_call_id"),
                is_streaming: row.get("is_streaming"),
                thinking: row.get("thinking"),
                thinking_signature: row.get("thinking_signature"),
                assistant_id: row.get("assistant_id"),
                attachments: row.get("attachments"),
                tool_use: row.get("tool_use"),
                created_at: row.get("created_at"),
                updated_at: row.get("updated_at"),
                source: row.get("source"),
                error: row.get("error"),
            })
            .collect();

        let total_usize = total as usize;
        let has_prev = page > 1;
        let has_next = page * page_size < total_usize;

        Ok(Page {
            items: messages,
            page,
            page_size,
            total_items: total_usize,
            has_next_page: has_next,
            has_previous_page: has_prev,
        })
    }

    async fn insert(&self, message: &Message) -> Result<(), DbError> {
        // db::upsert_message() 로직 이동
        sqlx::query(
            r#"
            INSERT INTO messages (
                id, session_id, role, content, tool_calls, tool_call_id,
                is_streaming, thinking, thinking_signature, assistant_id,
                attachments, tool_use, created_at, updated_at, source, error
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                session_id = excluded.session_id,
                role = excluded.role,
                content = excluded.content,
                tool_calls = excluded.tool_calls,
                tool_call_id = excluded.tool_call_id,
                is_streaming = excluded.is_streaming,
                thinking = excluded.thinking,
                thinking_signature = excluded.thinking_signature,
                assistant_id = excluded.assistant_id,
                attachments = excluded.attachments,
                tool_use = excluded.tool_use,
                updated_at = excluded.updated_at,
                source = excluded.source,
                error = excluded.error
            "#,
        )
        .bind(&message.id)
        .bind(&message.session_id)
        .bind(&message.role)
        .bind(&message.content)
        .bind(&message.tool_calls)
        .bind(&message.tool_call_id)
        .bind(message.is_streaming)
        .bind(&message.thinking)
        .bind(&message.thinking_signature)
        .bind(&message.assistant_id)
        .bind(&message.attachments)
        .bind(&message.tool_use)
        .bind(message.created_at)
        .bind(message.updated_at)
        .bind(&message.source)
        .bind(&message.error)
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    async fn insert_many(&self, messages: Vec<Message>) -> Result<(), DbError> {
        // db::upsert_messages() 로직 이동 (트랜잭션 포함)
        let mut tx = self.pool.begin().await?;

        for message in messages {
            sqlx::query(
                r#"
                INSERT INTO messages (
                    id, session_id, role, content, tool_calls, tool_call_id,
                    is_streaming, thinking, thinking_signature, assistant_id,
                    attachments, tool_use, created_at, updated_at, source, error
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    session_id = excluded.session_id,
                    role = excluded.role,
                    content = excluded.content,
                    tool_calls = excluded.tool_calls,
                    tool_call_id = excluded.tool_call_id,
                    is_streaming = excluded.is_streaming,
                    thinking = excluded.thinking,
                    thinking_signature = excluded.thinking_signature,
                    assistant_id = excluded.assistant_id,
                    attachments = excluded.attachments,
                    tool_use = excluded.tool_use,
                    updated_at = excluded.updated_at,
                    source = excluded.source,
                    error = excluded.error
                "#,
            )
            .bind(&message.id)
            .bind(&message.session_id)
            .bind(&message.role)
            .bind(&message.content)
            .bind(&message.tool_calls)
            .bind(&message.tool_call_id)
            .bind(message.is_streaming)
            .bind(&message.thinking)
            .bind(&message.thinking_signature)
            .bind(&message.assistant_id)
            .bind(&message.attachments)
            .bind(&message.tool_use)
            .bind(message.created_at)
            .bind(message.updated_at)
            .bind(&message.source)
            .bind(&message.error)
            .execute(&mut *tx)
            .await?;
        }

        tx.commit().await.map_err(|e| DbError::TransactionFailed(e.to_string()))?;
        Ok(())
    }

    async fn delete_by_id(&self, message_id: &str) -> Result<(), DbError> {
        // db::delete_message() 로직 이동
        sqlx::query("DELETE FROM messages WHERE id = ?")
            .bind(message_id)
            .execute(&self.pool)
            .await?;
        Ok(())
    }

    async fn delete_by_session(&self, session_id: &str) -> Result<(), DbError> {
        // db::delete_all_for_session() 로직 이동
        sqlx::query("DELETE FROM messages WHERE session_id = ?")
            .bind(session_id)
            .execute(&self.pool)
            .await?;
        Ok(())
    }

    async fn update_index_meta(
        &self,
        session_id: &str,
        index_path: &str,
        doc_count: usize,
        rebuild_duration_ms: i64,
    ) -> Result<(), DbError> {
        // db::update_index_meta() 로직 이동
        let now = chrono::Utc::now().timestamp_millis();

        sqlx::query(
            r#"
            INSERT INTO message_index_meta (session_id, index_path, last_indexed_at, doc_count, last_rebuild_duration_ms)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(session_id) DO UPDATE SET
                index_path = excluded.index_path,
                last_indexed_at = excluded.last_indexed_at,
                doc_count = excluded.doc_count,
                last_rebuild_duration_ms = excluded.last_rebuild_duration_ms
            "#,
        )
        .bind(session_id)
        .bind(index_path)
        .bind(now)
        .bind(doc_count as i64)
        .bind(rebuild_duration_ms)
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    async fn get_last_indexed_at(&self, session_id: &str) -> Result<i64, DbError> {
        // db::get_last_indexed_at() 로직 이동
        let result = sqlx::query("SELECT last_indexed_at FROM message_index_meta WHERE session_id = ?")
            .bind(session_id)
            .fetch_optional(&self.pool)
            .await?;

        Ok(result.map(|row| row.get("last_indexed_at")).unwrap_or(0))
    }

    async fn is_index_dirty(&self, session_id: &str) -> Result<bool, DbError> {
        // db::is_index_dirty() 로직 이동
        let last_indexed_at = self.get_last_indexed_at(session_id).await?;

        let row = sqlx::query("SELECT MAX(created_at) as max_created FROM messages WHERE session_id = ?")
            .bind(session_id)
            .fetch_one(&self.pool)
            .await?;

        let max_created: Option<i64> = row.get("max_created");
        Ok(max_created.map(|t| t > last_indexed_at).unwrap_or(false))
    }
}
```

---

### 3. repositories/content_store_repository.rs

#### 현재 상태

```rust
// 빈 파일
```

#### 수정 후

```rust
use async_trait::async_trait;
use sqlx::SqlitePool;
use super::error::DbError;

#[async_trait]
pub trait ContentStoreRepository: Send + Sync {
    async fn delete_by_session(&self, session_id: &str) -> Result<(), DbError>;
}

pub struct SqliteContentStoreRepository {
    pool: SqlitePool,
}

impl SqliteContentStoreRepository {
    pub fn new(pool: SqlitePool) -> Self {
        Self { pool }
    }
}

#[async_trait]
impl ContentStoreRepository for SqliteContentStoreRepository {
    async fn delete_by_session(&self, session_id: &str) -> Result<(), DbError> {
        // delete_content_store() 함수의 SQLx 로직 이동
        sqlx::query(
            "DELETE FROM chunks WHERE content_id IN (SELECT id FROM contents WHERE session_id = ?)",
        )
        .bind(session_id)
        .execute(&self.pool)
        .await?;

        sqlx::query("DELETE FROM contents WHERE session_id = ?")
            .bind(session_id)
            .execute(&self.pool)
            .await?;

        sqlx::query("DELETE FROM stores WHERE session_id = ?")
            .bind(session_id)
            .execute(&self.pool)
            .await?;

        Ok(())
    }
}
```

---

### 4. repositories/session_repository.rs

#### 현재 상태

```rust
// 빈 파일
```

#### 수정 후

```rust
use async_trait::async_trait;
use sqlx::SqlitePool;
use super::error::DbError;

#[async_trait]
pub trait SessionRepository: Send + Sync {
    async fn delete_index_metadata(&self, session_id: &str) -> Result<(), DbError>;
}

pub struct SqliteSessionRepository {
    pool: SqlitePool,
}

impl SqliteSessionRepository {
    pub fn new(pool: SqlitePool) -> Self {
        Self { pool }
    }
}

#[async_trait]
impl SessionRepository for SqliteSessionRepository {
    async fn delete_index_metadata(&self, session_id: &str) -> Result<(), DbError> {
        sqlx::query("DELETE FROM message_index_meta WHERE session_id = ?")
            .bind(session_id)
            .execute(&self.pool)
            .await?;
        Ok(())
    }
}
```

---

### 5. repositories/mod.rs

#### 현재 상태

```rust
// 빈 파일
```

#### 수정 후

```rust
pub mod error;
pub mod message_repository;
pub mod content_store_repository;
pub mod session_repository;

pub use error::DbError;
pub use message_repository::{MessageRepository, SqliteMessageRepository};
pub use content_store_repository::{ContentStoreRepository, SqliteContentStoreRepository};
pub use session_repository::{SessionRepository, SqliteSessionRepository};
```

---

### 6. commands/messages_commands.rs

#### 수정 전 (주요 부분)

```rust
use crate::state::get_sqlite_pool;

pub mod db {
    // ... 330줄의 db 로직 ...
}

#[command]
pub async fn messages_get_page(
    session_id: String,
    page: usize,
    page_size: usize,
) -> Result<Page<Message>, String> {
    let pool = get_sqlite_pool();
    db::get_messages_page(pool, &session_id, page, page_size).await
}

async fn get_or_build_index(session_id: &str) -> Result<MessageSearchEngine, String> {
    let pool = get_sqlite_pool();
    let is_dirty = db::is_index_dirty(pool, session_id).await?;
    // ...
    db::update_index_meta(pool, session_id, &index_path, doc_count, duration_ms).await?;
    // ...
}
```

#### 수정 후

```rust
use crate::state::get_sqlite_pool;
use crate::repositories::message_repository::{MessageRepository, SqliteMessageRepository};

// pub mod db { ... } 완전히 제거

#[command]
pub async fn messages_get_page(
    session_id: String,
    page: usize,
    page_size: usize,
) -> Result<Page<Message>, String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    repo.get_page(&session_id, page, page_size)
        .await
        .map_err(|e| e.to_string())
}

#[command]
pub async fn messages_upsert_many(messages: Vec<Message>) -> Result<(), String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    repo.insert_many(messages)
        .await
        .map_err(|e| e.to_string())
}

#[command]
pub async fn messages_upsert(message: Message) -> Result<(), String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    repo.insert(&message)
        .await
        .map_err(|e| e.to_string())
}

#[command]
pub async fn messages_delete(message_id: String) -> Result<(), String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    repo.delete_by_id(&message_id)
        .await
        .map_err(|e| e.to_string())
}

#[command]
pub async fn messages_delete_all_for_session(session_id: String) -> Result<(), String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    repo.delete_by_session(&session_id)
        .await
        .map_err(|e| e.to_string())
}

async fn get_or_build_index(session_id: &str) -> Result<MessageSearchEngine, String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    let is_dirty = repo.is_index_dirty(session_id).await.map_err(|e| e.to_string())?;
    // ...
    repo.update_index_meta(session_id, &index_path, doc_count, duration_ms)
        .await
        .map_err(|e| e.to_string())?;
    // ...
}
```

---

### 7. lib.rs

#### 수정 전

```rust
commands::messages_commands::db::create_messages_table(&pool)
    .await
    .expect("Failed to create messages table");
```

#### 수정 후

```rust
use crate::repositories::message_repository::{MessageRepository, SqliteMessageRepository};

let repo = SqliteMessageRepository::new(pool.clone());
repo.create_table()
    .await
    .expect("Failed to create messages table");
```

---

### 8. search/background_worker.rs

#### 수정 전

```rust
use crate::commands::messages_commands::db::{is_index_dirty, update_index_meta};

async fn reindex_dirty_sessions() -> Result<(), String> {
    // ...
    let is_dirty = is_index_dirty(pool, &session_id).await?;
    // ...
}

async fn rebuild_session_index(session_id: &str) -> Result<(), String> {
    // ...
    update_index_meta(pool, session_id, &index_path, doc_count, duration_ms).await?;
    // ...
}
```

#### 수정 후

```rust
use crate::repositories::message_repository::{MessageRepository, SqliteMessageRepository};

async fn reindex_dirty_sessions() -> Result<(), String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    // ...
    let is_dirty = repo.is_index_dirty(&session_id).await.map_err(|e| e.to_string())?;
    // ...
}

async fn rebuild_session_index(session_id: &str) -> Result<(), String> {
    let pool = get_sqlite_pool();
    let repo = SqliteMessageRepository::new(pool.clone());
    // ...
    repo.update_index_meta(session_id, &index_path, doc_count, duration_ms)
        .await
        .map_err(|e| e.to_string())?;
    // ...
}
```

---

### 9. commands/content_store_commands.rs

#### 수정 전

```rust
#[tauri::command]
pub async fn delete_content_store(session_id: String) -> Result<(), String> {
    if let Some(db_url) = get_sqlite_db_url() {
        let db_path = if let Some(p) = db_url.strip_prefix("sqlite://") {
            p.to_string()
        } else {
            db_url.clone()
        };

        let pool = SqlitePool::connect(&db_path).await.map_err(...)?;

        sqlx::query("DELETE FROM chunks WHERE content_id IN ...").bind(&session_id).execute(&pool).await?;
        sqlx::query("DELETE FROM contents WHERE session_id = ?").bind(&session_id).execute(&pool).await?;
        sqlx::query("DELETE FROM stores WHERE session_id = ?").bind(&session_id).execute(&pool).await?;
    }
    // ... 파일 시스템 정리 ...
}
```

#### 수정 후

```rust
use crate::repositories::content_store_repository::{ContentStoreRepository, SqliteContentStoreRepository};
use crate::state::get_sqlite_pool;

#[tauri::command]
pub async fn delete_content_store(session_id: String) -> Result<(), String> {
    if get_sqlite_db_url().is_some() {
        let pool = get_sqlite_pool();
        let repo = SqliteContentStoreRepository::new(pool.clone());
        repo.delete_by_session(&session_id)
            .await
            .map_err(|e| e.to_string())?;
    }

    // 파일 시스템 정리는 그대로 유지
    let session_manager = get_session_manager()?;
    let search_index_dir = session_manager
        .get_session_workspace_dir()
        .join("content_store_search");

    if search_index_dir.exists() {
        tokio_fs::remove_dir_all(&search_index_dir).await?;
    }

    Ok(())
}
```

---

### 10. commands/session_commands.rs

#### 수정 전

```rust
pub async fn remove_session(session_id: String) -> Result<(), String> {
    // ...
    let pool = get_sqlite_pool();
    if let Err(e) = sqlx::query("DELETE FROM message_index_meta WHERE session_id = ?")
        .bind(&session_id)
        .execute(pool)
        .await
    {
        error!("Failed to delete index metadata: {e}");
    }
    // ...
}
```

#### 수정 후

```rust
use crate::repositories::session_repository::{SessionRepository, SqliteSessionRepository};

pub async fn remove_session(session_id: String) -> Result<(), String> {
    // ...
    let pool = get_sqlite_pool();
    let repo = SqliteSessionRepository::new(pool.clone());

    if let Err(e) = repo.delete_index_metadata(&session_id).await {
        error!("Failed to delete index metadata: {e}");
    }
    // ...
}
```

---

## 재사용 가능한 연관 코드

### 1. 타입 정의 (그대로 사용)

- `commands/messages_commands.rs`의 `Message`, `Page<T>` 타입
- Repository에서 import하여 사용

### 2. State 관리 함수 (그대로 사용)

- `state::get_sqlite_pool()` - 전역 pool 가져오기
- `state::get_sqlite_db_url()` - DB URL 가져오기

### 3. 기존 쿼리 로직 (100% 재사용)

- `db::` 모듈의 모든 쿼리 로직을 Repository로 복사-붙여넣기
- SQL 문, bind 로직, 결과 매핑 로직 모두 동일

### 4. 에러 변환 패턴

```rust
// 표준 패턴
repo.method(...)
    .await
    .map_err(|e| e.to_string())
```

---

## Test Code 추가 및 수정 가이드

### 1. Repository 유닛 테스트 (신규 추가)

#### 테스트 파일 위치

```
src-tauri/src/repositories/
├── message_repository.rs
└── tests/
    ├── mod.rs
    └── message_repository_test.rs
```

#### 테스트 시나리오

**A. Mock을 사용한 유닛 테스트**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use mockall::mock;

    // Mock Repository 정의
    mock! {
        pub MessageRepository {}

        #[async_trait]
        impl MessageRepository for MessageRepository {
            async fn get_page(&self, session_id: &str, page: usize, page_size: usize)
                -> Result<Page<Message>, DbError>;
            // ... 나머지 메서드
        }
    }

    #[tokio::test]
    async fn test_get_page_returns_correct_pagination() {
        let mut mock_repo = MockMessageRepository::new();
        mock_repo
            .expect_get_page()
            .with(eq("session-1"), eq(1), eq(10))
            .times(1)
            .returning(|_, _, _| {
                Ok(Page {
                    items: vec![],
                    page: 1,
                    page_size: 10,
                    total_items: 0,
                    has_next_page: false,
                    has_previous_page: false,
                })
            });

        let result = mock_repo.get_page("session-1", 1, 10).await;
        assert!(result.is_ok());
    }
}
```

**B. 실제 DB를 사용한 통합 테스트**

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    use sqlx::SqlitePool;

    async fn setup_test_db() -> SqlitePool {
        let pool = SqlitePool::connect("sqlite::memory:").await.unwrap();
        let repo = SqliteMessageRepository::new(pool.clone());
        repo.create_table().await.unwrap();
        pool
    }

    #[tokio::test]
    async fn test_insert_and_get_message() {
        let pool = setup_test_db().await;
        let repo = SqliteMessageRepository::new(pool);

        let message = Message {
            id: "msg-1".to_string(),
            session_id: "session-1".to_string(),
            role: "user".to_string(),
            content: "Hello".to_string(),
            // ... 나머지 필드
        };

        // Insert
        repo.insert(&message).await.unwrap();

        // Get
        let page = repo.get_page("session-1", 1, 10).await.unwrap();
        assert_eq!(page.items.len(), 1);
        assert_eq!(page.items[0].id, "msg-1");
    }
}
```

### 2. 기존 통합 테스트 수정

기존 Commands 통합 테스트는 **수정 불필요**합니다. 이유:

- Commands의 public API (Tauri command 시그니처)는 변경 없음
- 내부 구현만 변경되었으므로 기존 테스트가 그대로 동작

단, 테스트가 실패하면 다음을 확인:

1. DB 초기화 로직이 올바르게 변경되었는지 (`create_table()` 호출)
2. 에러 메시지 형식이 변경되었는지 (DbError → String 변환)

### 3. 성능 테스트 (선택 사항)

```rust
#[cfg(test)]
mod performance_tests {
    use super::*;
    use std::time::Instant;

    #[tokio::test]
    async fn test_repository_overhead() {
        let pool = setup_test_db().await;
        let repo = SqliteMessageRepository::new(pool.clone());

        // 1000개 메시지 삽입 시간 측정
        let start = Instant::now();
        for i in 0..1000 {
            let message = create_test_message(i);
            repo.insert(&message).await.unwrap();
        }
        let duration = start.elapsed();

        println!("Repository insert 1000 messages: {:?}", duration);
        assert!(duration.as_secs() < 5); // 5초 이내
    }
}
```

---

## 추가 분석 과제

### 1. Pool Clone 성능 영향 분석

**현상:**

```rust
let repo = SqliteMessageRepository::new(pool.clone());
```

매 호출마다 `pool.clone()`이 발생합니다.

**분석 필요 사항:**

- `SqlitePool`은 내부적으로 `Arc<PoolInner>`이므로 clone이 cheap함
- 하지만 실제 성능 영향을 벤치마크로 측정 필요
- 대안: Tauri State로 Repository를 관리하여 clone 제거

**측정 방법:**

```rust
// 벤치마크 코드
let iterations = 10000;

// Pattern 1: 매번 clone
let start = Instant::now();
for _ in 0..iterations {
    let repo = SqliteMessageRepository::new(pool.clone());
    // use repo
}
let clone_duration = start.elapsed();

// Pattern 2: 한 번만 생성
let start = Instant::now();
let repo = SqliteMessageRepository::new(pool.clone());
for _ in 0..iterations {
    // use same repo
}
let reuse_duration = start.elapsed();

println!("Clone: {:?}, Reuse: {:?}", clone_duration, reuse_duration);
```

### 2. Trait vs Struct 직접 사용

**현재 설계:**

```rust
pub trait MessageRepository { ... }
pub struct SqliteMessageRepository { ... }
```

**분석 필요 사항:**

- Trait을 정의하는 이유: Mock 테스트, 다중 구현체 지원
- 단점: `dyn` 사용 시 dynamic dispatch 오버헤드
- 현재는 Trait을 정의하지만 Commands에서는 concrete type 사용

**대안 검토:**

1. Trait 제거하고 Struct만 사용 (간단함, Mock 어려움)
2. Trait + Struct 유지 (현재 방식, 유연성 높음)
3. Generic + Trait bound (복잡도 증가)

**권장:** Trait + Struct 유지 (테스트 용이성이 더 중요)

### 3. 트랜잭션 처리 개선

**현재 구조:**

```rust
async fn insert_many(&self, messages: Vec<Message>) -> Result<(), DbError> {
    let mut tx = self.pool.begin().await?;
    // ... 여러 쿼리 ...
    tx.commit().await?;
}
```

**분석 필요 사항:**

- 모든 트랜잭션이 Repository 내부에 캡슐화됨
- 만약 여러 Repository 호출을 하나의 트랜잭션으로 묶으려면?
  - 예: MessageRepository + ContentStoreRepository 동시 업데이트

**대안:**

```rust
// Transaction-aware Repository
pub struct SqliteMessageRepository<'a> {
    executor: &'a dyn Executor<'a, Database = Sqlite>,
}

// Pool 또는 Transaction 모두 받을 수 있음
let repo = SqliteMessageRepository::new(&pool);
let repo = SqliteMessageRepository::new(&mut tx);
```

**권장:** 현재는 단순하게 유지, 나중에 필요시 개선

### 4. 에러 타입 세분화

**현재 DbError:**

```rust
pub enum DbError {
    QueryFailed(sqlx::Error),
    NotFound(String),
    InvalidInput(String),
    TransactionFailed(String),
}
```

**분석 필요 사항:**

- `QueryFailed`가 너무 포괄적
- sqlx::Error를 그대로 노출하면 Repository 추상화 목적에 어긋남

**개선 방안:**

```rust
pub enum DbError {
    // 구체적인 에러 타입
    ConnectionFailed(String),
    UniqueConstraintViolation { field: String },
    ForeignKeyViolation { table: String, key: String },
    QueryTimeout,
    NotFound(String),
    InvalidInput(String),
    TransactionFailed(String),
    Unknown(String),
}

impl From<sqlx::Error> for DbError {
    fn from(err: sqlx::Error) -> Self {
        match err {
            sqlx::Error::RowNotFound => DbError::NotFound("Record not found".into()),
            sqlx::Error::Database(db_err) => {
                // SQLite 에러 코드 파싱하여 세분화
                // ...
            }
            _ => DbError::Unknown(err.to_string()),
        }
    }
}
```

**권장:** 일단 현재대로 진행, 실제 사용하면서 필요한 에러 타입 추가

---

## 작업 순서 및 체크리스트

### Phase 1: Repository 기반 작성

- [ ] `repositories/error.rs` - DbError 타입 정의
- [ ] `repositories/mod.rs` - 모듈 export
- [ ] `repositories/message_repository.rs` - Trait + Impl
- [ ] `repositories/content_store_repository.rs` - Trait + Impl
- [ ] `repositories/session_repository.rs` - Trait + Impl
- [ ] `cargo check` 통과 확인

### Phase 2: Commands 레이어 수정

- [ ] `commands/messages_commands.rs` - db:: 모듈 제거, Repository 사용
  - [ ] Tauri commands 5개 수정
  - [ ] `get_or_build_index()` 내부 로직 수정
- [ ] `commands/content_store_commands.rs` - Repository 사용
- [ ] `commands/session_commands.rs` - Repository 사용
- [ ] `cargo check` 통과 확인

### Phase 3: 외부 호출 지점 수정

- [ ] `lib.rs` - Repository 사용
- [ ] `search/background_worker.rs` - Repository 사용
- [ ] `cargo check` 통과 확인

### Phase 4: 테스트 및 검증

- [ ] `cargo clippy` 통과
- [ ] `pnpm refactor:validate` 통과
- [ ] 기존 통합 테스트 실행
- [ ] Repository 유닛 테스트 추가 (선택)
- [ ] 성능 테스트 (선택)

### Phase 5: 문서화

- [ ] Repository 사용 가이드 작성 (README)
- [ ] API 문서 업데이트 (rustdoc)
- [ ] 아키텍처 다이어그램 업데이트

---

## 예상 소요 시간

| Phase    | 작업                | 예상 시간 |
| -------- | ------------------- | --------- |
| Phase 1  | Repository 구현     | 1시간     |
| Phase 2  | Commands 수정       | 1시간     |
| Phase 3  | 외부 호출 지점 수정 | 30분      |
| Phase 4  | 테스트 및 검증      | 1시간     |
| Phase 5  | 문서화              | 30분      |
| **총계** | **전체 작업**       | **4시간** |

---

## 리스크 및 대응 방안

### 리스크 1: 트랜잭션 처리 누락

- **영향도**: 높음 (데이터 일관성 문제)
- **대응**: `insert_many()` 구현 시 트랜잭션 확인 철저히
- **검증**: 다중 메시지 저장 테스트 추가

### 리스크 2: 에러 변환 누락

- **영향도**: 중간 (컴파일 에러 발생)
- **대응**: `.map_err(|e| e.to_string())` 패턴 일관되게 적용
- **검증**: `cargo check`로 확인

### 리스크 3: Pool Clone 성능 저하

- **영향도**: 낮음 (SqlitePool은 Arc 기반)
- **대응**: 벤치마크로 측정, 문제 시 Tauri State로 변경
- **검증**: 성능 테스트 추가

### 리스크 4: 기존 테스트 실패

- **영향도**: 중간
- **대응**: 테스트 실패 시 디버깅하여 원인 파악
- **검증**: 모든 테스트 실행

---

## 참고 자료

### Rust Repository Pattern

- https://www.lpalmieri.com/posts/2020-08-09-zero-to-production-3-5-html-forms-databases-integration-tests/
- https://github.com/actix/actix-web/tree/master/examples

### SQLx Best Practices

- https://github.com/launchbadge/sqlx/blob/main/FAQ.md
- https://docs.rs/sqlx/latest/sqlx/

### Tauri State Management

- https://tauri.app/v1/guides/features/command/#accessing-managed-state
- https://docs.rs/tauri/latest/tauri/struct.State.html

### Async Trait

- https://docs.rs/async-trait/latest/async_trait/
- https://rust-lang.github.io/async-book/

---

## 결론

이 리팩토링은 **난이도 3/10의 낮은 복잡도**로 **약 4시간 내**에 완료 가능하며, 다음과 같은 이점을 제공합니다:

1. ✅ **명확한 레이어 분리**: Commands ↔ Repository ↔ SQLx
2. ✅ **테스트 용이성**: Mock을 통한 유닛 테스트 가능
3. ✅ **유지보수성 향상**: DB 로직 중앙 집중화
4. ✅ **타입 안전성**: 구조화된 에러 타입
5. ✅ **확장성**: 다른 DB 추가 시 Repository만 구현

작업자는 이 문서를 참고하여 단계별로 진행하되, 상황에 따라 유연하게 조정할 수 있습니다.


---

# refactoring_20250105_1430.md

# Refactoring Plan: WebMCP Event Notification System

**Date**: 2025-01-05 14:30  
**Branch**: feat/on-board  
**Author**: AI Assistant (Copilot)

---

## 작업의 목적

Web Worker 런타임에서 실행되는 MCP 도구(예: `mcp_manager`의 `create_server`)가 데이터베이스를 변경한 후, React 메인 스레드의 UI가 자동으로 업데이트되지 않는 문제를 해결합니다.

**핵심 목표:**

1. Web Worker에서 React로 이벤트 알림을 전달하는 시스템 구축
2. postMessage 기반의 단일 채널 통신으로 메시지 순서 보장
3. Polling 없이 즉각적인 UI 업데이트 지원
4. 타입 안전성과 확장 가능성 확보

---

## 현재의 상태 / 문제점

### 1. 통신 구조

```text
Web Worker Runtime              React Main Thread
├─ mcp-manager 실행            ├─ MCPServerRegistryContext
├─ create_server 도구          ├─ MCPServerDialog
├─ db.upsert() ✅              ├─ UI 컴포넌트
└─ postMessage(response)       └─ React 상태

❌ DB 변경 후 UI 동기화 없음
```

### 2. 문제점 상세

#### A. 런타임 분리

- Web Worker와 React는 완전히 격리된 메모리 공간
- 직접적인 함수 호출 불가능
- `window` 객체, React Context 접근 불가

#### B. 현재 응답 흐름

```typescript
// mcp-manager/server.ts (Web Worker)
await mcpServersCRUD.upsert(server);

return {
  jsonrpc: '2.0',
  result: { server },
  // ← UI 갱신 신호 없음!
};

// MCPServerRegistryContext (React)
// 변경 감지 메커니즘 없음 → UI 업데이트 안됨
```

#### C. 시도했던 대안들의 문제

| 방법                  | 문제점                                         |
| --------------------- | ---------------------------------------------- |
| **Observable DB**     | Worker에서 React 함수 호출 불가 (런타임 분리)  |
| **Broadcast Channel** | postMessage와 순서 보장 안됨 (Race Condition)  |
| **Polling**           | 여러 컴포넌트에서 사용 시 UI 깜빡임, 성능 저하 |

---

## 관련 코드의 구조 및 동작 방식 Summary

### 1. Web Worker MCP 통신 아키텍처

```
┌─────────────────────────────────────────────────────────────┐
│                     React Main Thread                        │
│  ┌────────────────────────────────────────────────────┐     │
│  │          WebMCPContext (Context Provider)          │     │
│  │  - proxyRef: WebMCPProxy                          │     │
│  │  - getServerProxy()                               │     │
│  │  - switchServerContext()                          │     │
│  └──────────────────┬─────────────────────────────────┘     │
│                     │                                         │
│  ┌─────────────────▼──────────────────────────────────┐     │
│  │           WebMCPProxy (Message Transport)          │     │
│  │  - worker: Worker                                  │     │
│  │  - pendingRequests: Map<id, Promise>              │     │
│  │  - sendMessage()                                   │     │
│  │  - handleWorkerMessage() ← 응답 처리               │     │
│  └──────────────────┬─────────────────────────────────┘     │
└────────────────────┼──────────────────────────────────────┘
                      │ postMessage
                      │ (JSON-RPC 2.0)
┌────────────────────▼──────────────────────────────────────┐
│                    Web Worker Runtime                      │
│  ┌────────────────────────────────────────────────────┐   │
│  │           mcp-worker.ts (Message Handler)          │   │
│  │  - self.onmessage = handleMCPMessage()            │   │
│  │  - self.postMessage(response) ← 응답 전송          │   │
│  └──────────────────┬─────────────────────────────────┘   │
│                     │                                       │
│  ┌─────────────────▼──────────────────────────────────┐   │
│  │       MCP Server Modules (e.g., mcp_manager)       │   │
│  │  - callTool() → server.callTool()                 │   │
│  │  - MCPResponse 생성 및 반환                        │   │
│  └────────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────────┘
```

### 2. 현재 메시지 흐름

```typescript
// 1. React에서 도구 호출
await proxy.callTool('mcp_manager', 'create_server', args);

// 2. WebMCPProxy.sendMessage()
const id = createId();
worker.postMessage({ id, type: 'callTool', serverName, toolName, args });

// 3. Web Worker에서 처리
async function handleMCPMessage(message) {
  const server = getMCPServer(message.serverName);
  const result = await server.callTool(message.toolName, message.args);
  return { jsonrpc: '2.0', id: message.id, result };
}

// 4. Worker → Main Thread
self.postMessage(response);

// 5. WebMCPProxy.handleWorkerMessage()
const pending = this.pendingRequests.get(response.id);
pending.resolve(response); // ✅ Promise 해결
// ❌ 하지만 UI 갱신 신호 없음!
```

### 3. 주요 컴포넌트별 역할

**A. WebMCPProxy (`src/lib/web-mcp/mcp-proxy.ts`)**

- 역할: Worker 생명주기 관리, 요청/응답 매칭
- 핵심 메서드:
  - `sendMessage()`: Worker에 메시지 전송
  - `handleWorkerMessage()`: Worker 응답 처리
  - `pendingRequests`: 요청 ID → Promise 매핑

**B. mcp-worker.ts (`src/lib/web-mcp/mcp-worker.ts`)**

- 역할: Worker 런타임 진입점, 메시지 라우팅
- 핵심 로직:
  - `self.onmessage`: 메인 스레드 메시지 수신
  - `handleMCPMessage()`: 메시지 타입별 분기
  - `self.postMessage()`: 응답 전송

**C. WebMCPContext (`src/context/WebMCPContext.tsx`)**

- 역할: React Context로 WebMCPProxy 공유
- 핵심 기능:
  - `getServerProxy()`: 서버별 동적 프록시 생성
  - `useWebMCP()`: Context hook

---

## 변경 이후의 상태 / 해결 판정 기준

### 1. 목표 아키텍처

```text
┌─────────────────────────────────────────────────────────────┐
│                     React Main Thread                        │
│  ┌────────────────────────────────────────────────────┐     │
│  │          WebMCPContext (Context Provider)          │     │
│  │  + on(event, handler) ← NEW                       │     │
│  │  + once(event, handler) ← NEW                     │     │
│  │  + off(event) ← NEW                               │     │
│  └──────────────────┬─────────────────────────────────┘     │
│                     │                                         │
│  ┌─────────────────▼──────────────────────────────────┐     │
│  │           WebMCPProxy (Enhanced)                   │     │
│  │  + eventSubscribers: Map<event, Set<handler>>     │     │
│  │  + on/once/off() ← NEW                            │     │
│  │  + dispatchNotifications() ← NEW                  │     │
│  │  * handleWorkerMessage() ← MODIFIED               │     │
│  └──────────────────┬─────────────────────────────────┘     │
└────────────────────┼──────────────────────────────────────┘
                      │ postMessage
                      │ { result, notifications: [...] } ← NEW
┌────────────────────▼──────────────────────────────────────┐
│                    Web Worker Runtime                      │
│  │  MCPResponse { notifications?: [...] } ← NEW          │   │
└────────────────────────────────────────────────────────────┘
```

### 2. 새로운 메시지 흐름

```typescript
// 1. React에서 도구 호출 (변경 없음)
await proxy.callTool('mcp_manager', 'create_server', args);

// 2-3. Worker에서 처리 및 응답 생성
return {
  jsonrpc: '2.0',
  id: message.id,
  result: { server },
  notifications: [
    {
      // ← NEW
      event: 'mcp:server-created',
      data: { serverId, serverName },
      timestamp: Date.now(),
      source: { serverName: 'mcp_manager', toolName: 'create_server' },
    },
  ],
};

// 4. Worker → Main Thread (변경 없음)
self.postMessage(response);

// 5. WebMCPProxy.handleWorkerMessage() ← MODIFIED
const pending = this.pendingRequests.get(response.id);

// ✅ NEW: 이벤트 디스패치
if (response.notifications) {
  await this.dispatchNotifications(response.notifications);
  // → 구독자들에게 알림 → refreshAll() 호출!
}

pending.resolve(response);
```

### 3. React에서 사용 예시

```typescript
// MCPServerRegistryContext.tsx
import { useWebMCPEvent } from '@/context/WebMCPContext';

export const MCPServerRegistryProvider = ({ children }) => {
  const { refreshAll } = useSomeHook();

  // ✅ 이벤트 구독
  useWebMCPEvent(
    'mcp:server-created',
    async (notification) => {
      logger.info('Server created:', notification.data);
      await refreshAll(); // ← 자동 갱신!
    },
    [refreshAll],
  );

  // ...
};
```

### 4. 해결 판정 기준

| 기준            | 측정 방법                         | 목표      |
| --------------- | --------------------------------- | --------- |
| **즉각 반영**   | create_server 후 UI 업데이트 시간 | < 100ms   |
| **순서 보장**   | 100회 연속 호출 시 이벤트 순서    | 100% 일치 |
| **메모리 효율** | 이벤트 구독/해제 후 메모리 누수   | 0 leaks   |
| **타입 안전**   | TypeScript 컴파일 에러            | 0 errors  |
| **성능**        | 이벤트 디스패치 오버헤드          | < 10ms    |

---

## 수정이 필요한 코드 및 수정부분의 코드 스니핏

### 1. 타입 정의 추가

**파일:** `src/lib/mcp/protocol/response.ts`

```typescript
// ===== 추가할 코드 (파일 끝에 추가) =====

/**
 * Event notification from Web Worker to React main thread.
 * Carries information about state changes that require UI updates.
 */
export interface MCPNotification<T = unknown> {
  /** Event name/type (e.g., 'mcp:server-created') */
  event: string;
  /** Event payload data */
  data: T;
  /** Unix timestamp in milliseconds when event was generated */
  timestamp: number;
  /** Optional source information for debugging */
  source?: {
    serverName: string;
    toolName?: string;
  };
}

/**
 * Event handler callback type for subscribing to MCP events.
 * Handlers can be synchronous or asynchronous.
 */
export type MCPEventHandler<T = unknown> = (
  notification: MCPNotification<T>,
) => void | Promise<void>;

/**
 * Standard MCP event type constants for type safety.
 */
export const MCPEventTypes = {
  // Server lifecycle events
  SERVER_CREATED: 'mcp:server-created',
  SERVER_UPDATED: 'mcp:server-updated',
  SERVER_DELETED: 'mcp:server-deleted',
  SERVER_CONNECTED: 'mcp:server-connected',
  SERVER_DISCONNECTED: 'mcp:server-disconnected',

  // Tool execution events (future use)
  TOOL_STARTED: 'mcp:tool-started',
  TOOL_COMPLETED: 'mcp:tool-completed',
  TOOL_FAILED: 'mcp:tool-failed',

  // Data change events
  DATA_UPDATED: 'mcp:data-updated',
  CACHE_INVALIDATED: 'mcp:cache-invalidated',
} as const;

export type MCPEventType = (typeof MCPEventTypes)[keyof typeof MCPEventTypes];
```

**수정할 코드:**

```typescript
// 기존 MCPResponse 인터페이스 찾기
export interface MCPResponse<T> {
  jsonrpc: '2.0';
  id: string | number | null;
  result?: MCPResult<T> | SamplingResult;
  error?: MCPError;
  // ===== 아래 줄 추가 =====
  /** Optional notifications to be dispatched to React subscribers */
  notifications?: MCPNotification[];
}
```

---

### 2. WebMCPProxy 이벤트 구독 기능 추가

**파일:** `src/lib/web-mcp/mcp-proxy.ts`

**A. import 추가 (파일 상단)**

```typescript
import {
  WebMCPMessage,
  WebMCPProxyConfig,
  MCPTool,
  MCPResponse,
  MCPNotification, // ← 추가
  MCPEventHandler, // ← 추가
} from '../mcp-types';
```

**B. 클래스 필드 추가**

```typescript
export class WebMCPProxy {
  private worker: Worker | null = null;
  private pendingRequests = new Map<...>();
  private config: WebMCPProxyConfig & { timeout: number };
  private isInitialized = false;
  private initializationPromise: Promise<void> | null = null;

  // ===== 아래 필드 추가 =====
  /**
   * Event subscribers registry.
   * Key: event name, Value: set of handler functions
   */
  private eventSubscribers = new Map<string, Set<MCPEventHandler>>();
```

**C. 이벤트 구독 메서드 추가 (callTool 메서드 뒤에 삽입)**

```typescript
  /**
   * Subscribe to specific event from Web Worker.
   * Returns unsubscribe function for cleanup.
   *
   * @param event Event name (e.g., 'mcp:server-created')
   * @param handler Callback to execute when event occurs
   * @returns Unsubscribe function
   *
   * @example
   * const unsubscribe = proxy.on('mcp:server-created', (notification) => {
   *   console.log('Server created:', notification.data);
   * });
   * // Later: unsubscribe();
   */
  on<T = unknown>(
    event: string,
    handler: MCPEventHandler<T>
  ): () => void {
    if (!this.eventSubscribers.has(event)) {
      this.eventSubscribers.set(event, new Set());
    }

    const handlers = this.eventSubscribers.get(event)!;
    handlers.add(handler as MCPEventHandler);

    logger.debug('Event subscriber added', {
      event,
      totalHandlers: handlers.size
    });

    // Return unsubscribe function
    return () => {
      handlers.delete(handler as MCPEventHandler);
      if (handlers.size === 0) {
        this.eventSubscribers.delete(event);
      }
      logger.debug('Event subscriber removed', { event });
    };
  }

  /**
   * Subscribe to event once (auto-unsubscribe after first execution).
   */
  once<T = unknown>(
    event: string,
    handler: MCPEventHandler<T>
  ): () => void {
    const wrappedHandler: MCPEventHandler<T> = async (notification) => {
      unsubscribe();
      await handler(notification);
    };

    const unsubscribe = this.on(event, wrappedHandler);
    return unsubscribe;
  }

  /**
   * Remove all subscribers for a specific event.
   */
  off(event: string): void {
    this.eventSubscribers.delete(event);
    logger.debug('All subscribers removed for event', { event });
  }

  /**
   * Remove all event subscribers.
   */
  offAll(): void {
    const count = this.eventSubscribers.size;
    this.eventSubscribers.clear();
    logger.debug('All event subscribers cleared', { count });
  }

  /**
   * Dispatch notifications to registered subscribers.
   * Executes all handlers in parallel with error isolation.
   * @private
   */
  private async dispatchNotifications(
    notifications: MCPNotification[]
  ): Promise<void> {
    if (!notifications || notifications.length === 0) return;

    logger.debug('Dispatching notifications', {
      count: notifications.length,
      events: notifications.map(n => n.event)
    });

    for (const notification of notifications) {
      const handlers = this.eventSubscribers.get(notification.event);

      if (!handlers || handlers.size === 0) {
        logger.debug('No subscribers for event', { event: notification.event });
        continue;
      }

      logger.info('Dispatching event to subscribers', {
        event: notification.event,
        handlerCount: handlers.size,
      });

      // Execute all handlers in parallel with error isolation
      const promises = Array.from(handlers).map(async (handler) => {
        try {
          await handler(notification);
        } catch (error) {
          logger.error('Event handler error', {
            event: notification.event,
            error: error instanceof Error ? error.message : String(error)
          });
          // Continue with other handlers even if one fails
        }
      });

      await Promise.all(promises);
    }
  }
```

**D. handleWorkerMessage 수정**

```typescript
  private handleWorkerMessage(event: MessageEvent<MCPResponse<unknown>>): void {
    const response = event.data;

    if (!response || response.id === undefined || response.id === null) {
      logger.warn('Invalid worker response - missing id', {
        responseId: response?.id,
      });
      return;
    }

    const pending = this.pendingRequests.get(String(response.id));
    if (!pending) {
      logger.warn('No pending request found for response', {
        responseId: response.id,
      });
      return;
    }

    clearTimeout(pending.timeout);
    this.pendingRequests.delete(String(response.id));

    // ===== 아래 블록 추가 (try 블록 전에) =====
    // Dispatch notifications BEFORE resolving promise
    // This ensures subscribers are notified before caller receives response
    if (response.notifications && response.notifications.length > 0) {
      this.dispatchNotifications(response.notifications).catch((error) => {
        logger.error('Failed to dispatch notifications', {
          error: error instanceof Error ? error.message : String(error)
        });
        // Don't fail the request even if notification dispatch fails
      });
    }
    // ===== 추가 끝 =====

    try {
      if (response.error) {
        const errorMessage =
          typeof response.error === 'string'
            ? response.error
            : response.error.message || 'Unknown error';
        logger.error('Worker returned error', {
          responseId: response.id,
          error: response.error,
          errorMessage,
        });
        pending.reject(new Error(errorMessage));
      } else {
        logger.debug('Worker returned success', {
          responseId: response.id,
          hasResult: !!response.result,
          hasNotifications: !!(response.notifications?.length), // ← 로그 추가
        });
        pending.resolve(response);
      }
    } catch (handleError) {
      // ... 기존 코드 유지 ...
    }
  }
```

**E. cleanup 메서드 수정**

```typescript
  cleanup(): void {
    logger.debug('Cleaning up WebMCP proxy', {
      pendingRequests: this.pendingRequests.size,
      eventSubscribers: this.eventSubscribers.size, // ← 로그 추가
    });

    for (const [, { reject, timeout }] of this.pendingRequests.entries()) {
      clearTimeout(timeout);
      reject(new Error('Worker terminated'));
    }
    this.pendingRequests.clear();

    // ===== 아래 줄 추가 =====
    // Clear event subscribers
    this.offAll();
    // ===== 추가 끝 =====

    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
    this.isInitialized = false;
  }
```

---

### 3. WebMCPContext 이벤트 Hook 제공

**파일:** `src/context/WebMCPContext.tsx`

**A. import 추가**

```typescript
import { MCPTool, MCPEventHandler } from '@/lib/mcp-types'; // ← MCPEventHandler 추가
```

**B. WebMCPContextValue 인터페이스 수정**

```typescript
interface WebMCPContextValue {
  proxy: WebMCPProxy | null;
  isLoading: boolean;
  initialized: boolean;
  getServerProxy: <T extends WebMCPServerProxy>(
    serverName: string,
  ) => Promise<T>;
  switchServerContext: (
    serverName: string,
    context: ServiceContextOptions,
  ) => Promise<{ success: boolean }>;
  // ===== 아래 메서드 추가 =====
  /** Subscribe to MCP event. Returns unsubscribe function. */
  on: <T = unknown>(event: string, handler: MCPEventHandler<T>) => () => void;
  /** Subscribe to MCP event once (auto-unsubscribe). Returns unsubscribe function. */
  once: <T = unknown>(event: string, handler: MCPEventHandler<T>) => () => void;
  /** Unsubscribe all handlers for an event. */
  off: (event: string) => void;
}
```

**C. Provider 컴포넌트에 메서드 추가 (switchServerContext 뒤에)**

```typescript
// ===== 아래 메서드 추가 =====

// Event subscription methods
const on = useCallback(
  <T = unknown>(event: string, handler: MCPEventHandler<T>): (() => void) => {
    if (!proxyRef.current) {
      logger.warn('Cannot subscribe - proxy not initialized', { event });
      return () => {}; // No-op unsubscribe
    }
    return proxyRef.current.on(event, handler);
  },
  [],
);

const once = useCallback(
  <T = unknown>(event: string, handler: MCPEventHandler<T>): (() => void) => {
    if (!proxyRef.current) {
      logger.warn('Cannot subscribe once - proxy not initialized', { event });
      return () => {};
    }
    return proxyRef.current.once(event, handler);
  },
  [],
);

const off = useCallback((event: string): void => {
  if (!proxyRef.current) {
    logger.warn('Cannot unsubscribe - proxy not initialized', { event });
    return;
  }
  proxyRef.current.off(event);
}, []);
```

**D. contextValue 수정**

```typescript
const contextValue: WebMCPContextValue = {
  proxy: proxyRef.current,
  isLoading,
  initialized,
  getServerProxy,
  switchServerContext,
  on, // ← 추가
  once, // ← 추가
  off, // ← 추가
};
```

**E. useWebMCPEvent Hook 추가 (파일 끝에)**

```typescript
/**
 * Custom hook for subscribing to MCP events.
 * Automatically manages subscription lifecycle (subscribe on mount, unsubscribe on unmount).
 *
 * @param event Event name to subscribe to
 * @param handler Event handler callback
 * @param deps Dependency array for handler (similar to useEffect)
 *
 * @example
 * useWebMCPEvent('mcp:server-created', (notification) => {
 *   console.log('Server created:', notification.data);
 *   refreshServerList();
 * }, [refreshServerList]);
 */
export function useWebMCPEvent<T = unknown>(
  event: string,
  handler: MCPEventHandler<T>,
  deps: React.DependencyList = [],
): void {
  const { on } = useWebMCP();

  useEffect(() => {
    const unsubscribe = on(event, handler);
    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [event, on, ...deps]);
}
```

---

## 재사용 가능한 연관 코드

### 1. 기존 MCP Response 생성 유틸리티

**파일:** `src/lib/mcp-response-utils.ts`

이미 존재하는 헬퍼 함수들을 참고하여 notification 추가 방식 이해:

```typescript
// 기존 코드
export function createMCPStructuredResponse<T>(
  text: string,
  structuredContent: T,
): MCPResponse<T> {
  return {
    jsonrpc: '2.0',
    id: null,
    result: {
      content: [{ type: 'text', text }],
      structuredContent,
    },
  };
}

// 향후 확장 시 참고: notifications 포함 버전
export function createMCPStructuredResponseWithNotifications<T>(
  text: string,
  structuredContent: T,
  notifications: MCPNotification[],
): MCPResponse<T> {
  return {
    jsonrpc: '2.0',
    id: null,
    result: {
      content: [{ type: 'text', text }],
      structuredContent,
    },
    notifications, // ← 추가
  };
}
```

### 2. Logger 사용 패턴

프로젝트 전반에서 사용하는 로깅 패턴:

```typescript
import { getLogger } from '@/lib/logger';
const logger = getLogger('ComponentName');

logger.debug('Debug info', { data });
logger.info('Important info', { data });
logger.warn('Warning', { data });
logger.error('Error occurred', error);
```

### 3. React Hook 패턴

useEffect를 사용한 구독 패턴 (프로젝트 전반):

```typescript
useEffect(() => {
  const cleanup = subscribeToSomething();
  return cleanup; // unsubscribe on unmount
}, [dependencies]);
```

---

## Test Code 추가 및 수정 필요 부분에 대한 가이드

### 1. WebMCPProxy 단위 테스트

**파일 생성:** `src/lib/web-mcp/__tests__/mcp-proxy-events.test.ts`

```typescript
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { WebMCPProxy } from '../mcp-proxy';
import { MCPEventTypes, MCPNotification } from '@/lib/mcp';

describe('WebMCPProxy Event System', () => {
  let proxy: WebMCPProxy;

  beforeEach(() => {
    // Mock Worker
    const mockWorker = {
      postMessage: vi.fn(),
      terminate: vi.fn(),
      onmessage: null,
      onerror: null,
    };

    proxy = new WebMCPProxy({
      workerInstance: mockWorker as unknown as Worker,
    });
  });

  describe('Event Subscription', () => {
    it('should subscribe to event', () => {
      const handler = vi.fn();
      const unsubscribe = proxy.on('test-event', handler);

      expect(unsubscribe).toBeInstanceOf(Function);
    });

    it('should call handler when event is dispatched', async () => {
      const handler = vi.fn();
      proxy.on('test-event', handler);

      const notification: MCPNotification = {
        event: 'test-event',
        data: { test: 'data' },
        timestamp: Date.now(),
      };

      // Simulate worker message with notification
      const response = {
        jsonrpc: '2.0' as const,
        id: 'test-id',
        result: { structuredContent: {} },
        notifications: [notification],
      };

      // Trigger handleWorkerMessage (need to expose or use reflection)
      // await proxy['handleWorkerMessage']({ data: response });

      // expect(handler).toHaveBeenCalledWith(notification);
    });

    it('should unsubscribe correctly', () => {
      const handler = vi.fn();
      const unsubscribe = proxy.on('test-event', handler);

      unsubscribe();

      // Verify handler is not called after unsubscribe
      // (requires event dispatch mechanism)
    });

    it('should support multiple handlers for same event', async () => {
      const handler1 = vi.fn();
      const handler2 = vi.fn();

      proxy.on('test-event', handler1);
      proxy.on('test-event', handler2);

      // Both should be called
    });

    it('should isolate handler errors', async () => {
      const errorHandler = vi.fn(() => {
        throw new Error('Handler error');
      });
      const successHandler = vi.fn();

      proxy.on('test-event', errorHandler);
      proxy.on('test-event', successHandler);

      // successHandler should still be called even if errorHandler throws
    });
  });

  describe('once() subscription', () => {
    it('should auto-unsubscribe after first call', async () => {
      const handler = vi.fn();
      proxy.once('test-event', handler);

      // Dispatch twice
      // First: handler called
      // Second: handler NOT called
    });
  });

  describe('off() and offAll()', () => {
    it('should remove all handlers for specific event', () => {
      const handler1 = vi.fn();
      const handler2 = vi.fn();

      proxy.on('test-event', handler1);
      proxy.on('other-event', handler2);

      proxy.off('test-event');

      // handler1 should not be called
      // handler2 should still work
    });

    it('should clear all subscribers on offAll()', () => {
      proxy.on('event1', vi.fn());
      proxy.on('event2', vi.fn());

      proxy.offAll();

      // No handlers should be called
    });
  });

  describe('cleanup()', () => {
    it('should clear event subscribers on cleanup', () => {
      const handler = vi.fn();
      proxy.on('test-event', handler);

      proxy.cleanup();

      // All subscriptions should be cleared
    });
  });
});
```

### 2. WebMCPContext 통합 테스트

**파일 생성:** `src/context/__tests__/WebMCPContext-events.test.tsx`

```typescript
import { describe, it, expect, vi } from 'vitest';
import { renderHook, waitFor } from '@testing-library/react';
import { WebMCPProvider, useWebMCP, useWebMCPEvent } from '../WebMCPContext';

describe('WebMCPContext Event Integration', () => {
  it('should provide event subscription methods', () => {
    const { result } = renderHook(() => useWebMCP(), {
      wrapper: WebMCPProvider,
    });

    expect(result.current.on).toBeInstanceOf(Function);
    expect(result.current.once).toBeInstanceOf(Function);
    expect(result.current.off).toBeInstanceOf(Function);
  });

  it('useWebMCPEvent should auto-subscribe and unsubscribe', () => {
    const handler = vi.fn();

    const { unmount } = renderHook(
      () => useWebMCPEvent('test-event', handler),
      { wrapper: WebMCPProvider },
    );

    // Subscription active

    unmount();

    // Subscription should be cleaned up
  });
});
```

### 3. End-to-End 시나리오 테스트

**수동 테스트 체크리스트:**

```typescript
// 1. create_server 도구 호출
const serverProxy = await getServerProxy('mcp_manager');
await serverProxy.create_server({
  name: 'test-server',
  transport: { type: 'stdio', command: 'npx' },
});

// 2. 이벤트 수신 확인
// - MCPServerRegistryContext가 'mcp:server-created' 이벤트 수신
// - refreshAll() 자동 호출
// - UI에 새 서버 즉시 표시

// 3. 메모리 누수 확인
// - 컴포넌트 마운트/언마운트 100회 반복
// - 메모리 프로파일러로 누수 확인

// 4. 순서 보장 확인
// - 10개 서버 연속 생성
// - 모든 이벤트가 순서대로 처리되는지 확인
```

---

## 추가 분석 과제

### 1. mcp-manager 모듈 이벤트 발송 구현

현재 계획에서는 인프라만 구축하고, 실제 이벤트를 발송하는 `mcp-manager` 수정은 별도 작업으로 분리했습니다.

**다음 단계에서 필요한 작업:**

- `createResponseWithNotification()` 헬퍼 함수 생성
- `createServer()`, `connectServer()`, `disconnectServer()`에 notifications 추가
- 이벤트 타입별 payload 데이터 정의

**참고 코드 위치:**

- `src/lib/web-mcp/modules/mcp-manager/server.ts`
- `src/lib/mcp-response-utils.ts` (헬퍼 함수 참고)

### 2. 다른 Web MCP 서버 모듈 적용

현재는 `mcp_manager`만 고려했지만, 다른 서버들도 이벤트를 발송할 수 있습니다:

**후보 모듈:**

- `playbook-store`: 플레이북 생성/삭제 이벤트
- `ui-tools`: UI 상태 변경 이벤트
- `planning-server`: 계획 상태 변경 이벤트

**분석 필요:**

- 각 모듈의 상태 변경 지점 파악
- 이벤트 타입 정의 (MCPEventTypes 확장)
- UI 업데이트 필요 여부 판단

### 3. 성능 최적화 포인트

**A. 이벤트 배치 처리**

- 현재는 각 이벤트마다 즉시 디스패치
- 짧은 시간 내 여러 이벤트 발생 시 배치 처리 고려

**B. 구독자 필터링**

- 현재는 이벤트 이름으로만 필터링
- 추가 필터 (source.serverName, data 조건 등) 필요성 검토

**C. 메모리 관리**

- 구독자 WeakMap 사용 검토
- 이벤트 히스토리 제한 정책

---

## Clarification Q-list

### 1. 이벤트 타입 네이밍 컨벤션

**질문:** 이벤트 이름을 `mcp:server-created` 형식으로 정했는데, 다른 컨벤션을 선호하시나요?

**대안:**

- `mcp.server.created` (점 구분)
- `MCP_SERVER_CREATED` (대문자 + 언더스코어)
- `serverCreated` (camelCase)

**추천:** 현재 `mcp:server-created` (네임스페이스 + kebab-case)가 가독성과 확장성 측면에서 우수

### 2. 에러 처리 전략

**질문:** 이벤트 핸들러에서 에러 발생 시 전체 응답을 실패시킬까요, 아니면 격리할까요?

**현재 구현:** 격리 (한 핸들러 실패해도 다른 핸들러 계속 실행)

**대안:**

- 첫 에러 발생 시 전체 중단
- 에러 수집 후 일괄 보고

**추천:** 현재 격리 방식 유지 (안정성 우선)

### 3. 이벤트 우선순위

**질문:** 여러 이벤트가 동시에 발생할 때 처리 순서가 중요한가요?

**현재 구현:** notifications 배열 순서대로 순차 처리

**고려사항:**

- 우선순위 필드 추가 필요 여부
- 특정 이벤트 먼저 처리 필요성

### 4. 테스트 커버리지 목표

**질문:** 이 기능의 테스트 커버리지 목표는 어느 정도인가요?

**제안:**

- 단위 테스트: 80% 이상
- 통합 테스트: 주요 시나리오 커버
- E2E 테스트: create_server → UI 업데이트 흐름

### 5. 배포 전략

**질문:** 이 변경사항을 단계적으로 배포할까요, 아니면 한번에 배포할까요?

**옵션:**

- **Option A:** 인프라만 먼저 배포 (이벤트 발송 없음, 기능 변화 없음)
- **Option B:** 전체 기능 한번에 배포
- **Option C:** Feature Flag로 점진적 활성화

**추천:** Option A (인프라 먼저) → 안정화 후 mcp-manager 수정

---

## 구현 체크리스트

- [ ] 1. 타입 정의 추가 (`mcp/protocol/response.ts`)
  - [ ] MCPNotification 인터페이스
  - [ ] MCPEventHandler 타입
  - [ ] MCPEventTypes 상수
  - [ ] MCPResponse에 notifications 필드 추가

- [ ] 2. WebMCPProxy 이벤트 시스템 (`mcp-proxy.ts`)
  - [ ] eventSubscribers 필드 추가
  - [ ] on() 메서드 구현
  - [ ] once() 메서드 구현
  - [ ] off(), offAll() 메서드 구현
  - [ ] dispatchNotifications() private 메서드
  - [ ] handleWorkerMessage() 수정
  - [ ] cleanup() 수정

- [ ] 3. WebMCPContext 통합 (`WebMCPContext.tsx`)
  - [ ] WebMCPContextValue 인터페이스 확장
  - [ ] on(), once(), off() Context 메서드 추가
  - [ ] useWebMCPEvent hook 구현

- [ ] 4. 테스트 작성
  - [ ] mcp-proxy-events.test.ts 작성
  - [ ] WebMCPContext-events.test.tsx 작성
  - [ ] E2E 테스트 시나리오 작성

- [ ] 5. 문서화
  - [ ] README 업데이트
  - [ ] 타입 주석 검증
  - [ ] 사용 예제 추가

- [ ] 6. 검증
  - [ ] TypeScript 컴파일 확인
  - [ ] ESLint 통과
  - [ ] 단위 테스트 통과
  - [ ] 수동 테스트 (create_server 시나리오)

---

## 예상 소요 시간

| 단계     | 작업               | 예상 시간 |
| -------- | ------------------ | --------- |
| 1        | 타입 정의          | 15분      |
| 2        | WebMCPProxy 구현   | 45분      |
| 3        | WebMCPContext 통합 | 30분      |
| 4        | 테스트 작성        | 60분      |
| 5        | 문서화             | 20분      |
| 6        | 검증 및 수정       | 30분      |
| **합계** |                    | **3시간** |

---

## 참고 자료

- [Model Context Protocol Specification](https://modelcontextprotocol.io/)
- [JSON-RPC 2.0 Specification](https://www.jsonrpc.org/specification)
- [Web Workers MDN](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API)
- [React Context Best Practices](https://react.dev/learn/passing-data-deeply-with-context)
- 프로젝트 내부: `docs/architecture/chat-feature-architecture.md`

---

**끝.**


---

# refactoring_20251102_0000.md

# MCP Server Management Tool Implementation Plan

## 작업의 목적

LibrAgent 에이전트가 런타임에 MCP 서버를 동적으로 관리할 수 있는 Built-in Tool을 제공합니다. 현재는 사용자가 UI를 통해서만 MCP 서버를 등록하고 활성화할 수 있지만, 에이전트가 필요에 따라 서버 목록 조회, 검색, 생성, 연결을 자동으로 수행할 수 있도록 합니다.

**핵심 가치:**

- 에이전트의 자율성 향상: 필요한 도구(MCP 서버)를 스스로 찾고 활성화
- 동적 도구 확장: 대화 중 새로운 기능이 필요할 때 즉시 MCP 서버 추가
- Assistant별 도구 격리: 각 Assistant가 자신만의 MCP 서버 세트 관리

## 현재의 상태 / 문제점

### 현재 MCP 서버 관리 구조

1. **데이터 계층 (IndexedDB via Dexie)**
   - `mcpServers` 테이블에 `MCPServerEntity` 저장
   - `mcpServersCRUD` (src/lib/db/crud.ts)로 CRUD 수행
   - Assistant와 M:N 관계 (Assistant.mcpServerIds)

2. **UI 계층**
   - SettingsPage에서 수동 등록/수정/삭제
   - MCPServerDialog로 서버 상세 설정
   - MCPServerManagement 컴포넌트로 목록 표시

3. **런타임 연결 (Backend)**
   - RustMCPToolProvider가 Rust backend의 builtin 서버 목록 조회
   - MCPServerContext/MCPServerRegistryContext가 사용자 정의 서버 관리
   - Tauri 명령으로 stdio/http 서버 시작

### 문제점

- **에이전트 접근 불가**: 에이전트가 MCP 서버 목록을 조회하거나 추가할 수 없음
- **수동 관리 의존**: 사용자가 UI로 미리 서버를 등록해야 에이전트가 사용 가능
- **컨텍스트 불일치**: Assistant별 서버 바인딩은 있지만 에이전트가 직접 제어할 수 없음
- **검색/발견 기능 부재**: 에이전트가 필요한 도구를 찾기 위한 검색 인터페이스 없음

## 관련 코드의 구조 및 동작 방식 Summary

### 1. 데이터 모델 (src/models/chat.ts)

```typescript
export interface MCPServerEntity {
  // Database metadata
  id: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;

  // MCP Protocol spec (from MCPServerConfigV2)
  name: string;
  transport: TransportConfig; // stdio or http
  authentication?: OAuthConfig;
  metadata?: ServerMetadata;
}

export interface Assistant {
  id?: string;
  name: string;
  mcpServerIds?: string[]; // References to MCPServerEntity
  // ...
}
```

### 2. CRUD 계층 (src/lib/db/crud.ts)

**mcpServersCRUD 주요 기능:**

- `upsert(server)`: 이름 중복 검사 (case-insensitive)
- `upsertMany(servers)`: 배치 등록 + 중복 검사
- `read(id)`: ID로 서버 조회
- `delete(id)`: Assistant 참조 확인 후 삭제 (참조 있으면 에러)
- `getPage(page, pageSize)`: 페이지네이션 지원 (-1이면 전체 반환)
- `count()`: 전체 서버 수

**assistantsCRUD 주요 기능:**

- Assistant의 `mcpServerIds` 배열 관리
- 서버 연결/해제 시 이 배열 업데이트

### 3. Web MCP 서버 패턴

**기존 서버 예시 (planning, bootstrap, playbook):**

```typescript
// src/lib/web-mcp/modules/{module-name}/server.ts
import { createMCPStructuredResponse, createMCPTextResponse } from '@/lib/mcp-response-utils';
import type { MCPResponse, WebMCPServer } from '@/lib/mcp-types';

const myServer: WebMCPServer = {
  name: 'server_name',
  version: '1.0.0',
  description: 'Server description',
  tools: toolsSchema,  // MCPTool[] from tools.ts

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    // Parse args
    const a = (args || {}) as Record<string, unknown>;

    switch (name) {
      case 'tool_name': {
        // Business logic
        const result = /* ... */;

        // Return with both text and structured content
        return createMCPStructuredResponse(
          `Human-readable summary: ${result.summary}`,
          result  // Structured data for agent
        );
      }
    }
  }
};
```

**컨텍스트 통합:**

- `WebMCPContextSetter`가 sessionId, assistantId 자동 주입
- `getServiceContext(options)`: 서버 상태 요약 반환
- `switchContext(options)`: 컨텍스트 전환 (sessionId, assistantId)

### 4. 등록 및 로딩 구조

```typescript
// src/lib/web-mcp/mcp-worker.ts
import mcpManagerServer from './modules/mcp-manager/index.ts';

const MODULE_REGISTRY = [
  { key: 'planning', module: planningServer },
  { key: 'playbook', module: playbookStore },
  { key: 'ui', module: uiTools },
  { key: 'bootstrap', module: bootstrapServer },
  { key: 'mcp_manager', module: mcpManagerServer }, // 새로 추가
];
```

```typescript
// src/app/App.tsx
<WebMCPServiceRegistry servers={[
  'planning', 'playbook', 'ui', 'bootstrap', 'mcp_manager'
]} />
```

## 변경 이후의 상태 / 해결 판정 기준

### 목표 상태

1. **에이전트가 MCP 서버를 관리할 수 있음**
   - 서버 목록 조회 (페이지네이션, 필터)
   - 서버 검색 (이름, 설명, 태그)
   - 새 서버 등록
   - 서버 활성화/연결 (Assistant 또는 전역 scope)

2. **사용자 경험 개선**
   - 에이전트가 필요한 도구를 자동 발견하고 제안
   - 대화 중 즉시 서버 추가 가능
   - Assistant별 도구 세트 동적 구성

3. **시스템 안정성 유지**
   - 기존 UI 기능 모두 동작
   - 데이터 무결성 보장 (중복, 참조 검증)
   - 에러 처리 및 복구 가능

### 판정 기준

**필수 (P0):**

- [ ] `list_servers` 도구가 페이지네이션된 서버 목록 반환
- [ ] `search_server` 도구가 쿼리 기반 검색 수행
- [ ] `create_server` 도구가 새 서버 등록 (이름 중복 검증 포함)
- [ ] `connect_server` 도구가 Assistant에 서버 연결
- [ ] 모든 도구가 text + structuredContent 반환
- [ ] 기존 SettingsPage 기능 정상 동작

**권장 (P1):**

- [ ] `disconnect_server` 도구로 서버 연결 해제
- [ ] `update_server` 도구로 서버 정보 수정
- [ ] `delete_server` 도구로 서버 삭제 (참조 검증)
- [ ] Assistant context 자동 주입으로 암묵적 scope 관리
- [ ] 서버 상태 요약 제공 (`getServiceContext`)

**선택 (P2):**

- [ ] Tauri backend 통합으로 실제 stdio/http 서버 시작
- [ ] 서버 health check/ping 도구
- [ ] 서버 메타데이터 업데이트 (tags, metadata)

## 수정이 필요한 코드 및 수정부분의 코드 스니핏

### 1. 새 Web MCP 서버 모듈 생성

#### 디렉토리 구조

```
src/lib/web-mcp/modules/mcp-manager/
├── index.ts              # Module exports
├── server.ts             # Main server implementation
├── tools.ts              # Tool schemas
├── README.md             # Usage documentation
└── __tests__/
    └── mcp-manager.test.ts
```

#### tools.ts - Tool 스키마 정의

```typescript
import type { MCPTool } from '@/lib/mcp-types';
import {
  createStringSchema,
  createIntegerSchema,
  createObjectSchema,
  createBooleanSchema,
} from '@/lib/mcp-types';

export const mcpManagerTools: MCPTool[] = [
  {
    name: 'list_servers',
    description: 'List all registered MCP servers with pagination',
    inputSchema: createObjectSchema({
      description: 'Pagination and filter options',
      properties: {
        page: createIntegerSchema({
          description: 'Page number (1-based)',
          minimum: 1,
        }),
        pageSize: createIntegerSchema({
          description: 'Number of items per page (-1 for all)',
          minimum: -1,
        }),
        filterByAssistant: createBooleanSchema({
          description: 'Filter to servers connected to current assistant',
        }),
        includeInactive: createBooleanSchema({
          description: 'Include inactive servers',
        }),
      },
      additionalProperties: false,
    }),
  },
  {
    name: 'search_server',
    description: 'Search MCP servers by name, description, or tags',
    inputSchema: createObjectSchema({
      description: 'Search query and options',
      properties: {
        query: createStringSchema({
          description: 'Search query string',
          minLength: 1,
        }),
        page: createIntegerSchema({
          description: 'Page number (1-based)',
          minimum: 1,
        }),
        pageSize: createIntegerSchema({
          description: 'Number of items per page',
          minimum: -1,
        }),
        byNameOnly: createBooleanSchema({
          description: 'Search only in server names',
        }),
        includeInactive: createBooleanSchema({
          description: 'Include inactive servers',
        }),
      },
      required: ['query'],
      additionalProperties: false,
    }),
  },
  {
    name: 'create_server',
    description: 'Create a new MCP server configuration',
    inputSchema: createObjectSchema({
      description: 'Server configuration',
      properties: {
        name: createStringSchema({
          description: 'Server name (must be unique)',
          minLength: 1,
        }),
        description: createStringSchema({
          description: 'Server description',
        }),
        transport: createObjectSchema({
          description: 'Transport configuration (stdio or http)',
          properties: {
            type: createStringSchema({
              description: 'Transport type',
              // enum would be: ['stdio', 'http']
            }),
            // stdio fields
            command: createStringSchema({ description: 'Command to execute' }),
            args: { type: 'array', items: { type: 'string' } },
            env: { type: 'object', additionalProperties: { type: 'string' } },
            // http fields
            url: createStringSchema({ description: 'HTTP endpoint URL' }),
            headers: {
              type: 'object',
              additionalProperties: { type: 'string' },
            },
          },
          required: ['type'],
        }),
        tags: { type: 'array', items: { type: 'string' } },
      },
      required: ['name', 'transport'],
      additionalProperties: false,
    }),
  },
  {
    name: 'connect_server',
    description: 'Connect a server to the current assistant or globally',
    inputSchema: createObjectSchema({
      description: 'Connection options',
      properties: {
        serverId: createStringSchema({
          description: 'Server ID to connect (serverId or serverName required)',
        }),
        serverName: createStringSchema({
          description:
            'Server name to connect (serverId or serverName required)',
        }),
        scope: createStringSchema({
          description: 'Connection scope: "assistant" or "global"',
          // enum: ['assistant', 'global']
        }),
        autoStart: createBooleanSchema({
          description: 'Automatically start the server if not running',
        }),
      },
      additionalProperties: false,
    }),
  },
  {
    name: 'disconnect_server',
    description: 'Disconnect a server from the current assistant',
    inputSchema: createObjectSchema({
      description: 'Disconnection options',
      properties: {
        serverId: createStringSchema({ description: 'Server ID' }),
        serverName: createStringSchema({ description: 'Server name' }),
        scope: createStringSchema({
          description: 'Scope to disconnect from',
        }),
      },
      additionalProperties: false,
    }),
  },
];
```

#### server.ts - 메인 서버 구현

```typescript
import {
  createMCPStructuredResponse,
  createMCPTextResponse,
} from '@/lib/mcp-response-utils';
import type { MCPResponse, WebMCPServer } from '@/lib/mcp-types';
import type { ServiceContext, ServiceContextOptions } from '@/features/tools';
import { getLogger } from '@/lib/logger';
import { mcpManagerTools } from './tools';
import { mcpServersCRUD, assistantsCRUD, createPage } from '@/lib/db/crud';
import { LocalDatabase } from '@/lib/db';
import type { MCPServerEntity, Assistant } from '@/models/chat';

const logger = getLogger('MCPManagerServer');

// Response types for structured content
interface ListServersOutput {
  items: MCPServerEntity[];
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

interface SearchServersOutput extends ListServersOutput {
  query: string;
}

interface CreateServerOutput {
  server: MCPServerEntity;
  message: string;
}

interface ConnectServerOutput {
  success: boolean;
  server: MCPServerEntity;
  scope: 'assistant' | 'global';
  message: string;
  assistantId?: string;
}

class MCPManagerServer implements WebMCPServer {
  name = 'mcp_manager';
  version = '1.0.0';
  description =
    'MCP server management tools for dynamic server registration and connection';
  tools = mcpManagerTools;

  // Context state (set by WebMCPContextSetter)
  private assistantId: string | null = null;
  private sessionId: string | null = null;

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    const a = (args || {}) as Record<string, unknown>;

    try {
      switch (name) {
        case 'list_servers':
          return await this.listServers(a);
        case 'search_server':
          return await this.searchServer(a);
        case 'create_server':
          return await this.createServer(a);
        case 'connect_server':
          return await this.connectServer(a);
        case 'disconnect_server':
          return await this.disconnectServer(a);
        default:
          return createMCPTextResponse(`Unknown tool: ${name}`);
      }
    } catch (error) {
      logger.error('Tool execution error', { name, error });
      const message = error instanceof Error ? error.message : String(error);
      return createMCPTextResponse(`Error: ${message}`);
    }
  }

  private async listServers(
    args: Record<string, unknown>,
  ): Promise<MCPResponse<ListServersOutput>> {
    const page = Number(args.page || 1);
    const pageSize = Number(args.pageSize || 20);
    const filterByAssistant = Boolean(args.filterByAssistant);
    const includeInactive = Boolean(args.includeInactive ?? true);

    let servers: MCPServerEntity[];

    if (filterByAssistant && this.assistantId) {
      // Get assistant's connected servers
      const assistant = await assistantsCRUD.read(this.assistantId);
      if (
        !assistant ||
        !assistant.mcpServerIds ||
        assistant.mcpServerIds.length === 0
      ) {
        const emptyPage = createPage<MCPServerEntity>([], page, pageSize, 0);
        return createMCPStructuredResponse(
          `No MCP servers connected to assistant "${assistant?.name || 'current'}"`,
          emptyPage,
        );
      }

      // Fetch servers by IDs
      const db = LocalDatabase.getInstance();
      servers = await db.mcpServers
        .where('id')
        .anyOf(assistant.mcpServerIds)
        .toArray();
    } else {
      // Get all servers
      const db = LocalDatabase.getInstance();
      servers = await db.mcpServers.toArray();
    }

    // Filter by active status
    if (!includeInactive) {
      servers = servers.filter((s) => s.isActive);
    }

    // Sort by name
    servers.sort((a, b) => a.name.localeCompare(b.name));

    // Apply pagination
    const totalItems = servers.length;
    const result = createPage(servers, page, pageSize, totalItems);

    const summary = [
      `📋 MCP Servers (${result.totalItems} total)`,
      filterByAssistant ? `   Filtered by current assistant` : '',
      `   Page ${result.page}/${result.totalPages}`,
      `   Showing ${result.items.length} server(s)`,
    ]
      .filter(Boolean)
      .join('\n');

    return createMCPStructuredResponse(summary, result);
  }

  private async searchServer(
    args: Record<string, unknown>,
  ): Promise<MCPResponse<SearchServersOutput>> {
    const query = String(args.query || '')
      .toLowerCase()
      .trim();
    const page = Number(args.page || 1);
    const pageSize = Number(args.pageSize || 20);
    const byNameOnly = Boolean(args.byNameOnly ?? true);
    const includeInactive = Boolean(args.includeInactive ?? true);

    if (!query) {
      return createMCPTextResponse('Search query is required');
    }

    const db = LocalDatabase.getInstance();
    let servers = await db.mcpServers.toArray();

    // Filter by active status
    if (!includeInactive) {
      servers = servers.filter((s) => s.isActive);
    }

    // Search filter
    servers = servers.filter((server) => {
      const nameMatch = server.name.toLowerCase().includes(query);
      if (byNameOnly) return nameMatch;

      const descMatch = server.metadata?.description
        ?.toLowerCase()
        .includes(query);
      const tagsMatch = server.metadata?.tags?.some((t) =>
        t.toLowerCase().includes(query),
      );

      return nameMatch || descMatch || tagsMatch;
    });

    // Sort by relevance (exact matches first, then starts-with, then contains)
    servers.sort((a, b) => {
      const aName = a.name.toLowerCase();
      const bName = b.name.toLowerCase();

      if (aName === query && bName !== query) return -1;
      if (aName !== query && bName === query) return 1;
      if (aName.startsWith(query) && !bName.startsWith(query)) return -1;
      if (!aName.startsWith(query) && bName.startsWith(query)) return 1;

      return aName.localeCompare(bName);
    });

    const totalItems = servers.length;
    const result = createPage(servers, page, pageSize, totalItems);

    const summary = [
      `🔍 Search Results for "${query}"`,
      `   Found ${result.totalItems} matching server(s)`,
      `   Page ${result.page}/${result.totalPages}`,
      `   Showing ${result.items.length} server(s)`,
    ].join('\n');

    return createMCPStructuredResponse(summary, {
      ...result,
      query,
    });
  }

  private async createServer(
    args: Record<string, unknown>,
  ): Promise<MCPResponse<CreateServerOutput>> {
    const name = String(args.name || '').trim();
    const description = String(args.description || '');
    const transport = args.transport as Record<string, unknown>;
    const tags = (args.tags as string[]) || [];

    // Validate required fields
    if (!name) {
      return createMCPTextResponse('Server name is required');
    }

    if (!transport || !transport.type) {
      return createMCPTextResponse('Transport configuration is required');
    }

    const transportType = String(transport.type);
    if (transportType !== 'stdio' && transportType !== 'http') {
      return createMCPTextResponse('Transport type must be "stdio" or "http"');
    }

    // Validate transport-specific fields
    if (transportType === 'stdio' && !transport.command) {
      return createMCPTextResponse('Command is required for stdio transport');
    }
    if (transportType === 'http' && !transport.url) {
      return createMCPTextResponse('URL is required for http transport');
    }

    // Build server entity
    const now = new Date();
    const server: MCPServerEntity = {
      id: `mcp-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      name,
      isActive: true,
      createdAt: now,
      updatedAt: now,
      transport: transport as MCPServerEntity['transport'],
      metadata: {
        description,
        tags,
      },
    };

    // Try to save (will throw if name exists)
    try {
      await mcpServersCRUD.upsert(server);

      const summary = [
        `✅ MCP Server Created Successfully`,
        `   Name: ${server.name}`,
        `   ID: ${server.id}`,
        `   Transport: ${transportType}`,
        `   Status: Active`,
        ``,
        `💡 Use "connect_server" to enable this server for the current assistant.`,
      ].join('\n');

      return createMCPStructuredResponse(summary, {
        server,
        message: 'Server created successfully',
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);

      if (message.includes('name already exists')) {
        return createMCPTextResponse(
          `❌ Server name "${name}" already exists. Please choose a different name.`,
        );
      }

      throw error;
    }
  }

  private async connectServer(
    args: Record<string, unknown>,
  ): Promise<MCPResponse<ConnectServerOutput>> {
    const serverId = String(args.serverId || '');
    const serverName = String(args.serverName || '');
    const scope = String(args.scope || 'assistant');
    const autoStart = Boolean(args.autoStart ?? true);

    // Validate scope
    if (scope !== 'assistant' && scope !== 'global') {
      return createMCPTextResponse('Scope must be "assistant" or "global"');
    }

    // Find server
    let server: MCPServerEntity | undefined;

    if (serverId) {
      server = await mcpServersCRUD.read(serverId);
    } else if (serverName) {
      const db = LocalDatabase.getInstance();
      server = await db.mcpServers
        .filter((s) => s.name.toLowerCase() === serverName.toLowerCase())
        .first();
    } else {
      return createMCPTextResponse('Either serverId or serverName is required');
    }

    if (!server) {
      return createMCPTextResponse(
        `Server not found: ${serverId || serverName}`,
      );
    }

    // Connect based on scope
    if (scope === 'assistant') {
      if (!this.assistantId) {
        return createMCPTextResponse(
          '❌ Assistant context not available. Cannot connect to assistant scope.',
        );
      }

      const assistant = await assistantsCRUD.read(this.assistantId);
      if (!assistant) {
        return createMCPTextResponse(
          `Assistant not found: ${this.assistantId}`,
        );
      }

      // Add to assistant's server list if not already connected
      const serverIds = assistant.mcpServerIds || [];
      if (!serverIds.includes(server.id)) {
        assistant.mcpServerIds = [...serverIds, server.id];
        await assistantsCRUD.upsert(assistant);
      }

      const summary = [
        `✅ Server Connected to Assistant`,
        `   Server: ${server.name}`,
        `   Assistant: ${assistant.name}`,
        `   Scope: assistant`,
        autoStart
          ? `   Status: Starting...`
          : `   Status: Registered (manual start required)`,
      ].join('\n');

      return createMCPStructuredResponse(summary, {
        success: true,
        server,
        scope: 'assistant',
        assistantId: this.assistantId,
        message: `Server "${server.name}" connected to assistant "${assistant.name}"`,
      });
    } else {
      // Global scope: mark server as globally enabled
      // This could be done via a flag or a special "global-enabled" list in objects table
      // For now, we just set isActive = true
      server.isActive = true;
      server.updatedAt = new Date();
      await mcpServersCRUD.upsert(server);

      const summary = [
        `✅ Server Enabled Globally`,
        `   Server: ${server.name}`,
        `   Scope: global`,
        `   Status: Active`,
      ].join('\n');

      return createMCPStructuredResponse(summary, {
        success: true,
        server,
        scope: 'global',
        message: `Server "${server.name}" enabled globally`,
      });
    }
  }

  private async disconnectServer(
    args: Record<string, unknown>,
  ): Promise<MCPResponse<unknown>> {
    const serverId = String(args.serverId || '');
    const serverName = String(args.serverName || '');
    const scope = String(args.scope || 'assistant');

    // Find server
    let server: MCPServerEntity | undefined;

    if (serverId) {
      server = await mcpServersCRUD.read(serverId);
    } else if (serverName) {
      const db = LocalDatabase.getInstance();
      server = await db.mcpServers
        .filter((s) => s.name.toLowerCase() === serverName.toLowerCase())
        .first();
    } else {
      return createMCPTextResponse('Either serverId or serverName is required');
    }

    if (!server) {
      return createMCPTextResponse(
        `Server not found: ${serverId || serverName}`,
      );
    }

    if (scope === 'assistant') {
      if (!this.assistantId) {
        return createMCPTextResponse('❌ Assistant context not available.');
      }

      const assistant = await assistantsCRUD.read(this.assistantId);
      if (!assistant) {
        return createMCPTextResponse(
          `Assistant not found: ${this.assistantId}`,
        );
      }

      const serverIds = assistant.mcpServerIds || [];
      assistant.mcpServerIds = serverIds.filter((id) => id !== server!.id);
      await assistantsCRUD.upsert(assistant);

      return createMCPStructuredResponse(
        `✅ Server "${server.name}" disconnected from assistant "${assistant.name}"`,
        { success: true, server, scope: 'assistant' },
      );
    } else {
      server.isActive = false;
      server.updatedAt = new Date();
      await mcpServersCRUD.upsert(server);

      return createMCPStructuredResponse(
        `✅ Server "${server.name}" disabled globally`,
        { success: true, server, scope: 'global' },
      );
    }
  }

  async switchContext(options: ServiceContextOptions): Promise<void> {
    this.assistantId = options.assistantId || null;
    this.sessionId = options.sessionId || null;
    logger.debug('Context switched', {
      assistantId: this.assistantId,
      sessionId: this.sessionId,
    });
  }

  async getServiceContext(
    options?: ServiceContextOptions,
  ): Promise<ServiceContext<unknown>> {
    const db = LocalDatabase.getInstance();
    const totalServers = await db.mcpServers.count();
    const activeServers = await db.mcpServers.filter((s) => s.isActive).count();

    let assistantInfo = '';
    if (this.assistantId) {
      const assistant = await assistantsCRUD.read(this.assistantId);
      const connectedCount = assistant?.mcpServerIds?.length || 0;
      assistantInfo = `\n**Current Assistant**: ${assistant?.name || 'Unknown'}\n**Connected Servers**: ${connectedCount}`;
    }

    const contextPrompt = [
      `# MCP Manager Server Status`,
      `**Server**: mcp_manager`,
      `**Status**: Active`,
      `**Total Servers**: ${totalServers}`,
      `**Active Servers**: ${activeServers}`,
      assistantInfo,
    ]
      .filter(Boolean)
      .join('\n');

    return {
      contextPrompt,
      structuredState: {
        totalServers,
        activeServers,
        assistantId: this.assistantId,
        sessionId: this.sessionId,
      },
    };
  }
}

export default new MCPManagerServer();
```

#### index.ts - 모듈 exports

```typescript
export { default } from './server';
export { mcpManagerTools } from './tools';
```

#### README.md - 사용 가이드

````markdown
# MCP Manager Server

Built-in Web MCP server for managing MCP server configurations dynamically.

## Purpose

Allows AI agents to:

- List and search registered MCP servers
- Create new server configurations
- Connect servers to assistants or enable globally
- Disconnect servers from assistants

## Tools

### list_servers

List all registered MCP servers with pagination and filtering.

**Parameters:**

- `page` (number, optional): Page number (default: 1)
- `pageSize` (number, optional): Items per page (default: 20, -1 for all)
- `filterByAssistant` (boolean, optional): Filter by current assistant's servers
- `includeInactive` (boolean, optional): Include inactive servers (default: true)

**Output:**

- Page<MCPServerEntity> with pagination metadata

### search_server

Search servers by name, description, or tags.

**Parameters:**

- `query` (string, required): Search query
- `page`, `pageSize`: Same as list_servers
- `byNameOnly` (boolean, optional): Search only names (default: true)
- `includeInactive` (boolean, optional): Include inactive servers

**Output:**

- Paginated search results with query

### create_server

Create a new MCP server configuration.

**Parameters:**

- `name` (string, required): Unique server name
- `description` (string, optional): Server description
- `transport` (object, required): Transport config
  - `type`: "stdio" or "http"
  - For stdio: `command`, `args?`, `env?`
  - For http: `url`, `headers?`
- `tags` (string[], optional): Tags for categorization

**Output:**

- Created MCPServerEntity

### connect_server

Connect a server to the current assistant or enable globally.

**Parameters:**

- `serverId` or `serverName` (string, required): Server to connect
- `scope` (string, optional): "assistant" or "global" (default: "assistant")
- `autoStart` (boolean, optional): Auto-start server (default: true)

**Output:**

- Connection status and server details

### disconnect_server

Disconnect server from current assistant or disable globally.

**Parameters:**

- `serverId` or `serverName` (string, required)
- `scope` (string, optional): "assistant" or "global"

**Output:**

- Disconnection status

## Context Integration

- Automatically receives `assistantId` via WebMCPContextSetter
- Assistant-scoped operations use current assistant context
- Global operations affect all assistants

## Example Usage

```typescript
// List servers for current assistant
await proxy.callTool('mcp_manager', 'list_servers', {
  filterByAssistant: true,
});

// Search for a server
await proxy.callTool('mcp_manager', 'search_server', {
  query: 'github',
});

// Create a new server
await proxy.callTool('mcp_manager', 'create_server', {
  name: 'my-github-server',
  description: 'GitHub API integration',
  transport: {
    type: 'http',
    url: 'https://api.github.com/mcp',
  },
  tags: ['github', 'api'],
});

// Connect to current assistant
await proxy.callTool('mcp_manager', 'connect_server', {
  serverName: 'my-github-server',
  scope: 'assistant',
});
```
````

````

### 2. Worker 등록

#### src/lib/web-mcp/mcp-worker.ts

```typescript
// 기존 imports...
import mcpManagerServer from './modules/mcp-manager/index.ts';

const MODULE_REGISTRY = [
  { key: 'planning', module: planningServer },
  { key: 'playbook', module: playbookStore },
  { key: 'ui', module: uiTools },
  { key: 'bootstrap', module: bootstrapServer },
  { key: 'mcp_manager', module: mcpManagerServer },  // 추가
] as const;
````

### 3. App 레벨 등록

#### src/app/App.tsx

```typescript
<WebMCPServiceRegistry
  servers={[
    'planning',
    'playbook',
    'ui',
    'bootstrap',
    'mcp_manager',  // 추가
  ]}
/>
```

### 4. Unimported 설정

#### .unimportedrc.json

```json
{
  "ignoreUnimported": [
    // ...existing entries...
    "src/lib/web-mcp/modules/mcp-manager",
    "src/lib/web-mcp/modules/mcp-manager/index.ts",
    "src/lib/web-mcp/modules/mcp-manager/server.ts",
    "src/lib/web-mcp/modules/mcp-manager/tools.ts"
  ]
}
```

## 재사용 가능한 연관 코드

### 1. 응답 생성 유틸리티

**파일**: `src/lib/mcp-response-utils.ts`

```typescript
export function createMCPStructuredResponse<T>(
  textSummary: string,
  structuredContent: T,
): MCPResponse<T>;

export function createMCPTextResponse(text: string): MCPResponse<unknown>;
```

**사용법**: 모든 도구 응답에 text + structuredContent 포함

### 2. JSON Schema 헬퍼

**파일**: `src/lib/mcp-types.ts`

```typescript
createStringSchema(options?: { description?, minLength?, maxLength?, pattern?, format? })
createIntegerSchema(options?: { description?, minimum?, maximum? })
createBooleanSchema(options?: { description? })
createObjectSchema(options?: { description?, properties?, required?, additionalProperties? })
```

**사용법**: Tool inputSchema 정의 시 사용

### 3. CRUD 계층

**파일**: `src/lib/db/crud.ts`

```typescript
// MCP 서버 CRUD
mcpServersCRUD.upsert(server);
mcpServersCRUD.read(id);
mcpServersCRUD.delete(id);
mcpServersCRUD.getPage(page, pageSize);
mcpServersCRUD.count();

// Assistant CRUD
assistantsCRUD.upsert(assistant);
assistantsCRUD.read(id);

// 페이지네이션 헬퍼
createPage<T>(items, page, pageSize, totalItems);
```

### 4. 컨텍스트 인터페이스

**파일**: `src/features/tools/index.tsx`

```typescript
export interface ServiceContextOptions {
  assistantId?: string;
  sessionId?: string;
  [key: string]: unknown;
}

export interface ServiceContext<T> {
  contextPrompt: string;
  structuredState: T | undefined;
}
```

**사용법**: `switchContext`, `getServiceContext` 구현 시

### 5. 로거

**파일**: `src/lib/logger.ts`

```typescript
import { getLogger } from '@/lib/logger';
const logger = getLogger('MCPManagerServer');

logger.debug('message', { data });
logger.info('message', { data });
logger.warn('message', { data });
logger.error('message', { data });
```

## Test Code 추가 및 수정 필요 부분

### 1. 유닛 테스트

**파일**: `src/lib/web-mcp/modules/mcp-manager/__tests__/mcp-manager.test.ts`

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import mcpManagerServer from '../server';
import { LocalDatabase } from '@/lib/db';
import { mcpServersCRUD, assistantsCRUD } from '@/lib/db/crud';

describe('MCP Manager Server', () => {
  beforeEach(async () => {
    // Clear test data
    const db = LocalDatabase.getInstance();
    await db.mcpServers.clear();
    await db.assistants.clear();
  });

  describe('Tool Schema', () => {
    it('should export 5 tools', () => {
      expect(mcpManagerServer.tools).toHaveLength(5);
    });

    it('should have required tools', () => {
      const toolNames = mcpManagerServer.tools.map((t) => t.name);
      expect(toolNames).toContain('list_servers');
      expect(toolNames).toContain('search_server');
      expect(toolNames).toContain('create_server');
      expect(toolNames).toContain('connect_server');
      expect(toolNames).toContain('disconnect_server');
    });
  });

  describe('list_servers', () => {
    it('should return empty list when no servers exist', async () => {
      const response = await mcpManagerServer.callTool('list_servers', {});

      expect(response.result?.structuredContent).toBeDefined();
      const data = response.result!.structuredContent as { items: unknown[] };
      expect(data.items).toHaveLength(0);
    });

    it('should return paginated list of servers', async () => {
      // Create test servers
      // ...

      const response = await mcpManagerServer.callTool('list_servers', {
        page: 1,
        pageSize: 10,
      });

      // Assertions...
    });

    it('should filter by assistant context', async () => {
      // Setup assistant with connected servers
      // ...

      const response = await mcpManagerServer.callTool('list_servers', {
        filterByAssistant: true,
      });

      // Assertions...
    });
  });

  describe('search_server', () => {
    it('should return error for empty query', async () => {
      const response = await mcpManagerServer.callTool('search_server', {
        query: '',
      });

      expect(response.result?.content?.[0]?.text).toContain('required');
    });

    it('should find servers by name', async () => {
      // Create test servers
      // ...

      const response = await mcpManagerServer.callTool('search_server', {
        query: 'github',
      });

      // Assertions...
    });
  });

  describe('create_server', () => {
    it('should create stdio server', async () => {
      const response = await mcpManagerServer.callTool('create_server', {
        name: 'test-server',
        description: 'Test server',
        transport: {
          type: 'stdio',
          command: 'node',
          args: ['server.js'],
        },
      });

      expect(response.result?.structuredContent).toBeDefined();
      const data = response.result!.structuredContent as {
        server: { name: string };
      };
      expect(data.server.name).toBe('test-server');
    });

    it('should reject duplicate server name', async () => {
      // Create first server
      await mcpManagerServer.callTool('create_server', {
        name: 'duplicate',
        transport: { type: 'stdio', command: 'node' },
      });

      // Try to create duplicate
      const response = await mcpManagerServer.callTool('create_server', {
        name: 'duplicate',
        transport: { type: 'stdio', command: 'node' },
      });

      expect(response.result?.content?.[0]?.text).toContain('already exists');
    });
  });

  describe('connect_server', () => {
    it('should connect server to assistant', async () => {
      // Setup test data
      // ...

      const response = await mcpManagerServer.callTool('connect_server', {
        serverId: 'server-id',
        scope: 'assistant',
      });

      expect(response.result?.structuredContent).toBeDefined();
      const data = response.result!.structuredContent as { success: boolean };
      expect(data.success).toBe(true);
    });

    it('should require assistant context for assistant scope', async () => {
      const response = await mcpManagerServer.callTool('connect_server', {
        serverId: 'server-id',
        scope: 'assistant',
      });

      expect(response.result?.content?.[0]?.text).toContain(
        'Assistant context not available',
      );
    });
  });
});
```

### 2. 통합 테스트

**시나리오**:

1. 서버 생성
2. 검색으로 확인
3. Assistant에 연결
4. 필터링된 목록에서 확인
5. 연결 해제
6. 다시 필터링된 목록에서 사라졌는지 확인

### 3. E2E 테스트 (선택)

**도구**: Playwright 또는 수동 테스트

**시나리오**:

- 에이전트가 대화 중 "GitHub 서버를 찾아서 연결해줘" 요청
- 에이전트가 `search_server(query: "github")` 호출
- 결과에서 서버 선택
- `connect_server(serverId: "...")` 호출
- Assistant의 설정 페이지에서 연결된 서버 확인

## 추가 분석 과제

### 1. Rust Backend 통합 (P1)

**현재 상태**: Web MCP 서버는 데이터만 관리하고 실제 stdio/http 연결은 하지 않음

**분석 필요 항목**:

- Tauri 명령으로 MCP 서버 시작/중지 API 존재 여부
- RustMCPToolProvider의 서버 발견 메커니즘
- 런타임 서버 추가 시 provider 갱신 방법

**제안**:

- `connect_server`의 `autoStart: true` 옵션 구현
- Tauri 명령 `start_mcp_server(serverId)` 호출
- 성공 시 provider에 갱신 신호 전송

### 2. 서버 상태 모니터링 (P2)

**분석 필요 항목**:

- 연결된 서버의 health check 방법
- 서버 다운 시 자동 재시작 로직
- 서버별 도구 목록 캐싱 전략

**제안**:

- `ping_server(serverId)` 도구 추가
- `get_server_status(serverId)` 도구로 상태 조회
- Backend에서 주기적 health check 후 frontend 동기화

### 3. 보안 및 권한 관리 (P1)

**분석 필요 항목**:

- Assistant별 서버 접근 권한 스코프
- 전역 서버의 접근 제어 정책
- 민감한 환경 변수 암호화 저장

**제안**:

- Assistant 레벨 권한 플래그 추가
- 전역 서버 활성화 시 관리자 확인 단계
- 환경 변수 암호화 저장 (Tauri secure storage)

### 4. UI 통합 (P1)

**분석 필요 항목**:

- SettingsPage에 "Add from Agent" 버튼 표시
- 에이전트가 추가한 서버 표시 방법 (태그, 아이콘)
- 에이전트 제안 서버 사용자 승인 플로우

**제안**:

- 서버 메타데이터에 `createdBy: 'user' | 'agent'` 플래그
- UI에서 에이전트 생성 서버 구분 표시
- 사용자 승인 대기 상태 추가 (`status: 'pending_approval'`)

## Clarification Q-list

### Q1: 전역 서버 활성화 정책

**질문**: `connect_server(scope: 'global')`은 모든 Assistant가 사용할 수 있게 하는 건데, 이게 보안상 괜찮은가요?

**옵션**:

1. 전역 서버는 사용자만 UI에서 활성화 가능, 에이전트는 불가
2. 전역 서버도 에이전트가 활성화 가능하지만 사용자 승인 필요
3. 제한 없이 허용

**권장**: 옵션 2 (사용자 승인 플로우)

### Q2: 서버 시작 타이밍

**질문**: `connect_server`가 호출되면 즉시 서버를 시작해야 하나요, 아니면 다음 대화 턴에서 도구 호출 시 시작하나요?

**옵션**:

1. `autoStart: true`이면 즉시 시작 (Tauri 명령 호출)
2. 지연 시작 (첫 도구 호출 시)
3. 사용자 명시적 시작 필요

**권장**: 옵션 1 (즉시 시작), 단 backend 준비 필요

### Q3: 서버 삭제 정책

**질문**: `delete_server` 도구를 추가할까요? 현재 CRUD에는 delete가 있지만 참조 확인이 필요합니다.

**고려사항**:

- Assistant가 참조 중이면 삭제 불가 (현재 CRUD 로직)
- 에이전트가 실수로 중요한 서버 삭제 가능성
- UI에서만 삭제 가능하게 제한?

**권장**: P1으로 `delete_server` 추가하되, 참조 확인 + 사용자 승인 플로우

### Q4: 서버 메타데이터 확장

**질문**: 서버에 추가로 저장해야 할 정보가 있나요?

**후보**:

- `version`: 서버 버전 (업데이트 추적)
- `capabilities`: 서버가 제공하는 기능 목록
- `dependencies`: 서버가 의존하는 다른 서버/도구
- `healthStatus`: 마지막 health check 결과
- `lastUsedAt`: 마지막 사용 시간

**권장**: P2로 `capabilities`, `healthStatus` 추가

### Q5: 페이지네이션 기본값

**질문**: `list_servers`의 기본 pageSize는 20이 적당한가요?

**고려사항**:

- 일반적으로 서버 수가 많지 않을 것 (10~50개?)
- 에이전트는 전체 목록을 한 번에 보는 게 유용할 수도
- UI 성능 고려

**권장**: 기본 20 유지, 에이전트가 필요 시 `-1` (전체) 요청 가능

## 작업 순서 제안

1. **Phase 1 - 기본 구조 (P0)**
   - tools.ts 작성 (도구 스키마)
   - server.ts 작성 (list_servers, search_server, create_server, connect_server)
   - worker 등록 + App 등록
   - 유닛 테스트 작성

2. **Phase 2 - 통합 및 검증 (P0)**
   - 실제 대화에서 도구 호출 테스트
   - SettingsPage 연동 확인 (에이전트가 추가한 서버 표시)
   - 에러 처리 강화

3. **Phase 3 - 확장 기능 (P1)**
   - disconnect_server, delete_server 추가
   - update_server 추가 (이름, 설명, 태그 수정)
   - getServiceContext 구현 (상태 요약)

4. **Phase 4 - Backend 통합 (P1)**
   - Tauri 명령으로 서버 시작/중지
   - RustMCPToolProvider와 동기화
   - 서버 health check

5. **Phase 5 - UI 개선 (P2)**
   - "Add from Agent" 버튼
   - 에이전트 생성 서버 구분 표시
   - 사용자 승인 플로우

## 참고 문서

- [Built-in Tools Architecture](../builtin-tools.md)
- [Web MCP README](../../lib/web-mcp/README.md)
- [Planning Server Implementation](../../lib/web-mcp/modules/planning-server/)
- [Bootstrap Server Implementation](../../lib/web-mcp/modules/bootstrap-server/)
- [CRUD Layer](../../lib/db/crud.ts)
- [MCP Types](../../lib/mcp-types.ts)


---

# refactoring_20251011_1700.md

# Refactoring Plan: Wait UI Tools (극단적 단순화)

**Date**: 2025-10-11 17:00  
**Author**: AI Agent  
**Version**: 1.0

## 작업의 목적

오래 걸리는 비동기 작업(예: shell command 실행) 실행 시 사용자에게
대기 애니메이션과 "계속" 버튼을 제공하여, 사용자가 명시적으로
버튼을 눌러 작업을 재개할 수 있도록 한다.

**핵심 원칙**:

- 극단적 단순성: waitId, 세션 관리, action 구분 없음
- 상태 비저장: 모든 정보는 UIResource에 embedded
- Non-blocking: UIResource 포함 메시지는 자동 submit 안 됨
- 2개 도구만: `wait_for_user_resume`, `resume_from_wait`

## 현재의 상태 / 문제점

### 현재 ui-tools.ts 구조

- 3개 도구 제공: `prompt_user`, `reply_prompt`, `visualize_data`
- 모든 도구는 즉각적인 사용자 입력/시각화 목적
- **부재**: 긴 작업 대기 중 사용자 확인 UI 없음

### 문제점

1. 긴 작업 실행 시 사용자는 응답 없는 상태로 대기
2. 작업 진행 상태가 불명확
3. 사용자가 작업 흐름을 제어할 수 없음

## 관련 코드의 구조 및 동작 방식 Summary

### ui-tools.ts 아키텍처

```text
WebMCPServer 'ui'
├── tools: MCPTool[] (3개 도구)
├── callTool(name, args) → MCPResponse
│   ├── 입력 검증
│   ├── HTML 생성 (build*Html)
│   ├── UIResource 생성 (createUiResourceFromHtml)
│   └── multipart 응답
└── activePrompts: Map<string, PromptState>
```

### 핵심 패턴

- HTML 생성: `build*Html()` → escaped HTML string
- UIResource 생성: `createUiResourceFromHtml(html, uri)`
- postMessage 통신: UI → parent → tool 호출
- 응답 형식: text + uiResource (multipart)

### 재사용 가능한 코드

- `escapeHtml(s: string)`: XSS 방지
- `createUiResourceFromHtml(html, uri)`: UIResource + serviceInfo
- `createMCPStructuredMultipartResponse()`: multipart 응답
- `nextMessageId`: 유니크 ID 생성

### ChatContext와의 통합

- UIResource 포함 메시지는 **자동 submit되지 않음**
- postMessage → tool 호출 → 응답은 별도 경로로 처리
- 따라서 별도 wait/blocking 로직 불필요

## 변경 이후의 상태 / 해결 판정 기준

### 변경 후 상태

- 2개 새 도구 추가: `wait_for_user_resume`, `resume_from_wait`
- 사용자는 spinner + "계속" 버튼이 있는 UI 확인
- 버튼 클릭 → `resume_from_wait` 호출 → agent가 컨텍스트 받음

### 해결 판정 기준

1. **기능**: 두 도구가 정상 동작
2. **UI**: spinner, 메시지, "계속" 버튼 표시
3. **컨텍스트**: agent가 재개 시 충분한 정보 수신
4. **테스트**: 도구 lifecycle, HTML 생성, postMessage 테스트 통과

## 수정이 필요한 코드 및 수정 부분

### 1. 타입 정의 추가 (파일 상단)

```typescript
// Wait context type (구조화된 정보)
interface WaitContext {
  startedAt: string; // ISO 8601 timestamp (서버가 자동 생성)
  reason: string; // 대기 이유
  command: string; // 실행 중인 명령/작업
  nextAction: string; // 재개 후 수행할 동작
}
```

### 2. Helper 함수 추가

```typescript
/**
 * Format duration in human-readable format
 */
function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);

  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
}

/**
 * Generate HTML for wait UI
 */
function buildWaitHtml(message: string, context: WaitContext): string {
  const escapedMessage = escapeHtml(message);
  const escapedContext = escapeHtml(JSON.stringify(context));

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      margin: 0;
      padding: 16px;
      background: #f9fafb;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }
    .wait-container {
      max-width: 500px;
      background: white;
      border-radius: 8px;
      padding: 32px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      text-align: center;
    }
    .spinner {
      font-size: 48px;
      margin-bottom: 16px;
      animation: spin 2s linear infinite;
    }
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    @media (prefers-reduced-motion: reduce) {
      .spinner { animation: none; }
    }
    .message {
      font-size: 18px;
      font-weight: 600;
      color: #1f2937;
      margin-bottom: 24px;
    }
    .btn-continue {
      padding: 12px 24px;
      background: #3b82f6;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
    }
    .btn-continue:hover {
      background: #2563eb;
    }
    .btn-continue:focus {
      outline: none;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
    }
  </style>
</head>
<body>
  <div class="wait-container" role="dialog" aria-modal="true"
       aria-labelledby="wait-message">
    <div class="spinner" aria-hidden="true">⏳</div>
    <div id="wait-message" class="message">${escapedMessage}</div>
    <button class="btn-continue" onclick="handleContinue()" autofocus>
      계속
    </button>
  </div>
  <script>
    const context = ${escapedContext};

    function handleContinue() {
      window.parent.postMessage({
        type: 'tool',
        payload: {
          toolName: 'resume_from_wait',
          params: { context }
        }
      }, '*');
    }

    // Keyboard support
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') {
        handleContinue();
      }
    });
  </script>
</body>
</html>`;
}
```

### 3. 도구 정의 추가 (tools 배열)

```typescript
const tools: MCPTool[] = [
  // ... 기존 도구들 ...

  {
    name: 'wait_for_user_resume',
    description: 'Display wait UI with continue button for long operations',
    inputSchema: {
      type: 'object',
      properties: {
        message: {
          type: 'string',
          description: 'Message to display to user',
        },
        context: {
          type: 'object',
          properties: {
            reason: {
              type: 'string',
              description: 'Why waiting (for agent context)',
            },
            command: {
              type: 'string',
              description: 'Command or task being executed',
            },
            nextAction: {
              type: 'string',
              description: 'What to do after resume',
            },
          },
          required: ['reason', 'command', 'nextAction'],
        },
      },
      required: ['message', 'context'],
    },
  },

  {
    name: 'resume_from_wait',
    description: 'Resume from wait (called by UI button click)',
    inputSchema: {
      type: 'object',
      properties: {
        context: {
          type: 'object',
          properties: {
            startedAt: { type: 'string' },
            reason: { type: 'string' },
            command: { type: 'string' },
            nextAction: { type: 'string' },
          },
          required: ['startedAt', 'reason', 'command', 'nextAction'],
        },
        sessionId: {
          type: 'string',
          description: 'Optional session ID for validation',
        },
      },
      required: ['context'],
    },
  },
];
```

### 4. callTool 핸들러 추가 (switch문에 case 추가)

```typescript
async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
  const a = (args || {}) as Record<string, unknown>;

  try {
    switch (name) {
      // ... 기존 케이스들 ...

      case 'wait_for_user_resume': {
        const message = String(a.message || '');
        const contextInput = a.context as Omit<WaitContext, 'startedAt'>;

        if (!message) {
          return createMCPTextResponse('Message is required');
        }

        if (!contextInput || !contextInput.reason ||
            !contextInput.command || !contextInput.nextAction) {
          return createMCPTextResponse(
            'Context with reason, command, nextAction required'
          );
        }

        // Add startedAt timestamp
        const context: WaitContext = {
          ...contextInput,
          startedAt: new Date().toISOString()
        };

        // Generate HTML
        const html = buildWaitHtml(message, context);
        const uri = `ui://wait/${Date.now()}` as `ui://${string}`;
        const uiResource = createUiResourceFromHtml(html, uri);

        // Text content
        const textContent: MCPContent = {
          type: 'text',
          text: `⏳ Waiting: ${message}\nReason: ${context.reason}`
        } as MCPContent;

        // Return multipart
        return createMCPStructuredMultipartResponse(
          [textContent, uiResource],
          { waiting: true, context }
        );
      }

      case 'resume_from_wait': {
        const context = a.context as WaitContext;

        if (!context || !context.startedAt) {
          return createMCPTextResponse('Valid context required');
        }

        // Calculate duration
        const startedAt = new Date(context.startedAt);
        const resumedAt = new Date();
        const duration = formatDuration(
          resumedAt.getTime() - startedAt.getTime()
        );

        // Build agent-friendly text response
        const text = [
          `✅ User resumed after waiting ${duration}`,
          '',
          `What was waiting: ${context.reason}`,
          `Command/Task: ${context.command}`,
          `Started: ${context.startedAt}`,
          `Ended: ${resumedAt.toISOString()}`,
          '',
          `Next action: ${context.nextAction}`
        ].join('\n');

        return createMCPStructuredResponse(text, {
          resumed: true,
          duration,
          ...context,
          resumedAt: resumedAt.toISOString()
        });
      }

      default:
        return createMCPTextResponse(`Unknown tool: ${name}`);
    }
  } catch (err) {
    return createMCPTextResponse(
      `Error in ui-tools: ${err instanceof Error ? err.message : String(err)}`
    );
  }
}
```

## 재사용 가능한 연관 코드

### 기존 ui-tools.ts 패턴

- **파일**: `src/lib/web-mcp/modules/ui-tools.ts`
- **패턴**:
  - `escapeHtml`: XSS 방지
  - `createUiResourceFromHtml`: UIResource 생성
  - postMessage 통신 패턴
  - multipart 응답 생성
- **인터페이스**:
  - `MCPTool`, `MCPResponse`, `MCPContent`, `UIResource`
  - `WebMCPServer`

### MCP 응답 유틸리티

- **파일**: `src/lib/mcp-response-utils.ts`
- **함수**:
  - `createMCPTextResponse(text)`
  - `createMCPStructuredResponse(text, data)`
  - `createMCPStructuredMultipartResponse(contents, data)`

### @mcp-ui/server

- **패키지**: `@mcp-ui/server`
- **함수**: `createUIResource({ uri, content, encoding })`

## Test Code 추가 및 수정 필요 부분

### 1. Unit Tests: 도구 기본 동작

**파일**: `src/lib/web-mcp/modules/__tests__/ui-tools.test.ts`

**테스트 케이스**:

```typescript
describe('wait_for_user_resume tool', () => {
  test('returns multipart response with text and uiResource', async () => {
    const response = await uiTools.callTool('wait_for_user_resume', {
      message: 'Testing wait',
      context: {
        reason: 'Test reason',
        command: 'test command',
        nextAction: 'test next',
      },
    });

    expect(response.content).toHaveLength(2);
    expect(response.content[0].type).toBe('text');
    expect(response.content[1].type).toBe('resource');
  });

  test('automatically adds startedAt timestamp', async () => {
    const before = new Date().toISOString();
    const response = await uiTools.callTool('wait_for_user_resume', {
      message: 'Test',
      context: {
        reason: 'Test',
        command: 'test',
        nextAction: 'test',
      },
    });
    const after = new Date().toISOString();

    const metadata = response.metadata as { context: WaitContext };
    expect(metadata.context.startedAt).toBeDefined();
    expect(metadata.context.startedAt >= before).toBe(true);
    expect(metadata.context.startedAt <= after).toBe(true);
  });

  test('rejects invalid context', async () => {
    const response = await uiTools.callTool('wait_for_user_resume', {
      message: 'Test',
      context: { reason: 'Test' }, // incomplete
    });

    expect(response.content[0].text).toContain('required');
  });
});

describe('resume_from_wait tool', () => {
  test('returns formatted agent message', async () => {
    const context = {
      startedAt: '2025-10-11T17:00:00Z',
      reason: 'Test wait',
      command: 'npm install',
      nextAction: 'Continue deployment',
    };

    const response = await uiTools.callTool('resume_from_wait', {
      context,
    });

    expect(response.content[0].text).toContain('✅ User resumed');
    expect(response.content[0].text).toContain('Test wait');
    expect(response.content[0].text).toContain('npm install');
    expect(response.content[0].text).toContain('Continue deployment');
  });

  test('calculates duration correctly', async () => {
    const startedAt = new Date(Date.now() - 65000).toISOString();
    const response = await uiTools.callTool('resume_from_wait', {
      context: {
        startedAt,
        reason: 'Test',
        command: 'test',
        nextAction: 'test',
      },
    });

    expect(response.content[0].text).toMatch(/1m \d+s/);
  });
});
```

### 2. Integration Tests: HTML 생성

```typescript
test('buildWaitHtml generates valid HTML', () => {
  const html = buildWaitHtml('Test message', {
    startedAt: '2025-10-11T17:00:00Z',
    reason: 'Test',
    command: 'test cmd',
    nextAction: 'next',
  });

  expect(html).toContain('<!doctype html>');
  expect(html).toContain('Test message');
  expect(html).toContain('role="dialog"');
  expect(html).toContain('resume_from_wait');
  expect(html).toContain('postMessage');
});

test('HTML includes accessibility attributes', () => {
  const html = buildWaitHtml('Test', mockContext);

  expect(html).toContain('aria-modal="true"');
  expect(html).toContain('autofocus');
  expect(html).toContain('aria-labelledby');
});
```

### 3. E2E Tests: postMessage 시뮬레이션

```typescript
test('UI button triggers correct postMessage', () => {
  // JSDOM 또는 Playwright로 HTML 렌더링
  const messages: unknown[] = [];
  window.addEventListener('message', (e) => messages.push(e.data));

  // Simulate button click
  const button = document.querySelector('.btn-continue');
  button?.click();

  expect(messages).toHaveLength(1);
  expect(messages[0]).toMatchObject({
    type: 'tool',
    payload: {
      toolName: 'resume_from_wait',
      params: { context: expect.any(Object) },
    },
  });
});
```

## 추가 분석 과제

### 1. 보안: postMessage origin 검증

- 현재: `postMessage` origin '\*' 사용
- **분석**: origin 제한 또는 nonce 검증 필요성
- **제안**: context에 nonce 추가하여 서버 검증

### 2. Timeout 정책

- 현재: timeout 처리 없음
- **분석**: 사용자가 장시간 버튼 안 누르는 경우
- **제안**: 옵션으로 timeout 파라미터 추가 고려

### 3. 여러 대기 동시 발생

- 현재: 상태 비저장 방식
- **분석**: 동일 세션에서 여러 wait 동시 발생 시나리오
- **제안**: sessionId 검증으로 충돌 방지

### 4. 사용자가 창 닫는 경우

- 현재: 처리 없음
- **분석**: onbeforeunload 처리 필요성
- **제안**: UI에서 페이지 이탈 시 cancel 신호 전송

## 요약

- **새 도구 2개**: `wait_for_user_resume`, `resume_from_wait`
- **핵심**: 극단적 단순화 — waitId, 세션 관리, action 구분 없음
- **상태**: UIResource에 모든 context embedded
- **UI**: spinner + 메시지 + "계속" 버튼
- **agent 메시지**: 재개 시 충분한 컨텍스트 제공 (간결)
- **테스트**: 도구 lifecycle, HTML, postMessage, duration 계산

---

**다음 단계**: 이 계획에 따라 `ui-tools.ts` 수정 및 테스트 작성 진행.


---

# refactoring_20251102_1130.md

# MCP Manager + BM25 검색 확장 Refactoring Plan (2025-11-02 11:30)

## 작업의 목적

- 기존 mcp-manager Web MCP 서버의 기능을 완성하고 품질을 보강한다.
  - 리뷰에서 지적한 P0/P1 수정사항을 반영한다.
- 검색 기능을 확장하여 이름(name)과 설명(description)에 대해 BM25(bm25s) 기반 랭킹 검색을 지원한다.
- 테스트와 문서를 보강하여 안정적인 통합을 가능하게 한다.

## 현재의 상태 / 문제점

- 구현 계획 문서(`docs/history/refactoring_20251102_0000.md`)에는 완성도 높은 스펙과 코드 초안이 있으나 실제 파일 생성 및 통합 전이다.
- 리뷰에서 확인된 보완 필요점
  - 입력 타입 안전성 부족: 각 도구가 `Record<string, unknown>` 처리(런타임 캐스팅)에 의존
  - 페이지네이션 `pageSize = -1` 전체 조회 미처리
  - `disconnect_server`에서 scope 검증 누락
  - 서버 조회 로직(`serverId`/`serverName`) 중복
  - ID 생성: `Date.now() + Math.random()` → 충돌 낮지만 권장 방식 아님
  - Transport 타입 검증 불충분(런타임 캐스팅 중심)
  - 간단 검색(simple) 정렬 로직 개선 여지
- 검색은 현재 부분 문자열(contains) 기반으로만 동작하며, description 가중치 반영 및 랭킹 품질 개선이 어렵다.

## 관련 코드의 구조 및 동작 방식 Summary (Bird-eye View)

- Web MCP 서버 모듈: `src/lib/web-mcp/modules/mcp-manager/`
  - `server.ts`: MCPManagerServer 구현, 5개 도구(list/search/create/connect/disconnect)
  - `tools.ts`: 도구 스키마 정의(JSON Schema helpers 활용)
  - `index.ts`: 모듈 export
- 공통 유틸/타입
  - `src/lib/mcp-response-utils.ts`: text + structuredContent 응답 생성
  - `src/lib/mcp-types.ts`: JSON schema helper
  - `src/lib/db/`, `src/lib/db/crud.ts`: Dexie 기반 DB 및 CRUD 계층 (mcpServersCRUD, assistantsCRUD)
  - `src/lib/logger.ts`: 중앙 로깅
- 통합 포인트
  - `src/lib/web-mcp/mcp-worker.ts` MODULE_REGISTRY 등록
  - `src/app/App.tsx` WebMCPServiceRegistry servers 목록 추가

## 변경 이후의 상태 / 해결 판정 기준

- 검색 기능
  - `search_server`는 기본값으로 BM25(bm25s) 랭킹 검색을 지원한다.
  - 이름/설명 필드에 대한 가중치 기반 합산 점수로 랭킹한다(예: name 2.0, description 1.0 기본).
  - 옵션으로 기존 simple 검색도 유지한다.
- 품질/타입 안정성
  - 각 도구의 입력 타입 인터페이스 도입 및 런타임 가드 추가
  - `pageSize = -1` 시 전체 반환
  - `disconnect_server` scope 검증 추가
  - 서버 조회 중복 로직 헬퍼로 통일
  - ID 생성은 `crypto.randomUUID()`(가용 시)로 전환
  - Transport 타입 가드 추가
- 테스트 커버리지
  - BM25 검색 유닛 테스트 및 통합 테스트 추가
  - 리뷰에서 지적된 케이스(assistant 필터, scope 검증, 중복 이름 등) 모두 포함
- 빌드/린트/타입 검사/테스트 통과(`pnpm refactor:validate` 성공)

## 수정이 필요한 코드 및 수정부분의 코드 스니핏

아래 스니핏은 방향성과 핵심 로직을 보여주며, 실제 파일 통합 시 경로와 import를 프로젝트 구조에 맞게 조정한다. 코드 주석은 영어로 작성한다.

### 1) search_server 스키마 확장 (`tools.ts`)

- 변경 요약:
  - `searchMode`: 'bm25' | 'simple' (기본값 'bm25')
  - `weights?`: `{ nameWeight?: number; descWeight?: number }` (기본값: `2.0`, `1.0`)
  - `byNameOnly`: bm25 모드에선 무시되며 simple 모드에서만 의미 있음(하위 호환 유지)

```ts
// tools.ts (snippet)
import {
  createStringSchema,
  createIntegerSchema,
  createBooleanSchema,
  createObjectSchema,
  createEnumSchema,
} from '@/lib/mcp-types';

export const mcpManagerTools: MCPTool[] = [
  // ...
  {
    name: 'search_server',
    description: 'Search servers using BM25 (default) or simple matching',
    inputSchema: createObjectSchema({
      required: ['query'],
      properties: {
        query: createStringSchema({ description: 'Search query' }),
        page: createIntegerSchema({ description: 'Page number' }),
        pageSize: createIntegerSchema({
          description: 'Items per page (-1 for all)',
        }),
        searchMode: createEnumSchema(['bm25', 'simple'], {
          description: 'Search mode',
          default: 'bm25',
        }),
        byNameOnly: createBooleanSchema({
          description: 'Simple mode only: match name only',
          default: true,
        }),
        includeInactive: createBooleanSchema({
          description: 'Include inactive servers',
          default: true,
        }),
        weights: createObjectSchema({
          description: 'BM25 field weights',
          properties: {
            nameWeight: createIntegerSchema({
              description: 'Weight for name field',
              minimum: 0,
            }),
            descWeight: createIntegerSchema({
              description: 'Weight for description field',
              minimum: 0,
            }),
          },
        }),
      },
    }),
  },
  // ...
];
```

> 참고: `createEnumSchema`가 없다면 간단한 `createStringSchema({ enum: [...] })` 변형을 사용합니다.

### 2) BM25 유틸 추가 (`src/lib/search/bm25.ts`)

간단한 in-memory BM25 구현. 데이터셋이 작으므로 매 요청 시 인덱싱(초기 버전) → 후속 최적화에서 캐시 고려.

```ts
// src/lib/search/bm25.ts
// Minimal BM25 implementation for small corpora

export interface BM25Doc {
  id: string;
  // Combined text or field-wise tokens handled by caller
  tokens: string[];
  length?: number; // computed
}

export interface BM25IndexOptions {
  k1?: number; // default 1.5
  b?: number; // default 0.75
}

export class BM25Index {
  private docs: BM25Doc[] = [];
  private N = 0;
  private avgdl = 0;
  private df: Map<string, number> = new Map();
  private tf: Map<string, Map<string, number>> = new Map(); // term -> (docId -> tf)

  constructor(private readonly options: BM25IndexOptions = {}) {}

  addDocuments(docs: BM25Doc[]) {
    this.docs = docs.map((d) => ({ ...d, length: d.tokens.length }));
    this.N = this.docs.length;
    this.avgdl =
      this.docs.reduce((s, d) => s + (d.length || 0), 0) / Math.max(1, this.N);

    this.df.clear();
    this.tf.clear();

    for (const d of this.docs) {
      const tfPerDoc: Map<string, number> = new Map();
      for (const term of d.tokens) {
        tfPerDoc.set(term, (tfPerDoc.get(term) || 0) + 1);
      }
      // persist per-term maps
      for (const [term, freq] of tfPerDoc) {
        if (!this.tf.has(term)) this.tf.set(term, new Map());
        this.tf.get(term)!.set(d.id, freq);
        this.df.set(term, (this.df.get(term) || 0) + 1);
      }
    }
  }

  private idf(term: string) {
    const n = this.df.get(term) || 0;
    // BM25 idf with add-one smoothing flavor
    return Math.log(1 + (this.N - n + 0.5) / (n + 0.5));
  }

  score(queryTokens: string[]): Map<string, number> {
    const k1 = this.options.k1 ?? 1.5;
    const b = this.options.b ?? 0.75;
    const scores: Map<string, number> = new Map();

    const unique = Array.from(new Set(queryTokens));
    for (const term of unique) {
      const posting = this.tf.get(term);
      if (!posting) continue;
      const idf = this.idf(term);

      for (const [docId, tf] of posting) {
        const doc = this.docs.find((d) => d.id === docId);
        if (!doc || !doc.length) continue;
        const dl = doc.length;
        const denom = tf + k1 * (1 - b + b * (dl / this.avgdl));
        const s = idf * ((tf * (k1 + 1)) / Math.max(1e-9, denom));
        scores.set(docId, (scores.get(docId) || 0) + s);
      }
    }
    return scores;
  }
}

export function defaultTokenizer(text: string): string[] {
  return (text || '')
    .toLowerCase()
    .normalize('NFKC') // Unicode normalization for various character systems
    .split(/[\s\p{P}\p{S}]+/u) // Split by whitespace, punctuation, symbols (Unicode-aware)
    .filter((t) => t.length > 1); // Filter out single characters
}
```

### 3) server.ts 검색 로직 변경 + 리뷰 반영

핵심 변경점:

- 입력 타입 인터페이스 도입
- `search_server`에 BM25 적용(기본)
- 페이지네이션 `-1` 전체 반환
- 서버 조회 헬퍼 `findServer` 추가
- `disconnect_server` scope 검증 추가
- ID 생성: `crypto.randomUUID()` 우선 사용
- Transport 타입 가드 추가

```ts
// server.ts (snippets)
import { BM25Index, defaultTokenizer } from '@/lib/search/bm25';

// Input types
interface ListServersInput { page?: number; pageSize?: number; filterByAssistant?: boolean; includeInactive?: boolean; }
interface SearchServersInput {
  query: string; page?: number; pageSize?: number; searchMode?: 'bm25' | 'simple'; byNameOnly?: boolean; includeInactive?: boolean;
  weights?: { nameWeight?: number; descWeight?: number };
}
interface CreateServerInput { name: string; description?: string; transport: unknown; tags?: string[]; }
interface ConnectInput { serverId?: string; serverName?: string; scope?: 'assistant' | 'global'; autoStart?: boolean; }
interface DisconnectInput { serverId?: string; serverName?: string; scope?: 'assistant' | 'global'; }

// Transport type guards
interface StdioTransport { type: 'stdio'; command: string; args?: string[]; env?: Record<string,string>; }
interface HttpTransport { type: 'http'; url: string; headers?: Record<string,string>; }
function isStdioTransport(t: any): t is StdioTransport { return t && t.type === 'stdio' && typeof t.command === 'string'; }
function isHttpTransport(t: any): t is HttpTransport { return t && t.type === 'http' && typeof t.url === 'string'; }

private async findServer(serverId?: string, serverName?: string) {
  if (serverId) return await mcpServersCRUD.read(serverId);
  if (serverName) {
    const db = LocalDatabase.getInstance();
    return await db.mcpServers
      .filter((s) => s.name.toLowerCase() === serverName.toLowerCase())
      .first();
  }
  return null;
}

private normalizePagination<T>(items: T[], page: number, pageSize: number) {
  if (pageSize === -1) {
    return { items, page: 1, pageSize: items.length, totalPages: 1, totalItems: items.length };
  }
  // createPage helper 재사용 권장. 여기선 아이디어만 제시
  const totalItems = items.length;
  const start = Math.max(0, (page - 1) * pageSize);
  const slice = items.slice(start, start + pageSize);
  const totalPages = Math.max(1, Math.ceil(totalItems / Math.max(1, pageSize)));
  return { items: slice, page, pageSize, totalPages, totalItems };
}

private async createServer(args: CreateServerInput) {
  const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? `mcp-${crypto.randomUUID()}`
    : `mcp-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
  // transport guards
  if (!(isStdioTransport(args.transport) || isHttpTransport(args.transport))) {
    return createMCPTextResponse('Invalid transport configuration');
  }
  // ... build & upsert as before
}

private async disconnectServer(args: DisconnectInput) {
  const scope = args.scope ?? 'assistant';
  if (scope !== 'assistant' && scope !== 'global') {
    return createMCPTextResponse('Scope must be "assistant" or "global"');
  }
  // ... rest unchanged, uses findServer
}

private async searchServer(args: SearchServersInput) {
  const query = (args.query || '').trim();
  if (!query) return createMCPTextResponse('Search query is required');

  const db = LocalDatabase.getInstance();
  let servers = await db.mcpServers.toArray();
  if (!(args.includeInactive ?? true)) servers = servers.filter(s => s.isActive);

  const page = args.page ?? 1;
  const pageSize = args.pageSize ?? 20;
  const searchMode = args.searchMode ?? 'bm25';

  if (searchMode === 'simple') {
    const q = query.toLowerCase();
    const byNameOnly = args.byNameOnly ?? true;
    servers = servers.filter(s => {
      const nameMatch = s.name.toLowerCase().includes(q);
      if (byNameOnly) return nameMatch;
      const desc = s.metadata?.description?.toLowerCase() || '';
      return nameMatch || desc.includes(q) || (s.metadata?.tags||[]).some(t => t.toLowerCase().includes(q));
    });
    // improved relevance: exact > startsWith > contains, then alpha
    const scoreLevel = (name: string) => name === q ? 3 : name.startsWith(q) ? 2 : name.includes(q) ? 1 : 0;
    servers.sort((a,b)=>{
      const sa = scoreLevel(a.name.toLowerCase());
      const sb = scoreLevel(b.name.toLowerCase());
      if (sa !== sb) return sb - sa;
      return a.name.localeCompare(b.name);
    });

    const result = this.normalizePagination(servers, page, pageSize);
    return createMCPStructuredResponse(
      `🔍 Search Results for "${query}" (simple)`,
      { ...result, query }
    );
  }

  // BM25 mode (default)
  const nameW = args.weights?.nameWeight ?? 2.0;
  const descW = args.weights?.descWeight ?? 1.0;

  // Build BM25 docs with weighted tokens
  const docs = servers.map(s => {
    const nameTokens = defaultTokenizer(s.name);
    const descTokens = defaultTokenizer(s.metadata?.description || '');
    const tokens = [
      ...nameTokens.flatMap(t => Array(Math.max(1, Math.round(nameW))).fill(t)),
      ...descTokens.flatMap(t => Array(Math.max(1, Math.round(descW))).fill(t)),
    ];
    return { id: s.id, tokens };
  });

  const index = new BM25Index();
  index.addDocuments(docs);
  const qTokens = defaultTokenizer(query);
  const scores = index.score(qTokens);

  // sort by score desc, tie-breaker: name alpha
  servers.sort((a,b)=>{
    const sa = scores.get(a.id) || 0;
    const sb = scores.get(b.id) || 0;
    if (sa !== sb) return sb - sa;
    return a.name.localeCompare(b.name);
  });

  const result = this.normalizePagination(servers, page, pageSize);
  return createMCPStructuredResponse(
    `🔎 BM25 Results for "${query}" (name×${nameW}, desc×${descW})`,
    { ...result, query, mode: 'bm25' }
  );
}
```

### 4) list_servers 페이지네이션 보강

```ts
private async listServers(args: ListServersInput) {
  const page = args.page ?? 1;
  const pageSize = args.pageSize ?? 20;
  // ... collect servers then
  const result = this.normalizePagination(servers, page, pageSize);
  return createMCPStructuredResponse(summary, result);
}
```

## 재사용 가능한 연관 코드 (파일 경로, 주요 기능, 인터페이스 등)

- `src/lib/mcp-response-utils.ts`: text + structuredContent 응답 유틸
- `src/lib/mcp-types.ts`: JSON Schema helpers (enum 스키마 지원이 없으면 string+enum 옵션으로 대체)
- `src/lib/db/crud.ts`: mcpServersCRUD, assistantsCRUD, createPage
- `src/lib/logger.ts`: getLogger
- 참고 문서: `docs/3rd_party/bm25/bm25_crate.md` (개념 레퍼런스)

## Test Code 추가 및 수정 필요 부분

### 유닛 테스트 (`src/lib/web-mcp/modules/mcp-manager/__tests__/mcp-manager.test.ts`)

- BM25 랭킹 검증
  - name/description에 키워드가 분리 배치된 서버들 생성
  - 기본값(name 2.0, desc 1.0)에서 name 매칭 서버가 상위 랭크인지 확인
  - weights 조정(desc 3.0 등) 시 랭킹 역전 확인
- 페이지네이션 `-1` 동작
  - `search_server`/`list_servers` 모두에서 전체 반환 확인
- scope 검증
  - `disconnect_server`의 잘못된 scope 입력 시 에러 메시지 확인
- 타입/가드
  - invalid transport 입력 시 오류 응답
- 서버 조회 헬퍼
  - `serverId`/`serverName` 각각으로 조회 성공/실패 케이스

예시 스니핏:

```ts
it('bm25 ranks name match above description by default', async () => {
  // create two servers: one name matches, one description matches
  // call search_server with query and assert order
});

it('pageSize -1 returns all items', async () => {
  const res = await mcpManagerServer.callTool('search_server', {
    query: 'x',
    pageSize: -1,
  });
  const data = res.result!.structuredContent as { items: any[] };
  expect(data.items.length).toBe(totalCreated);
});
```

### 통합 테스트 시나리오

1. 서버 여러 개 생성 → 2) BM25 검색 확인 → 3) weights로 랭킹 변경 → 4) assistant에 connect → 5) `filterByAssistant`로 확인 → 6) disconnect + scope 검증

## Clarification Q-list

1. 기본 검색 모드
   - 기본을 BM25로 설정해도 될까요? (제안: 기본 BM25, 옵션으로 simple 유지)
2. 토크나이저 및 불용어(stopwords)
   - 현재는 단순 토큰화(영문/숫자/한글 유지). 불용어 제거가 필요할까요?
3. 필드 가중치 기본값
   - 제안: name 2.0, description 1.0. 조정 필요 시 설정으로 노출?
4. 인덱스 캐시
   - 현재 호출 시 마다 인덱싱. 데이터가 커지면 캐시/증분 업데이트가 필요합니다. P1로 미룰까요?
5. Rust 백엔드 연동
   - BM25를 Rust로 이전하여 대규모 데이터에 대비할 계획이 있을까요? 현재는 Web実装으로 충분해 보입니다.

## 완료 판정 기준

- 모든 변경사항 반영 후 `pnpm refactor:validate` PASS (Build/Lint/Type/Dead-code 포함)
- 도구 응답(텍스트+구조화) 일관성 유지
- BM25 검색 결과가 테스트 기준(가중치/랭킹) 충족
- 페이지네이션 `-1` 및 scope 검증 등 리뷰 반영 항목 모두 테스트로 보증


---

# refactoring_20251029_2340.md

# MCP Configuration Migration to Comprehensive Format

**Date**: 2025-10-29  
**Author**: AI Assistant + fritzprix  
**Status**: Planning Complete - Ready for Implementation

---

## 작업의 목적

LibrAgent의 MCP 서버 설정을 stdio 전용 레거시 포맷에서 **MCP 공식 스펙 (2025-06-18)** 을 완벽히 준수하는 포괄적인 포맷으로 마이그레이션하여, HTTP/SSE transport와 OAuth 2.1 기반 인증을 지원하는 원격 MCP 서버 연동을 가능하게 한다.

### 핵심 목표

1. **Transport 확장**: stdio → stdio + HTTP + SSE (Streamable HTTP)
2. **인증 지원**: 없음 → OAuth 2.1 with PKCE
3. **보안 강화**: 환경변수 API 키 → OS keychain + encrypted storage
4. **사용자 경험**: 수동 설정 → 자동 discovery + dynamic registration
5. **Backward Compatibility**: 기존 stdio 설정 100% 유지 보장

---

## 현재의 상태 / 문제점

### 1. 타입 정의 한계

#### TypeScript (src/models/chat.ts)

```typescript
export interface MCPConfig {
  mcpServers?: Record<
    string,
    {
      command: string;
      args?: string[];
      env?: Record<string, string>;
    }
  >;
}
```

#### Rust (src-tauri/src/mcp/types.rs)

```rust
pub struct MCPServerConfig {
    pub name: String,
    pub command: String,
    pub args: Vec<String>,
    pub env: HashMap<String, String>,
    pub transport: String, // 항상 "stdio"
    pub url: Option<String>, // 미사용
    pub port: Option<u16>, // 미사용
}
```

**문제점**:

- HTTP/SSE transport 설정 불가
- OAuth 인증 정보 저장 불가
- Protocol version 협상 불가
- Session management 불가

### 2. 보안 취약점

### 현재 방식: Assistant 정의에 API 키 하드코딩

```typescript
const assistant: Assistant = {
  systemPrompt: '...',
  mcpConfig: {
    mcpServers: {
      'remote-server': {
        command: 'npx',
        args: ['-y', '@modelcontextprotocol/server-example'],
        env: {
          API_KEY: 'sk-1234567890abcdef', // ❌ 평문 저장
        },
      },
    },
  },
};
```

**문제점**:

- IndexedDB에 평문 저장 (브라우저 DevTools로 접근 가능)
- 사용자별 인증 관리 불가
- Token refresh 메커니즘 없음

### 3. MCP 스펙 불일치

| MCP 스펙 요구사항              | 현재 구현 | 갭                               |
| ------------------------------ | --------- | -------------------------------- |
| Streamable HTTP Transport      | ❌ 미지원 | POST/GET/DELETE 핸들러 필요      |
| SSE (deprecated but supported) | ❌ 미지원 | Backward compatibility 위해 필요 |
| `MCP-Protocol-Version` 헤더    | ❌ 미지원 | 모든 HTTP 요청에 필수            |
| `Mcp-Session-Id` 헤더          | ❌ 미지원 | Stateful 통신 필수               |
| OAuth 2.1 with PKCE            | ❌ 미지원 | 원격 서버 인증 필수              |
| RFC 8414 Discovery             | ❌ 미지원 | 자동 엔드포인트 발견             |
| DNS Rebinding Protection       | ❌ 미지원 | 로컬 서버 보안 필수              |

---

## 관련 코드의 구조 및 동작 방식 (Bird's Eye View)

### 아키텍처 다이어그램

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (React + TypeScript)            │
├─────────────────────────────────────────────────────────────┤
│  MCPServerContext.tsx                                       │
│  ├─ connectServers(mcpConfig)  ← MCPConfig (stdio only)    │
│  ├─ executeToolCall(toolCall)                              │
│  └─ Tool Aliasing: ${serverAlias}__${toolName}            │
├─────────────────────────────────────────────────────────────┤
│  useRustBackend Hook                                        │
│  └─ safeInvoke() → Tauri Command Wrapper                   │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Tauri Backend (Rust)                           │
├─────────────────────────────────────────────────────────────┤
│  commands/mcp_commands.rs                                   │
│  ├─ list_tools_from_config(config: MCPServerConfig)        │
│  └─ start_mcp_server(config: MCPServerConfig)              │
├─────────────────────────────────────────────────────────────┤
│  mcp/server.rs: MCPServerManager                            │
│  ├─ Global State: Mutex<HashMap<ServerAlias, Connection>>  │
│  ├─ start_stdio_server() ✅ 구현 완료                       │
│  ├─ start_http_server() ❌ 스텁                             │
│  └─ start_sse_server() ❌ 스텁                              │
├─────────────────────────────────────────────────────────────┤
│  mcp/types.rs: MCPServerConfig                              │
│  └─ stdio 전용 필드만 사용                                   │
├─────────────────────────────────────────────────────────────┤
│  External Dependency                                         │
│  └─ rmcp (Rust MCP Client Library)                          │
│     └─ TokioChildProcess transport (stdio only)            │
└─────────────────────────────────────────────────────────────┘
```

### 핵심 데이터 흐름

1. **사용자 액션**: Settings에서 Assistant + MCP 서버 설정
2. **저장**: IndexedDB에 `Assistant` 객체 저장 (mcpConfig 포함)
3. **연결 시도**: Chat 페이지에서 `MCPServerContext.connectServers()` 호출
4. **Rust 호출**: `start_mcp_server` Tauri command 실행
5. **프로세스 생성**: `MCPServerManager::start_stdio_server()` → 자식 프로세스 spawn
6. **RMCP 연결**: `rmcp::RunningService` 생성, stdin/stdout 통신
7. **도구 목록**: `list_tools` JSON-RPC 호출 → React state 업데이트
8. **도구 실행**: `executeToolCall()` → `call_tool` JSON-RPC → 결과 반환

---

## 변경 이후의 상태 / 해결 판정 기준

### 성공 기준 (Acceptance Criteria)

#### 1. Backward Compatibility (필수)

- [ ] 기존 stdio 설정이 수정 없이 작동
- [ ] 레거시 `MCPServerConfig` JSON이 자동으로 `MCPServerConfigV2`로 변환
- [ ] 기존 Assistant의 `mcpConfig` 필드 호환성 유지

#### 2. HTTP Transport (필수)

- [ ] HTTP POST `/mcp` 엔드포인트로 JSON-RPC 요청 가능
- [ ] `MCP-Protocol-Version: 2025-06-18` 헤더 자동 추가
- [ ] `Mcp-Session-Id` 헤더로 stateful 통신 지원
- [ ] 최소 1개 공개 MCP 서버 (예: Brave Search) 연동 성공

#### 3. OAuth 인증 (필수)

- [ ] OAuth 2.1 Authorization Code Grant with PKCE 구현
- [ ] RFC 8414 메타데이터 discovery 지원
- [ ] Access token OS keychain 저장
- [ ] Token refresh 자동 처리

#### 4. 보안 (필수)

- [ ] API 키/토큰 평문 저장 제거
- [ ] DNS rebinding protection 활성화 (로컬 서버)
- [ ] CORS Origin 검증 (원격 서버)

#### 5. 사용자 경험 (권장)

- [ ] Settings UI에서 HTTP/OAuth 서버 추가 가능
- [ ] OAuth 플로우 웹뷰 또는 시스템 브라우저 통합
- [ ] 연결 상태 실시간 피드백

---

## 수정이 필요한 코드 및 코드 스니펫

### Phase 0: 타입 정의 수정

#### 1. TypeScript 타입 (src/models/chat.ts)

**수정 전**:

```typescript
export interface MCPConfig {
  mcpServers?: Record<
    string,
    {
      command: string;
      args?: string[];
      env?: Record<string, string>;
    }
  >;
}
```

**수정 후**:

```typescript
// Discriminated union for transport-specific configs
export type TransportConfig =
  | {
      type: 'stdio';
      command: string;
      args?: string[];
      env?: Record<string, string>;
    }
  | {
      type: 'http';
      url: string;
      protocolVersion?: string; // Default: "2025-06-18"
      sessionId?: string;
      headers?: Record<string, string>;
      enableSSE?: boolean; // For backward compatibility
      security?: {
        enableDnsRebindingProtection?: boolean;
        allowedOrigins?: string[];
        allowedHosts?: string[];
      };
    };

export interface OAuthConfig {
  type: 'oauth2.1';
  discoveryUrl?: string; // RFC 8414
  authorizationEndpoint?: string; // Fallback
  tokenEndpoint?: string;
  registrationEndpoint?: string; // RFC 7591
  clientId?: string;
  redirectUri?: string;
  scopes?: string[];
  usePKCE: boolean; // Default: true
  resourceParameter?: string; // RFC 9728
}

export interface MCPServerConfigV2 {
  name: string;
  transport: TransportConfig;
  authentication?: OAuthConfig;
  metadata?: {
    description?: string;
    vendor?: string;
    version?: string;
  };
}

export interface MCPConfig {
  mcpServers?: Record<string, MCPServerConfigV2>;
}

// Legacy type alias for backward compatibility
export type LegacyMCPServerConfig = {
  command: string;
  args?: string[];
  env?: Record<string, string>;
};
```

#### 2. Rust 타입 (src-tauri/src/mcp/types.rs)

**추가**:

```rust
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "lowercase")]
pub enum TransportConfig {
    Stdio {
        command: String,
        args: Vec<String>,
        #[serde(default)]
        env: HashMap<String, String>,
    },
    Http {
        url: String,
        #[serde(default = "default_protocol_version")]
        protocol_version: String,
        #[serde(skip_serializing_if = "Option::is_none")]
        session_id: Option<String>,
        #[serde(skip_serializing_if = "Option::is_none")]
        headers: Option<HashMap<String, String>>,
        #[serde(skip_serializing_if = "Option::is_none")]
        enable_sse: Option<bool>,
        #[serde(skip_serializing_if = "Option::is_none")]
        security: Option<SecurityConfig>,
    },
}

fn default_protocol_version() -> String {
    "2025-06-18".to_string()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityConfig {
    #[serde(default)]
    pub enable_dns_rebinding_protection: bool,
    #[serde(default)]
    pub allowed_origins: Vec<String>,
    #[serde(default)]
    pub allowed_hosts: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OAuthConfig {
    #[serde(rename = "type")]
    pub oauth_type: String, // "oauth2.1"
    pub discovery_url: Option<String>,
    pub authorization_endpoint: Option<String>,
    pub token_endpoint: Option<String>,
    pub registration_endpoint: Option<String>,
    pub client_id: Option<String>,
    pub redirect_uri: Option<String>,
    pub scopes: Option<Vec<String>>,
    #[serde(default = "default_use_pkce")]
    pub use_pkce: bool,
    pub resource_parameter: Option<String>,
}

fn default_use_pkce() -> bool {
    true
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MCPServerConfigV2 {
    pub name: String,
    pub transport: TransportConfig,
    pub authentication: Option<OAuthConfig>,
    pub metadata: Option<ServerMetadata>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerMetadata {
    pub description: Option<String>,
    pub vendor: Option<String>,
    pub version: Option<String>,
}

// Wrapper for auto-detection
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum MCPServerConfigWrapper {
    V2(MCPServerConfigV2),
    Legacy(MCPServerConfig),
}

// Auto-conversion trait
impl From<MCPServerConfig> for MCPServerConfigV2 {
    fn from(legacy: MCPServerConfig) -> Self {
        MCPServerConfigV2 {
            name: legacy.name,
            transport: TransportConfig::Stdio {
                command: legacy.command,
                args: legacy.args,
                env: legacy.env,
            },
            authentication: None,
            metadata: None,
        }
    }
}

impl From<MCPServerConfigWrapper> for MCPServerConfigV2 {
    fn from(wrapper: MCPServerConfigWrapper) -> Self {
        match wrapper {
            MCPServerConfigWrapper::V2(v2) => v2,
            MCPServerConfigWrapper::Legacy(legacy) => legacy.into(),
        }
    }
}
```

### Phase 1: Command Handlers 수정

#### src-tauri/src/commands/mcp_commands.rs

**수정 필요 함수**:

```rust
#[tauri::command]
pub async fn list_tools_from_config(
    config_wrapper: MCPServerConfigWrapper, // ← 변경
) -> Result<Vec<ToolInfo>, String> {
    let config: MCPServerConfigV2 = config_wrapper.into(); // ← 자동 변환

    match &config.transport {
        TransportConfig::Stdio { command, args, env } => {
            // 기존 로직 유지
        }
        TransportConfig::Http { url, protocol_version, .. } => {
            // HTTP transport 로직 추가
            list_tools_from_http(url, protocol_version, &config.authentication).await
        }
    }
}

async fn list_tools_from_http(
    url: &str,
    protocol_version: &str,
    auth: &Option<OAuthConfig>,
) -> Result<Vec<ToolInfo>, String> {
    let client = reqwest::Client::new();
    let mut headers = reqwest::header::HeaderMap::new();

    // Add required headers
    headers.insert(
        "MCP-Protocol-Version",
        protocol_version.parse().unwrap(),
    );

    // Add authorization if available
    if let Some(oauth) = auth {
        if let Some(token) = get_cached_token(&oauth).await? {
            headers.insert(
                reqwest::header::AUTHORIZATION,
                format!("Bearer {}", token).parse().unwrap(),
            );
        }
    }

    // Send JSON-RPC request
    let response = client
        .post(url)
        .headers(headers)
        .json(&json!({
            "jsonrpc": "2.0",
            "method": "tools/list",
            "id": 1
        }))
        .send()
        .await
        .map_err(|e| e.to_string())?;

    // Parse response
    // ...
}
```

### Phase 2: OAuth Flow 구현

#### src-tauri/src/mcp/oauth.rs (신규 파일)

```rust
use oauth2::{
    AuthorizationCode, ClientId, CsrfToken, PkceCodeChallenge, PkceCodeVerifier,
    RedirectUrl, Scope, TokenResponse,
};
use oauth2::basic::BasicClient;
use oauth2::reqwest::async_http_client;
use tauri::Manager;

pub struct OAuthManager {
    pkce_verifiers: Arc<Mutex<HashMap<String, PkceCodeVerifier>>>,
}

impl OAuthManager {
    pub async fn start_authorization_flow(
        &self,
        config: &OAuthConfig,
        server_id: &str,
    ) -> Result<String, String> {
        // 1. Discover endpoints (RFC 8414)
        let endpoints = if let Some(discovery_url) = &config.discovery_url {
            discover_endpoints(discovery_url).await?
        } else {
            // Use fallback endpoints
            OAuthEndpoints {
                authorization_endpoint: config.authorization_endpoint.clone().unwrap(),
                token_endpoint: config.token_endpoint.clone().unwrap(),
            }
        };

        // 2. Create PKCE challenge
        let (pkce_challenge, pkce_verifier) = PkceCodeChallenge::new_random_sha256();
        self.pkce_verifiers.lock().unwrap().insert(server_id.to_string(), pkce_verifier);

        // 3. Build authorization URL
        let client = BasicClient::new(
            ClientId::new(config.client_id.clone().unwrap()),
            None,
            AuthUrl::new(endpoints.authorization_endpoint)?,
            Some(TokenUrl::new(endpoints.token_endpoint)?),
        )
        .set_redirect_uri(RedirectUrl::new(config.redirect_uri.clone().unwrap())?);

        let (authorize_url, csrf_state) = client
            .authorize_url(CsrfToken::new_random)
            .add_scopes(config.scopes.iter().map(|s| Scope::new(s.clone())))
            .set_pkce_challenge(pkce_challenge)
            .url();

        // 4. Return URL for frontend to open
        Ok(authorize_url.to_string())
    }

    pub async fn exchange_code_for_token(
        &self,
        config: &OAuthConfig,
        server_id: &str,
        authorization_code: &str,
    ) -> Result<String, String> {
        // Retrieve PKCE verifier
        let verifier = self.pkce_verifiers.lock().unwrap()
            .remove(server_id)
            .ok_or("PKCE verifier not found")?;

        // Exchange code for token
        let client = /* ... */;
        let token_result = client
            .exchange_code(AuthorizationCode::new(authorization_code.to_string()))
            .set_pkce_verifier(verifier)
            .request_async(async_http_client)
            .await
            .map_err(|e| e.to_string())?;

        let access_token = token_result.access_token().secret().clone();

        // Store in OS keychain
        store_token_securely(server_id, &access_token).await?;

        Ok(access_token)
    }
}

async fn discover_endpoints(discovery_url: &str) -> Result<OAuthEndpoints, String> {
    let client = reqwest::Client::new();
    let metadata: AuthServerMetadata = client
        .get(discovery_url)
        .send()
        .await
        .map_err(|e| e.to_string())?
        .json()
        .await
        .map_err(|e| e.to_string())?;

    Ok(OAuthEndpoints {
        authorization_endpoint: metadata.authorization_endpoint,
        token_endpoint: metadata.token_endpoint,
    })
}
```

### Phase 3: Token Storage (OS Keychain)

#### Cargo.toml 추가

```toml
[dependencies]
keyring = "2.0"
```

#### src-tauri/src/mcp/keychain.rs (신규 파일)

```rust
use keyring::Entry;

const SERVICE_NAME: &str = "com.libr-agent.mcp";

pub async fn store_token_securely(server_id: &str, token: &str) -> Result<(), String> {
    let entry = Entry::new(SERVICE_NAME, server_id)
        .map_err(|e| format!("Failed to create keychain entry: {}", e))?;

    entry.set_password(token)
        .map_err(|e| format!("Failed to store token: {}", e))?;

    Ok(())
}

pub async fn get_cached_token(server_id: &str) -> Result<Option<String>, String> {
    let entry = Entry::new(SERVICE_NAME, server_id)
        .map_err(|e| format!("Failed to create keychain entry: {}", e))?;

    match entry.get_password() {
        Ok(token) => Ok(Some(token)),
        Err(keyring::Error::NoEntry) => Ok(None),
        Err(e) => Err(format!("Failed to retrieve token: {}", e)),
    }
}

pub async fn delete_token(server_id: &str) -> Result<(), String> {
    let entry = Entry::new(SERVICE_NAME, server_id)
        .map_err(|e| format!("Failed to create keychain entry: {}", e))?;

    entry.delete_password()
        .map_err(|e| format!("Failed to delete token: {}", e))?;

    Ok(())
}
```

### Phase 4: HTTP Transport 구현

#### src-tauri/src/mcp/http_transport.rs (신규 파일)

```rust
use reqwest::{Client, Response};
use serde_json::{json, Value};
use std::sync::Arc;
use tokio::sync::Mutex;

pub struct HttpTransport {
    client: Client,
    base_url: String,
    protocol_version: String,
    session_id: Option<String>,
    headers: HeaderMap,
}

impl HttpTransport {
    pub fn new(config: &HttpConfig, auth_token: Option<String>) -> Self {
        let mut headers = HeaderMap::new();

        // Add protocol version header
        headers.insert(
            "MCP-Protocol-Version",
            config.protocol_version.parse().unwrap(),
        );

        // Add authorization header if available
        if let Some(token) = auth_token {
            headers.insert(
                AUTHORIZATION,
                format!("Bearer {}", token).parse().unwrap(),
            );
        }

        // Add custom headers
        if let Some(custom_headers) = &config.headers {
            for (key, value) in custom_headers {
                headers.insert(
                    key.parse().unwrap(),
                    value.parse().unwrap(),
                );
            }
        }

        Self {
            client: Client::new(),
            base_url: config.url.clone(),
            protocol_version: config.protocol_version.clone(),
            session_id: config.session_id.clone(),
            headers,
        }
    }

    pub async fn send_request(&mut self, method: &str, params: Value) -> Result<Value, String> {
        let mut request_headers = self.headers.clone();

        // Add session ID if available
        if let Some(session_id) = &self.session_id {
            request_headers.insert(
                "Mcp-Session-Id",
                session_id.parse().unwrap(),
            );
        }

        let request_body = json!({
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": generate_request_id(),
        });

        let response = self.client
            .post(&self.base_url)
            .headers(request_headers)
            .json(&request_body)
            .send()
            .await
            .map_err(|e| e.to_string())?;

        // Extract session ID from response if present
        if let Some(session_id) = response.headers().get("Mcp-Session-Id") {
            self.session_id = Some(session_id.to_str().unwrap().to_string());
        }

        let response_json: Value = response.json().await.map_err(|e| e.to_string())?;

        if let Some(error) = response_json.get("error") {
            return Err(format!("JSON-RPC error: {}", error));
        }

        response_json.get("result")
            .cloned()
            .ok_or_else(|| "No result in response".to_string())
    }
}
```

### Phase 5: Frontend 수정

#### src/context/MCPServerContext.tsx

**수정 부분**:

```typescript
const connectServers = async (mcpConfig: MCPConfig) => {
  if (!mcpConfig.mcpServers) return;

  for (const [alias, serverConfig] of Object.entries(mcpConfig.mcpServers)) {
    try {
      // Check if OAuth is required
      if (serverConfig.authentication?.type === 'oauth2.1') {
        // Check for cached token
        const hasToken = await checkCachedToken(alias);

        if (!hasToken) {
          // Start OAuth flow
          const authUrl = await invokeRust('start_oauth_flow', {
            serverId: alias,
            config: serverConfig.authentication,
          });

          // Open system browser or webview
          await open(authUrl);

          // Wait for callback (implement deep link handling)
          await waitForOAuthCallback(alias);
        }
      }

      // Start MCP server connection
      const tools = await invokeRust('list_tools_from_config', {
        configWrapper: serverConfig, // Auto-converts V1 → V2
      });

      // Store tools with alias prefix
      setAvailableTools((prev) => ({
        ...prev,
        ...tools.reduce((acc, tool) => {
          acc[`${alias}__${tool.name}`] = tool;
          return acc;
        }, {}),
      }));
    } catch (error) {
      logger.error(`Failed to connect to ${alias}`, error);
    }
  }
};
```

---

## 재사용 가능한 연관 코드

### 기존 stdio Transport (유지)

**파일**: `src-tauri/src/mcp/server.rs`  
**함수**: `MCPServerManager::start_stdio_server()`  
**용도**: stdio transport는 그대로 유지, 새로운 HTTP/SSE transport와 병행 사용

### RMCP 라이브러리

**Crate**: `rmcp = "0.2.1"`  
**용도**: JSON-RPC 메시지 직렬화/역직렬화, stdio transport 지원  
**제약**: HTTP transport 미지원 → 직접 구현 필요

### Tauri 보안 API

**Plugin**: `tauri-plugin-secure-store` (검토 필요)  
**대안**: `keyring` crate로 OS keychain 직접 접근

### OAuth 2.1 라이브러리

**Crate**: `oauth2 = "4.4"`  
**기능**: Authorization Code Grant, PKCE, Token exchange  
**참고**: [oauth2-rs documentation](https://docs.rs/oauth2/latest/oauth2/)

### HTTP Client

**Crate**: `reqwest = "0.11"` (이미 프로젝트에 포함)  
**용도**: HTTP/HTTPS 요청, JSON 직렬화

---

## Test Code 추가 및 수정 가이드

### Unit Tests

#### 1. 타입 변환 테스트 (Rust)

**파일**: `src-tauri/src/mcp/types.rs`

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_legacy_to_v2_conversion() {
        let legacy = MCPServerConfig {
            name: "test-server".to_string(),
            command: "node".to_string(),
            args: vec!["server.js".to_string()],
            env: HashMap::new(),
            transport: "stdio".to_string(),
            url: None,
            port: None,
        };

        let v2: MCPServerConfigV2 = legacy.into();

        assert_eq!(v2.name, "test-server");
        match v2.transport {
            TransportConfig::Stdio { command, .. } => {
                assert_eq!(command, "node");
            }
            _ => panic!("Expected Stdio transport"),
        }
    }

    #[test]
    fn test_wrapper_deserialize_v2() {
        let json = r#"{
            "name": "http-server",
            "transport": {
                "type": "http",
                "url": "https://api.example.com/mcp",
                "protocol_version": "2025-06-18"
            }
        }"#;

        let wrapper: MCPServerConfigWrapper = serde_json::from_str(json).unwrap();
        let v2: MCPServerConfigV2 = wrapper.into();

        assert_eq!(v2.name, "http-server");
    }

    #[test]
    fn test_wrapper_deserialize_legacy() {
        let json = r#"{
            "name": "legacy-server",
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-example"],
            "env": {},
            "transport": "stdio"
        }"#;

        let wrapper: MCPServerConfigWrapper = serde_json::from_str(json).unwrap();
        let v2: MCPServerConfigV2 = wrapper.into();

        assert_eq!(v2.name, "legacy-server");
    }
}
```

#### 2. HTTP Transport 테스트 (Rust)

**파일**: `src-tauri/src/mcp/http_transport.rs`

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use wiremock::{MockServer, Mock, ResponseTemplate};
    use wiremock::matchers::{method, path, header};

    #[tokio::test]
    async fn test_http_transport_list_tools() {
        let mock_server = MockServer::start().await;

        Mock::given(method("POST"))
            .and(path("/mcp"))
            .and(header("MCP-Protocol-Version", "2025-06-18"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "jsonrpc": "2.0",
                "result": {
                    "tools": [
                        {"name": "test-tool", "description": "A test tool"}
                    ]
                },
                "id": 1
            })))
            .mount(&mock_server)
            .await;

        let config = HttpConfig {
            url: mock_server.uri(),
            protocol_version: "2025-06-18".to_string(),
            session_id: None,
            headers: None,
            enable_sse: None,
            security: None,
        };

        let mut transport = HttpTransport::new(&config, None);
        let result = transport.send_request("tools/list", json!({})).await;

        assert!(result.is_ok());
    }
}
```

### Integration Tests

#### 3. OAuth Flow 테스트

**파일**: `src-tauri/tests/oauth_integration_test.rs`

```rust
#[tokio::test]
async fn test_oauth_authorization_flow() {
    // Mock OAuth server
    let mock_server = MockServer::start().await;

    // Test discovery
    // Test authorization URL generation
    // Test token exchange
    // Test token storage
}
```

### Frontend Tests

#### 4. MCPServerContext 테스트

**파일**: `src/context/__tests__/MCPServerContext.test.tsx`

```typescript
import { renderHook, act } from '@testing-library/react';
import { useMCPServer } from '../MCPServerContext';

describe('MCPServerContext', () => {
  it('should handle legacy stdio config', async () => {
    const { result } = renderHook(() => useMCPServer());

    await act(async () => {
      await result.current.connectServers({
        mcpServers: {
          'legacy-server': {
            command: 'node',
            args: ['server.js'],
            env: {},
          },
        },
      });
    });

    expect(result.current.connectedServers).toContain('legacy-server');
  });

  it('should handle HTTP config with OAuth', async () => {
    // Test HTTP transport connection
    // Test OAuth flow triggering
  });
});
```

---

## 추가 분석 과제

### 1. RMCP HTTP Transport 지원 조사 (우선순위: 높)

**목적**: `rmcp` crate가 HTTP transport를 지원하는지 확인, 지원하지 않으면 대안 검토

**방법**:

```bash
# RMCP 소스코드 확인
git clone https://github.com/modelcontextprotocol/rmcp
cd rmcp
grep -r "http" src/
grep -r "HttpTransport" src/
```

**결과에 따른 대응**:

- 지원함: RMCP API 사용
- 지원 안 함: 직접 구현 (위의 `http_transport.rs` 사용)

### 2. Tauri Deep Link 설정 (우선순위: 중)

**목적**: OAuth callback을 위한 custom URL scheme 등록 (`libr-agent://oauth/callback`)

**참고**:

- [Tauri Deep Links Plugin](https://v2.tauri.app/plugin/deep-link/)
- macOS: Info.plist에 URL scheme 추가
- Windows: Registry에 URL protocol 등록
- Linux: .desktop 파일 수정

### 3. MCP 공개 서버 목록 조사 (우선순위: 낮)

**목적**: 테스트 및 데모용 공개 MCP 서버 확인

**후보**:

- Brave Search MCP (검색 도구)
- GitHub MCP (리포지토리 접근)
- Notion MCP (노트 연동)

**조사 항목**:

- OAuth 지원 여부
- API 키 발급 방법
- Rate limiting 정책

### 4. 보안 감사 (우선순위: 높)

**검토 항목**:

- [ ] Token 저장: OS keychain 사용 확인
- [ ] HTTPS 강제: 원격 서버는 HTTPS만 허용
- [ ] CORS 설정: Origin 검증 로직 확인
- [ ] PKCE 구현: Code verifier entropy 충분성
- [ ] Token refresh: Refresh token rotation 구현

---

## 구현 일정

| Phase     | 작업 내용                  | 예상 소요 시간 | 담당자 | 시작일 | 완료일 |
| --------- | -------------------------- | -------------- | ------ | ------ | ------ |
| Phase 0   | 타입 정의 수정 (TS + Rust) | 1일            | TBD    |        |        |
| Phase 1   | Command handlers 수정      | 2일            | TBD    |        |        |
| Phase 2   | OAuth 플로우 구현          | 2-3일          | TBD    |        |        |
| Phase 3   | OS Keychain 통합           | 1일            | TBD    |        |        |
| Phase 4   | HTTP Transport 구현        | 2-3일          | TBD    |        |        |
| Phase 5   | Frontend 수정 + UI         | 2일            | TBD    |        |        |
| Testing   | Unit + Integration tests   | 2일            | TBD    |        |        |
| QA        | 전체 기능 테스트           | 1일            | TBD    |        |        |
| **Total** |                            | **13-16일**    |        |        |        |

---

## 롤백 계획

### 위험 요소

1. **HTTP Transport 버그**: JSON-RPC 프로토콜 불일치
2. **OAuth 플로우 실패**: 브라우저 통합 문제
3. **Token 저장 실패**: OS keychain 권한 문제

### 롤백 절차

1. **Feature Flag 사용**:

   ```rust
   #[cfg(feature = "http-transport")]
   mod http_transport;
   ```

2. **Gradual Rollout**:
   - Week 1: stdio만 지원 (기존 동작)
   - Week 2: stdio + HTTP (beta 테스터)
   - Week 3: 전체 배포

3. **Backward Compatibility 보장**:
   - 기존 설정 파일 자동 변환
   - 변환 실패 시 경고 + stdio fallback

---

## 참고 자료

### MCP 공식 문서

- [MCP Specification 2025-06-18](https://modelcontextprotocol.io/specification/2025-06-18/)
- [Streamable HTTP Transport](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports)
- [OAuth 2.1 Integration](https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization)

### RFC 표준

- [RFC 8414: OAuth 2.0 Authorization Server Metadata](https://www.rfc-editor.org/rfc/rfc8414.html)
- [RFC 7591: OAuth 2.0 Dynamic Client Registration](https://www.rfc-editor.org/rfc/rfc7591.html)
- [RFC 7636: PKCE](https://www.rfc-editor.org/rfc/rfc7636.html)
- [RFC 9728: Protected Resource Metadata](https://datatracker.ietf.org/doc/html/rfc9728)

### 구현 참고

- [TypeScript SDK](https://github.com/modelcontextprotocol/typescript-sdk)
- [Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [oauth2-rs Documentation](https://docs.rs/oauth2/latest/oauth2/)

---

## 승인 체크리스트

- [ ] 설계 리뷰 완료
- [ ] 보안 감사 완료
- [ ] 테스트 계획 승인
- [ ] 일정 확정
- [ ] 담당자 할당

**Reviewer**: **\*\*\*\***\_**\*\*\*\***  
**Date**: **\*\*\*\***\_**\*\*\*\***  
**Signature**: **\*\*\*\***\_**\*\*\*\***


---

# refactoring_20251026_2258.md

# SQLite 통합 및 Repository 패턴 적용 리팩토링

**작성일**: 2025-10-26 22:58  
**대상**: SQLite 의존성 중앙화 및 데이터 레이어 재구조화  
**예상 기간**: 5주

---

## 1. 작업의 목적

### 1.1 핵심 목표

현재 프로젝트 전반에 분산되어 있는 SQLite 관련 코드를 중앙화하고, Repository 패턴을 도입하여 데이터 계층을 명확히 분리한다.

### 1.2 달성하고자 하는 것

- **중앙화된 데이터베이스 관리**: 모든 SQL 쿼리와 스키마를 한 곳에서 관리
- **마이그레이션 시스템**: 스키마 버전 관리 및 자동 마이그레이션
- **재사용 가능한 Repository**: 여러 command에서 공통으로 사용할 수 있는 데이터 접근 계층
- **테스트 용이성**: Repository를 Mock으로 대체 가능한 구조
- **트랜잭션 지원**: 복잡한 데이터 변경 작업에 대한 원자성 보장
- **MCP 활성화 지원**: 향후 MCP Server 활성화 기능 추가를 위한 확장성

---

## 2. 현재의 상태 / 문제점

### 2.1 SQLite 의존성 분포 현황

```text
현재 SQLite를 사용하는 모듈:
├── src-tauri/src/lib.rs                          # Pool 초기화
├── src-tauri/src/state.rs                        # Global pool 저장
├── src-tauri/src/commands/
│   ├── messages_commands.rs                      # messages, message_index_meta 테이블
│   ├── content_store_commands.rs                 # DELETE 쿼리
│   └── session_commands.rs                       # DELETE 쿼리
└── src-tauri/src/mcp/builtin/content_store/
    └── storage.rs                                # stores, contents, chunks 테이블
```

### 2.2 구체적 문제점

#### 문제 1: SQL 쿼리 분산

- `messages_commands.rs`: 10+ 함수에 SQL embedded
- `content_store/storage.rs`: 15+ 메서드에 SQL embedded
- 스키마 변경 시 여러 파일 수정 필요

#### 문제 2: 마이그레이션 부재

- 각 모듈에서 `CREATE TABLE IF NOT EXISTS` 직접 실행
- 스키마 버전 관리 불가
- 데이터베이스 업그레이드 전략 없음

#### 문제 3: 트랜잭션 관리 어려움

- Content + Chunks 저장 시 원자성 보장 어려움
- 여러 테이블 간 일관성 유지 복잡

#### 문제 4: 테스트 어려움

- SQL 로직이 command에 직접 embedded
- Mock/Stub 적용 불가
- 통합 테스트만 가능

#### 문제 5: 코드 중복

- CRUD 패턴이 여러 곳에 반복
- 에러 처리 로직 중복
- Pool 접근 방식 일관성 부족

---

## 3. 관련 코드의 구조 및 동작 방식 Summary

### 3.1 현재 데이터 흐름 (Bird's Eye View)

```
Frontend (TypeScript)
    ↓ Tauri Command
Commands Layer
├─ messages_commands.rs
│  ├─ pub mod db { ... }        # SQL 직접 작성
│  ├─ get_sqlite_pool()         # Global pool 접근
│  └─ sqlx::query(...)          # 쿼리 실행
│
├─ content_store_commands.rs
│  └─ sqlx::query("DELETE...")  # 직접 쿼리
│
└─ session_commands.rs
   └─ sqlx::query("DELETE...")  # 직접 쿼리
    ↓
Built-in MCP Server
└─ content_store/storage.rs
   ├─ ContentStoreStorage
   ├─ create_tables(&pool)      # SQL embedded
   ├─ add_content(&mut self)    # SQL embedded
   └─ list_content(&self)       # SQL embedded
    ↓
Global State (state.rs)
├─ SQLITE_POOL: OnceLock
└─ get_sqlite_pool()
    ↓
SQLite Database
├─ messages
├─ message_index_meta
├─ stores
├─ contents
└─ chunks
```

### 3.2 주요 테이블 스키마

**messages 테이블** (messages_commands.rs):

- 세션별 메시지 저장
- 인덱스: session_id, created_at

**content_store 테이블들** (storage.rs):

- stores: 1:1 with session
- contents: 파일 컨텐츠
- chunks: 컨텐츠 청크 (1:N)

### 3.3 문제가 되는 코드 패턴

```rust
// 패턴 1: SQL embedded in command
pub mod db {
    pub async fn list_messages(pool: &SqlitePool, ...) {
        sqlx::query("SELECT * FROM messages WHERE ...").execute(pool).await
    }
}

// 패턴 2: CREATE TABLE in runtime
async fn create_tables(pool: &SqlitePool) {
    sqlx::query("CREATE TABLE IF NOT EXISTS ...").execute(pool).await
}

// 패턴 3: 여러 테이블 수정 시 트랜잭션 부재
sqlx::query("DELETE FROM contents ...").execute(pool).await?;
sqlx::query("DELETE FROM stores ...").execute(pool).await?;  // 원자성 보장 안 됨
```

---

## 4. 변경 이후의 상태 / 해결 판정 기준

### 4.1 목표 아키텍처

```
Frontend (TypeScript)
    ↓ Tauri Command
Commands Layer (Application Logic)
├─ messages_commands.rs         # Repository 사용만
├─ content_store_commands.rs    # Repository 사용만
└─ session_commands.rs          # Repository 사용만
    ↓
Repository Layer (Data Access)
├─ MessageRepository
├─ ContentStoreRepository
└─ MCPActivationRepository
    ↓
Data Layer
├─ models/ (SQLx derive)
├─ migrations/ (SQL files)
└─ connection.rs
    ↓
SQLite Database
```

### 4.2 성공 판정 기준

#### 필수 조건 (Must Have)

- [ ] 모든 SQL 쿼리가 Repository 내부로 이동
- [ ] 마이그레이션 파일로 스키마 관리
- [ ] Commands는 Repository만 사용
- [ ] 기존 기능 100% 동작 (회귀 없음)
- [ ] 트랜잭션 지원 (content + chunks)

#### 권장 조건 (Should Have)

- [ ] 단위 테스트 커버리지 > 80%
- [ ] Repository 통합 테스트
- [ ] 에러 처리 통합 (DbError)
- [ ] 성능 저하 없음 (벤치마크)

#### 선택 조건 (Nice to Have)

- [ ] Migration rollback 지원
- [ ] Connection pooling 최적화
- [ ] 쿼리 로깅 및 모니터링

---

## 5. 수정이 필요한 코드 및 수정 부분

### 5.1 신규 생성 파일

#### 파일: `src-tauri/src/db/mod.rs`

```rust
pub mod connection;
pub mod error;
pub mod models;
pub mod repositories;

pub use connection::{get_pool, create_pool};
pub use error::DbError;
pub use repositories::{MessageRepository, ContentStoreRepository};

/// Initialize database and run migrations
pub async fn init(pool: &sqlx::SqlitePool) -> Result<(), DbError> {
    sqlx::migrate!("./migrations")
        .run(pool)
        .await
        .map_err(|e| DbError::Migration(e.to_string()))?;
    Ok(())
}
```

#### 파일: `src-tauri/src/db/error.rs`

```rust
use thiserror::Error;

#[derive(Debug, Error)]
pub enum DbError {
    #[error("Database query failed: {0}")]
    Query(#[from] sqlx::Error),

    #[error("Migration failed: {0}")]
    Migration(String),

    #[error("Record not found: {0}")]
    NotFound(String),
}

impl From<DbError> for String {
    fn from(err: DbError) -> String {
        err.to_string()
    }
}
```

#### 파일: `src-tauri/src/db/models/message.rs`

```rust
use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Message {
    pub id: String,
    pub session_id: String,
    pub role: String,
    pub content: String,
    // ... 나머지 필드
    pub created_at: i64,
    pub updated_at: i64,
}
```

#### 파일: `src-tauri/src/db/repositories/message_repository.rs`

```rust
use crate::db::{error::DbError, models::Message};
use sqlx::SqlitePool;

pub struct MessageRepository {
    pool: SqlitePool,
}

impl MessageRepository {
    pub fn new(pool: SqlitePool) -> Self {
        Self { pool }
    }

    pub async fn list_by_session(
        &self,
        session_id: &str,
        page: usize,
        page_size: usize,
    ) -> Result<Vec<Message>, DbError> {
        // SQL 쿼리 구현
    }

    pub async fn upsert(&self, message: &Message) -> Result<(), DbError> {
        // Upsert 로직
    }

    // ... 기타 메서드
}
```

### 5.2 수정 필요 파일

#### 파일: `src-tauri/src/lib.rs`

**변경 전**:

```rust
// line 72-100
let pool = match sqlx::sqlite::SqlitePool::connect(&db_url).await {
    Ok(p) => p,
    Err(e) => { /* error handling */ }
};
state::set_sqlite_pool(pool.clone());
```

**변경 후**:

```rust
let pool = db::connection::create_pool(&db_url).await?;
db::init(&pool).await?;  // ← 마이그레이션 실행
state::set_sqlite_pool(pool.clone());
```

#### 파일: `src-tauri/src/commands/messages_commands.rs`

**변경 전** (line 54-100):

```rust
pub mod db {
    use sqlx::{Row, SqlitePool};

    pub async fn create_messages_table(pool: &SqlitePool) -> Result<(), String> {
        sqlx::query("CREATE TABLE IF NOT EXISTS messages ...").execute(pool).await
    }

    pub async fn list_messages(pool: &SqlitePool, ...) -> Result<...> {
        sqlx::query("SELECT * FROM messages ...").fetch_all(pool).await
    }
}
```

**변경 후**:

```rust
use crate::db::{MessageRepository, get_pool};

#[tauri::command]
pub async fn list_messages(
    session_id: String,
    page: usize,
    page_size: usize,
) -> Result<Vec<Message>, String> {
    let repo = MessageRepository::new(get_pool().clone());
    repo.list_by_session(&session_id, page, page_size)
        .await
        .map_err(|e| e.to_string())
}

// db 모듈 전체 제거
```

#### 파일: `src-tauri/src/mcp/builtin/content_store/storage.rs`

**변경 전** (line 48-100):

```rust
pub struct ContentStoreStorage {
    stores: HashMap<String, ContentStore>,
    contents: HashMap<String, ContentItem>,
    chunks: HashMap<String, Vec<ContentChunk>>,
    sqlite_pool: Option<SqlitePool>,  // ← 제거
}

async fn create_tables(pool: &SqlitePool) { /* SQL */ }
pub async fn add_content(&mut self, ...) { /* SQL */ }
```

**변경 후**:

```rust
pub struct ContentStoreStorage {
    stores: HashMap<String, ContentStore>,
    contents: HashMap<String, ContentItem>,
    chunks: HashMap<String, Vec<ContentChunk>>,
    // sqlite_pool 제거 - Repository로 분리
}

// SQL 관련 메서드 모두 제거
// In-memory 조작만 남김
```

#### 파일: `src-tauri/src/mcp/builtin/content_store/server.rs`

**변경 전** (line 10-45):

```rust
pub struct ContentStoreServer {
    session_manager: Arc<SessionManager>,
    storage: Mutex<storage::ContentStoreStorage>,
    search_engine: Arc<Mutex<search::ContentSearchEngine>>,
}

pub async fn new_with_sqlite(...) -> Result<Self, String> {
    let storage = storage::ContentStoreStorage::new_sqlite(database_url).await?;
    // ...
}
```

**변경 후**:

```rust
use crate::db::ContentStoreRepository;

pub struct ContentStoreServer {
    session_manager: Arc<SessionManager>,
    storage: Mutex<storage::ContentStoreStorage>,  // In-memory only
    repository: Arc<ContentStoreRepository>,        // ← 추가
    search_engine: Arc<Mutex<search::ContentSearchEngine>>,
}

pub fn new(session_manager: Arc<SessionManager>) -> Self {
    let repo = ContentStoreRepository::new(crate::db::get_pool().clone());
    // ...
}
```

### 5.3 마이그레이션 파일

#### 파일: `src-tauri/migrations/001_create_messages_table.sql`

```sql
-- Messages table
CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL CHECK(session_id <> ''),
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    -- ... 나머지 컬럼
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_session_created
ON messages(session_id, created_at);

-- Message index metadata
CREATE TABLE IF NOT EXISTS message_index_meta (
    session_id TEXT PRIMARY KEY,
    index_path TEXT,
    last_indexed_at INTEGER DEFAULT 0
);
```

#### 파일: `src-tauri/migrations/002_create_content_store_tables.sql`

```sql
CREATE TABLE IF NOT EXISTS stores (
    session_id TEXT PRIMARY KEY,
    name TEXT,
    description TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS contents (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    filename TEXT NOT NULL,
    -- ... 나머지 컬럼
    FOREIGN KEY (session_id) REFERENCES stores(session_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS chunks (
    id TEXT PRIMARY KEY,
    content_id TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    text TEXT NOT NULL,
    start_line INTEGER NOT NULL,
    end_line INTEGER NOT NULL,
    FOREIGN KEY (content_id) REFERENCES contents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_chunks_content_id ON chunks(content_id);
CREATE INDEX IF NOT EXISTS idx_contents_session_id ON contents(session_id);
```

---

## 6. 재사용 가능한 연관 코드

### 6.1 참고할 기존 코드

#### 파일: `src-tauri/src/state.rs`

- **주요 기능**: Global SQLite pool 관리
- **재사용**: `get_sqlite_pool()` 함수 패턴
- **인터페이스**: `pub fn get_sqlite_pool() -> &'static SqlitePool`

#### 파일: `src-tauri/src/commands/messages_commands.rs` (line 54-291)

- **주요 기능**: Messages CRUD 로직
- **재사용**: 쿼리 로직을 Repository로 이동
- **인터페이스**:
  - `list_messages()` → `MessageRepository::list_by_session()`
  - `upsert_message()` → `MessageRepository::upsert()`
  - `delete_message()` → `MessageRepository::delete()`

#### 파일: `src-tauri/src/mcp/builtin/content_store/storage.rs` (line 145-450)

- **주요 기능**: Content store CRUD
- **재사용**: 쿼리 로직을 Repository로 이동
- **인터페이스**:
  - `create_store()` → `ContentStoreRepository::get_or_create_store()`
  - `add_content()` → `ContentStoreRepository::add_content_with_chunks()`
  - `list_content()` → `ContentStoreRepository::list_content()`

### 6.2 새로 만들 공통 패턴

#### Repository 기본 패턴

```rust
pub struct XxxRepository {
    pool: SqlitePool,
}

impl XxxRepository {
    pub fn new(pool: SqlitePool) -> Self {
        Self { pool }
    }

    // CRUD methods
    pub async fn create(&self, item: &Xxx) -> Result<(), DbError> { }
    pub async fn get(&self, id: &str) -> Result<Xxx, DbError> { }
    pub async fn update(&self, item: &Xxx) -> Result<(), DbError> { }
    pub async fn delete(&self, id: &str) -> Result<(), DbError> { }
}
```

#### Transaction 패턴

```rust
pub async fn add_content_with_chunks(
    &self,
    item: &ContentItem,
    chunks: &[ContentChunk],
) -> Result<(), DbError> {
    let mut tx = self.pool.begin().await?;

    // Insert content
    sqlx::query("INSERT INTO contents ...").execute(&mut *tx).await?;

    // Insert chunks
    for chunk in chunks {
        sqlx::query("INSERT INTO chunks ...").execute(&mut *tx).await?;
    }

    tx.commit().await?;
    Ok(())
}
```

---

## 7. Test Code 추가 및 수정 가이드

### 7.1 단위 테스트 (Repository)

#### 파일: `src-tauri/tests/db/message_repository_test.rs`

```rust
#[cfg(test)]
mod tests {
    use super::*;

    async fn setup_test_db() -> SqlitePool {
        let pool = SqlitePool::connect(":memory:").await.unwrap();
        db::init(&pool).await.unwrap();
        pool
    }

    #[tokio::test]
    async fn test_create_and_get_message() {
        let pool = setup_test_db().await;
        let repo = MessageRepository::new(pool);

        let message = Message {
            id: "msg_1".to_string(),
            session_id: "session_1".to_string(),
            role: "user".to_string(),
            content: "Hello".to_string(),
            created_at: 1000,
            updated_at: 1000,
        };

        // Create
        repo.upsert(&message).await.unwrap();

        // Get
        let messages = repo.list_by_session("session_1", 1, 10).await.unwrap();
        assert_eq!(messages.len(), 1);
        assert_eq!(messages[0].content, "Hello");
    }

    #[tokio::test]
    async fn test_transaction_rollback() {
        // 트랜잭션 실패 시 롤백 검증
    }
}
```

### 7.2 통합 테스트 (Command)

#### 파일: `src-tauri/tests/commands/messages_commands_test.rs`

```rust
#[tokio::test]
async fn test_list_messages_command() {
    // Given: 테스트 DB 및 데이터 준비
    let pool = setup_test_db().await;
    let repo = MessageRepository::new(pool.clone());

    // Insert test data
    repo.upsert(&test_message()).await.unwrap();

    // When: Command 호출
    let result = list_messages("session_1".to_string(), 1, 10).await;

    // Then: 결과 검증
    assert!(result.is_ok());
    let messages = result.unwrap();
    assert_eq!(messages.len(), 1);
}
```

### 7.3 테스트 체크리스트

- [ ] MessageRepository 단위 테스트
  - [ ] CRUD 기본 동작
  - [ ] Pagination
  - [ ] Error handling
- [ ] ContentStoreRepository 단위 테스트
  - [ ] Content + Chunks 트랜잭션
  - [ ] Cascade delete 검증
  - [ ] Error handling

- [ ] Command 통합 테스트
  - [ ] 기존 기능 회귀 테스트
  - [ ] Repository 통합 검증

- [ ] Migration 테스트
  - [ ] 스키마 생성 검증
  - [ ] Index 생성 확인

---

## 8. 작업 단계별 가이드

### Phase 1: 기반 구조 생성 (Week 1)

**목표**: 새로운 db/ 디렉토리 구조 생성

```
작업:
1. db/ 디렉토리 및 하위 구조 생성
2. error.rs, connection.rs 작성
3. models/ 하위 파일 생성 (message.rs, content_store.rs)
4. migrations/ 디렉토리 및 SQL 파일 작성

검증:
- 컴파일 성공
- 마이그레이션 실행 성공 (in-memory DB)
```

### Phase 2: Repository 구현 (Week 2)

**목표**: MessageRepository, ContentStoreRepository 구현

```
작업:
1. MessageRepository 구현 및 단위 테스트
2. ContentStoreRepository 구현 및 단위 테스트
3. Transaction 로직 구현 및 검증

검증:
- 모든 단위 테스트 통과
- 기존 DB 스키마와 호환성 확인
```

### Phase 3: Command 마이그레이션 (Week 3)

**목표**: Commands를 Repository 사용으로 변경

```
작업:
1. messages_commands.rs 리팩토링
   - db 모듈 제거
   - Repository 사용으로 변경
2. content_store_commands.rs 리팩토링
3. 통합 테스트 작성 및 실행

검증:
- 기존 기능 100% 동작
- 통합 테스트 통과
```

### Phase 4: ContentStoreServer 리팩토링 (Week 4)

**목표**: storage.rs 간소화 및 Repository 통합

```
작업:
1. storage.rs에서 SQLite 관련 코드 제거
2. ContentStoreServer에 Repository 주입
3. Handler 로직 Repository 사용으로 변경

검증:
- Content Store MCP 서버 정상 동작
- 기존 기능 회귀 없음
```

### Phase 5: 최종 검증 및 문서화 (Week 5)

**목표**: 성능 검증 및 문서 정리

```
작업:
1. 성능 벤치마크
2. 코드 리뷰 및 리팩토링
3. 문서 업데이트
4. MCP Activation 준비 (선택)

검증:
- 성능 저하 없음
- 모든 테스트 통과
- 문서 완성
```

---

## 9. 추가 분석 과제

### 9.1 성능 영향 분석

**현재 불명확한 부분**:

- Repository 레이어 추가로 인한 성능 오버헤드
- Connection pooling 최적화 필요성

**분석 방향**:

- 기존 코드와 새 코드 벤치마크 비교
- Pool 크기 및 timeout 최적화
- 쿼리 실행 계획 분석 (EXPLAIN)

### 9.2 마이그레이션 전략

**현재 불명확한 부분**:

- 기존 DB에서 새 스키마로 전환 방법
- Down migration 필요성

**분석 방향**:

- 기존 사용자 DB 스키마 조사
- 마이그레이션 롤백 시나리오 정의
- 데이터 손실 방지 전략

### 9.3 트랜잭션 범위

**현재 불명확한 부분**:

- 어떤 작업에 트랜잭션이 필요한가
- Command 레벨 vs Repository 레벨 트랜잭션

**분석 방향**:

- 데이터 일관성이 중요한 작업 식별
- 트랜잭션 격리 수준 결정
- 성능 vs 일관성 트레이드오프 분석

---

## 10. 리스크 및 대응 방안

### 리스크 1: 기존 기능 회귀

- **위험도**: 높음
- **대응**: 통합 테스트 100% 커버리지, 단계적 배포

### 리스크 2: 성능 저하

- **위험도**: 중간
- **대응**: 벤치마크 수행, 필요 시 캐싱 추가

### 리스크 3: 마이그레이션 실패

- **위험도**: 중간
- **대응**: 백업 전략, 롤백 메커니즘

---

## 11. 참고 문서

- `docs/SQLITE_INTEGRATION_DESIGN.md` - 상세 설계
- `docs/CONTENT_STORE_STRUCTURE_ANALYSIS.md` - Content Store 분석
- `docs/SQLITE_SCHEMA_FOR_MCP_ACTIVATION.md` - MCP 활성화 스키마
- SQLx 문서: <https://github.com/launchbadge/sqlx>
- Repository 패턴: <https://martinfowler.com/eaaCatalog/repository.html>


---

# refactoring_20250109_ui_builtin_tools.md

# UI Builtin Tools 구현 계획

**작성일**: 2025-01-09  
**목표**: 사용자와의 상호작용을 위한 Built-in MCP UI 도구 구현

## 작업 목적

AI 에이전트가 사용자와 직접 상호작용할 수 있는 UI 도구 세트를 제공하여, 선택지 제시, 텍스트 입력 요청, 데이터 시각화 등의 기능을 지원한다.

**핵심 요구사항**:

- `visualizeData`: 기본 시각화 (bar/chart)
- `promptUser`: 사용자 프롬프트 (선택지/텍스트 입력)
- `reply`: 사용자 응답 처리

## 현재 상태 / 문제점

### 현재 구조 (Birdeye View)

**WebMCP 아키텍처**:

```
[Chat UI / Tool Renderer]
    ↓ uses
[WebMCPContext] → provides getServerProxy()
    ↓ wraps
[WebMCPProxy] → communicates via postMessage
    ↓ sends to
[Web Worker (mcp-worker.ts)]
    ↓ loads
[MCP Server Modules] (planning, playbook, ...)
    ↓ returns
[MCPResponse with UIResource]
    ↓ rendered by
[UIResourceRenderer] → fires onUIAction
    ↓ routes back to
[WebMCPProxy.callTool()]
```

**기존 구현 패턴 (playbook-store 참고)**:

- `createUIResource()`: UI 리소스 생성 (`rawHtml` 또는 `remoteDom`)
- `createMCPStructuredMultipartResponse()`: 텍스트 + UI 리소스 응답
- UIResource에 `serviceInfo.serverName` 첨부하여 클라이언트 라우팅 지원
- iframe 내 스크립트: `window.parent.postMessage({ type: 'tool', payload: { toolName, params } }, '*')`

### 문제점

1. **UI 상호작용 도구 부재**: 사용자 입력/선택을 받는 built-in 도구가 없음
2. **UIAction 라우팅 미구현**: `UIResourceRenderer`의 `onUIAction` 핸들러가 전역적으로 연결되지 않음
3. **응답 비동기 처리**: UI에서 발생한 액션을 원래 툴 호출로 다시 연결하는 메커니즘 필요

## 변경 이후 상태 / 해결 판정 기준

### 성공 기준

1. **새 MCP 서버 모듈 (`ui-tools`) 추가 완료**:
   - `prompt_user`: 사용자 프롬프트 UI 생성 (텍스트/선택지)
   - `reply_prompt`: 사용자 응답 수신
   - `visualize_data`: 간단 데이터 시각화

2. **Worker 등록 완료**:
   - `mcp-worker.ts`에 `ui-tools` 모듈 등록

3. **통합 검증**:
   - Chat UI에서 `prompt_user` 호출 시 UI 렌더링
   - 사용자 액션 시 `reply_prompt` 자동 호출
   - 응답이 원래 호출 컨텍스트로 반환

### ✅ 이미 구현된 사항 (변경 불필요)

- **UIAction 라우팅**: `MessageRenderer.tsx:95-335`에 이미 완전히 구현됨
  - `UIResourceRenderer`의 `onUIAction` 핸들러 연결됨
  - `serviceInfo.serverName` 기반 자동 라우팅 동작 중
  - Tauri 명령어, MCP 도구, Intent, Prompt 등 모든 액션 타입 처리 완료

### 판정 방법

- `pnpm build` 성공 (타입 오류 없음)
- `pnpm refactor:validate` 통과
- Smoke test: Chat에서 `ui.prompt_user()` 호출 → UI 렌더 → 사용자 클릭 → `reply_prompt` 실행 확인

## 구현 계획

### 1. 새 MCP 서버 모듈 추가

**파일**: `src/lib/web-mcp/modules/ui-tools.ts`

**구현 내용**:

```typescript
/**
 * UI 상호작용을 위한 Built-in MCP 서버
 * - prompt_user: 사용자 프롬프트 생성
 * - reply_prompt: 사용자 응답 수신
 * - visualize_data: 데이터 시각화
 */

import {
  createMCPStructuredResponse,
  createMCPTextResponse,
  createMCPStructuredMultipartResponse,
} from '@/lib/mcp-response-utils';
import type {
  MCPResponse,
  MCPTool,
  WebMCPServer,
  MCPContent,
  ServiceInfo,
} from '@/lib/mcp-types';
import { createUIResource, type UIResource } from '@mcp-ui/server';

let nextMessageId = 1;

// prompt_user 툴 구현
// - 입력: { prompt: string, type: 'text'|'select'|'multiselect', options?: string[] }
// - 출력: multipart(text + UIResource) + structured { messageId }
// - UIResource: rawHtml with inline form + postMessage script

// reply_prompt 툴 구현
// - 입력: { messageId: string, answer: unknown }
// - 출력: structured { messageId, answer, timestamp }

// visualize_data 툴 구현
// - 입력: { type: 'bar'|'line', data: Array<{label:string, value:number}> }
// - 출력: multipart(text + UIResource with SVG/Chart)

const tools: MCPTool[] = [
  {
    name: 'prompt_user',
    description:
      'Display interactive prompt to user (text input, select, multiselect)',
    inputSchema: {
      type: 'object',
      properties: {
        prompt: { type: 'string', description: 'Question to ask user' },
        type: {
          type: 'string',
          enum: ['text', 'select', 'multiselect'],
          description: 'Type of prompt',
        },
        options: {
          type: 'array',
          items: { type: 'string' },
          description: 'Options for select/multiselect',
        },
      },
      required: ['prompt', 'type'],
    },
  },
  {
    name: 'reply_prompt',
    description: 'Receive user response from prompt UI (called by UI action)',
    inputSchema: {
      type: 'object',
      properties: {
        messageId: { type: 'string' },
        answer: { description: 'User answer' },
      },
      required: ['messageId', 'answer'],
    },
  },
  {
    name: 'visualize_data',
    description: 'Visualize data as bar or line chart',
    inputSchema: {
      type: 'object',
      properties: {
        type: { type: 'string', enum: ['bar', 'line'] },
        data: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              label: { type: 'string' },
              value: { type: 'number' },
            },
            required: ['label', 'value'],
          },
        },
      },
      required: ['type', 'data'],
    },
  },
];

const uiTools: WebMCPServer = {
  name: 'ui',
  version: '0.1.0',
  description: 'Built-in UI interaction tools',
  tools,

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    // Tool 구현 로직
  },
};

export default uiTools;
```

**핵심 구현 사항**:

- `prompt_user`의 HTML 생성 시 `window.parent.postMessage({ type: 'tool', payload: { toolName: 'reply_prompt', params: { messageId, answer } } }, '*')` 포함
- `createUIResource()` 후 `serviceInfo = { serverName: 'ui', toolName: '', backendType: 'BuiltInWeb' }` 첨부
- messageId 생성: `ui-${Date.now()}-${nextMessageId++}`

### 2. Worker 모듈 등록

**파일**: `src/lib/web-mcp/mcp-worker.ts`

**수정 위치**:

```typescript
// Static imports section
import planningServer from './modules/planning-server';
import playbookStore from './modules/playbook-store';
import uiTools from './modules/ui-tools'; // ← 추가

// MODULE_REGISTRY
const MODULE_REGISTRY = [
  { key: 'planning', module: planningServer },
  { key: 'playbook', module: playbookStore },
  { key: 'ui', module: uiTools }, // ← 추가
] as const;
```

### 3. ~~UIAction 라우팅 구현~~ ✅ 이미 완료

**상태**: `MessageRenderer.tsx:95-335`에 이미 구현되어 있음

**구현 내용** (참고용):

- `handleUIAction` 콜백이 `UIResourceRenderer`에 연결됨 (line 392-399)
- Service context 기반 자동 라우팅 구현됨 (line 197-215)
- 모든 UIAction 타입 처리 완료 (tool, intent, prompt, link, notify)
- **변경 불필요**

### 4. ~~Chat UI 연동~~ ✅ 이미 완료

**상태**: `MessageRenderer.tsx`에 이미 완전히 구현되어 있음

**구현 내용** (참고용):

```tsx
// MessageRenderer.tsx:392-399
<UIResourceRenderer
  key={key}
  remoteDomProps={remoteDomProps}
  onUIAction={handleUIAction} // ← 이미 연결됨
  supportedContentTypes={[...supportedContentTypes]}
  htmlProps={{ autoResizeIframe: { height: true } }}
  resource={item.resource}
/>
```

- **변경 불필요**

## 재사용 가능한 연관 코드

### playbook-store.ts 참고 패턴

**UIResource 생성 + serviceInfo 첨부**:

```typescript
function createUiResourceFromHtml(html: string) {
  const res = createUIResource({
    uri: `ui://playbooks/list/${Date.now()}`,
    content: { type: 'rawHtml', htmlString: html },
    encoding: 'text',
  }) as UIResource & { serviceInfo?: ServiceInfo };

  res.serviceInfo = {
    serverName: 'playbook',
    toolName: '',
    backendType: 'BuiltInWeb',
  };

  return res;
}
```

**Multipart 응답 생성**:

```typescript
function makeListMultipartResponse(
  items: PlaybookRecord[],
  formattedText: string,
  structured: unknown,
) {
  const textPart: MCPContent = {
    type: 'text',
    text: formattedText,
  } as unknown as MCPContent;

  const uiResource = createUiResourceFromHtml(buildListItemsHtml(items));

  return createMCPStructuredMultipartResponse(
    [textPart, uiResource],
    structured,
  );
}
```

**iframe 내 postMessage 스크립트**:

```javascript
document.addEventListener('click', function (e) {
  const btn = e.target;
  if (btn && btn.classList.contains('select-pb-btn')) {
    const id = btn.getAttribute('data-pbid');
    window.parent.postMessage(
      {
        type: 'tool',
        payload: { toolName: 'select_playbook', params: { id } },
      },
      '*',
    );
  }
});
```

### mcp-response-utils 위치

**파일**: `src/lib/web-mcp/mcp-response-utils.ts` (또는 유사 유틸리티)

필요 함수:

- `createUIResource()`
- `createMCPStructuredMultipartResponse()`
- `createMCPTextResponse()`

※ 실제 파일 위치는 grep 검색 필요. playbook-store에서 import하는 경로 확인.

## 구현 순서 (수정됨)

1. **Phase 1: 서버 모듈 기본 구현**
   - `ui-tools.ts` 생성 (tools 정의 + 기본 스켈레톤)
   - `mcp-worker.ts` 등록
   - 빌드/타입 체크

2. **Phase 2: 툴 로직 구현**
   - `prompt_user`: HTML 생성 로직 (text/select/multiselect)
   - `reply_prompt`: 응답 수신 및 structured 반환
   - `visualize_data`: 간단 SVG 바 차트 생성

3. ~~**Phase 3: 라우팅 연결**~~ ✅ **이미 완료됨 - 생략**
   - `MessageRenderer.tsx`에 이미 모든 라우팅 구현 완료

4. **Phase 3 (최종): 통합 검증**
   - `pnpm refactor:validate` 실행
   - Smoke test (수동 테스트)

## 추가 분석 과제

1. **UIResourceRenderer 사용 위치 식별**:
   - Chat UI에서 tool result를 렌더링하는 정확한 컴포넌트 위치
   - 이미 `UIResourceRenderer`를 사용 중인지, 아니면 추가 필요한지 확인
   - 검색 키워드: `UIResourceRenderer`, `isUIResource`, `tool result render`

2. **mcp-response-utils 실제 위치**:
   - `createUIResource`, `createMCPStructuredMultipartResponse` 함수가 정의된 파일
   - playbook-store의 import 문 확인
   - 없을 경우 해당 유틸리티 함수 구현 필요

3. **MessageId 관리 전략**:
   - 여러 동시 프롬프트 처리 시 messageId 충돌 방지
   - 타임아웃/만료된 프롬프트 처리 (선택적)

4. **보안 고려사항**:
   - rawHtml 사용 시 XSS 방지 (HTML escape)
   - postMessage origin 검증 (UIResourceRenderer 내부 처리 확인)

## 변경 파일 목록 (수정됨)

### 추가

- `src/lib/web-mcp/modules/ui-tools.ts` (새 MCP 서버 모듈)

### 수정

- `src/lib/web-mcp/mcp-worker.ts` (모듈 등록)

### ~~변경 불필요~~ (이미 구현됨)

- ~~`src/context/WebMCPContext.tsx`~~ - 변경 불필요
- ~~`src/components/MessageRenderer.tsx`~~ - 이미 완전히 구현됨 (line 95-399)


---

# refactoring_20251010_async_execute_shell.md

# Refactoring Plan: Async Execute Shell Support

**Date**: 2025-10-10  
**Author**: Development Team  
**Status**: Planning Phase  
**Version**: 1.0

---

## 📋 작업의 목적

Workspace MCP 서버의 `execute_shell` 도구에 비동기/백그라운드 실행 모드를 추가하여, LLM Agent가 장시간 실행되는 명령어(서버 시작, 파일 감시, 빌드 프로세스 등)를 non-blocking 방식으로 실행하고 모니터링할 수 있도록 개선합니다.

### 핵심 목표

1. **비동기 실행 지원**: 명령어를 백그라운드에서 실행하고 즉시 제어권 반환
2. **프로세스 모니터링**: 실행 중인 프로세스의 상태 및 출력을 조회할 수 있는 API 제공
3. **출력 스트리밍**: stdout/stderr를 파일로 스트리밍하여 대용량 출력 처리
4. **세션 격리**: 각 세션의 프로세스를 독립적으로 관리

### 사용 시나리오

```
Agent: execute_shell("npm run dev", run_mode: "async")
→ Response: { process_id: "c1a2b3", status: "starting" }

Agent: poll_process("c1a2b3", tail: {src: "stdout", n: 20})
→ Response: { status: "running", tail: ["Server started...", ...] }

Agent: read_process_output("c1a2b3", stream: "stderr", lines: 50)
→ Response: { content: ["Error log 1", "Error log 2", ...] }
```

---

## 🔍 현재의 상태 / 문제점

### 현재 동작 방식

`execute_shell` 도구는 **동기(synchronous) 실행 모드만** 지원합니다:

```rust
// src-tauri/src/mcp/builtin/workspace/code_execution.rs
pub async fn handle_execute_shell(&self, args: Value) -> MCPResponse {
    // 1. Parse command and timeout
    // 2. Create isolated command
    // 3. Execute with timeout: timeout(duration, cmd.output()).await
    // 4. Wait for completion (blocking)
    // 5. Return stdout/stderr in response
}
```

**호출 흐름**:

```
MCP Client → WorkspaceServer::call_tool("execute_shell")
    → handle_execute_shell()
        → execute_shell_with_isolation()
            → isolation_manager.create_isolated_command()
            → timeout(duration, cmd.output()).await  // 블로킹 대기
            → return MCPResponse with stdout/stderr
```

### 문제점

#### 1. **장시간 실행 명령어 처리 불가**

- 서버 프로세스, watch 모드, 빌드 등은 완료까지 수 분~수 시간 소요
- Agent는 응답을 받기 전까지 블로킹되어 다른 작업 불가
- 타임아웃 발생 시 프로세스 강제 종료

#### 2. **출력 확인 불가**

- 실행 완료 후에만 출력 확인 가능
- 실행 중 진행 상황, 에러 로그를 실시간으로 볼 수 없음
- 디버깅 및 모니터링 어려움

#### 3. **프로세스 관리 기능 부재**

- 실행 중인 프로세스 목록 조회 불가
- 프로세스 상태(실행 중, 완료, 실패) 확인 불가
- 수동 종료/재시작 불가

#### 4. **대용량 출력 처리 문제**

- 모든 stdout/stderr를 메모리에 버퍼링 (`cmd.output().await`)
- 대용량 로그 출력 시 메모리 초과 위험
- MCP 응답 크기 제한 초과 가능

---

## 🏗️ 관련 코드의 구조 및 동작 방식 (Bird's Eye View)

### 현재 아키텍처

```
┌─────────────────────────────────────────────────────────────┐
│                    MCP Client (Agent)                        │
└───────────────────────┬─────────────────────────────────────┘
                        │ call_tool("execute_shell", args)
                        ▼
┌─────────────────────────────────────────────────────────────┐
│              WorkspaceServer (mod.rs)                        │
│  - session_manager: Arc<SessionManager>                     │
│  - isolation_manager: SessionIsolationManager               │
│  - tools(): Vec<MCPTool>                                    │
│  - call_tool(name, args) → MCPResponse                      │
└───────────────────────┬─────────────────────────────────────┘
                        │ handle_execute_shell(args)
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         code_execution.rs                                    │
│  - handle_execute_shell()                                   │
│      ├─ parse args (command, timeout, isolation)            │
│      ├─ normalize_shell_command()                           │
│      └─ execute_shell_with_isolation()                      │
│            ├─ build IsolatedProcessConfig                   │
│            ├─ create_isolated_command()                     │
│            ├─ timeout(duration, cmd.output()).await         │
│            └─ return stdout/stderr                          │
└───────────────────────┬─────────────────────────────────────┘
                        │ create_isolated_command(config)
                        ▼
┌─────────────────────────────────────────────────────────────┐
│       session_isolation.rs (SessionIsolationManager)         │
│  - create_isolated_command(config) → AsyncCommand           │
│      ├─ Basic: env vars, working dir                        │
│      ├─ Medium: process groups, resource limits             │
│      └─ High: unshare/sandbox-exec/job objects              │
└─────────────────────────────────────────────────────────────┘
```

### 주요 컴포넌트

#### 1. **WorkspaceServer** (`mod.rs`)

- Workspace MCP 서버의 메인 구조체
- 도구 라우팅 및 세션 관리
- **현재**: `process_registry` 없음 (추가 필요)

#### 2. **code_execution.rs**

- `execute_shell` 도구의 핵심 로직
- **현재**: 동기 실행만 지원
- **변경 필요**: `run_mode` 파라미터 추가, 비동기 spawn 로직 추가

#### 3. **SessionIsolationManager** (`session_isolation.rs`)

- 플랫폼별 프로세스 격리 및 샌드박싱
- `tokio::process::Command` (AsyncCommand) 생성
- **변경 불필요**: 현재 API 그대로 사용 가능

#### 4. **tools/** 디렉토리

- MCP 도구 스키마 정의
- **현재**: `code_tools.rs`에 `execute_shell` 정의
- **추가 필요**: `terminal_tools.rs` (신규 도구들)

---

## 🎯 변경 이후의 상태 / 해결 판정 기준

### 목표 상태

#### 1. **execute_shell 확장**

- ✅ `run_mode: "sync"` (기본): 기존 동작 유지
- ✅ `run_mode: "async"`: 즉시 process_id 반환, 백그라운드 실행
- ✅ `run_mode: "background"`: async와 동일 (명시적 표현)

#### 2. **신규 도구 추가**

- ✅ `poll_process`: 프로세스 상태 조회 + optional tail
- ✅ `read_process_output`: stdout/stderr 읽기 (텍스트, 최대 100줄)
- ✅ `list_processes`: 세션 내 프로세스 목록

#### 3. **프로세스 레지스트리**

- ✅ 실행 중/완료된 프로세스 메타데이터 저장
- ✅ 세션별 격리 (다른 세션 접근 불가)
- ✅ 출력 파일 경로 관리

#### 4. **출력 스트리밍**

- ✅ stdout/stderr를 `tmp/process_{id}/` 디렉토리의 파일로 저장
- ✅ 실시간 append (메모리 버퍼링 없음)
- ✅ 파일 크기 추적

### 성공 판정 기준

#### 기능 검증

1. **비동기 실행**

   ```bash
   # Test: 장시간 실행 명령어
   execute_shell("sleep 60", run_mode: "async")
   → 즉시 process_id 반환 (< 1초)
   → 백그라운드에서 실행 중
   ```

2. **상태 모니터링**

   ```bash
   poll_process(process_id)
   → status: "running", pid: 12345, started_at: "..."

   # 60초 후
   poll_process(process_id)
   → status: "finished", exit_code: 0
   ```

3. **출력 조회**

   ```bash
   execute_shell("echo 'line1'; echo 'line2'", run_mode: "async")
   poll_process(process_id, tail: {src: "stdout", n: 10})
   → tail: ["line1", "line2"]

   read_process_output(process_id, stream: "stdout", lines: 50)
   → content: ["line1", "line2"]
   ```

4. **세션 격리**

   ```bash
   # Session A에서 실행
   execute_shell("echo 'session A'", run_mode: "async") → process_id: "p1"

   # Session B에서 조회 시도
   poll_process("p1") → Error: "Process not found or access denied"
   ```

#### 비기능 검증

- ✅ 메모리 사용량: 대용량 출력(10MB+)에서도 안정적
- ✅ 동시 실행: 10개 이상의 프로세스 동시 실행 가능
- ✅ 보안: 세션 간 프로세스 격리 유지
- ✅ 에러 처리: spawn 실패, 권한 부족 등 적절히 처리

---

## 🔧 수정이 필요한 코드 및 수정 부분

### 1. 신규 파일 생성

#### **`src-tauri/src/mcp/builtin/workspace/terminal_manager.rs`** (신규)

**목적**: 프로세스 레지스트리 및 출력 읽기 헬퍼

```rust
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;
use tokio::sync::RwLock;
use chrono::{DateTime, Utc};

/// Process status enumeration
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ProcessStatus {
    Starting,   // Spawning in progress
    Running,    // Actively running
    Finished,   // Completed successfully
    Failed,     // Exited with error
    Killed,     // Terminated by user/system
}

/// Process metadata entry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessEntry {
    pub id: String,
    pub session_id: String,
    pub command: String,
    pub status: ProcessStatus,
    pub pid: Option<u32>,
    pub exit_code: Option<i32>,
    pub started_at: DateTime<Utc>,
    pub finished_at: Option<DateTime<Utc>>,
    pub stdout_path: String,
    pub stderr_path: String,
    pub stdout_size: u64,
    pub stderr_size: u64,
}

/// Thread-safe process registry
pub type ProcessRegistry = Arc<RwLock<HashMap<String, ProcessEntry>>>;

/// Create a new process registry
pub fn create_process_registry() -> ProcessRegistry {
    Arc::new(RwLock::new(HashMap::new()))
}

/// Read last N lines from file (max 100, text only)
pub async fn tail_lines(
    file_path: &PathBuf,
    n: usize,
) -> Result<Vec<String>, String> {
    let n = n.min(100); // enforce max

    if !file_path.exists() {
        return Ok(Vec::new());
    }

    // Read file as UTF-8 (lossy conversion for non-UTF8)
    let content = tokio::fs::read_to_string(file_path)
        .await
        .map_err(|e| format!("Failed to read file: {}", e))?;

    // Get last N lines in reverse order, then reverse back
    let lines: Vec<String> = content
        .lines()
        .rev()
        .take(n)
        .map(|s| s.to_string())
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect();

    Ok(lines)
}

/// Read first N lines from file (max 100, text only)
pub async fn head_lines(
    file_path: &PathBuf,
    n: usize,
) -> Result<Vec<String>, String> {
    let n = n.min(100); // enforce max

    if !file_path.exists() {
        return Ok(Vec::new());
    }

    let content = tokio::fs::read_to_string(file_path)
        .await
        .map_err(|e| format!("Failed to read file: {}", e))?;

    let lines: Vec<String> = content
        .lines()
        .take(n)
        .map(|s| s.to_string())
        .collect();

    Ok(lines)
}

/// Get file size in bytes
pub async fn get_file_size(file_path: &PathBuf) -> u64 {
    tokio::fs::metadata(file_path)
        .await
        .map(|m| m.len())
        .unwrap_or(0)
}
```

---

#### **`src-tauri/src/mcp/builtin/workspace/tools/terminal_tools.rs`** (신규)

**목적**: 신규 MCP 도구 스키마 정의

```rust
use crate::mcp::{utils::schema_builder::*, MCPTool};
use serde_json::json;
use std::collections::HashMap;

/// Create poll_process tool
pub fn create_poll_process_tool() -> MCPTool {
    let mut props = HashMap::new();

    props.insert(
        "process_id".to_string(),
        string_prop_required("Process ID returned by execute_shell (async mode)"),
    );

    // Optional tail parameter
    props.insert(
        "tail".to_string(),
        object_prop(
            vec![
                ("src".to_string(), enum_prop(vec!["stdout", "stderr"], "stdout")),
                ("n".to_string(), integer_prop_with_default(1, 100, 10, Some("Number of lines (max 100)"))),
            ],
            Vec::new(),
            Some("Get last N lines from stdout or stderr"),
        ),
    );

    MCPTool {
        name: "poll_process".to_string(),
        title: Some("Poll Process Status".to_string()),
        description: "Check the status of an asynchronously running process. \
                      Optionally retrieve the last N lines of output (max 100 lines). \
                      Only processes from the current session can be queried.".to_string(),
        input_schema: object_schema(props, vec!["process_id".to_string()]),
        output_schema: None,
        annotations: None,
    }
}

/// Create read_process_output tool
pub fn create_read_process_output_tool() -> MCPTool {
    let mut props = HashMap::new();

    props.insert(
        "process_id".to_string(),
        string_prop_required("Process ID"),
    );

    props.insert(
        "stream".to_string(),
        enum_prop_required(vec!["stdout", "stderr"], "Stream to read from"),
    );

    props.insert(
        "mode".to_string(),
        enum_prop(vec!["tail", "head"], "tail"),
    );

    props.insert(
        "lines".to_string(),
        integer_prop_with_default(1, 100, 20, Some("Number of lines to read (max 100)")),
    );

    MCPTool {
        name: "read_process_output".to_string(),
        title: Some("Read Process Output".to_string()),
        description: "Read stdout or stderr from a background process. \
                      TEXT OUTPUT ONLY. Maximum 100 lines per request. \
                      Use 'tail' mode for last N lines, 'head' for first N lines.".to_string(),
        input_schema: object_schema(props, vec!["process_id".to_string(), "stream".to_string()]),
        output_schema: None,
        annotations: None,
    }
}

/// Create list_processes tool
pub fn create_list_processes_tool() -> MCPTool {
    let mut props = HashMap::new();

    props.insert(
        "status_filter".to_string(),
        enum_prop(vec!["all", "running", "finished"], "all"),
    );

    MCPTool {
        name: "list_processes".to_string(),
        title: Some("List Processes".to_string()),
        description: "List all background processes in the current session. \
                      Filter by status: 'all' (default), 'running', or 'finished'.".to_string(),
        input_schema: object_schema(props, Vec::new()),
        output_schema: None,
        annotations: None,
    }
}

/// Export all terminal tools
pub fn terminal_tools() -> Vec<MCPTool> {
    vec![
        create_poll_process_tool(),
        create_read_process_output_tool(),
        create_list_processes_tool(),
    ]
}
```

---

### 2. 기존 파일 수정

#### **`src-tauri/src/mcp/builtin/workspace/mod.rs`** (수정)

**변경 사항**:

1. `terminal_manager` 모듈 추가
2. `WorkspaceServer`에 `process_registry` 필드 추가
3. `call_tool()` 메서드에 신규 도구 라우팅
4. `get_service_context()`에 실행 중인 프로세스 정보 추가
5. `tools()` 메서드에 `terminal_tools()` 포함

```rust
// Module imports
pub mod code_execution;
pub mod export_operations;
pub mod file_operations;
pub mod tools;
pub mod ui_resources;
pub mod utils;
pub mod terminal_manager;  // NEW

#[derive(Debug)]
pub struct WorkspaceServer {
    session_manager: Arc<SessionManager>,
    isolation_manager: crate::session_isolation::SessionIsolationManager,
    process_registry: terminal_manager::ProcessRegistry,  // NEW
}

impl WorkspaceServer {
    pub fn new(session_manager: Arc<SessionManager>) -> Self {
        info!("WorkspaceServer using session-based workspace management");
        Self {
            session_manager,
            isolation_manager: crate::session_isolation::SessionIsolationManager::new(),
            process_registry: terminal_manager::create_process_registry(),  // NEW
        }
    }

    // NEW: Poll process handler
    pub async fn handle_poll_process(&self, args: Value) -> MCPResponse {
        let request_id = Self::generate_request_id();

        // Parse process_id
        let process_id = match args.get("process_id").and_then(|v| v.as_str()) {
            Some(id) => id,
            None => {
                return Self::error_response(
                    request_id,
                    -32602,
                    "Missing required parameter: process_id",
                );
            }
        };

        // Get current session
        let session_id = self.session_manager
            .get_current_session()
            .unwrap_or_else(|| "default".to_string());

        // Get process entry
        let registry = self.process_registry.read().await;
        let entry = match registry.get(process_id) {
            Some(e) => e.clone(),
            None => {
                return Self::error_response(
                    request_id,
                    -32603,
                    "Process not found or access denied",
                );
            }
        };

        // Verify session access
        if entry.session_id != session_id {
            return Self::error_response(
                request_id,
                -32603,
                "Process not found or access denied",
            );
        }
        drop(registry);

        // Build response
        let mut response = json!({
            "process_id": entry.id,
            "status": format!("{:?}", entry.status).to_lowercase(),
            "command": entry.command,
            "pid": entry.pid,
            "exit_code": entry.exit_code,
            "started_at": entry.started_at.to_rfc3339(),
            "finished_at": entry.finished_at.map(|t| t.to_rfc3339()),
            "stdout_size": entry.stdout_size,
            "stderr_size": entry.stderr_size,
        });

        // Optional tail
        if let Some(tail_obj) = args.get("tail").and_then(|v| v.as_object()) {
            let src = tail_obj.get("src")
                .and_then(|v| v.as_str())
                .unwrap_or("stdout");
            let n = tail_obj.get("n")
                .and_then(|v| v.as_u64())
                .unwrap_or(10) as usize;

            let file_path = if src == "stdout" {
                std::path::PathBuf::from(&entry.stdout_path)
            } else {
                std::path::PathBuf::from(&entry.stderr_path)
            };

            match terminal_manager::tail_lines(&file_path, n).await {
                Ok(lines) => {
                    response["tail"] = json!({
                        "src": src,
                        "lines": lines,
                    });
                }
                Err(e) => {
                    tracing::warn!("Failed to read tail: {}", e);
                }
            }
        }

        Self::success_response(
            request_id,
            &serde_json::to_string_pretty(&response).unwrap_or_default(),
        )
    }

    // NEW: Read process output handler
    pub async fn handle_read_process_output(&self, args: Value) -> MCPResponse {
        let request_id = Self::generate_request_id();

        // Parse parameters
        let process_id = match args.get("process_id").and_then(|v| v.as_str()) {
            Some(id) => id,
            None => {
                return Self::error_response(
                    request_id,
                    -32602,
                    "Missing required parameter: process_id",
                );
            }
        };

        let stream = match args.get("stream").and_then(|v| v.as_str()) {
            Some(s) => s,
            None => {
                return Self::error_response(
                    request_id,
                    -32602,
                    "Missing required parameter: stream",
                );
            }
        };

        let mode = args.get("mode")
            .and_then(|v| v.as_str())
            .unwrap_or("tail");

        let lines = args.get("lines")
            .and_then(|v| v.as_u64())
            .unwrap_or(20) as usize;

        // Get current session
        let session_id = self.session_manager
            .get_current_session()
            .unwrap_or_else(|| "default".to_string());

        // Get process entry
        let registry = self.process_registry.read().await;
        let entry = match registry.get(process_id) {
            Some(e) => e.clone(),
            None => {
                return Self::error_response(
                    request_id,
                    -32603,
                    "Process not found or access denied",
                );
            }
        };

        // Verify session access
        if entry.session_id != session_id {
            return Self::error_response(
                request_id,
                -32603,
                "Process not found or access denied",
            );
        }
        drop(registry);

        // Get file path
        let file_path = if stream == "stdout" {
            std::path::PathBuf::from(&entry.stdout_path)
        } else {
            std::path::PathBuf::from(&entry.stderr_path)
        };

        // Read lines based on mode
        let content = match mode {
            "head" => terminal_manager::head_lines(&file_path, lines).await,
            _ => terminal_manager::tail_lines(&file_path, lines).await,
        };

        match content {
            Ok(lines_vec) => {
                let response = json!({
                    "process_id": process_id,
                    "stream": stream,
                    "mode": mode,
                    "lines_requested": lines.min(100),
                    "lines_returned": lines_vec.len(),
                    "content": lines_vec,
                    "total_size": terminal_manager::get_file_size(&file_path).await,
                    "note": "Text output only. Max 100 lines per request.",
                });

                Self::success_response(
                    request_id,
                    &serde_json::to_string_pretty(&response).unwrap_or_default(),
                )
            }
            Err(e) => {
                Self::error_response(
                    request_id,
                    -32603,
                    &format!("Failed to read output: {}", e),
                )
            }
        }
    }

    // NEW: List processes handler
    pub async fn handle_list_processes(&self, args: Value) -> MCPResponse {
        let request_id = Self::generate_request_id();

        let status_filter = args.get("status_filter")
            .and_then(|v| v.as_str())
            .unwrap_or("all");

        // Get current session
        let session_id = self.session_manager
            .get_current_session()
            .unwrap_or_else(|| "default".to_string());

        // Filter processes by session
        let registry = self.process_registry.read().await;
        let mut processes: Vec<Value> = registry
            .values()
            .filter(|e| e.session_id == session_id)
            .filter(|e| {
                match status_filter {
                    "running" => matches!(e.status, terminal_manager::ProcessStatus::Running),
                    "finished" => matches!(e.status, terminal_manager::ProcessStatus::Finished),
                    _ => true,
                }
            })
            .map(|e| json!({
                "process_id": e.id,
                "command": e.command,
                "status": format!("{:?}", e.status).to_lowercase(),
                "pid": e.pid,
                "started_at": e.started_at.to_rfc3339(),
                "exit_code": e.exit_code,
            }))
            .collect();

        processes.sort_by(|a, b| {
            let a_time = a.get("started_at").and_then(|v| v.as_str()).unwrap_or("");
            let b_time = b.get("started_at").and_then(|v| v.as_str()).unwrap_or("");
            b_time.cmp(a_time) // descending order
        });

        let total = processes.len();
        let running = registry.values()
            .filter(|e| e.session_id == session_id)
            .filter(|e| matches!(e.status, terminal_manager::ProcessStatus::Running))
            .count();
        let finished = registry.values()
            .filter(|e| e.session_id == session_id)
            .filter(|e| matches!(e.status, terminal_manager::ProcessStatus::Finished))
            .count();

        drop(registry);

        let response = json!({
            "processes": processes,
            "total": total,
            "running": running,
            "finished": finished,
        });

        Self::success_response(
            request_id,
            &serde_json::to_string_pretty(&response).unwrap_or_default(),
        )
    }
}

#[async_trait]
impl BuiltinMCPServer for WorkspaceServer {
    // ... existing methods ...

    fn tools(&self) -> Vec<MCPTool> {
        let mut tools = Vec::new();
        tools.extend(tools::file_tools());
        tools.extend(tools::code_tools());
        tools.extend(tools::export_tools());
        tools.extend(tools::terminal_tools());  // NEW
        tools
    }

    fn get_service_context(&self, _options: Option<&Value>) -> ServiceContext {
        let workspace_dir_path = self.get_workspace_dir();
        let workspace_dir = workspace_dir_path.to_string_lossy().to_string();
        let tree_output = self.get_workspace_tree(&workspace_dir, 2);

        // NEW: Add running processes summary
        let registry = self.process_registry.blocking_read();
        let session_id = self.session_manager
            .get_current_session()
            .unwrap_or_else(|| "default".to_string());

        let running_count = registry.values()
            .filter(|e| e.session_id == session_id)
            .filter(|p| matches!(p.status, terminal_manager::ProcessStatus::Running))
            .count();

        drop(registry);

        let context_prompt = format!(
            "workspace: Active, {} tools, dir: {}, {} running processes",
            self.tools().len(),
            workspace_dir,
            running_count
        );

        ServiceContext {
            context_prompt,
            structured_state: Some(Value::String(workspace_dir)),
        }
    }

    async fn call_tool(&self, tool_name: &str, args: Value) -> MCPResponse {
        match tool_name {
            // Existing tools
            "read_file" => self.handle_read_file(args).await,
            "write_file" => self.handle_write_file(args).await,
            "list_directory" => self.handle_list_directory(args).await,
            "replace_lines_in_file" => self.handle_replace_lines_in_file(args).await,
            "import_file" => self.handle_import_file(args).await,
            "execute_shell" => self.handle_execute_shell(args).await,
            "export_file" => self.handle_export_file(args).await,
            "export_zip" => self.handle_export_zip(args).await,
            // NEW: Terminal tools
            "poll_process" => self.handle_poll_process(args).await,
            "read_process_output" => self.handle_read_process_output(args).await,
            "list_processes" => self.handle_list_processes(args).await,
            _ => {
                let request_id = Self::generate_request_id();
                Self::error_response(request_id, -32601, &format!("Tool '{tool_name}' not found"))
            }
        }
    }
}
```

---

#### **`src-tauri/src/mcp/builtin/workspace/code_execution.rs`** (수정)

**변경 사항**:

1. `handle_execute_shell()`에 `run_mode` 파라미터 처리 추가
2. `execute_shell_async()` 메서드 추가 (비동기 실행 로직)
3. 프로세스 모니터링 태스크 spawn

```rust
use super::terminal_manager;  // NEW

impl WorkspaceServer {
    pub async fn handle_execute_shell(&self, args: Value) -> MCPResponse {
        let request_id = Self::generate_request_id();

        let raw_command = match args.get("command").and_then(|v| v.as_str()) {
            Some(cmd) => cmd,
            None => {
                return Self::error_response(
                    request_id,
                    -32602,
                    "Missing required parameter: command",
                );
            }
        };

        // NEW: Check run_mode
        let run_mode = args
            .get("run_mode")
            .and_then(|v| v.as_str())
            .unwrap_or("sync");

        // Sync mode: existing behavior
        if run_mode == "sync" {
            let timeout_secs = utils::validate_timeout(
                args.get("timeout").and_then(|v| v.as_u64())
            );
            let isolation_level = args
                .get("isolation")
                .and_then(|v| v.as_str())
                .map(|level| match level {
                    "basic" => IsolationLevel::Basic,
                    "high" => IsolationLevel::High,
                    _ => IsolationLevel::Medium,
                })
                .unwrap_or(IsolationLevel::Medium);

            return self
                .execute_shell_with_isolation(raw_command, isolation_level, timeout_secs)
                .await;
        }

        // Async/Background mode: NEW
        self.execute_shell_async(raw_command, &args).await
    }

    // NEW: Async execution handler
    async fn execute_shell_async(
        &self,
        command: &str,
        args: &Value,
    ) -> MCPResponse {
        let request_id = Self::generate_request_id();

        // Generate process ID
        let process_id = cuid2::create_id();

        // Get session info
        let session_id = self
            .session_manager
            .get_current_session()
            .unwrap_or_else(|| "default".to_string());

        let workspace_path = self.get_workspace_dir();

        // Create process tmp directory
        let process_tmp_dir = workspace_path
            .join("tmp")
            .join(format!("process_{}", process_id));

        if let Err(e) = tokio::fs::create_dir_all(&process_tmp_dir).await {
            return Self::error_response(
                request_id,
                -32603,
                &format!("Failed to create process directory: {}", e),
            );
        }

        let stdout_path = process_tmp_dir.join("stdout");
        let stderr_path = process_tmp_dir.join("stderr");

        // Normalize command
        let normalized_command = Self::normalize_shell_command(command);

        // Determine isolation level
        let isolation_level = args
            .get("isolation")
            .and_then(|v| v.as_str())
            .map(|level| match level {
                "basic" => IsolationLevel::Basic,
                "high" => IsolationLevel::High,
                _ => IsolationLevel::Medium,
            })
            .unwrap_or(IsolationLevel::Medium);

        // Create isolation config
        let isolation_config = IsolatedProcessConfig {
            session_id: session_id.clone(),
            workspace_path: workspace_path.clone(),
            command: normalized_command.clone(),
            args: vec![],
            env_vars: HashMap::new(),
            isolation_level,
        };

        // Create isolated command
        let mut cmd = match self
            .isolation_manager
            .create_isolated_command(isolation_config)
            .await
        {
            Ok(cmd) => cmd,
            Err(e) => {
                return Self::error_response(
                    request_id,
                    -32603,
                    &format!("Failed to create isolated command: {}", e),
                );
            }
        };

        // Setup stdout/stderr to pipes
        use tokio::process::Stdio;
        cmd.stdout(Stdio::piped());
        cmd.stderr(Stdio::piped());

        // Register process in registry
        let entry = terminal_manager::ProcessEntry {
            id: process_id.clone(),
            session_id: session_id.clone(),
            command: command.to_string(),
            status: terminal_manager::ProcessStatus::Starting,
            pid: None,
            exit_code: None,
            started_at: chrono::Utc::now(),
            finished_at: None,
            stdout_path: stdout_path.to_string_lossy().to_string(),
            stderr_path: stderr_path.to_string_lossy().to_string(),
            stdout_size: 0,
            stderr_size: 0,
        };

        {
            let mut registry = self.process_registry.write().await;
            registry.insert(process_id.clone(), entry.clone());
        }

        // Spawn monitoring task
        let registry = self.process_registry.clone();
        let pid_copy = process_id.clone();

        tokio::spawn(async move {
            // Spawn process
            let mut child = match cmd.spawn() {
                Ok(c) => c,
                Err(e) => {
                    // Update registry: failed
                    let mut reg = registry.write().await;
                    if let Some(entry) = reg.get_mut(&pid_copy) {
                        entry.status = terminal_manager::ProcessStatus::Failed;
                        entry.finished_at = Some(chrono::Utc::now());
                    }
                    tracing::error!("Failed to spawn process: {}", e);
                    return;
                }
            };

            let pid = child.id();

            // Update registry: running
            {
                let mut reg = registry.write().await;
                if let Some(entry) = reg.get_mut(&pid_copy) {
                    entry.status = terminal_manager::ProcessStatus::Running;
                    entry.pid = pid;
                }
            }

            // Stream stdout to file
            if let Some(mut stdout) = child.stdout.take() {
                let stdout_path_clone = stdout_path.clone();
                tokio::spawn(async move {
                    if let Ok(mut file) = tokio::fs::File::create(&stdout_path_clone).await {
                        let _ = tokio::io::copy(&mut stdout, &mut file).await;
                    }
                });
            }

            // Stream stderr to file
            if let Some(mut stderr) = child.stderr.take() {
                let stderr_path_clone = stderr_path.clone();
                tokio::spawn(async move {
                    if let Ok(mut file) = tokio::fs::File::create(&stderr_path_clone).await {
                        let _ = tokio::io::copy(&mut stderr, &mut file).await;
                    }
                });
            }

            // Wait for completion
            let exit_status = child.wait().await;

            // Update registry: finished
            let mut reg = registry.write().await;
            if let Some(entry) = reg.get_mut(&pid_copy) {
                match exit_status {
                    Ok(status) => {
                        entry.status = if status.success() {
                            terminal_manager::ProcessStatus::Finished
                        } else {
                            terminal_manager::ProcessStatus::Failed
                        };
                        entry.exit_code = status.code();
                    }
                    Err(e) => {
                        entry.status = terminal_manager::ProcessStatus::Failed;
                        tracing::error!("Process wait error: {}", e);
                    }
                }
                entry.finished_at = Some(chrono::Utc::now());

                // Update file sizes
                entry.stdout_size = terminal_manager::get_file_size(&stdout_path).await;
                entry.stderr_size = terminal_manager::get_file_size(&stderr_path).await;
            }

            info!(
                "Process {} completed with status: {:?}",
                pid_copy,
                reg.get(&pid_copy).map(|e| &e.status)
            );
        });

        // Return immediate response
        let response_msg = format!(
            "Process started in background.\n\
             Process ID: {}\n\
             Command: {}\n\
             \n\
             Use 'poll_process' to check status and view output:\n\
             poll_process(process_id: \"{}\", tail: {{src: \"stdout\", n: 20}})",
            process_id, command, process_id
        );

        Self::success_response(request_id, &response_msg)
    }

    // ... existing methods (execute_shell_with_isolation, etc.) ...
}
```

---

#### **`src-tauri/src/mcp/builtin/workspace/tools/mod.rs`** (수정)

**변경 사항**: `terminal_tools()` 함수 추가 및 export

```rust
pub mod code_tools;
pub mod export_tools;
pub mod file_tools;
pub mod terminal_tools;  // NEW

pub use code_tools::*;
pub use export_tools::*;
pub use file_tools::*;
pub use terminal_tools::*;  // NEW

// Export terminal tools
pub fn terminal_tools() -> Vec<crate::mcp::MCPTool> {
    vec![
        terminal_tools::create_poll_process_tool(),
        terminal_tools::create_read_process_output_tool(),
        terminal_tools::create_list_processes_tool(),
    ]
}
```

---

#### **`src-tauri/src/mcp/builtin/workspace/tools/code_tools.rs`** (수정)

**변경 사항**: `execute_shell` 도구 스키마에 `run_mode` 파라미터 추가

```rust
pub fn create_execute_shell_tool() -> MCPTool {
    let mut props = HashMap::new();
    props.insert(
        "command".to_string(),
        string_prop_with_examples(
            Some(1),
            Some(1000),
            Some("Shell command to execute (POSIX sh compatible)"),
            vec![
                json!("ls -la"),
                json!("grep -r 'pattern' ."),
                json!(". script.sh"),
            ],
        ),
    );
    props.insert(
        "timeout".to_string(),
        integer_prop_with_default(
            Some(1),
            Some(crate::config::max_execution_timeout() as i64),
            crate::config::default_execution_timeout() as i64,
            Some("Timeout in seconds (default: 30, sync mode only)"),
        ),
    );
    // NEW: run_mode parameter
    props.insert(
        "run_mode".to_string(),
        enum_prop(
            vec!["sync", "async", "background"],
            "sync",
            Some("Execution mode: 'sync' (wait for completion), 'async'/'background' (return immediately)"),
        ),
    );
    props.insert(
        "isolation".to_string(),
        enum_prop(
            vec!["basic", "medium", "high"],
            "medium",
            Some("Isolation level: 'basic' (env only), 'medium' (process groups), 'high' (sandboxing)"),
        ),
    );

    MCPTool {
        name: "execute_shell".to_string(),
        title: Some("Execute Shell Command".to_string()),
        description: "Execute a shell command in a sandboxed environment using POSIX sh shell. \
                      \n\n\
                      MODES:\n\
                      - 'sync' (default): Wait for completion, return stdout/stderr\n\
                      - 'async'/'background': Run in background, return process_id immediately\n\
                      \n\
                      For async mode, use 'poll_process' to check status and view output.\n\
                      \n\
                      Note: bash-specific commands like 'source' are not available - use '.' instead.".to_string(),
        input_schema: object_schema(props, vec!["command".to_string()]),
        output_schema: None,
        annotations: None,
    }
}
```

---

## 🔗 재사용 가능한 연관 코드

### 기존 코드 활용

#### 1. **SessionIsolationManager** (`src-tauri/src/session_isolation.rs`)

- **목적**: 플랫폼별 프로세스 격리 및 샌드박싱
- **재사용**: `create_isolated_command()` 메서드를 그대로 사용
- **인터페이스**:

  ```rust
  pub async fn create_isolated_command(
      &self,
      config: IsolatedProcessConfig,
  ) -> Result<AsyncCommand, String>
  ```

#### 2. **SessionManager** (`src-tauri/src/session/`)

- **목적**: 세션별 워크스페이스 디렉토리 관리
- **재사용**: `get_current_session()`, `get_session_workspace_dir()`
- **인터페이스**:

  ```rust
  pub fn get_current_session(&self) -> Option<String>
  pub fn get_session_workspace_dir(&self) -> PathBuf
  ```

#### 3. **utils 모듈** (`src-tauri/src/mcp/builtin/workspace/utils.rs`)

- **목적**: 공통 유틸리티 함수
- **재사용**: `generate_request_id()`, `validate_timeout()`, response 생성 함수
- **인터페이스**:

  ```rust
  pub fn generate_request_id() -> Value
  pub fn create_success_response(request_id: Value, message: &str) -> MCPResponse
  pub fn create_error_response(request_id: Value, code: i32, message: &str) -> MCPResponse
  ```

#### 4. **schema_builder** (`src-tauri/src/mcp/utils/schema_builder.rs`)

- **목적**: MCP 도구 스키마 빌더 헬퍼
- **재사용**: `string_prop_*`, `integer_prop_*`, `enum_prop`, `object_schema`
- **인터페이스**:

  ```rust
  pub fn string_prop_required(description: &str) -> Value
  pub fn integer_prop_with_default(min, max, default, description) -> Value
  pub fn enum_prop(values: Vec<&str>, default: &str) -> Value
  pub fn object_schema(props: HashMap, required: Vec<String>) -> Value
  ```

---

## 🧪 Test Code 가이드

### 단위 테스트 (Unit Tests)

#### **테스트 파일**: `src-tauri/src/mcp/builtin/workspace/terminal_manager.rs`

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use tokio::fs;

    #[tokio::test]
    async fn test_create_process_registry() {
        let registry = create_process_registry();
        assert!(registry.read().await.is_empty());
    }

    #[tokio::test]
    async fn test_tail_lines() {
        // Create temp file
        let temp_dir = std::env::temp_dir();
        let test_file = temp_dir.join("test_tail.txt");

        let content = "line1\nline2\nline3\nline4\nline5\n";
        fs::write(&test_file, content).await.unwrap();

        // Test tail
        let lines = tail_lines(&test_file, 3).await.unwrap();
        assert_eq!(lines.len(), 3);
        assert_eq!(lines[0], "line3");
        assert_eq!(lines[2], "line5");

        // Cleanup
        let _ = fs::remove_file(&test_file).await;
    }

    #[tokio::test]
    async fn test_tail_lines_max_limit() {
        let temp_dir = std::env::temp_dir();
        let test_file = temp_dir.join("test_tail_max.txt");

        // Create 200 lines
        let mut content = String::new();
        for i in 1..=200 {
            content.push_str(&format!("line{}\n", i));
        }
        fs::write(&test_file, content).await.unwrap();

        // Request 200 lines, should get max 100
        let lines = tail_lines(&test_file, 200).await.unwrap();
        assert_eq!(lines.len(), 100);
        assert_eq!(lines[0], "line101");
        assert_eq!(lines[99], "line200");

        // Cleanup
        let _ = fs::remove_file(&test_file).await;
    }

    #[tokio::test]
    async fn test_head_lines() {
        let temp_dir = std::env::temp_dir();
        let test_file = temp_dir.join("test_head.txt");

        let content = "line1\nline2\nline3\nline4\nline5\n";
        fs::write(&test_file, content).await.unwrap();

        let lines = head_lines(&test_file, 3).await.unwrap();
        assert_eq!(lines.len(), 3);
        assert_eq!(lines[0], "line1");
        assert_eq!(lines[2], "line3");

        let _ = fs::remove_file(&test_file).await;
    }
}
```

### 통합 테스트 (Integration Tests)

#### **테스트 파일**: `src-tauri/tests/workspace_async_execute.rs` (신규)

```rust
use serde_json::json;

#[tokio::test]
async fn test_async_execute_shell() {
    // Setup workspace server
    let session_manager = /* create test session manager */;
    let server = WorkspaceServer::new(session_manager);

    // Test 1: Async execute
    let args = json!({
        "command": "echo 'test output'",
        "run_mode": "async"
    });

    let response = server.handle_execute_shell(args).await;
    // Verify immediate response with process_id
    assert!(response.is_success());

    // Extract process_id from response
    let process_id = /* parse from response */;

    // Test 2: Poll process
    tokio::time::sleep(std::time::Duration::from_millis(100)).await;

    let poll_args = json!({
        "process_id": process_id,
        "tail": {
            "src": "stdout",
            "n": 10
        }
    });

    let poll_response = server.handle_poll_process(poll_args).await;
    // Verify status and output
    assert!(poll_response.is_success());

    // Test 3: Read output
    let read_args = json!({
        "process_id": process_id,
        "stream": "stdout",
        "mode": "tail",
        "lines": 20
    });

    let read_response = server.handle_read_process_output(read_args).await;
    assert!(read_response.is_success());
    // Verify "test output" in content
}

#[tokio::test]
async fn test_session_isolation() {
    // Create two sessions
    let session_a = /* ... */;
    let session_b = /* ... */;

    // Session A: execute command
    let server_a = WorkspaceServer::new(session_a);
    let response_a = server_a.handle_execute_shell(json!({
        "command": "echo 'session A'",
        "run_mode": "async"
    })).await;

    let process_id_a = /* extract process_id */;

    // Session B: try to poll Session A's process
    let server_b = WorkspaceServer::new(session_b);
    let response_b = server_b.handle_poll_process(json!({
        "process_id": process_id_a
    })).await;

    // Should get error: access denied
    assert!(response_b.is_error());
    assert!(response_b.error_message().contains("access denied"));
}

#[tokio::test]
async fn test_large_output_streaming() {
    let server = /* setup */;

    // Execute command with large output (e.g., 10MB)
    let response = server.handle_execute_shell(json!({
        "command": "seq 1 1000000",
        "run_mode": "async"
    })).await;

    let process_id = /* extract */;

    // Wait for completion
    tokio::time::sleep(std::time::Duration::from_secs(2)).await;

    // Verify file exists and has correct size
    let registry = server.process_registry.read().await;
    let entry = registry.get(&process_id).unwrap();
    assert!(entry.stdout_size > 1_000_000);

    // Read output should succeed and return max 100 lines
    let read_response = server.handle_read_process_output(json!({
        "process_id": process_id,
        "stream": "stdout",
        "lines": 100
    })).await;

    assert!(read_response.is_success());
    // Verify line count is exactly 100
}
```

### 테스트 체크리스트

- [ ] **Unit Tests**
  - [ ] `tail_lines()` 함수 (정상 케이스)
  - [ ] `tail_lines()` 최대 100줄 제한
  - [ ] `head_lines()` 함수
  - [ ] `get_file_size()` 함수
  - [ ] ProcessRegistry CRUD 연산

- [ ] **Integration Tests**
  - [ ] Async execute + poll (정상 완료)
  - [ ] Async execute + poll (실패 케이스)
  - [ ] read_process_output (stdout/stderr)
  - [ ] list_processes (필터링)
  - [ ] 세션 격리 (다른 세션 접근 불가)
  - [ ] 대용량 출력 스트리밍 (10MB+)
  - [ ] 동시 다중 프로세스 실행

- [ ] **Manual Tests**
  - [ ] 장시간 실행 명령어 (npm run dev)
  - [ ] 실시간 출력 확인 (tail -f)
  - [ ] 에러 발생 시 stderr 조회
  - [ ] 프로세스 완료 후 상태 확인

---

## 📝 추가 고려사항

### 1. 프로세스 정리 (Cleanup)

- **문제**: 오래된 프로세스 메타데이터 및 출력 파일 누적
- **해결책**:
  - 완료된 프로세스는 24시간 후 자동 삭제
  - `cleanup_old_processes()` 함수 추가 (백그라운드 태스크)
  - 세션 종료 시 해당 세션의 모든 프로세스 정리

### 2. 프로세스 강제 종료 (Kill)

- **Phase 2 기능** (현재 MVP 제외)
- `kill_process(process_id)` 도구 추가
- 모니터링 태스크와 통신하는 채널 필요 (`tokio::sync::mpsc`)

### 3. 보안 강화

- **세션 검증**: 모든 도구 호출 시 session_id 검증
- **경로 제한**: 출력 파일은 반드시 세션 워크스페이스 내부
- **리소스 제한**: 동시 실행 프로세스 수 제한 (예: 최대 20개)

### 4. 성능 최적화

- **파일 읽기**: 대용량 파일 tail 시 역방향 버퍼 읽기 최적화
- **레지스트리**: 완료된 프로세스는 별도 저장소로 이동 (메모리 절약)
- **출력 압축**: 오래된 출력 파일 자동 압축 (gzip)

### 5. 에러 처리

- **Spawn 실패**: 명령어 찾을 수 없음, 권한 부족 등
- **파일 쓰기 실패**: 디스크 공간 부족, 권한 문제
- **비정상 종료**: 시그널 kill, 시스템 재시작 등

---

## 📅 구현 일정 (예상)

### Phase 1: Core Infrastructure (2-3 days)

- [ ] Day 1: `terminal_manager.rs` 구현 및 단위 테스트
- [ ] Day 2: `mod.rs` 수정 (레지스트리 통합)
- [ ] Day 3: `code_execution.rs` async 로직 구현

### Phase 2: Tool Implementation (2-3 days)

- [ ] Day 4: `terminal_tools.rs` 스키마 정의
- [ ] Day 5: Poll/Read/List 핸들러 구현
- [ ] Day 6: 통합 테스트 작성

### Phase 3: Testing & Refinement (2-3 days)

- [ ] Day 7-8: 통합 테스트 실행 및 버그 수정
- [ ] Day 9: 매뉴얼 테스트 및 문서화

**Total**: 6-9 일 (약 1-1.5주)

---

## ✅ 체크리스트 (작업 시작 전)

- [ ] 코드 리뷰: 기존 `execute_shell` 동작 완전히 이해
- [ ] 테스트 환경: 개발/테스트용 세션 및 워크스페이스 준비
- [ ] 의존성 확인: `cuid2`, `chrono`, `tokio` 버전 호환성
- [ ] 보안 검토: 세션 격리 로직 검증
- [ ] 문서 업데이트: API 문서, 사용 가이드 작성 계획

---

## 🔗 참고 자료

### 프로젝트 문서

- [Chat Feature Architecture](../architecture/chat-feature-architecture.md)
- [Built-in Tools Documentation](../builtin-tools.md)
- [Coding Standards](../contributing/coding-standards.md)

### 외부 자료

- [Tokio Process Documentation](https://docs.rs/tokio/latest/tokio/process/)
- [MCP Protocol Specification](https://modelcontextprotocol.io/docs)

---

**Document Version**: 1.0  
**Last Updated**: 2025-10-10  
**Next Review**: After Phase 1 completion


---

# refactoring_20251101_1325.md

# Chat UI/UX 개선: Width Overflow 및 Rich Display 리팩토링 계획

## 📅 작성 일시

2025년 11월 1일 13:25

## 🎯 작업의 목적

Chat UI의 사용자 경험을 개선하기 위해 다음을 달성:

1. Agent 응답에서 width overflow 발생 시 적절한 스크롤 제공
2. Agent 메시지를 Rich하게 표시 (ChatGPT 스타일의 전체 너비 활용)
3. 코드 블록에 Syntax Highlighting 추가
4. Streaming 중 더 나은 Loading UI 제공
5. User 메시지는 간결한 버블, Agent는 Embedded 형태로 차별화

**핵심 목표**: idea.md의 요구사항을 충족하면서 overflow 문제를 해결하고 가독성을 향상

## 🔍 현재의 상태 / 문제점

### 1. Width Overflow 문제

- **ReactMarkdown 컴포넌트**: `pre`, `code` 태그에 overflow 처리 스타일이 없음
  - 긴 코드 라인이 버블 밖으로 넘침
  - 수평 스크롤 없음
  - `MessageRenderer.tsx` lines 402-418
- **전역 CSS**: `globals.css`에 markdown 관련 스타일 정의 없음

### 2. 메시지 레이아웃 제약

- **모든 메시지 역할에 동일한 너비 제한** (`MessageBubble.tsx` line 74)

  ```tsx
  max-w-[85%] lg:max-w-4xl
  ```

  - User 메시지도, Agent 메시지도 동일한 제약
  - idea.md 요구사항: Agent는 전체 너비 활용 필요

### 3. Syntax Highlighting 부재

- 현재 ReactMarkdown만 사용, syntax highlighting 없음
- 코드 블록이 단순 텍스트로 표시되어 가독성 저하

### 4. 단조로운 Loading UI

- `ChatMessages.tsx` lines 86-95: 단순 "thinking..." 텍스트
- 애니메이션이나 동적 효과 없음

## 🏗️ 관련 코드 구조 및 동작 방식 (Bird's Eye View)

### 컴포넌트 계층 구조

```text
Chat (Provider)
└─ ChatMessages (스크롤 컨테이너: overflow-y-auto)
    └─ MessageBubble (max-w-[85%] 제약)
        ├─ Header (아바타, 역할, 타임스탬프)
        ├─ Attachments (파일 목록)
        ├─ Thinking (스트리밍 상태)
        └─ MessageBubbleRouter
            ├─ ContentBubble → MessageRenderer
            │   └─ ReactMarkdown (텍스트)
            │       ├─ p, code, pre (스타일 없음)
            │       └─ ...
            │   └─ UIResourceRenderer (리소스)
            ├─ ToolCallBubble (BaseBubble)
            └─ ToolOutputBubble (BaseBubble)
```

### 데이터 플로우

1. `ChatContext` → `ChatMessages` → messages 배열
2. 각 message → `MessageBubble` (역할별 스타일 결정)
3. message.content (MCPContent[]) → `MessageRenderer`
4. Text content → `ReactMarkdown` 렌더링
5. Resource content → `UIResourceRenderer`

### Width 제한 지점

1. **MessageBubble**: `max-w-[85%] lg:max-w-4xl` (모든 역할 공통)
2. **BaseBubble**: `max-h-96 overflow-auto` (수직 스크롤만)
3. **ReactMarkdown**: 스타일 없음 (overflow 처리 안됨)

## ✨ 변경 이후의 상태 / 해결 판정 기준

### 성공 기준

1. ✅ 긴 코드 블록이 수평 스크롤로 처리됨 (버블 밖으로 나가지 않음)
2. ✅ Agent 메시지가 전체 너비 활용 (User는 기존 버블 유지)
3. ✅ 코드 블록에 syntax highlighting 적용
4. ✅ Loading UI가 애니메이션 효과와 함께 표시
5. ✅ 긴 텍스트 라인이 자동 줄바꿈됨
6. ✅ 기존 UI Resource (remoteDom, rawHtml) 정상 작동

### 테스트 시나리오

- [ ] 100자 이상의 긴 코드 라인 입력 시 수평 스크롤 확인
- [ ] Agent 메시지가 채팅 창 전체 너비 사용 확인
- [ ] User 메시지가 여전히 버블 형태 유지 확인
- [ ] Python, JavaScript, TypeScript 코드 블록 syntax highlighting 확인
- [ ] Streaming 중 로딩 애니메이션 표시 확인
- [ ] Tool Output의 UI Resource 정상 표시 확인

## 🔧 수정이 필요한 코드 및 코드 스니핏

### 1. MessageRenderer.tsx - Code Block Overflow 처리

**파일**: `src/components/MessageRenderer.tsx`
**위치**: lines 402-418

**현재 코드**:

```tsx
<ReactMarkdown
  skipHtml={false}
  remarkPlugins={[]}
  rehypePlugins={[]}
  components={{
    p: ({ children, ...props }) => <p {...props}>{children}</p>,
    code: ({ children, className }) => (
      <code className={className}>{children}</code>
    ),
    pre: ({ children, ...props }) => <pre {...props}>{children}</pre>,
  }}
>
  {textItem.text}
</ReactMarkdown>
```

**수정 후 코드**:

```tsx
<ReactMarkdown
  skipHtml={false}
  remarkPlugins={[]}
  rehypePlugins={[]}
  components={{
    p: ({ children, ...props }) => (
      <p className="mb-2 last:mb-0" {...props}>
        {children}
      </p>
    ),
    code: ({ inline, children, className, ...props }) => {
      // inline code vs block code 구분
      if (inline) {
        return (
          <code
            className="px-1.5 py-0.5 bg-muted rounded text-sm font-mono border border-border"
            {...props}
          >
            {children}
          </code>
        );
      }
      // block code (pre > code 구조에서 사용됨)
      return (
        <code className={`${className} block font-mono text-sm`} {...props}>
          {children}
        </code>
      );
    },
    pre: ({ children, ...props }) => (
      <pre
        className="overflow-x-auto bg-muted rounded-lg p-4 my-3 border border-border max-w-full"
        {...props}
      >
        {children}
      </pre>
    ),
    // 추가: 기타 마크다운 요소
    h1: ({ children, ...props }) => (
      <h1 className="text-2xl font-bold mb-3 mt-4" {...props}>
        {children}
      </h1>
    ),
    h2: ({ children, ...props }) => (
      <h2 className="text-xl font-bold mb-2 mt-3" {...props}>
        {children}
      </h2>
    ),
    h3: ({ children, ...props }) => (
      <h3 className="text-lg font-semibold mb-2 mt-2" {...props}>
        {children}
      </h3>
    ),
    ul: ({ children, ...props }) => (
      <ul className="list-disc list-inside mb-2 space-y-1" {...props}>
        {children}
      </ul>
    ),
    ol: ({ children, ...props }) => (
      <ol className="list-decimal list-inside mb-2 space-y-1" {...props}>
        {children}
      </ol>
    ),
    li: ({ children, ...props }) => (
      <li className="ml-2" {...props}>
        {children}
      </li>
    ),
    blockquote: ({ children, ...props }) => (
      <blockquote
        className="border-l-4 border-primary pl-4 italic my-2 text-muted-foreground"
        {...props}
      >
        {children}
      </blockquote>
    ),
    a: ({ children, href, ...props }) => (
      <a
        href={href}
        className="text-primary hover:underline"
        target="_blank"
        rel="noopener noreferrer"
        {...props}
      >
        {children}
      </a>
    ),
  }}
>
  {textItem.text}
</ReactMarkdown>
```

**외부 컨테이너에도 overflow 보호 추가** (line 385):

```tsx
<div key={key} className="group relative text-sm leading-relaxed overflow-x-hidden break-words">
```

### 2. MessageBubble.tsx - 역할별 차별화된 레이아웃

**파일**: `src/features/chat/MessageBubble.tsx`
**위치**: lines 24-73

**수정 전략**:

- User 메시지: 기존 버블 스타일 유지 (`max-w-[85%]`)
- Agent/Tool 메시지: 전체 너비 활용, 버블 스타일 최소화

**현재 코드** (line 74):

```tsx
<div
  className={`flex ${styles.container} mb-8 mt-3 animate-in fade-in slide-in-from-bottom-4 duration-500`}
>
  <div
    className={`max-w-[85%] lg:max-w-4xl ${styles.bubble} rounded-2xl px-5 py-4 backdrop-blur-sm transition-all duration-200 hover:shadow-xl`}
  >
```

**수정 후 코드**:

```tsx
<div
  className={`flex ${styles.container} mb-8 mt-3 animate-in fade-in slide-in-from-bottom-4 duration-500`}
>
  <div
    className={`${getBubbleContainerStyles()} ${styles.bubble} ${getBubblePaddingStyles()} backdrop-blur-sm transition-all duration-200 hover:shadow-xl`}
  >
```

**추가 함수**:

```tsx
const getBubbleContainerStyles = () => {
  if (isUser) {
    // User: 간결한 버블
    return 'max-w-[85%] lg:max-w-4xl rounded-2xl';
  } else if (isAssistant) {
    // Agent: 전체 너비, 최소 버블 스타일
    return 'w-full max-w-full rounded-lg border-l-4';
  } else {
    // Tool: 중간 크기
    return 'max-w-[90%] lg:max-w-5xl rounded-lg';
  }
};

const getBubblePaddingStyles = () => {
  if (isUser) {
    return 'px-5 py-4';
  } else if (isAssistant) {
    return 'px-6 py-5'; // Agent는 더 넓은 패딩
  } else {
    return 'px-4 py-3';
  }
};
```

### 3. ChatMessages.tsx - Loading UI 개선

**파일**: `src/features/chat/components/ChatMessages.tsx`
**위치**: lines 86-95

**현재 코드**:

```tsx
{
  isLoading && (
    <div className="flex justify-start">
      <div className="rounded px-3 py-2">
        <div className="text-xs mb-1">
          Agent ({currentSession?.assistants[0]?.name})
        </div>
        <div className="text-sm">thinking...</div>
      </div>
    </div>
  );
}
```

**수정 후 코드**:

```tsx
{
  isLoading && (
    <div className="flex justify-start mb-8 mt-3">
      <div className="w-full max-w-full bg-secondary/30 border-l-4 border-primary rounded-lg px-6 py-5">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-7 h-7 bg-primary rounded-full flex items-center justify-center animate-pulse">
            <Bot size={16} className="text-primary-foreground" />
          </div>
          <span className="text-xs font-medium">
            Agent ({currentSession?.assistants[0]?.name})
          </span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <div className="flex gap-1">
            <span className="animate-bounce" style={{ animationDelay: '0ms' }}>
              ●
            </span>
            <span
              className="animate-bounce"
              style={{ animationDelay: '150ms' }}
            >
              ●
            </span>
            <span
              className="animate-bounce"
              style={{ animationDelay: '300ms' }}
            >
              ●
            </span>
          </div>
          <span className="animate-pulse">Thinking and analyzing...</span>
        </div>
      </div>
    </div>
  );
}
```

### 4. Syntax Highlighting 추가 (Optional Enhancement)

**새 의존성 추가**:

```bash
pnpm add react-syntax-highlighter @types/react-syntax-highlighter
```

**MessageRenderer.tsx에 통합**:

```tsx
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';

// 테마 감지
const isDark = typeof window !== 'undefined' &&
  window.matchMedia('(prefers-color-scheme: dark)').matches;

// ReactMarkdown components 수정
code: ({ inline, children, className, ...props }) => {
  if (inline) {
    return (
      <code className="px-1.5 py-0.5 bg-muted rounded text-sm font-mono border border-border">
        {children}
      </code>
    );
  }

  // language 추출 (예: language-python)
  const match = /language-(\w+)/.exec(className || '');
  const language = match ? match[1] : 'text';

  return (
    <SyntaxHighlighter
      style={isDark ? oneDark : oneLight}
      language={language}
      PreTag="div"
      className="rounded-lg my-3 text-sm"
      customStyle={{
        margin: 0,
        borderRadius: '0.5rem',
        maxWidth: '100%',
      }}
      codeTagProps={{
        className: 'text-sm',
      }}
    >
      {String(children).replace(/\n$/, '')}
    </SyntaxHighlighter>
  );
},
pre: ({ children }) => <>{children}</>, // SyntaxHighlighter가 wrapper 제공
```

## 🔗 재사용 가능한 연관 코드

### 1. BaseBubble 컴포넌트

**파일**: `src/components/ui/BaseBubble.tsx`

- **주요 기능**: Collapsible 버블 UI (Tool Call/Output에 사용)
- **인터페이스**:
  ```tsx
  interface BaseBubbleProps {
    title: string;
    icon?: React.ReactNode;
    badge?: React.ReactNode;
    defaultExpanded?: boolean;
    copyData?: string;
    collapsedSummary?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
  }
  ```
- **재사용 가능**: Tool 관련 메시지에 이미 적용됨, 변경 불필요

### 2. UIResourceRenderer

**파일**: `@mcp-ui/client` (외부 라이브러리)

- **주요 기능**: MCP UI Resource 렌더링 (remoteDom, rawHtml, externalUrl)
- **사용 위치**: `MessageRenderer.tsx` lines 436-467
- **주의사항**: 이 부분은 수정하지 않고 유지

### 3. useClipboard Hook

**파일**: `src/hooks/useClipboard.ts`

- **주요 기능**: 클립보드 복사 기능
- **재사용**: Copy 버튼 구현에 이미 사용 중

### 4. 테마 감지 로직

**현재 위치**: `MessageBubble.tsx` lines 20-22

```tsx
const isDark =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-color-scheme: dark)').matches;
```

- **재사용 가능**: Syntax highlighting 테마 선택에 활용

## 🧪 Test Code 추가 및 수정 가이드

### 단위 테스트

#### 1. MessageRenderer 테스트

**파일**: `src/components/__tests__/MessageRenderer.test.tsx` (신규 생성)

````tsx
import { render, screen } from '@testing-library/react';
import { MessageRenderer } from '../MessageRenderer';
import type { MCPContent } from '@/lib/mcp-types';

describe('MessageRenderer', () => {
  it('renders code blocks with overflow scroll', () => {
    const content: MCPContent[] = [
      {
        type: 'text',
        text: '```python\nprint("very long line that should trigger horizontal scroll" * 10)\n```',
      },
    ];

    const { container } = render(<MessageRenderer content={content} />);
    const preElement = container.querySelector('pre');

    expect(preElement).toHaveClass('overflow-x-auto');
    expect(preElement).toHaveClass('max-w-full');
  });

  it('renders inline code with proper styling', () => {
    const content: MCPContent[] = [
      { type: 'text', text: 'This is `inline code` test' },
    ];

    render(<MessageRenderer content={content} />);
    const codeElement = screen.getByText('inline code');

    expect(codeElement.tagName).toBe('CODE');
    expect(codeElement).toHaveClass('bg-muted');
  });

  it('renders long text with word break', () => {
    const longText = 'verylongtextwithoutspaces'.repeat(20);
    const content: MCPContent[] = [{ type: 'text', text: longText }];

    const { container } = render(<MessageRenderer content={content} />);
    const wrapper = container.firstChild as HTMLElement;

    expect(wrapper).toHaveClass('break-words');
  });
});
````

#### 2. MessageBubble 레이아웃 테스트

**파일**: `src/features/chat/__tests__/MessageBubble.test.tsx` (신규 생성)

```tsx
import { render } from '@testing-library/react';
import MessageBubble from '../MessageBubble';
import type { Message } from '@/models/chat';

describe('MessageBubble Layout', () => {
  it('applies compact bubble style for user messages', () => {
    const userMessage: Message = {
      id: '1',
      role: 'user',
      content: [{ type: 'text', text: 'Hello' }],
      createdAt: new Date(),
    };

    const { container } = render(<MessageBubble message={userMessage} />);

    const bubble = container.querySelector('[class*="max-w-[85%]"]');
    expect(bubble).toBeInTheDocument();
    expect(bubble).toHaveClass('rounded-2xl');
  });

  it('applies full-width style for assistant messages', () => {
    const assistantMessage: Message = {
      id: '2',
      role: 'assistant',
      content: [{ type: 'text', text: 'Response' }],
      createdAt: new Date(),
    };

    const { container } = render(<MessageBubble message={assistantMessage} />);

    const bubble = container.querySelector('[class*="w-full"]');
    expect(bubble).toBeInTheDocument();
    expect(bubble).toHaveClass('border-l-4');
  });
});
```

### 통합 테스트

#### ChatMessages 통합 테스트

**파일**: `src/features/chat/__tests__/ChatMessages.integration.test.tsx`

```tsx
describe('ChatMessages Integration', () => {
  it('renders loading state with animation', () => {
    // Mock isLoading = true
    render(<ChatMessages />);

    const loadingElement = screen.getByText(/Thinking and analyzing/i);
    expect(loadingElement).toBeInTheDocument();
    expect(loadingElement).toHaveClass('animate-pulse');

    const dots = screen.getAllByText('●');
    expect(dots).toHaveLength(3);
  });

  it('scrolls to bottom on new message', async () => {
    const { rerender } = render(<ChatMessages />);

    // Add new message and verify scroll behavior
    // (구현 세부사항은 실제 테스트 환경에 맞게 조정)
  });
});
```

### E2E 테스트 시나리오 (Manual Testing Checklist)

```markdown
## Chat UI Overflow & Layout Testing

### Code Block Overflow

- [ ] 긴 Python 코드 입력 시 수평 스크롤 생성 확인
- [ ] 긴 JavaScript 코드 입력 시 수평 스크롤 생성 확인
- [ ] Inline code가 줄바꿈 없이 표시되는지 확인
- [ ] 코드 블록이 버블 밖으로 넘치지 않는지 확인

### Layout Differentiation

- [ ] User 메시지가 오른쪽 정렬, 최대 85% 너비 확인
- [ ] Agent 메시지가 왼쪽 정렬, 전체 너비 사용 확인
- [ ] Tool Output이 중간 크기 버블로 표시되는지 확인

### Loading State

- [ ] Streaming 시작 시 애니메이션 로딩 표시 확인
- [ ] "●●●" 점 애니메이션 작동 확인
- [ ] Avatar 아이콘 pulse 효과 확인

### Markdown Rendering

- [ ] 헤딩(h1, h2, h3) 스타일 적용 확인
- [ ] 리스트(ul, ol) 들여쓰기 확인
- [ ] 인용구(blockquote) 왼쪽 테두리 확인
- [ ] 링크가 새 탭에서 열리는지 확인

### Syntax Highlighting (Optional)

- [ ] Python 코드 syntax highlighting 확인
- [ ] JavaScript/TypeScript 코드 컬러링 확인
- [ ] 다크/라이트 모드에서 테마 전환 확인
```

## 📋 작업 순서 제안

### Phase 1: Critical Overflow 수정 (우선순위: 높음)

1. MessageRenderer.tsx의 ReactMarkdown components 스타일 추가
2. 외부 컨테이너에 `overflow-x-hidden`, `break-words` 추가
3. 수동 테스트: 긴 코드 입력 후 overflow 확인

### Phase 2: 레이아웃 차별화 (우선순위: 높음)

4. MessageBubble.tsx에 역할별 스타일 함수 추가
5. User/Agent/Tool 메시지 렌더링 후 레이아웃 확인
6. 반응형 동작 테스트 (모바일, 태블릿, 데스크톱)

### Phase 3: Loading UI 개선 (우선순위: 중간)

7. ChatMessages.tsx의 loading 상태 UI 교체
8. 애니메이션 효과 확인
9. 여러 에이전트 이름으로 테스트

### Phase 4: Syntax Highlighting (우선순위: 낮음, Optional)

10. react-syntax-highlighter 의존성 추가
11. MessageRenderer에 SyntaxHighlighter 통합
12. 주요 언어(Python, JS, TS, Java, Rust) 테스트
13. 다크/라이트 모드 테마 전환 확인

### Phase 5: 테스트 및 검증

14. 단위 테스트 작성 및 실행
15. 통합 테스트 작성
16. E2E 수동 테스트 체크리스트 완료
17. `pnpm refactor:validate` 실행

## ⚠️ 주의 사항

### Breaking Changes 방지

- `MessageRenderer`의 기존 props interface 유지
- `MessageBubble`의 외부 API 변경 없음
- `BaseBubble`, `UIResourceRenderer` 등 재사용 컴포넌트는 수정하지 않음

### 성능 고려사항

- ReactMarkdown components를 함수 컴포넌트로 정의하되, 가능한 React.memo 사용
- Syntax Highlighting은 Optional로 두고, 성능 저하 시 토글 기능 추가 고려
- 긴 메시지 렌더링 시 virtual scrolling 고려 (추후 개선)

### 접근성 (Accessibility)

- 코드 블록에 적절한 `aria-label` 추가
- 스크롤 가능한 영역에 키보드 네비게이션 지원
- 로딩 상태 애니메이션이 `prefers-reduced-motion` 존중

### 호환성

- Tauri 환경에서 window.matchMedia 사용 확인
- 외부 라이브러리(react-syntax-highlighter)의 번들 크기 확인
- 다크/라이트 모드 전환 시 깜빡임 없는지 확인

## 📊 추가 분석 과제

작업자가 구현 중 추가로 확인해야 할 사항들:

### 1. Markdown 렌더링 최적화

- **질문**: 매우 긴 메시지(수천 줄 코드)에서 ReactMarkdown 성능은?
- **분석 방향**:
  - 필요시 lazy loading이나 virtualization 고려
  - `react-window`나 `react-virtualized` 사용 검토

### 2. 스트리밍 중 레이아웃 Shift

- **질문**: Agent 메시지가 streaming되는 동안 레이아웃이 튀지 않는가?
- **분석 방향**:
  - `message.isStreaming` 상태에서 스타일 일관성 확인
  - 필요시 최소 높이(min-height) 설정

### 3. 모바일 반응형 동작

- **질문**: 작은 화면에서 전체 너비 Agent 메시지가 적절한가?
- **분석 방향**:
  - 768px 이하에서 패딩 조정 필요성 검토
  - 모바일에서 수평 스크롤 제스처 테스트

### 4. Tool Output의 UI Resource

- **질문**: ToolOutputBubble에서 `expandResources={true}` 전달 시 문제 없는가?
- **분석 방향**:
  - `ToolOutputBubble.tsx` line 26의 `expandResources` prop 동작 확인
  - Resource가 매우 클 때 스크롤 동작 검증

### 5. Copy 버튼 위치 조정

- **질문**: 전체 너비 Agent 메시지에서 Copy 버튼이 적절한 위치에 있는가?
- **분석 방향**:
  - `MessageRenderer.tsx` line 389의 Copy 버튼이 잘 보이는지 확인
  - 필요시 sticky position 고려

## 🎯 Clarification Q-list

구현 전 사용자의 의사 결정이 필요한 사항들:

### Q1: Syntax Highlighting 라이브러리 선택

**질문**: `react-syntax-highlighter`를 사용할 것인가, 아니면 더 가벼운 대안을 사용할 것인가?

- **옵션 A**: `react-syntax-highlighter` (풍부한 기능, 번들 크기 큼)
- **옵션 B**: `prism-react-renderer` (가벼움, 제한적 언어 지원)
- **옵션 C**: Syntax highlighting 제외하고 단순 스타일만 (Phase 4 생략)

**권장**: 옵션 A (react-syntax-highlighter) - 가장 많이 사용되고 안정적

### Q2: Agent 메시지 레이아웃 스타일

**질문**: Agent 메시지에 버블 스타일을 완전히 제거할 것인가, 최소한으로 유지할 것인가?

- **옵션 A**: 완전 제거 (ChatGPT 스타일, 평평한 레이아웃)
- **옵션 B**: 최소 유지 (border-l-4, 약간의 배경색)
- **옵션 C**: 현재처럼 버블 유지, 너비만 확장

**권장**: 옵션 B - 구분을 위한 최소한의 시각적 요소 유지

### Q3: Loading UI 애니메이션 강도

**질문**: "Thinking..." 로딩 애니메이션을 얼마나 동적으로 만들 것인가?

- **옵션 A**: 단순 점 애니메이션 (제안된 코드)
- **옵션 B**: 단계별 메시지 변경 ("Thinking..." → "Analyzing..." → "Generating...")
- **옵션 C**: Progress bar 추가

**권장**: 옵션 A로 시작, 사용자 피드백 후 옵션 B 고려

### Q4: 모바일에서 Agent 메시지 너비

**질문**: 모바일 화면(< 768px)에서도 Agent 메시지가 전체 너비를 사용해야 하는가?

- **옵션 A**: 모든 화면 크기에서 전체 너비
- **옵션 B**: 모바일에서는 User처럼 제한된 너비 (max-w-[95%])

**권장**: 옵션 A - 일관성 유지, 단 패딩 조정

### Q5: 테스트 범위

**질문**: 어느 수준까지 테스트를 작성할 것인가?

- **옵션 A**: 단위 테스트만 (Phase 5의 일부)
- **옵션 B**: 단위 + 통합 테스트
- **옵션 C**: 단위 + 통합 + E2E 자동화

**권장**: 옵션 B - 핵심 기능에 대한 단위/통합 테스트, E2E는 수동

---

**다음 단계**: 위 Clarification Q-list에 대한 결정 후 Phase 1부터 순차 진행


---

# refactoring_20251009_1545.md

# Message Persistence → Backend SQLite (Development-mode)

**작성일**: 2025-10-09 15:45  
**작업자**: AI Agent  
**관련 이슈**: 메시지 저장소를 frontend(IndexedDB)에서 backend(SQLite)로 전환 (개발 모드, 마이그레이션 없음)

## 작업의 목적

- 개발 모드에서 메시지 저장을 일관된 로컬 백엔드(SQLite)에 두어 서버/백엔드 로직과 동일한 환경에서 개발 및 디버그를 진행할 수 있게 합니다.
- IndexedDB 기반의 프론트엔드 저장소를 운영/동기화하는 추가 복잡성을 제거합니다(마이그레이션 미실시).

## 현재의 상태 / 문제점

- 현재 메시지 저장/조회는 프론트엔드 IndexedDB(Dexie)에서 수행됩니다 (`src/lib/db/crud.ts`, `SessionHistoryContext.tsx`).
- 프런트엔드에서만 저장되면 백엔드 테스트 시 데이터 일관성/재현성이 낮고, 서버 쪽 테스트가 어렵습니다.
- 메시지 성능/페이징, 백엔드 쿼리 최적화 및 보안/권한 모델을 백엔드에서 테스트 불가능합니다.

## Birdeye View (동작 흐름)

기존(간단):

```text
UI -> SessionHistoryContext -> dbService.messages (IndexedDB)
```

변경(개발 모드):

```text
UI -> SessionHistoryContext (mutate optimistic) -> safeInvoke -> Tauri command -> Rust backend -> sqlite (local)
```

핵심 포인트: 낙관적 업데이트(optimistic mutate)는 유지합니다. 실패 시 롤백 로직은 기존과 동일하게 동작합니다.

## 변경 이후의 상태 / 해결 판정 기준

성공 기준:

1. `SessionHistoryContext`와 기존 UI는 변경 없이 메시지 작성/삭제/수정이 동작한다. (API 변경은 내부적인 호출 대상 변경)
2. `cargo build` 성공 및 Tauri 명령이 정상적으로 호출되어 메시지가 SQLite에 영속화된다.
3. 페이지네이션(페이징) 지원: `messages_get_page(sessionId, page, pageSize)` 명령이 `Page<Message>` 형태로 정확한 메타(총 건수, hasNext, hasPrevious)를 반환한다.
4. 단위/통합 테스트 통과(즉시 작성한 테스트 기준).

## 수정이 필요한 코드 및 수정부분 (파일/심볼, 최소 변경)

Backend (Rust) — 새 파일/수정

- `src-tauri/src/models/message.rs` (없다면 생성)
  - serde Serialize/Deserialize 가능한 `Message` 타입 정의
- `src-tauri/src/db/messages.rs` (신규 또는 기존 DB 레이어에 추가)
  - `get_messages_page(pool, session_id, page, page_size) -> Page<Message>`
  - `upsert_messages(pool, messages)`
  - `upsert_message(pool, message)`
  - `delete_message(pool, message_id)`
  - `delete_all_for_session(pool, session_id)`
- `src-tauri/src/commands/messages_commands.rs` (신규)
  - Tauri commands로 노출(아래 코드 스니펫 참고)
- `src-tauri/src/commands/mod.rs` (수정)
  - `pub mod messages_commands;` 및 `pub use messages_commands::*;` 추가

Frontend (TypeScript) — 수정

- `src/lib/rust-backend-client.ts` (중요: typesafe 인터페이스)
  - 단순한 raw `safeInvoke` 호출을 직접내보내는 대신, 각 Tauri 명령에 대해 타입 안전한 트랜스페어런트 인터페이스를 정의합니다.
  - 제공 항목(예시):
    - `getMessagesPageForSession(sessionId: string, page: number, pageSize: number): Promise<Page<Message>>`
    - `upsertMessages(messages: Message[]): Promise<void>` / `upsertMessage(message: Message): Promise<void>`
    - `deleteMessage(messageId: string): Promise<void>` / `deleteAllMessagesForSession(sessionId: string): Promise<void>`
  - 이 함수들은 내부적으로 `safeInvoke()`를 사용하지만, 호출부는 문자열 명령 이름이나 untyped payload를 직접 다루지 않습니다.
  - 장점: 컴파일 타임 타입 검사, 자동완성, 변경 영향 범위 축소, 테스트 용이성
  - 구현 옵션:
    1. 수동 작성: 각 함수에 명확한 시그니처를 제공하는 wrapper를 수동으로 추가
    2. 코드 생성: Rust 타입(serde)로부터 TS 타입 선언(.d.ts)과 wrapper를 자동 생성하는 스크립트(선택)

- `src/context/SessionHistoryContext.tsx`
  - SWR fetcher: `dbUtils.getMessagesPageForSession` -> `backend.getMessagesPageForSession`
  - persistence 호출: `dbService.messages.*` -> `backend` 호출
  - 낙관적 업데이트(mutate) 로직은 동일하게 유지
- `src/lib/db/crud.ts` (선택)
  - `messagesCRUD`를 직접 바꾸거나 `backendMessagesCRUD`를 추가하여 `dbService`에서 사용하도록 전환(개발 모드 편의)

## 핵심 코드 스니펫

1. SQL (DB 초기화에 추가)

```sql
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  role TEXT,
  content TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  metadata TEXT
);
CREATE INDEX IF NOT EXISTS idx_messages_session_created ON messages(session_id, created_at);
```

### Rust: `Message` 타입

```rust
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
  pub id: String,
  pub session_id: String,
  pub role: Option<String>,
  pub content: Option<String>,
  pub created_at: i64,
  pub updated_at: i64,
  pub metadata: Option<serde_json::Value>,
}
```

### Rust: `Page<T>` 타입 (공통)

```rust
use serde::{Serialize, Deserialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct Page<T> {
  pub items: Vec<T>,
  pub page: usize,
  pub page_size: isize,
  pub total_items: usize,
  pub has_next_page: bool,
  pub has_previous_page: bool,
}
```

### Rust: paginated query (sqlx 예시)

```rust
pub async fn get_messages_page(
  pool: &SqlitePool,
  session_id: &str,
  page: usize,
  page_size: usize,
) -> Result<Page<Message>, anyhow::Error> {
  if page_size == 0 { anyhow::bail!("page_size must be > 0"); }
  let offset = (page.saturating_sub(1)) as i64 * page_size as i64;

  let total: i64 = sqlx::query_scalar!("SELECT COUNT(1) FROM messages WHERE session_id = ?", session_id)
    .fetch_one(pool)
    .await?;

  let rows: Vec<Message> = sqlx::query_as!(
    Message,
    "SELECT id, session_id, role, content, created_at as \"created_at: i64\", updated_at as \"updated_at: i64\", metadata
     FROM messages WHERE session_id = ?
     ORDER BY created_at ASC
     LIMIT ? OFFSET ?",
    session_id,
    page_size as i64,
    offset
  )
  .fetch_all(pool)
  .await?;

  let total_usize = total as usize;
  let has_prev = page > 1;
  let has_next = page * page_size < total_usize;

  Ok(Page {
    items: rows,
    page,
    page_size: page_size as isize,
    total_items: total_usize,
    has_next_page: has_next,
    has_previous_page: has_prev,
  })
}
```

5. Rust: Tauri commands (`src-tauri/src/commands/messages_commands.rs`)

```rust
use tauri::command;
use crate::db::messages as messages_db;
use crate::models::Message;

#[command]
async fn messages_get_page(session_id: String, page: u32, page_size: u32) -> Result<Page<Message>, String> {
  let pool = get_sqlite_pool();
  messages_db::get_messages_page(&pool, &session_id, page as usize, page_size as usize)
    .await
    .map_err(|e| e.to_string())
}

#[command]
async fn messages_upsert_many(messages: Vec<Message>) -> Result<(), String> {
  let pool = get_sqlite_pool();
  messages_db::upsert_messages(&pool, messages).await.map_err(|e| e.to_string())
}

#[command]
async fn messages_upsert(message: Message) -> Result<(), String> {
  let pool = get_sqlite_pool();
  messages_db::upsert_message(&pool, message).await.map_err(|e| e.to_string())
}

#[command]
async fn messages_delete(message_id: String) -> Result<(), String> {
  let pool = get_sqlite_pool();
  messages_db::delete_message(&pool, &message_id).await.map_err(|e| e.to_string())
}

#[command]
async fn messages_delete_all_for_session(session_id: String) -> Result<(), String> {
  let pool = get_sqlite_pool();
  messages_db::delete_all_for_session(&pool, &session_id).await.map_err(|e| e.to_string())
}
```

6. Frontend: `rust-backend-client.ts` wrappers

```ts
export async function getMessagesPageForSession(
  sessionId: string,
  page: number,
  pageSize: number,
) {
  return safeInvoke<Page<Message>>('messages_get_page', {
    sessionId,
    page,
    pageSize,
  });
}

export async function upsertMessages(messages: Message[]) {
  return safeInvoke<void>('messages_upsert_many', { messages });
}

export async function upsertMessage(message: Message) {
  return safeInvoke<void>('messages_upsert', { message });
}

export async function deleteMessage(messageId: string) {
  return safeInvoke<void>('messages_delete', { messageId });
}

export async function deleteAllMessagesForSession(sessionId: string) {
  return safeInvoke<void>('messages_delete_all_for_session', { sessionId });
}
```

7. Frontend: `SessionHistoryContext.tsx` 변경 요약

- SWR fetcher 변경: `dbUtils.getMessagesPageForSession(sessionId, page, PAGE_SIZE)` -> `backend.getMessagesPageForSession(sessionId, page, PAGE_SIZE)`
- 저장/삭제 호출 변경: `dbService.messages.*` -> `backend.*` (위 wrapper 호출)
- 낙관적 업데이트(mutative) 로직은 유지 (revalidate: false, 실패 시 rollback)

## 재사용 가능한 연관 코드

- `src/context/SessionHistoryContext.tsx`: 페이징, 낙관적 업데이트 로직(수정 없음)
- `src/lib/db/crud.ts`: 기존 messages CRUD가 IndexedDB용으로 정의되어 있음(교체 또는 대체 wrapper 사용)
- `src-tauri/src/db/storage.rs` 또는 유사 DB 초기화 코드: sqlite pool 초기화 및 마이그레이션 로직에 messages 테이블 추가

## Test Code 추가 및 수정 가이드

### Rust 단위/통합 테스트

- `get_messages_page`: 빈 세션, 첫 페이지, 마지막 페이지, 페이지 초과 케이스
- `upsert_messages`: 중복 id, 트랜잭션 롤백 시나리오
- `delete_all_for_session`: 트랜잭션 무결성

### Frontend 테스트 (Vitest/Jest)

- `SessionHistoryContext`의 optimistic mutate: 성공시 유지, 실패시 rollback
- SWR 페이징 종료 조건: `hasNextPage`가 false일 때 더 이상 fetch하지 않음

## 위험 요소 및 대응 방안

| 위험                           | 영향도 | 대응                                                     |
| ------------------------------ | -----: | -------------------------------------------------------- |
| 타입 불일치(serde vs TS)       |   높음 | Message 타입 사전 동기화, 작은 스펙(primitive 타입) 유지 |
| 동시성 충돌                    |   중간 | updated_at 기준 last-writer-wins, DB 트랜잭션 사용       |
| UI/서버 간 페이징 방향 불일치  |   중간 | ORDER BY(ASC/DESC) 규칙 정하고 프런트/백엔드 동기화      |
| 빌드/명령 노출 실수 (`mod.rs`) |   낮음 | 변경 전 `mod.rs` 상태 확인 후 최소 변경으로 병합         |

## 예상 작업 시간 (개발 모드, 대략)

- Backend (DB 레이어 + commands + tests): 2–3시간
- Frontend (wrappers + SessionHistoryContext 변경 + tests): 1–2시간
- Smoke & validation: 0.5–1시간
- 총합: 3.5–6시간

## 파일 규칙

- 본 문서는 `docs/history/refactoring_20251009_1545.md`에 기록했습니다. 제출 시 동일한 규칙(`refactoring_{yyyyMMdd_hhmm}.md`)을 따라 주세요.

## 다음 단계 (권장 순서)

1. `src-tauri/src/models/message.rs` 및 DB 테이블 생성 코드 추가(파일 작성).
2. `src-tauri/src/db/messages.rs`의 DB 함수 구현 및 유닛 테스트 추가.
3. `src-tauri/src/commands/messages_commands.rs`에 Tauri 명령을 추가.
4. `src-tauri/src/commands/mod.rs`에 모듈 노출(주의: 현재 되돌린 상태였으니 파일 확인 후 적용).
5. `src/lib/rust-backend-client.ts`에 wrapper 추가.
6. `SessionHistoryContext.tsx`에서 fetcher/persistence 라우팅 변경.
7. 로컬 개발에서 빌드/작동 확인, 프론트엔드 자동화 테스트 실행.

---

필요하면 제가 이 순서대로 바로 코드를 생성/수정해 드릴게요 — 먼저 어떤 파일부터 만들까요? (추천: 백엔드 `messages_commands.rs` + DB 레이어 먼저.)


---

# refactoring_20250201_1400.md

# MCP Server Management Architecture Refactoring

**Date:** 2025-02-01 14:00  
**Author:** Development Team  
**Status:** Planning

---

## 목적 (Purpose)

MCP 서버 설정을 독립적인 엔티티로 분리하여 관리의 유연성과 재사용성을 향상시킨다. 현재 Assistant가 MCP 설정을 직접 embedding하는 구조를 개선하여, MCP 서버를 중앙에서 관리하고 Assistant는 참조만 하도록 변경한다.

**주요 목표:**

- MCP 서버 설정의 중복 제거 및 중앙 관리
- Assistant 편집 UI 단순화 (MCP 설정 분리)
- MCP 서버 관리 전용 UI 제공 (Settings)
- 확장 가능한 MCP 서버 선택 인터페이스

---

## 현재 상태 / 문제점

### 현재 구조

```typescript
// Assistant가 MCPConfig를 직접 포함
interface Assistant {
  id?: string;
  name: string;
  systemPrompt: string;
  mcpConfig: MCPConfig; // ❌ 전체 설정 embedding
  // ...
}

interface MCPConfig {
  mcpServers?: Record<string, MCPServerConfigV2 | LegacyMCPServerConfig>;
}
```

### 문제점

1. **중복 저장**: 여러 Assistant가 동일한 MCP 서버 설정을 중복 저장

   ```typescript
   // Assistant A
   { mcpConfig: { mcpServers: { filesystem: {...} } } }

   // Assistant B (동일한 filesystem 설정 중복)
   { mcpConfig: { mcpServers: { filesystem: {...} } } }
   ```

2. **유지보수 어려움**: MCP 서버 설정 변경 시 모든 Assistant를 찾아 업데이트 필요

3. **UI 복잡도**: Assistant 편집 = MCP 전체 설정 편집
   - `MCPConfigEditor` 컴포넌트가 JSON 텍스트 편집
   - 사용자가 MCP 프로토콜 스펙을 이해해야 함

4. **관리 기능 부족**:
   - MCP 서버 목록 조회 불가
   - 서버별 활성화/비활성화 불가
   - 서버 재사용 어려움

### 데이터 흐름 (현재)

```
AssistantEditor
  ├─ MCPConfigEditor (JSON 텍스트)
  │   └─ assistant.mcpConfig 직접 수정
  │
  └─ AssistantContext.saveAssistant()
      └─ IndexedDB에 전체 assistant 저장 (mcpConfig 포함)

ChatContext
  └─ MCPServerContext.connectServers(assistant.mcpConfig)
      └─ Rust Backend: list_tools_from_config()
          └─ MCP 서버 프로세스 spawn
```

---

## 변경 후 상태 / 해결 판정 기준

### 새로운 구조

```typescript
// MCP 서버를 독립적인 엔티티로
interface MCPServerEntity {
  // DB metadata
  id: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;

  // MCP protocol spec
  name: string;
  transport: TransportConfig;
  authentication?: OAuthConfig;
  metadata?: ServerMetadata;
}

// Assistant는 MCP 서버 ID만 참조
interface Assistant {
  id?: string;
  name: string;
  systemPrompt: string;
  mcpServerIds?: string[]; // ✅ ID 배열만 저장
  // ...
}
```

### 데이터 흐름 (변경 후)

```
Settings > MCPServerManagement
  ├─ MCP 서버 목록 표시 (pagination)
  ├─ MCPServerDialog로 개별 서버 편집
  └─ MCPServerRegistryContext
      └─ IndexedDB mcpServers 테이블

AssistantEditor
  ├─ 활성 MCP 서버 목록 조회
  ├─ Checkbox로 서버 선택/해제
  └─ assistant.mcpServerIds 업데이트

ChatContext
  └─ MCPServerContext.connectServersFromAssistant(assistant)
      ├─ assistant.mcpServerIds로 DB 조회
      ├─ MCPServerEntity[] → MCPConfig 변환
      └─ Rust Backend: list_tools_from_config()
```

### 성공 판정 기준

✅ **기능적 요구사항**

- [ ] Settings에서 MCP 서버 CRUD 가능
- [ ] MCP 서버 활성화/비활성화 토글 가능
- [ ] Assistant 편집 시 활성 서버 목록에서 선택 가능
- [ ] 선택된 MCP 서버들이 Chat에서 정상 작동
- [ ] Pagination으로 다수의 MCP 서버 관리 가능

✅ **비기능적 요구사항**

- [ ] 중복 데이터 제거 (MCP 설정 단일 저장소)
- [ ] Assistant 편집 UI 단순화 (JSON 편집 제거)
- [ ] 검색 기능으로 서버 필터링 가능
- [ ] DB Schema 단일 버전으로 단순화

---

## 관련 코드 구조 및 동작 방식 (Birdeye View)

### 현재 아키텍처

```
Frontend (React)
├─ Context Layer
│   ├─ AssistantContext
│   │   ├─ currentAssistant (includes mcpConfig)
│   │   └─ saveAssistant() → IndexedDB
│   │
│   └─ MCPServerContext
│       ├─ connectServers(mcpConfig)
│       └─ executeToolCall()
│
├─ UI Layer
│   ├─ AssistantEditor
│   │   ├─ MCPConfigEditor (JSON 텍스트)
│   │   └─ EditorContext
│   │
│   └─ SettingsPage
│       └─ API Key Settings only
│
└─ Database Layer
    └─ IndexedDB (Dexie)
        ├─ assistants (includes mcpConfig)
        ├─ sessions
        └─ messages

Backend (Rust)
└─ MCP Commands
    └─ list_tools_from_config(MCPConfig)
        ├─ Parse V1/V2 configs
        ├─ Spawn MCP server processes
        └─ List tools from servers
```

### 새로운 아키텍처

```
Frontend (React)
├─ Context Layer
│   ├─ MCPServerRegistryContext ✅ NEW
│   │   ├─ allServers, activeServers
│   │   ├─ Pagination support (SWRInfinite 패턴 재사용)
│   │   └─ CRUD operations
│   │
│   ├─ AssistantContext (modified)
│   │   ├─ currentAssistant (mcpServerIds only)
│   │   └─ saveAssistant()
│   │
│   └─ MCPServerContext (modified)
│       ├─ connectServersFromAssistant(assistant)
│       │   └─ Load MCPServerEntity by IDs
│       └─ executeToolCall()
│
├─ UI Layer
│   ├─ Settings
│   │   └─ MCPServerManagement ✅ NEW
│   │       ├─ Server list (pagination)
│   │       ├─ Add/Edit/Delete buttons
│   │       └─ MCPServerDialog
│   │           └─ Transport-specific forms
│   │
│   └─ AssistantEditor (simplified)
│       ├─ Server selection (checkboxes)
│       ├─ Search filter
│       └─ NO MCPConfigEditor
│
└─ Database Layer
    └─ IndexedDB (Dexie)
        ├─ assistants (mcpServerIds only)
        ├─ mcpServers ✅ NEW
        ├─ sessions
        └─ messages

Backend (Rust)
└─ MCP Commands (unchanged)
    └─ list_tools_from_config(MCPConfig)
```

---

## 수정이 필요한 코드 및 코드 스니핏

### Phase 1: 타입 정의

#### 1.1 MCPServerEntity 추가

**파일:** `src/models/chat.ts`

```typescript
// 추가: MCP 서버 엔티티
export interface MCPServerEntity {
  // Database metadata
  id: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;

  // MCP Protocol spec (from MCPServerConfigV2)
  name: string;
  transport: TransportConfig;
  authentication?: OAuthConfig;
  metadata?: ServerMetadata;
}
```

#### 1.2 Assistant 타입 수정

**파일:** `src/models/chat.ts`

```typescript
// 수정: mcpConfig 제거, mcpServerIds 추가
export interface Assistant {
  id?: string;
  name: string;
  description?: string;
  avatar?: string;
  systemPrompt: string;

  mcpServerIds?: string[]; // ✅ 추가
  // mcpConfig: MCPConfig;  // ❌ 제거

  localServices?: string[];
  allowedBuiltInServiceAliases?: string[];
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
}
```

### Phase 2: Database Schema

#### 2.1 Schema 단순화 및 mcpServers 테이블 추가

**파일:** `src/lib/db/service.ts`

````typescript
// 수정: 단일 버전으로 squash
constructor() {
  super('MCPAgentDB');

  this.version(1).stores({
    assistants: '&id, createdAt, updatedAt, name',
    mcpServers: '&id, name, createdAt, updatedAt, isActive',  // ✅ 추가
    sessions: '&id, createdAt, updatedAt',
    messages: '&id, sessionId, [sessionId+threadId], createdAt',
    playbooks: '&id, agentId, createdAt, updatedAt, goal',
    objects: '&key, createdAt, updatedAt',
  });
}

// Table 선언 추가
#### 4.1 MCPServerManagement 생성
**파일:** `src/features/settings/MCPServerManagement.tsx` (신규)

```typescript
import { useMemo, useState } from 'react';
import useSWRInfinite from 'swr/infinite';
import { Plus } from 'lucide-react';
import { createId } from '@paralleldrive/cuid2';
import { MCPServerEntity } from '@/models/chat';
import { dbService } from '@/lib/db/service';
import { useMCPServerRegistry } from '@/context/MCPServerRegistryContext';
import { Button, Card, CardHeader, CardTitle, CardContent } from '@/components/ui';
import { MCPServerDialog } from './MCPServerDialog';

export function MCPServerManagement() {
  const { saveServer, deleteServer, toggleActive } = useMCPServerRegistry();

  // Follow SessionContext pattern: useSWRInfinite + Page<T>
  const { data, isLoading, isValidating, setSize } = useSWRInfinite(
    (pageIndex) => ['mcpServers', pageIndex],
    async ([, pageIndex]) => {
      // getPage is 1-based; pass pageIndex + 1
      return dbService.mcpServers.getPage(pageIndex + 1, 10);
    },
  );

  const pages = data ?? [];
  const servers = useMemo(() => pages.flatMap((p) => p.items), [pages]);
  const hasNextPage = useMemo(
    () => !(pages.length > 0 && !pages[pages.length - 1].hasNextPage),
    [pages],
  );

  const [editingServer, setEditingServer] = useState<MCPServerEntity | null>(
    null,
  );

  const handleCreateNew = () => {
    const newServer: MCPServerEntity = {
      id: createId(),
      name: 'New Server',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      transport: {
        type: 'stdio',
        command: 'npx',
        args: [],
      },
    };
    setEditingServer(newServer);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">MCP Server Management</h2>
        <Button onClick={handleCreateNew}>
          <Plus className="w-4 h-4 mr-2" />
          Add Server
        </Button>
      </div>

      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <>
          <div className="grid gap-4">
            {servers.map((server) => (
              <Card key={server.id}>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div className="flex-1">
                    <CardTitle>{server.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {server.metadata?.description || 'No description'}
                    </p>
                  </div>
                  <Switch
                    checked={server.isActive}
                    onCheckedChange={(checked) =>
                      toggleActive(server.id, checked)
                    }
                  />
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingServer(server)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (confirm(`Delete server "${server.name}"?`)) {
                          deleteServer(server.id);
                        }
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {hasNextPage && (
            <div className="flex justify-center pt-2">
              <Button
                variant="outline"
                disabled={isValidating}
                onClick={() => setSize((s) => s + 1)}
              >
                {isValidating ? 'Loading…' : 'Load more'}
              </Button>
            </div>
          )}
        </>
      )}

      {editingServer && (
        <MCPServerDialog
          server={editingServer}
          onSave={async (server) => {
            await saveServer(server);
            setEditingServer(null);
          }}
          onCancel={() => setEditingServer(null)}
        />
      )}
    </div>
  );
}
````

// Pagination (Settings용)
servers: MCPServerEntity[];
currentPage: number;
totalPages: number;
pageSize: number;
loading: boolean;
error?: string;

// Actions
loadPage: (page: number) => Promise<void>;
saveServer: (server: MCPServerEntity) => Promise<void>;
deleteServer: (id: string) => Promise<void>;
toggleActive: (id: string, active: boolean) => Promise<void>;
refreshAll: () => Promise<void>;
}

const MCPServerRegistryContext = createContext<MCPServerRegistryContextType | undefined>(undefined);

export const MCPServerRegistryProvider = ({ children }: { children: React.ReactNode }) => {
const [allServers, setAllServers] = useState<MCPServerEntity[]>([]);
const [servers, setServers] = useState<MCPServerEntity[]>([]);
const [currentPage, setCurrentPage] = useState(1);
const [pageSize] = useState(10);
const [loading, setLoading] = useState(false);
const [error, setError] = useState<string>();

// 전체 서버 로드 (캐시)
const refreshAll = useCallback(async () => {
try {
const all = await dbUtils.getAllMCPServers();
setAllServers(all);
} catch (err) {
logger.error('Failed to load all servers', err);
setError(err instanceof Error ? err.message : 'Unknown error');
}
}, []);

// Pagination 로드
const loadPage = useCallback(async (page: number) => {
setLoading(true);
try {
const result = await dbService.mcpServers.getPage(page, pageSize);
setServers(result.items);
setCurrentPage(page);
setError(undefined);
} catch (err) {
logger.error('Failed to load page', err);
setError(err instanceof Error ? err.message : 'Unknown error');
} finally {
setLoading(false);
}
}, [pageSize]);

const saveServer = useCallback(async (server: MCPServerEntity) => {
await dbService.mcpServers.upsert(server);
await refreshAll();
await loadPage(currentPage);
}, [refreshAll, loadPage, currentPage]);

const deleteServer = useCallback(async (id: string) => {
await dbService.mcpServers.delete(id);
await refreshAll();
await loadPage(currentPage);
}, [refreshAll, loadPage, currentPage]);

const toggleActive = useCallback(async (id: string, active: boolean) => {
const server = allServers.find(s => s.id === id);
if (server) {
await saveServer({ ...server, isActive: active });
}
}, [allServers, saveServer]);

const activeServers = useMemo(
() => allServers.filter(s => s.isActive),
[allServers]
);

const totalPages = useMemo(
() => Math.ceil(allServers.length / pageSize),
[allServers.length, pageSize]
);

// 초기 로드
useEffect(() => {
refreshAll();
loadPage(1);
}, [refreshAll, loadPage]);

return (
<MCPServerRegistryContext.Provider value={{
      allServers,
      activeServers,
      servers,
      currentPage,
      totalPages,
      pageSize,
      loading,
      error,
      loadPage,
      saveServer,
      deleteServer,
      toggleActive,
      refreshAll,
    }}>
{children}
</MCPServerRegistryContext.Provider>
);
};

export function useMCPServerRegistry() {
const context = useContext(MCPServerRegistryContext);
if (!context) {
throw new Error('useMCPServerRegistry must be used within MCPServerRegistryProvider');
}
return context;
}

````

#### 3.x 캐시 무효화 전략 (SWR + 이벤트)

레지스트리 변경 시 다음을 수행해 목록/선택/연결 상태를 일관성 있게 갱신합니다.

- 목록 UI(Settings): SWR 키 `['mcpServers', pageIndex]` 전역 무효화 → useSWRInfinite가 재검증
- 선택 UI(AssistantEditor): 레지스트리 컨텍스트의 `allServers/activeServers`를 즉시 새로고침
- 연결 상태(Chat): 현재 Assistant가 참조하는 서버에 영향이 있는 경우 재연결 트리거

구현 요지:

```typescript
// src/context/MCPServerRegistryContext.tsx
import { mutate } from 'swr';

const invalidateMCPServerPages = async () => {
  await mutate((key) => Array.isArray(key) && key[0] === 'mcpServers');
};

const broadcastChange = () => {
  if (typeof window !== 'undefined') {
    try {
      window.dispatchEvent(new CustomEvent('libragent:mcp-servers-changed'));
    } catch {}
  }
};

const saveServer = useCallback(async (server: MCPServerEntity) => {
  await dbService.mcpServers.upsert(server);
  await refreshAll();
  await invalidateMCPServerPages();
  broadcastChange();
}, [refreshAll]);

const deleteServer = useCallback(async (id: string) => {
  await dbService.mcpServers.delete(id);
  await refreshAll();
  await invalidateMCPServerPages();
  broadcastChange();
}, [refreshAll]);

const toggleActive = useCallback(async (id: string, active: boolean) => {
  const found = allServers.find((s) => s.id === id);
  if (!found) return;
  await saveServer({ ...found, isActive: active });
  await invalidateMCPServerPages();
  broadcastChange();
}, [allServers, saveServer]);
````

```typescript
// src/context/AssistantContext.tsx (연결 재시도)
useEffect(() => {
  const handler = () => {
    const cur = currentAssistantRef.current;
    if (cur) {
      connectServersFromAssistant(cur);
    }
  };
  window.addEventListener('libragent:mcp-servers-changed', handler);
  return () =>
    window.removeEventListener('libragent:mcp-servers-changed', handler);
}, [connectServersFromAssistant]);
```

```typescript
// src/features/settings/MCPServerManagement.tsx
// 별도 무효화 호출 불필요 — RegistryContext가 mutate 전파, 여기서는 useSWRInfinite가 자동 재검증
```

#### 3.2 MCPServerContext 수정

**파일:** `src/context/MCPServerContext.tsx`

```typescript
// 수정: connectServers 대신 connectServersFromAssistant
const connectServersFromAssistant = useCallback(
  async (assistant: Assistant) => {
    setError(undefined);

    if (!assistant.mcpServerIds || assistant.mcpServerIds.length === 0) {
      setAvailableTools([]);
      setServerStatus({});
      return;
    }

    try {
      // 1. DB에서 서버 엔티티 조회
      const entities = await dbUtils.getMCPServersByIds(assistant.mcpServerIds);

      // 2. 활성화된 서버만 필터링
      const activeEntities = entities.filter((e) => e.isActive);

      if (activeEntities.length === 0) {
        setAvailableTools([]);
        setServerStatus({});
        return;
      }

      // 3. MCPConfig 구성 (DB metadata 제외)
      const mcpConfig: MCPConfig = {
        mcpServers: Object.fromEntries(
          activeEntities.map((entity) => [
            entity.name,
            {
              name: entity.name,
              transport: entity.transport,
              authentication: entity.authentication,
              metadata: entity.metadata,
            } as MCPServerConfigV2,
          ]),
        ),
      };

      // 4. 기존 로직 실행
      const serverStatus: Record<string, boolean> = {};
      Object.keys(mcpConfig.mcpServers).forEach((name) => {
        serverStatus[name] = false;
      });

      setServerStatus(serverStatus);
      const rawToolsByServer = await listToolsFromConfig(mcpConfig);
      toolsByServer.current = rawToolsByServer;

      const availableTools: MCPTool[] = Object.entries(
        rawToolsByServer,
      ).flatMap(([serverName, tools]) => {
        if (!aliasToIdTableRef.current.has(serverName)) {
          aliasToIdTableRef.current.set(toValidJsName(serverName), serverName);
        }
        return tools.map((t) => ({
          ...t,
          name: `${toValidJsName(serverName)}__${t.name}`,
        }));
      });

      setAvailableTools(availableTools);

      const connectedServers = await getConnectedServers();
      for (const serverName of connectedServers) {
        if (Object.prototype.hasOwnProperty.call(serverStatus, serverName)) {
          serverStatus[serverName] = true;
        }
      }
      setServerStatus({ ...serverStatus });

      logger.debug(
        `Total tools loaded: ${availableTools.length} across ${Object.keys(rawToolsByServer).length} servers`,
      );
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      setError(errorMessage);
      logger.error('Error connecting servers from assistant:', { error });
      setAvailableTools([]);
      setServerStatus({});
    }
  },
  [listToolsFromConfig, getConnectedServers],
);

// Context value 업데이트
const value: MCPServerContextType = useMemo(
  () => ({
    availableTools,
    isLoading,
    error,
    getAvailableTools,
    status: serverStatus,
    connectServersFromAssistant, // ✅ 변경
    executeToolCall,
    sampleFromModel,
  }),
  [
    availableTools,
    isLoading,
    error,
    serverStatus,
    getAvailableTools,
    connectServersFromAssistant, // ✅ 변경
    executeToolCall,
    sampleFromModel,
  ],
);
```

#### 3.3 AssistantContext 수정

**파일:** `src/context/AssistantContext.tsx`

```typescript
// 수정: connectServers → connectServersFromAssistant
const { connectServersFromAssistant } = useMCPServer();

useEffect(() => {
  currentAssistantRef.current = currentAssistant;
  if (currentAssistant) {
    connectServersFromAssistant(currentAssistant); // ✅ 변경
  }
}, [currentAssistant, connectServersFromAssistant]);
```

### Phase 4: UI Components

#### 4.1 MCPServerManagement 생성

**파일:** `src/features/settings/MCPServerManagement.tsx` (신규)

```typescript
import { useState } from 'react';
import { Plus } from 'lucide-react';
import { createId } from '@paralleldrive/cuid2';
import { MCPServerEntity } from '@/models/chat';
import { useMCPServerRegistry } from '@/context/MCPServerRegistryContext';
import { Button, Card, CardHeader, CardTitle, CardContent } from '@/components/ui';
import { MCPServerDialog } from './MCPServerDialog';
import { Pagination } from '@/components/ui/pagination';

export function MCPServerManagement() {
  const {
    servers,
    currentPage,
    totalPages,
    loading,
    loadPage,
    saveServer,
    deleteServer,
    toggleActive,
  } = useMCPServerRegistry();

  const [editingServer, setEditingServer] = useState<MCPServerEntity | null>(null);

  const handleCreateNew = () => {
    const newServer: MCPServerEntity = {
      id: createId(),
      name: 'New Server',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      transport: {
        type: 'stdio',
        command: 'npx',
        args: [],
      },
    };
    setEditingServer(newServer);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">MCP Server Management</h2>
        <Button onClick={handleCreateNew}>
          <Plus className="w-4 h-4 mr-2" />
          Add Server
        </Button>
      </div>

      {loading ? (
        <div>Loading...</div>
      ) : (
        <>
          <div className="grid gap-4">
            {servers.map(server => (
              <Card key={server.id}>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div className="flex-1">
                    <CardTitle>{server.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {server.metadata?.description || 'No description'}
                    </p>
                  </div>
                  <Switch
                    checked={server.isActive}
                    onCheckedChange={(checked) => toggleActive(server.id, checked)}
                  />
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingServer(server)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (confirm(`Delete server "${server.name}"?`)) {
                          deleteServer(server.id);
                        }
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {totalPages > 1 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={loadPage}
            />
          )}
        </>
      )}

      {editingServer && (
        <MCPServerDialog
          server={editingServer}
          onSave={async (server) => {
            await saveServer(server);
            setEditingServer(null);
          }}
          onCancel={() => setEditingServer(null)}
        />
      )}
    </div>
  );
}
```

#### 4.2 MCPServerDialog 생성

**파일:** `src/features/settings/MCPServerDialog.tsx` (신규)

```typescript
import { useState } from 'react';
import { MCPServerEntity } from '@/models/chat';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  Button,
  InputWithLabel,
  TextareaWithLabel,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui';

interface MCPServerDialogProps {
  server: MCPServerEntity;
  onSave: (server: MCPServerEntity) => Promise<void>;
  onCancel: () => void;
}

export function MCPServerDialog({ server, onSave, onCancel }: MCPServerDialogProps) {
  const [draft, setDraft] = useState(server);

  return (
    <Dialog open onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {server.id ? 'Edit MCP Server' : 'Add MCP Server'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <InputWithLabel
            label="Server Name *"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            placeholder="e.g., filesystem, github"
          />

          <TextareaWithLabel
            label="Description"
            value={draft.metadata?.description || ''}
            onChange={(e) => setDraft({
              ...draft,
              metadata: { ...draft.metadata, description: e.target.value }
            })}
            placeholder="Optional description for this server"
          />

          <div>
            <label className="block text-sm font-medium mb-2">Transport Type *</label>
            <Select
              value={draft.transport.type}
              onValueChange={(type: 'stdio' | 'http') => {
                if (type === 'stdio') {
                  setDraft({
                    ...draft,
                    transport: { type: 'stdio', command: '', args: [] }
                  });
                } else {
                  setDraft({
                    ...draft,
                    transport: { type: 'http', url: '' }
                  });
                }
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stdio">stdio</SelectItem>
                <SelectItem value="http">http</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {draft.transport.type === 'stdio' && (
            <>
              <InputWithLabel
                label="Command *"
                value={draft.transport.command}
                onChange={(e) => setDraft({
                  ...draft,
                  transport: { ...draft.transport, command: e.target.value }
                })}
                placeholder="e.g., npx, node, python"
              />

              <InputWithLabel
                label="Arguments"
                value={draft.transport.args?.join(' ') || ''}
                onChange={(e) => setDraft({
                  ...draft,
                  transport: {
                    ...draft.transport,
                    args: e.target.value.split(' ').filter(Boolean)
                  }
                })}
                placeholder="e.g., -y @modelcontextprotocol/server-filesystem /tmp"
              />
            </>
          )}

          {draft.transport.type === 'http' && (
            <InputWithLabel
              label="URL *"
              value={draft.transport.url}
              onChange={(e) => setDraft({
                ...draft,
                transport: { ...draft.transport, url: e.target.value }
              })}
              placeholder="https://api.example.com/mcp"
            />
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            onClick={() => onSave(draft)}
            disabled={!draft.name || (draft.transport.type === 'stdio' && !draft.transport.command)}
          >
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
```

#### 4.3 AssistantEditor 수정

**파일:** `src/features/assistant/AssistantEditor.tsx`

```typescript
// 수정: MCPConfigEditor 제거, 서버 선택 UI 추가
import { useState, useEffect } from 'react';
import { useEditor } from '@/context/EditorContext';
import { Assistant } from '@/models/chat';
import { useMCPServerRegistry } from '@/context/MCPServerRegistryContext';
import { Checkbox, Input } from '@/components/ui';

export default function AssistantEditor() {
  const { draft, update } = useEditor<Assistant>();
  const { activeServers } = useMCPServerRegistry();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredServers = activeServers.filter(s =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.metadata?.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleServerToggle = (serverId: string, enabled: boolean) => {
    update((draft) => {
      if (!draft.mcpServerIds) draft.mcpServerIds = [];

      if (enabled) {
        if (!draft.mcpServerIds.includes(serverId)) {
          draft.mcpServerIds.push(serverId);
        }
      } else {
        draft.mcpServerIds = draft.mcpServerIds.filter(id => id !== serverId);
      }
    });
  };

  return (
    <div className="w-full p-4 space-y-4">
      <InputWithLabel
        label="Assistant Name *"
        value={draft?.name || ''}
        onChange={(e) => update((draft) => { draft.name = e.target.value; })}
        placeholder="Enter assistant name..."
      />

      <TextareaWithLabel
        label="System Prompt *"
        value={draft?.systemPrompt || ''}
        onChange={(e) => update((draft) => { draft.systemPrompt = e.target.value; })}
        placeholder="Describe the AI's role and behavior..."
        className="h-32"
      />

      <BuiltInToolsEditor />
      <LocalServicesEditor />

      {/* ✅ MCP 서버 선택 UI (MCPConfigEditor 대체) */}
      <div>
        <label className="block text-sm font-medium mb-2">
          MCP Servers
        </label>

        {activeServers.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No active MCP servers. <Link to="/settings">Add servers in Settings</Link>
          </p>
        ) : (
          <>
            <Input
              placeholder="Search servers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="mb-2"
            />

            <div className="max-h-64 overflow-y-auto border rounded-md p-2 space-y-2">
              {filteredServers.map(server => (
                <div
                  key={server.id}
                  className="flex items-start gap-2 p-2 hover:bg-accent rounded"
                >
                  <Checkbox
                    checked={draft.mcpServerIds?.includes(server.id) || false}
                    onCheckedChange={(checked) =>
                      handleServerToggle(server.id, checked as boolean)
                    }
                  />
                  <div className="flex-1">
                    <div className="font-medium">{server.name}</div>
                    {server.metadata?.description && (
                      <div className="text-xs text-muted-foreground">
                        {server.metadata.description}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ❌ MCPConfigEditor 컴포넌트 사용 제거
```

#### 4.4 SettingsPage 탭 추가

**파일:** `src/features/settings/SettingsPage.tsx`

```typescript
// 추가: MCP Servers 탭
import { MCPServerManagement } from './MCPServerManagement';

<Tabs defaultValue="api-key">
  <TabsList>
    <TabsTrigger value="api-key">API Keys</TabsTrigger>
    <TabsTrigger value="mcp-servers">MCP Servers</TabsTrigger>  {/* ✅ 추가 */}
    <TabsTrigger value="conversation-model">Conversation & Model</TabsTrigger>
    <TabsTrigger value="data-reset">Data & Reset</TabsTrigger>
  </TabsList>

  <TabsContent value="mcp-servers">
    <MCPServerManagement />  {/* ✅ 추가 */}
  </TabsContent>

  {/* ... 기존 탭들 */}
</Tabs>
```

### Phase 5: Provider 구조 업데이트

#### 5.1 App.tsx Provider 추가

**파일:** `src/app/App.tsx`

```typescript
// 추가: MCPServerRegistryProvider
import { MCPServerRegistryProvider } from '@/context/MCPServerRegistryContext';

<MCPServerRegistryProvider>  {/* ✅ 추가 */}
  <AssistantContextProvider>
    <MCPServerProvider>
      <WebMCPProvider>
        {/* ... 기존 컴포넌트들 */}
      </WebMCPProvider>
    </MCPServerProvider>
  </AssistantContextProvider>
</MCPServerRegistryProvider>
```

---

## 재사용 가능한 연관 코드

### 기존 컴포넌트 재사용

**1. Pagination Component**

- **경로:** `src/components/ui/pagination.tsx` (필요시 생성)
- **용도:** MCPServerManagement에서 페이지네이션 UI

**2. Card Components**

- **경로:** `src/components/ui/card.tsx`
- **용도:** 서버 목록 표시

**3. Dialog Components**

- **경로:** `src/components/ui/dialog.tsx`
- **용도:** MCPServerDialog

**4. Form Components**

- **경로:** `src/components/ui/`
- **컴포넌트:** Input, Textarea, Select, Checkbox, Switch
- **용도:** 서버 편집 폼

### 유틸리티 함수

**1. ID 생성**

```typescript
import { createId } from '@paralleldrive/cuid2';
```

**2. Logger**

```typescript
import { getLogger } from '@/lib/logger';
const logger = getLogger('ComponentName');
```

**3. 이름 변환**

```typescript
import { toValidJsName } from '@/lib/utils';
```

---

## Test Code 가이드

### 단위 테스트

**1. CRUD Operations**

```typescript
// src/lib/db/crud.test.ts
describe('mcpServersCRUD', () => {
  it('should create a new MCP server', async () => {
    const server: MCPServerEntity = {
      id: 'test-id',
      name: 'test-server',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      transport: { type: 'stdio', command: 'test' },
    };

    await mcpServersCRUD.upsert(server);
    const retrieved = await mcpServersCRUD.read('test-id');

    expect(retrieved).toBeDefined();
    expect(retrieved?.name).toBe('test-server');
  });

  it('should support pagination', async () => {
    const page = await mcpServersCRUD.getPage(1, 10);
    expect(page.items).toBeInstanceOf(Array);
    expect(page.page).toBe(1);
  });
});
```

**2. Context Operations**

```typescript
// src/context/MCPServerRegistryContext.test.tsx
describe('MCPServerRegistryContext', () => {
  it('should load all servers on mount', async () => {
    const { result } = renderHook(() => useMCPServerRegistry(), {
      wrapper: MCPServerRegistryProvider,
    });

    await waitFor(() => {
      expect(result.current.allServers).toBeDefined();
    });
  });

  it('should filter active servers', async () => {
    const { result } = renderHook(() => useMCPServerRegistry(), {
      wrapper: MCPServerRegistryProvider,
    });

    await waitFor(() => {
      const active = result.current.activeServers;
      expect(active.every((s) => s.isActive)).toBe(true);
    });
  });
});
```

### 통합 테스트

**1. Assistant MCP Server Connection**

```typescript
// src/context/AssistantContext.integration.test.tsx
describe('Assistant MCP Server Integration', () => {
  it('should connect MCP servers from assistant', async () => {
    // 1. MCP 서버 생성
    const server: MCPServerEntity = {
      /* ... */
    };
    await dbService.mcpServers.upsert(server);

    // 2. Assistant 생성 (서버 참조)
    const assistant: Assistant = {
      /* ... */
      mcpServerIds: [server.id],
    };

    // 3. Assistant 활성화
    const { result } = renderHook(() => useAssistantContext());
    act(() => {
      result.current.setCurrentAssistant(assistant);
    });

    // 4. MCP 도구 로드 확인
    await waitFor(() => {
      const { availableTools } = useMCPServer();
      expect(availableTools.length).toBeGreaterThan(0);
    });
  });
});
```

### E2E 테스트 시나리오

**1. MCP Server Management Flow**

```typescript
test('should manage MCP servers end-to-end', async () => {
  // 1. Settings 이동
  await page.goto('/settings');
  await page.click('[data-testid="mcp-servers-tab"]');

  // 2. 서버 추가
  await page.click('[data-testid="add-server-btn"]');
  await page.fill('[data-testid="server-name"]', 'test-server');
  await page.fill('[data-testid="command"]', 'npx');
  await page.click('[data-testid="save-btn"]');

  // 3. 서버 목록 확인
  const serverCard = await page.waitForSelector(
    '[data-testid="server-card-test-server"]',
  );
  expect(serverCard).toBeTruthy();

  // 4. Assistant에서 서버 선택
  await page.goto('/assistants');
  await page.click('[data-testid="create-assistant"]');
  await page.click('[data-testid="server-checkbox-test-server"]');
  await page.click('[data-testid="save-assistant"]');

  // 5. Chat에서 도구 사용 가능 확인
  // ...
});
```

---

## Clarification Q-list

### Q1: 기존 Assistant의 mcpConfig 마이그레이션

**질문:** 기존에 저장된 Assistant들의 `mcpConfig` 데이터를 어떻게 처리할 것인가?

**옵션:**

- A) 앱 시작 시 자동 마이그레이션 (한 번만 실행)
- B) 사용자에게 마이그레이션 프롬프트 표시
- C) 기존 데이터 무시 (새로 설정 필요)

**권장:** Option A (자동 마이그레이션)

- localStorage에 마이그레이션 완료 플래그 저장
- 한 번만 실행되도록 보장

**답변:** C 기존 데이터 무시

### Q2: MCP 서버 중복 처리

**질문:** 동일한 name을 가진 MCP 서버가 여러 개 생성될 수 있는가?

**옵션:**

- A) name을 unique constraint로 지정 (중복 불가)
- B) 중복 허용 (사용자 책임)
- C) 경고만 표시 (저장은 가능)

**권장:** Option A (중복 불가)

- DB schema에 unique index 추가
- 저장 시 중복 체크 및 에러 표시

**답변:** A 중복 불가

### Q3: MCP 서버 삭제 시 Assistant 처리

**질문:** 어떤 Assistant가 참조하는 MCP 서버를 삭제하려 할 때?

**옵션:**

- A) 삭제 불가 (참조 있음 경고)
- B) 강제 삭제 + Assistant의 참조 자동 제거
- C) Cascade delete (Assistant도 삭제)

**권장:** Option B (강제 삭제 + 참조 제거)

- 삭제 전 경고 메시지 표시
- 삭제 후 Assistant의 mcpServerIds에서 해당 ID 제거

**답변:** A 삭제 불가 / 참조 있음 경고

### Q4: Transport 타입별 세부 설정 UI

**질문:** HTTP Transport의 OAuth, SSE 등 고급 설정을 모두 UI로 제공할 것인가?

**옵션:**

- A) 모든 필드 UI 제공 (복잡)
- B) 기본 필드만 UI, 고급 설정은 JSON 편집
- C) Phase 1은 stdio만, Phase 2에서 HTTP 추가

**권장:** Option C (단계적 구현)

- Phase 1: stdio transport만 완전 지원
- Phase 2: HTTP transport 기본 필드
- Phase 3: OAuth/SSE 등 고급 기능

**답변:** C 우선 stdio만 지원

### Q5: Pagination vs Infinite Scroll

**질문:** MCP 서버 목록 UI에서 어떤 방식을 사용할 것인가?

**옵션:**

- A) Pagination (페이지 번호)
- B) Infinite Scroll
- C) Load More 버튼

**권장:** Option A (Pagination)

- 사용자가 현재 위치 파악 쉬움
- Settings 화면 특성상 적합
- 구현 단순
  **답변:** A Pagination

---

## 작업 순서 제안

1. **Phase 1-2 (Database)** - 1일
   - 타입 정의
   - DB Schema 추가
   - CRUD 구현

2. **Phase 3 (Context)** - 1일

- MCPServerRegistryContext
- MCPServerContext 수정
- AssistantContext 수정

3. **Phase 4 (UI - Settings)** - 1일
   - MCPServerManagement
   - MCPServerDialog
   - SettingsPage 탭 추가

4. **Phase 4 (UI - Assistant)** - 0.5일
   - AssistantEditor 수정
   - MCPConfigEditor 제거

5. **Phase 5 (Integration)** - 0.5일
   - Provider 구조 업데이트
   - 통합 테스트

6. **Testing & Polish** - 1일
   - 단위 테스트
   - 통합 테스트
   - 버그 수정

**총 예상 기간:** 5일

---

## 성공 메트릭

- [ ] MCP 서버 CRUD 동작 확인
- [ ] Assistant 편집에서 서버 선택 가능
- [ ] Chat에서 선택된 서버의 도구 사용 가능
- [ ] 중복 데이터 제거 확인 (DB 크기 감소)
- [ ] UI 복잡도 감소 (JSON 편집 제거)
- [ ] 모든 테스트 통과

---

## 추가 고려사항

### 성능

- IndexedDB 조회 최적화 (인덱스 활용)
- Context에서 불필요한 re-render 방지 (useMemo, useCallback)

### 보안

- MCP 서버 설정에 민감한 정보(API 키) 포함 시 암호화 고려

### UX

- 로딩 상태 표시 (Skeleton, Spinner)
- 에러 메시지 명확화
- 성공/실패 Toast 알림

### 확장성

- Future: MCP 서버 공유/Export 기능
- Future: 서버 템플릿 (preset configurations)
- Future: 서버 검색 및 필터링 (태그 시스템)


---

# refactoring_20251018_1430.md

# Anthropic Service 모델 로딩 메커니즘 개선 Refactoring 계획

## 1. 작업의 목적

Anthropic API에서 동적으로 모델 정보를 조회하고, 사고 확장(thinking) 기능 활성화 판정을 메타데이터 기반으로 개선하여, 새로운 모델 출시 시 자동으로 대응할 수 있도록 합니다.

**목표:**

- Anthropic SDK의 `models.list()` API를 활용한 동적 모델 조회
- 문자열 매칭에서 메타데이터 기반 기능 활성화로 전환
- 하드코드된 fallback 모델 제거 및 안전한 기본값 설정

---

## 2. 현재의 상태 / 문제점

### 2.1 현재 아키텍처 개요

```text
AnthropicService (src/lib/ai-service/anthropic.ts)
    ↓ extends
BaseAIService (src/lib/ai-service/base-service.ts)
    ↓ uses
LLMConfigManager (src/lib/llm-config-manager.ts)
    ↓ loads
llm-config.json (src/config/llm-config.json) [Static]
```

### 2.2 현재 구현 문제점

| 문제                            | 위치                                                    | 영향                                                                     | 심각도 |
| ------------------------------- | ------------------------------------------------------- | ------------------------------------------------------------------------ | ------ |
| **동적 모델 미지원**            | `BaseAIService.listModels()`                            | 새 Anthropic 모델이 출시되어도 config 수동 업데이트 필요                 | 높음   |
| **문자열 기반 사고 활성화**     | `AnthropicService.shouldEnableThinking()` (lines 66-75) | claude-4 등 새 모델에서 사고 기능 미활성화 가능                          | 높음   |
| **유효하지 않은 fallback 모델** | `AnthropicService.streamChat()` (line 115)              | `'claude-3-sonnet-20240229'`는 llm-config.json에 없음 → 런타임 에러 위험 | 중간   |
| **메타데이터 불일치**           | `shouldEnableThinking()` vs `llm-config.json`           | 코드 로직과 config의 `supportReasoning` 필드 불일치                      | 중간   |

### 2.3 코드 스니핏: 현재 구현

**파일:** `src/lib/ai-service/anthropic.ts`

```typescript
// 문제 1: 문자열 매칭으로 사고 활성화 판정
private shouldEnableThinking(modelName?: string, config?: AIServiceConfig): boolean {
  const model = modelName || config?.defaultModel;
  // 문제: 새 모델(예: claude-4-20250514)에서 미활성화
  return !!(model?.includes('claude-3-5') || model?.includes('claude-3-opus'));
}

// 문제 2: 하드코드된 유효하지 않은 fallback 모델
public async streamChat(options: StreamChatOptions): Promise<void> {
  const modelName = options.modelName || this.config.defaultModel || 'claude-3-sonnet-20240229'; // ❌ llm-config.json에 없음
  // ...
}
```

**파일:** `src/lib/ai-service/base-service.ts`

```typescript
// 문제 3: 정적 config만 사용, 동적 조회 없음
public async listModels(): Promise<ModelInfo[]> {
  const models = llmConfigManager.getModelsForProvider(this.getProvider());
  return models ? Object.values(models) : [];
}
```

**파일:** `src/config/llm-config.json`

```json
{
  "anthropic": {
    "models": {
      "claude-opus-4-20250514": { "supportReasoning": true, ... },
      "claude-sonnet-4-20250514": { "supportReasoning": true, ... },
      // ... 기타 모델
      // 주의: 'claude-3-sonnet-20240229'는 없음 (비추천/폐기된 모델)
    }
  }
}
```

### 2.4 검증: Anthropic SDK 모델 API 지원

✅ **확인됨:**

- Anthropic SDK (`@anthropic-ai/sdk`) 지원
- 엔드포인트: `GET /v1/models` (paginated)
- 응답 형식: `ModelInfosPage` (data 배열 + pagination)
- 자동 페이지네이션: `for await` 문법 지원
- 예시:

```typescript
for await (const model of client.models.list()) {
  console.log(model.id, model.name);
}
```

---

## 3. 변경 이후의 상태 / 해결 판정 기준

### 3.1 목표 상태

| 측면                 | Before                        | After                                     |
| -------------------- | ----------------------------- | ----------------------------------------- |
| **모델 조회**        | 정적 config (llm-config.json) | 동적 SDK 호출 + 정적 폴백                 |
| **사고 활성화 판정** | 문자열 매칭 (`includes()`)    | 메타데이터 조회 (`supportReasoning` 필드) |
| **Fallback 모델**    | 하드코드 (유효하지 않음)      | 동적 선택 (항상 유효)                     |
| **확장성**           | 수동 config 업데이트 필요     | 자동 반영 (SDK 최신 모델)                 |

### 3.2 해결 판정 기준 (Acceptance Criteria)

#### ✅ 기능 기준

1. **listModels() 오버라이드**
   - [ ] `AnthropicService.listModels()`가 `this.anthropic.models.list()`를 호출
   - [ ] SDK 응답을 `ModelInfo[]`로 정확하게 매핑
   - [ ] 네트워크 실패 시 `super.listModels()`로 자동 폴백
   - [ ] 로깅: 성공 시 로드된 모델 개수, 실패 시 에러 메시지 기록

2. **shouldEnableThinking() 리팩토링**
   - [ ] 문자열 매칭 제거, `llmConfigManager.getModel()` 사용
   - [ ] 모든 claude-opus, claude-sonnet-4 계열에서 사고 활성화 검증
   - [ ] config에 없는 모델: `false` 반환 (안전 기본값)

3. **streamChat() Fallback 개선**
   - [ ] 현재의 하드코드 모델 제거
   - [ ] 우선순위 체인: `options.modelName` > `config.defaultModel` > config의 첫 모델 > 기본값
   - [ ] 선택된 모델이 항상 유효한지 검증

#### ✅ 테스트 기준

1. **단위 테스트** (`src/lib/ai-service/__tests__/anthropic.test.ts`)
   - [ ] `listModels()`: SDK 응답 10개 모델 → ModelInfo[] 변환 검증
   - [ ] `listModels()`: 네트워크 에러 시 super.listModels() 호출 검증
   - [ ] `shouldEnableThinking()`: `supportReasoning=true` 모델에서 `true` 반환
   - [ ] `shouldEnableThinking()`: config 없는 모델에서 `false` 반환
   - [ ] `streamChat()`: 모델 선택 우선순위 검증

2. **통합 테스트**
   - [ ] UI 모델 드롭다운에서 SDK 모델 목록 로드 (E2E 시뮬레이션)
   - [ ] 챗 메시지 스트림에서 사고 기능 활성화 여부 검증

#### ✅ 호환성 기준

- [ ] 기존 API 호환성 유지 (breaking change 없음)
- [ ] 폴백 메커니즘으로 인한 성능 저하 무시할 수 있는 수준 (<100ms)
- [ ] 모든 기존 모델 (claude-3-5-sonnet-20241022 등) 계속 작동

---

## 4. 수정이 필요한 코드

### 4.1 수정 파일 목록

| 파일                                             | 변경 사항               | 영향도 |
| ------------------------------------------------ | ----------------------- | ------ |
| `src/lib/ai-service/anthropic.ts`                | 3개 메서드 추가/수정    | 직접   |
| `src/lib/ai-service/__tests__/anthropic.test.ts` | 테스트 5개 추가         | 간접   |
| `src/config/llm-config.json`                     | 변경 없음 (폴백용 유지) | 없음   |

### 4.2 상세 수정 사항

#### **4.2.1 `src/lib/ai-service/anthropic.ts` - 메서드 1: listModels() 오버라이드**

**위치:** 파일의 `AnthropicService` 클래스 내, `streamChat()` 메서드 이전

**현재 상태:** 메서드 없음 (상속받은 `BaseAIService.listModels()` 사용)

**변경 사항:**

````typescript
/**
 * Fetches available Claude models from Anthropic API.
 * Falls back to static config if SDK call fails.
 */
async listModels(): Promise<ModelInfo[]> {
  const logger = getLogger('AnthropicService.listModels');

  try {
    // SDK provides ModelInfosPage type with data array
    const response = await this.anthropic.models.list();

    if (Array.isArray(response?.data)) {
      for (const model of response.data) {
        // Map SDK ModelInfo to our ModelInfo interface
        models.push({
          id: model.id,
          name: model.name || model.id,
          contextWindow: model.context_window || 200000,
          supportReasoning: model.type === 'model' &&
                           (model.id.includes('opus') || model.id.includes('sonnet-4')),
          supportTools: true, // All Claude models support tools
          supportStreaming: true, // All Claude models support streaming
          cost: {
            inputCost: 0, // Not provided by SDK, kept from config
            outputCost: 0,
          },
          description: `Claude model: ${model.id}`,
        });
      }

      logger.info(`Loaded ${models.length} models from Anthropic API`);
      return models;
    }
  } catch (error) {
    logger.warn('Failed to fetch models from Anthropic API, falling back to static config', error);
  }

  // Fallback to static config
  return super.listModels();
}
```#### **4.2.2 `src/lib/ai-service/anthropic.ts` - 메서드 2: shouldEnableThinking() 리팩토링**

**위치:** 파일의 `shouldEnableThinking()` 메서드 (현재 lines 66-75)

**현재 상태:**

```typescript
private shouldEnableThinking(modelName?: string, config?: AIServiceConfig): boolean {
  const model = modelName || config?.defaultModel;
  return !!(model?.includes('claude-3-5') || model?.includes('claude-3-opus'));
}
````

**변경 사항:**

```typescript
private shouldEnableThinking(modelName?: string, config?: AIServiceConfig): boolean {
  const logger = getLogger('AnthropicService.shouldEnableThinking');
  const modelId = modelName || config?.defaultModel;

  if (!modelId) {
    logger.debug('No model specified, thinking disabled by default');
    return false;
  }

  // Use metadata from config instead of string matching
  const modelInfo = llmConfigManager.getModel('anthropic', modelId);

  if (!modelInfo) {
    logger.warn(`Model ${modelId} not found in config, thinking disabled`);
    return false;
  }

  return !!modelInfo.supportReasoning;
}
```

**수정 이유:**

- 메타데이터 기반 판정으로 코드-config 불일치 제거
- 새 모델 자동 지원 (config에서 `supportReasoning: true`이면 지원)
- 명확한 폴백 로직

#### **4.2.3 `src/lib/ai-service/anthropic.ts` - 메서드 3: getDefaultModel() 추가 + streamChat() 개선**

**위치:** 파일의 `streamChat()` 메서드 이전 (헬퍼 메서드)

**새 헬퍼 메서드 추가:**

```typescript
/**
 * Selects the best available model following priority order.
 * Priority: explicit option > config default > first available config model > fallback
 */
private getDefaultModel(): string {
  const logger = getLogger('AnthropicService.getDefaultModel');

  // Priority 1: Check config default
  if (this.config.defaultModel) {
    logger.debug(`Using config default model: ${this.config.defaultModel}`);
    return this.config.defaultModel;
  }

  // Priority 2: First model from config
  const configModels = llmConfigManager.getModelsForProvider('anthropic');
  if (configModels && Object.keys(configModels).length > 0) {
    const firstModel = Object.keys(configModels)[0];
    logger.debug(`Using first config model: ${firstModel}`);
    return firstModel;
  }

  // Priority 3: Safe fallback (verified to exist in current config)
  const fallback = 'claude-3-5-sonnet-20241022';
  logger.warn(`No config models found, using fallback: ${fallback}`);
  return fallback;
}
```

**streamChat() 메서드 수정 부분 (현재 line 115 근처):**

**변경 전:**

```typescript
public async streamChat(options: StreamChatOptions): Promise<void> {
  const modelName = options.modelName || this.config.defaultModel || 'claude-3-sonnet-20240229';
  // ...
}
```

**변경 후:**

```typescript
public async streamChat(options: StreamChatOptions): Promise<void> {
  const modelName = options.modelName || this.getDefaultModel();
  // ...
}
```

---

## 5. 재사용 가능한 연관 코드

### 5.1 인터페이스 & 타입 (기존, 재사용)

**파일:** `src/lib/ai-service/types.ts`

```typescript
// 이미 정의됨, 수정 불필요
export interface ModelInfo {
  id: string;
  name: string;
  contextWindow: number;
  supportReasoning: boolean;
  supportTools: boolean;
  supportStreaming: boolean;
  cost: {
    inputCost: number;
    outputCost: number;
  };
  description: string;
}

export interface AIServiceConfig {
  apiKey: string;
  defaultModel?: string;
  // ...
}
```

### 5.2 기존 유틸리티 (재사용)

**파일:** `src/lib/llm-config-manager.ts`

```typescript
// 이미 구현됨
export class LLMConfigManager {
  getModel(providerId: string, modelId: string): ModelInfo | undefined {
    // Returns model metadata or undefined
  }

  getModelsForProvider(
    providerId: string,
  ): Record<string, ModelInfo> | undefined {
    // Returns all models for provider
  }
}
```

### 5.3 로깅 유틸리티 (재사용)

**파일:** `src/lib/logger.ts`

```typescript
// 이미 구현됨
export const getLogger = (context: string) => ({
  debug: (msg: string, data?: unknown) => {
    /* ... */
  },
  info: (msg: string, data?: unknown) => {
    /* ... */
  },
  warn: (msg: string, error?: unknown) => {
    /* ... */
  },
  error: (msg: string, error?: unknown) => {
    /* ... */
  },
});
```

### 5.4 Anthropic SDK 클라이언트 (기존)

**파일:** `src/lib/ai-service/anthropic.ts`

```typescript
// 이미 초기화됨
constructor(config: AIServiceConfig) {
  super(config);
  this.anthropic = new Anthropic({
    apiKey: config.apiKey,
    defaultHeaders: {
      'anthropic-version': '2023-06-01',
    },
  });
}
```

---

## 6. Test Code 추가 및 수정 가이드

### 6.1 테스트 파일 생성

**파일:** `src/lib/ai-service/__tests__/anthropic.test.ts` (신규 또는 기존 확장)

### 6.2 테스트 케이스

#### **테스트 1: listModels() - 성공 케이스**

```typescript
describe('AnthropicService.listModels()', () => {
  it('should fetch models from SDK and map to ModelInfo[]', async () => {
    // Mock SDK response
    const mockModels = [
      {
        id: 'claude-opus-4-20250514',
        name: 'Claude Opus 4',
        context_window: 200000,
        type: 'model',
      },
      {
        id: 'claude-sonnet-4-20250514',
        name: 'Claude Sonnet 4',
        context_window: 200000,
        type: 'model',
      },
    ];

    const service = new AnthropicService({ apiKey: 'test-key' });
    jest.spyOn(service['anthropic'].models, 'list').mockResolvedValue({
      data: mockModels,
    });

    const result = await service.listModels();

    expect(result).toHaveLength(2);
    expect(result[0].id).toBe('claude-opus-4-20250514');
    expect(result[0].supportReasoning).toBe(true);
  });
});
```

#### **테스트 2: listModels() - 폴백 케이스**

```typescript
it('should fallback to super.listModels() on SDK error', async () => {
  const service = new AnthropicService({ apiKey: 'test-key' });
  jest
    .spyOn(service['anthropic'].models, 'list')
    .mockRejectedValue(new Error('Network error'));
  const superSpy = jest.spyOn(BaseAIService.prototype, 'listModels');

  await service.listModels();

  expect(superSpy).toHaveBeenCalled();
});
```

#### **테스트 3: shouldEnableThinking() - 메타데이터 기반**

```typescript
describe('AnthropicService.shouldEnableThinking()', () => {
  it('should return true for supportReasoning models', () => {
    const service = new AnthropicService({ apiKey: 'test-key' });
    // Assuming llm-config.json has claude-opus-4 with supportReasoning=true

    const result = service['shouldEnableThinking'](
      'claude-opus-4-20250514',
      {},
    );

    expect(result).toBe(true);
  });

  it('should return false for models without supportReasoning', () => {
    const service = new AnthropicService({ apiKey: 'test-key' });
    // Assuming llm-config.json has claude-3-5-haiku with supportReasoning=false

    const result = service['shouldEnableThinking'](
      'claude-3-5-haiku-20241022',
      {},
    );

    expect(result).toBe(false);
  });

  it('should return false for unknown models', () => {
    const service = new AnthropicService({ apiKey: 'test-key' });

    const result = service['shouldEnableThinking']('unknown-model-xyz', {});

    expect(result).toBe(false);
  });
});
```

#### **테스트 4: getDefaultModel() - 우선순위**

```typescript
describe('AnthropicService.getDefaultModel()', () => {
  it('should prefer config default model', () => {
    const service = new AnthropicService({
      apiKey: 'test-key',
      defaultModel: 'claude-opus-4-20250514',
    });

    const result = service['getDefaultModel']();

    expect(result).toBe('claude-opus-4-20250514');
  });

  it('should fallback to first config model if no default', () => {
    const service = new AnthropicService({ apiKey: 'test-key' });
    // Mock llmConfigManager.getModelsForProvider to return models

    const result = service['getDefaultModel']();

    expect(result).not.toBeNull();
  });
});
```

#### **테스트 5: streamChat() - 모델 선택**

```typescript
describe('AnthropicService.streamChat()', () => {
  it('should use explicit model name if provided', async () => {
    const service = new AnthropicService({ apiKey: 'test-key' });
    const createSpy = jest.spyOn(service['anthropic'].messages, 'create');

    await service.streamChat({
      modelName: 'claude-opus-4-20250514',
      messages: [],
    });

    expect(createSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        model: 'claude-opus-4-20250514',
      }),
      expect.anything(),
    );
  });
});
```

### 6.3 테스트 실행 명령

```bash
# 특정 테스트만 실행
pnpm test -- anthropic.test.ts

# 모든 테스트 실행
pnpm test

# 커버리지 포함
pnpm test -- --coverage
```

---

## 7. 구현 순서 & 주의사항

### 7.1 추천 구현 순서

#### Phase 1: 저위험 리팩토링

- `shouldEnableThinking()` 메서드 리팩토링 → 단위 테스트
- `getDefaultModel()` 헬퍼 메서드 추가 → `streamChat()` 수정 → 단위 테스트

#### Phase 2: 중위험 기능 추가

- `listModels()` 오버라이드 구현 → 통합 테스트

#### Phase 3: 검증

- 전체 E2E 테스트 및 로그 검증
- `pnpm refactor:validate` 실행

### 7.2 주의사항

#### 타입 안전성

- `@ts-expect-error` 사용: SDK에서 `models.list()` 공식 지원 안 함
- 향후 SDK 버전 업데이트 시 제거 가능

#### 성능 고려

- `listModels()` 호출은 가능한 캐싱하기 (서비스 초기화 시 1회)
- UI에서 반복 호출 시 성능 저하 가능

#### 폴백 안전성

- 네트워크 에러 시 정적 config으로 자동 폴백
- `getDefaultModel()`의 fallback 모델 유효성 검증 필수

#### 로깅

- 모든 주요 경로에서 로깅 추가 (SDK 호출, 폴백, 에러)
- 프로덕션 디버깅 용이

---

## 8. 검증 체크리스트

### 구현 전

- [ ] 이 계획 문서 리뷰 완료
- [ ] 관련 팀/동료 승인 획득
- [ ] 기존 테스트 스위트 실행 확인 (기준선)

### 구현 중

- [ ] Phase 1 완료 후 `pnpm lint` 통과
- [ ] Phase 2 완료 후 `pnpm build` 성공
- [ ] 새로 추가한 테스트 모두 통과

### 구현 후

- [ ] `pnpm refactor:validate` 완전 통과
- [ ] 모든 기존 모델 작동 확인 (claude-3-5-sonnet, claude-opus, etc.)
- [ ] 새 모델 추가 시 자동 지원 확인 (mock 테스트)
- [ ] 에러 로그 검증 (폴백 시 warn 레벨)
- [ ] 통합 테스트: UI 모델 드롭다운 로드 검증

---

## 9. 참고 자료

### 관련 파일

- `src/lib/ai-service/anthropic.ts` - 주 수정 파일
- `src/lib/ai-service/base-service.ts` - 부모 클래스 참고
- `src/lib/llm-config-manager.ts` - 메타데이터 소스
- `src/config/llm-config.json` - 정적 모델 정의
- `src/lib/ai-service/__tests__/anthropic.test.ts` - 테스트 추가

### 외부 참고

- [Anthropic SDK 문서](https://docs.anthropic.com/) - `models.list()` API
- [LibrAgent 코딩 가이드](./.github/copilot-instructions.md) - 코드 스타일
- [모델 기능 매트릭스](./docs/builtin-tools.md) - 모델별 기능

---

## 10. 이전 분석 자료

### 10.1 수행한 선행 분석

✅ **분석 완료:**

- 현재 아키텍처 전수 검토 (메시지 1-2)
- Anthropic SDK 모델 API 문서 검증 (메시지 5)
- 구현 전략 3가지 설계 (메시지 6)
- Todo 리스트 작성 (메시지 6, 8개 항목)

✅ **기술 검증:**

- SDK 엔드포인트: `GET /v1/models` (paginated)
- 자동 페이지네이션: `for await` 문법 지원
- 폴백: 정적 config 유지 가능

---

**작성일:** 2025-10-18
**작성자:** GitHub Copilot (분석 기반 AI 제안)
**상태:** 검토 대기 중


---

# refactoring_20251102_1400.md

# Refactoring Plan: MCP Types Modularization

**Date**: 2025-11-02 14:00  
**Task**: Refactor `src/lib/mcp-types.ts` into focused, manageable modules  
**Type**: Code Structure Improvement

---

## 작업의 목적

### Primary Goals

1. **Reduce Complexity**: Split 700+ line monolithic file into smaller, focused modules (50-150 lines each)
2. **Improve Maintainability**: Group related types by domain (Schema, Protocol, Config, Web Worker, Utils)
3. **Enable Tree Shaking**: Allow bundlers to eliminate unused code more effectively
4. **Better Discoverability**: Make it easier for developers to find specific type definitions
5. **Prevent Circular Dependencies**: Establish clear dependency hierarchies

### Secondary Goals

- Preserve backward compatibility during migration
- Support incremental refactoring without breaking changes
- Improve documentation through self-documenting file structure
- Facilitate easier testing of individual modules

---

## 현재의 상태 / 문제점

### Current State Analysis

**File Structure:**

```
src/lib/mcp-types.ts (763 lines)
├── JSON Schema Types (~200 lines)
│   ├── Type definitions (JSONSchemaString, JSONSchemaNumber, etc.)
│   └── Builder functions (createStringSchema, createNumberSchema, etc.)
├── MCP Content Types (~100 lines)
│   ├── Content interfaces (MCPTextContent, MCPImageContent, etc.)
│   └── ServiceInfo types
├── MCP Protocol Types (~150 lines)
│   ├── Request/Response types (MCPResponse, MCPResult, etc.)
│   └── Sampling types
├── MCP Tool Types (~80 lines)
├── Server Configuration Types (~120 lines)
│   ├── Legacy config (MCPServerConfig)
│   ├── V2 config (MCPServerConfigV2, TransportConfig, OAuthConfig)
│   └── Unified config
├── Web Worker Types (~80 lines)
│   ├── WebMCPServer interface
│   ├── WebMCPMessage types
│   └── WebMCPProxyConfig
└── Utility Functions (~130 lines)
    ├── Type guards (isMCPSuccess, isMCPError, etc.)
    └── Helper functions (extractServiceInfo, etc.)
```

### Identified Problems

1. **High Cognitive Load**
   - Single file contains 8+ distinct conceptual domains
   - Difficult to understand the full scope without reading entire file
   - New developers struggle to locate specific types

2. **Poor Module Boundaries**
   - JSON Schema builders mixed with protocol types
   - Configuration types mixed with runtime types
   - No clear separation between spec-compliant types and internal extensions

3. **Import Inefficiency**
   - Every import pulls in entire 700+ line file
   - No opportunity for code splitting or lazy loading
   - Bundle size impact for features that only need subset of types

4. **Maintenance Challenges**
   - Changes require navigating large file
   - Merge conflicts more likely due to single-file bottleneck
   - Difficult to identify unused types

5. **Documentation Issues**
   - File-level documentation doesn't match granular concerns
   - Hard to provide domain-specific context
   - JSDoc comments scattered across disparate concepts

### Usage Analysis

**High-Traffic Importers** (identified via grep):

- `src/models/chat.ts`: 8 types (MCPTool, MCPContent, MCPServerConfigV2, etc.)
- `src/lib/rust-backend-client.ts`: 6 types (MCPResponse, MCPTool, TransportConfig, etc.)
- `src/features/tools/*.tsx`: 10+ files importing MCPTool, MCPResponse
- `src/lib/web-mcp/`: 8+ files importing WebMCPServer, MCPResponse, MCPTool
- `src/hooks/*.ts`: 5 files importing MCPResponse, MCPContent, MCPTool
- `src/context/*.tsx`: 4 files importing MCPTool, various types

**Import Patterns:**

```typescript
// Most common pattern (protocol types)
import { MCPResponse, MCPTool, MCPContent } from '@/lib/mcp-types';

// Second most common (config types)
import {
  MCPServerConfigV2,
  TransportConfig,
  OAuthConfig,
} from '@/lib/mcp-types';

// Web Worker specific
import {
  WebMCPServer,
  WebMCPMessage,
  WebMCPProxyConfig,
} from '@/lib/mcp-types';

// Utility functions
import { isMCPError, extractServiceInfoFromContent } from '@/lib/mcp-types';
```

---

## 관련 코드의 구조 및 동작 방식 Summary (Birdeye View)

### Architectural Context

```
┌─────────────────────────────────────────────────────────────────┐
│                        Application Layer                         │
├─────────────────────────────────────────────────────────────────┤
│  React Components (Chat, Tools, Settings)                       │
│    ↓ uses                                                        │
│  Contexts (ChatContext, AssistantContext, WebMCPContext)        │
│    ↓ uses                                                        │
│  Hooks (useUnifiedMCP, useToolProcessor, useRustMCPServer)      │
└─────────────────────────────────────────────────────────────────┘
                              ↓ depends on
┌─────────────────────────────────────────────────────────────────┐
│                        Service Layer                             │
├─────────────────────────────────────────────────────────────────┤
│  rust-backend-client.ts (Tauri command wrappers)                │
│  web-mcp/mcp-proxy.ts (Web Worker communication)                │
│  tools/index.tsx (BuiltInToolProvider)                          │
└─────────────────────────────────────────────────────────────────┘
                              ↓ depends on
┌─────────────────────────────────────────────────────────────────┐
│                    Type Definitions Layer                        │
├─────────────────────────────────────────────────────────────────┤
│  📦 src/lib/mcp-types.ts (CURRENT MONOLITH)                     │
│    - Defines all MCP protocol types                             │
│    - Defines all configuration types                            │
│    - Defines all utility functions                              │
│    - Defines all Web Worker types                               │
└─────────────────────────────────────────────────────────────────┘
                              ↓ consumed by
┌─────────────────────────────────────────────────────────────────┐
│                       Backend Layer                              │
├─────────────────────────────────────────────────────────────────┤
│  Rust Backend (MCPServerManager)                                │
│  Web Workers (planning-server, playbook-store, ui-tools)        │
└─────────────────────────────────────────────────────────────────┘
```

### Type Dependencies Flow

```
External Dependencies:
  - @mcp-ui/server (UIResource)
  - @/features/tools (ServiceContext, ServiceContextOptions)

Core Type Groups (Current Coupling):
  JSON Schema Types ──→ MCP Tool Types
                          ↓
  MCP Content Types ──→ MCP Protocol Types ──→ Web Worker Types
                          ↓                        ↓
                    Config Types ←─────────────────┘
                          ↓
                    Utility Functions (depends on all above)
```

### Key Type Relationships

1. **JSONSchema → MCPTool**: Tools use JSONSchemaObject for inputSchema
2. **MCPContent → MCPResponse**: Responses contain content arrays
3. **MCPTool → WebMCPServer**: Servers expose tool arrays
4. **TransportConfig → MCPServerConfigV2**: Config composition
5. **ServiceInfo → MCPContent**: Content parts track service origin

---

## 변경 이후의 상태 / 해결 판정 기준

### Target Module Structure

```
src/lib/mcp/
├── index.ts                          # 🔄 Barrel export (public API)
│
├── schema/
│   ├── index.ts                      # Schema types barrel
│   ├── json-schema.ts               # Core JSON Schema types (~150 lines)
│   └── builders.ts                   # Schema builder functions (~80 lines)
│
├── protocol/
│   ├── index.ts                      # Protocol types barrel
│   ├── content.ts                    # MCPContent types (~80 lines)
│   ├── response.ts                   # MCPResponse, MCPResult (~100 lines)
│   ├── tool.ts                       # MCPTool types (~50 lines)
│   └── sampling.ts                   # Sampling types (~60 lines)
│
├── config/
│   ├── index.ts                      # Config types barrel
│   ├── server-config.ts             # Server configuration (~120 lines)
│   └── transport.ts                  # TransportConfig, OAuthConfig (~80 lines)
│
├── web-worker/
│   ├── index.ts                      # Web worker types barrel
│   ├── server.ts                     # WebMCPServer interface (~60 lines)
│   ├── message.ts                    # WebMCPMessage types (~40 lines)
│   └── proxy.ts                      # WebMCPProxyConfig (~50 lines)
│
└── utils/
    ├── index.ts                      # Utils barrel
    ├── type-guards.ts               # Type guard functions (~80 lines)
    └── service-info.ts              # ServiceInfo helpers (~40 lines)
```

### Success Criteria

#### Must-Have Requirements

1. ✅ **No Breaking Changes**: All existing imports continue to work
2. ✅ **All Tests Pass**: `pnpm refactor:validate` succeeds
3. ✅ **Build Success**: Production build completes without errors
4. ✅ **Type Safety**: No new TypeScript errors introduced
5. ✅ **Import Compatibility**: Both old and new import paths work

#### Quality Metrics

1. **File Size**: All new files ≤ 150 lines
2. **Import Count**: Reduce by 30% through focused imports
3. **Bundle Size**: No increase (ideally 5-10% decrease with tree shaking)
4. **Cognitive Complexity**: Each module has single clear purpose
5. **Documentation**: Each module has clear README/header comments

#### Verification Steps

```bash
# 1. Type checking
pnpm tsc --noEmit

# 2. Linting
pnpm lint

# 3. Formatting
pnpm format --check

# 4. Build
pnpm build

# 5. Dead code detection
pnpm dead-code

# 6. Full validation
pnpm refactor:validate
```

---

## 수정이 필요한 코드 및 수정부분의 코드 스니핏

### Phase 1: Create New Module Structure (No Breaking Changes)

#### 1.1 Create `src/lib/mcp/schema/json-schema.ts`

```typescript
/**
 * @file JSON Schema Type Definitions
 * @description Core JSON Schema types adhering to JSON Schema Draft 7
 * @see https://json-schema.org/draft-07/json-schema-release-notes.html
 */

/**
 * Represents the possible data types in a JSON Schema.
 */
export type JSONSchemaType =
  | 'string'
  | 'number'
  | 'integer'
  | 'boolean'
  | 'object'
  | 'array'
  | 'null';

/**
 * The base interface for all JSON Schema definitions.
 */
export interface JSONSchemaBase {
  type?: JSONSchemaType | JSONSchemaType[];
  title?: string;
  description?: string;
  default?: unknown;
  examples?: unknown[];
  enum?: unknown[];
  const?: unknown;
}

export interface JSONSchemaString extends JSONSchemaBase {
  type: 'string';
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  format?: string;
}

export interface JSONSchemaNumber extends JSONSchemaBase {
  type: 'number' | 'integer';
  minimum?: number;
  maximum?: number;
  exclusiveMinimum?: number;
  exclusiveMaximum?: number;
  multipleOf?: number;
}

export interface JSONSchemaBoolean extends JSONSchemaBase {
  type: 'boolean';
}

export interface JSONSchemaNull extends JSONSchemaBase {
  type: 'null';
}

export interface JSONSchemaArray extends JSONSchemaBase {
  type: 'array';
  items?: JSONSchema | JSONSchema[];
  minItems?: number;
  maxItems?: number;
  uniqueItems?: boolean;
  additionalItems?: boolean | JSONSchema;
}

export interface JSONSchemaObject extends JSONSchemaBase {
  type: 'object';
  properties?: Record<string, JSONSchema>;
  required?: string[];
  additionalProperties?: boolean | JSONSchema;
  patternProperties?: Record<string, JSONSchema>;
  minProperties?: number;
  maxProperties?: number;
  dependencies?: Record<string, JSONSchema | string[]>;
}

export type JSONSchema =
  | JSONSchemaString
  | JSONSchemaNumber
  | JSONSchemaBoolean
  | JSONSchemaNull
  | JSONSchemaArray
  | JSONSchemaObject
  | (JSONSchemaBase & { type?: JSONSchemaType | JSONSchemaType[] });
```

#### 1.2 Create `src/lib/mcp/schema/builders.ts`

```typescript
/**
 * @file JSON Schema Builder Functions
 * @description Helper functions for creating JSON Schema objects
 */

import type {
  JSONSchemaString,
  JSONSchemaNumber,
  JSONSchemaBoolean,
  JSONSchemaArray,
  JSONSchemaObject,
  JSONSchema,
} from './json-schema';

export function createStringSchema(options?: {
  description?: string;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  format?: string;
}): JSONSchemaString {
  return {
    type: 'string',
    ...options,
  };
}

export function createNumberSchema(options?: {
  description?: string;
  minimum?: number;
  maximum?: number;
  exclusiveMinimum?: number;
  exclusiveMaximum?: number;
  multipleOf?: number;
}): JSONSchemaNumber {
  return {
    type: 'number',
    ...options,
  };
}

export function createIntegerSchema(options?: {
  description?: string;
  minimum?: number;
  maximum?: number;
  exclusiveMinimum?: number;
  exclusiveMaximum?: number;
  multipleOf?: number;
}): JSONSchemaNumber {
  return {
    type: 'integer',
    ...options,
  };
}

export function createBooleanSchema(options?: {
  description?: string;
}): JSONSchemaBoolean {
  return {
    type: 'boolean',
    ...options,
  };
}

export function createArraySchema(options?: {
  description?: string;
  items?: JSONSchema;
  minItems?: number;
  maxItems?: number;
  uniqueItems?: boolean;
}): JSONSchemaArray {
  return {
    type: 'array',
    ...options,
  };
}

export function createObjectSchema(options?: {
  description?: string;
  properties?: Record<string, JSONSchema>;
  required?: string[];
  additionalProperties?: boolean;
}): JSONSchemaObject {
  return {
    type: 'object',
    ...options,
  };
}
```

#### 1.3 Create `src/lib/mcp/schema/index.ts`

```typescript
/**
 * @file JSON Schema Module Barrel Export
 */

export * from './json-schema';
export * from './builders';
```

#### 1.4 Create `src/lib/mcp/protocol/content.ts`

```typescript
/**
 * @file MCP Content Types
 * @description Content types for MCP messages (text, image, audio, resources)
 * @see https://modelcontextprotocol.io/
 */

import { UIResource } from '@mcp-ui/server';

/**
 * Provides information about the service that generated a content part.
 */
export interface ServiceInfo {
  serverName: string;
  toolName: string;
  backendType: 'ExternalMCP' | 'BuiltInWeb' | 'BuiltInRust';
}

export interface MCPTextContent {
  type: 'text';
  text: string;
  annotations?: Record<string, unknown>;
  serviceInfo?: ServiceInfo;
}

export interface MCPImageContent {
  type: 'image';
  data: string; // base64-encoded
  mimeType: string;
  annotations?: Record<string, unknown>;
  serviceInfo?: ServiceInfo;
}

export interface MCPAudioContent {
  type: 'audio';
  data: string; // base64-encoded
  mimeType: string;
  annotations?: Record<string, unknown>;
  serviceInfo?: ServiceInfo;
}

export interface MCPResourceLinkContent {
  type: 'resource_link';
  uri: string;
  name: string;
  description?: string;
  mimeType?: string;
  annotations?: Record<string, unknown>;
  serviceInfo?: ServiceInfo;
}

type MCPResourceContent = UIResource & {
  serviceInfo?: ServiceInfo;
};

export type MCPContent =
  | MCPTextContent
  | MCPImageContent
  | MCPAudioContent
  | MCPResourceLinkContent
  | MCPResourceContent;
```

#### 1.5 Create `src/lib/mcp/protocol/response.ts`

```typescript
/**
 * @file MCP Response Types
 * @description JSON-RPC 2.0 compliant response types
 * @see https://modelcontextprotocol.io/
 */

import type { MCPContent } from './content';

export interface MCPResult<T = unknown> {
  content?: MCPContent[];
  structuredContent?: T;
  isError?: boolean;
}

export interface SamplingResult extends MCPResult {
  sampling?: {
    finishReason?: 'stop' | 'length' | 'tool_use' | 'error';
    usage?: {
      promptTokens: number;
      completionTokens: number;
      totalTokens: number;
    };
    model?: string;
  };
}

export interface MCPError {
  code: number;
  message: string;
  data?: unknown;
}

export interface MCPResponse<T> {
  jsonrpc: '2.0';
  id: string | number | null;
  result?: MCPResult<T> | SamplingResult;
  error?: MCPError;
}

export interface ExtendedMCPResponse extends MCPResponse<unknown> {
  serviceInfo?: {
    serverName: string;
    toolName: string;
    backendType: 'ExternalMCP' | 'BuiltInWeb' | 'BuiltInRust';
  };
}
```

#### 1.6 Create `src/lib/mcp/protocol/tool.ts`

```typescript
/**
 * @file MCP Tool Types
 * @description Tool definition and annotation types
 */

import type { JSONSchemaObject } from '../schema';

export interface MCPToolAnnotations {
  audience?: ('user' | 'assistant')[];
  priority?: number;
  lastModified?: string;
  [key: string]: unknown;
}

export interface MCPTool {
  name: string;
  title?: string;
  description: string;
  inputSchema: JSONSchemaObject;
  outputSchema?: JSONSchemaObject;
  annotations?: MCPToolAnnotations;
  backend?: 'tauri' | 'webworker';
}
```

#### 1.7 Create `src/lib/mcp/protocol/sampling.ts`

```typescript
/**
 * @file MCP Sampling Types
 * @description Text generation and sampling request/response types
 */

import type { MCPResponse, SamplingResult } from './response';

export interface SamplingOptions {
  model?: string;
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  topK?: number;
  stopSequences?: string[];
  presencePenalty?: number;
  frequencyPenalty?: number;
}

export interface SamplingRequest {
  prompt: string;
  options?: SamplingOptions;
}

export interface SamplingResponse extends MCPResponse<unknown> {
  result?: SamplingResult;
}
```

#### 1.8 Create `src/lib/mcp/protocol/index.ts`

```typescript
/**
 * @file MCP Protocol Module Barrel Export
 */

export * from './content';
export * from './response';
export * from './tool';
export * from './sampling';
```

#### 1.9 Create `src/lib/mcp/config/transport.ts`

```typescript
/**
 * @file MCP Transport Configuration Types
 * @description Transport and authentication configuration (MCP 2025-06-18 Spec)
 */

export type TransportConfig =
  | {
      type: 'stdio';
      command: string;
      args?: string[];
      env?: Record<string, string>;
    }
  | {
      type: 'http';
      url: string;
      protocolVersion?: string;
      sessionId?: string;
      headers?: Record<string, string>;
      enableSSE?: boolean;
      security?: {
        enableDnsRebindingProtection?: boolean;
        allowedOrigins?: string[];
        allowedHosts?: string[];
      };
    };

export interface OAuthConfig {
  type: 'oauth2.1';
  discoveryUrl?: string;
  authorizationEndpoint?: string;
  tokenEndpoint?: string;
  registrationEndpoint?: string;
  clientId?: string;
  redirectUri?: string;
  scopes?: string[];
  usePKCE?: boolean;
  resourceParameter?: string;
}
```

#### 1.10 Create `src/lib/mcp/config/server-config.ts`

```typescript
/**
 * @file MCP Server Configuration Types
 * @description Server configuration for both legacy and V2 formats
 */

import type { TransportConfig, OAuthConfig } from './transport';

export interface ServerMetadata {
  description?: string;
  vendor?: string;
  version?: string;
}

export interface MCPServerConfigV2 {
  name: string;
  transport: TransportConfig;
  authentication?: OAuthConfig;
  metadata?: ServerMetadata;
}

export interface LegacyMCPServerConfig {
  command: string;
  args?: string[];
  env?: Record<string, string>;
}

export interface MCPConfig {
  mcpServers?: Record<string, MCPServerConfigV2 | LegacyMCPServerConfig>;
}

// Legacy format (kept for backward compatibility)
export interface MCPServerConfig {
  name: string;
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  transport: 'stdio' | 'http' | 'websocket';
  url?: string;
  port?: number;
}

// Unified configuration
export type MCPServerType = 'tauri' | 'webworker';

export interface UnifiedMCPServerConfig {
  name: string;
  type: MCPServerType;
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  transport?: 'stdio' | 'http' | 'websocket';
  url?: string;
  port?: number;
  modulePath?: string;
  workerPath?: string;
}

export interface MCPToolExecutionContext {
  serverType: MCPServerType;
  serverName: string;
  toolName: string;
  arguments: unknown;
  timeout?: number;
}

// Type guard
export function isMCPServerConfigV2(
  config: MCPServerConfigV2 | LegacyMCPServerConfig,
): config is MCPServerConfigV2 {
  return 'transport' in config && typeof config.transport === 'object';
}

// Converter
export function convertLegacyToV2(
  name: string,
  legacy: LegacyMCPServerConfig,
): MCPServerConfigV2 {
  return {
    name,
    transport: {
      type: 'stdio',
      command: legacy.command,
      args: legacy.args,
      env: legacy.env,
    },
  };
}
```

#### 1.11 Create `src/lib/mcp/config/index.ts`

```typescript
/**
 * @file MCP Configuration Module Barrel Export
 */

export * from './transport';
export * from './server-config';
```

#### 1.12 Create `src/lib/mcp/web-worker/server.ts`

```typescript
/**
 * @file Web Worker MCP Server Interface
 * @description Interface for MCP servers running in Web Workers
 */

import type { MCPTool } from '../protocol';
import type { MCPResponse, SamplingResponse } from '../protocol';
import type { SamplingOptions } from '../protocol';
import type { ServiceContext, ServiceContextOptions } from '@/features/tools';

export interface WebMCPServer {
  name: string;
  description?: string;
  version?: string;
  tools: MCPTool[];
  callTool: (name: string, args: unknown) => Promise<MCPResponse<unknown>>;
  sampleText?: (
    prompt: string,
    options?: SamplingOptions,
  ) => Promise<SamplingResponse>;
  getServiceContext?: (
    options?: ServiceContextOptions,
  ) => Promise<ServiceContext<unknown>>;
  switchContext?: (context: ServiceContextOptions) => Promise<void>;
}

export interface WebMCPServerState {
  loaded: boolean;
  tools: MCPTool[];
  lastError?: string;
  lastActivity?: number;
}
```

#### 1.13 Create `src/lib/mcp/web-worker/message.ts`

```typescript
/**
 * @file Web Worker MCP Message Types
 * @description Message protocol for Web Worker communication
 */

export interface WebMCPMessage {
  id: string;
  type:
    | 'listTools'
    | 'callTool'
    | 'ping'
    | 'loadServer'
    | 'sampleText'
    | 'getServiceContext'
    | 'setContext'
    | 'switchContext';
  serverName?: string;
  toolName?: string;
  args?: unknown;
}
```

#### 1.14 Create `src/lib/mcp/web-worker/proxy.ts`

```typescript
/**
 * @file Web Worker MCP Proxy Configuration
 * @description Configuration types for Web Worker proxy
 */

export interface WebMCPProxyConfig {
  workerPath?: string;
  workerInstance?: Worker;
  timeout?: number;
  retryOptions?: {
    maxRetries?: number;
    baseDelay?: number;
    maxDelay?: number;
    timeout?: number;
  };
}
```

#### 1.15 Create `src/lib/mcp/web-worker/index.ts`

```typescript
/**
 * @file Web Worker MCP Module Barrel Export
 */

export * from './server';
export * from './message';
export * from './proxy';
```

#### 1.16 Create `src/lib/mcp/utils/type-guards.ts`

```typescript
/**
 * @file MCP Type Guard Functions
 * @description Runtime type checking utilities
 */

import type { MCPResponse, MCPResult, ExtendedMCPResponse } from '../protocol';

export function isMCPSuccess(
  response: MCPResponse<unknown>,
): response is MCPResponse<unknown> & { result: MCPResult } {
  return response.error === undefined && response.result !== undefined;
}

export function isMCPError(
  response: MCPResponse<unknown>,
): response is MCPResponse<unknown> & {
  error: { code: number; message: string; data?: unknown };
} {
  return response.error !== undefined;
}

export function isValidMCPResult(result: MCPResult): boolean {
  return !!(result.content?.length || result.structuredContent);
}

export function extractStructuredContent<T>(
  response: MCPResponse<T>,
): T | null {
  if (!response.result || response.error) {
    return null;
  }

  if ('sampling' in response.result) {
    return null;
  }

  return (response.result as MCPResult<T>).structuredContent || null;
}

export function hasStructuredContent<T>(
  response: MCPResponse<T>,
): response is MCPResponse<T> & {
  result: MCPResult<T> & { structuredContent: T };
} {
  const structured = extractStructuredContent(response);
  return structured !== null && structured !== undefined;
}

export function isExtendedResponse(
  response: MCPResponse<unknown>,
): response is ExtendedMCPResponse {
  return response && typeof response === 'object' && 'serviceInfo' in response;
}
```

#### 1.17 Create `src/lib/mcp/utils/service-info.ts`

```typescript
/**
 * @file Service Info Utilities
 * @description Helper functions for extracting service information
 */

import type { MCPContent, ServiceInfo } from '../protocol';

export function hasServiceInfo(
  content: MCPContent,
): content is MCPContent & { serviceInfo: ServiceInfo } {
  return (
    content &&
    typeof content === 'object' &&
    'serviceInfo' in content &&
    content.serviceInfo !== undefined
  );
}

export function extractServiceInfoFromContent(
  content: MCPContent[],
): ServiceInfo | null {
  for (const item of content) {
    if (hasServiceInfo(item)) {
      return item.serviceInfo;
    }
  }
  return null;
}
```

#### 1.18 Create `src/lib/mcp/utils/index.ts`

```typescript
/**
 * @file MCP Utils Module Barrel Export
 */

export * from './type-guards';
export * from './service-info';
```

#### 1.19 Create `src/lib/mcp/index.ts` (Main Barrel Export)

```typescript
/**
 * @file MCP Module Public API
 * @description Unified export for all MCP types and utilities
 *
 * This barrel export maintains backward compatibility while enabling
 * tree-shaking through granular imports.
 *
 * @example
 * // Old way (still works)
 * import { MCPTool, MCPResponse } from '@/lib/mcp-types';
 *
 * // New way (preferred for tree-shaking)
 * import { MCPTool } from '@/lib/mcp/protocol';
 * import { MCPResponse } from '@/lib/mcp/protocol';
 *
 * // Or use barrel
 * import { MCPTool, MCPResponse } from '@/lib/mcp';
 */

// Schema types
export * from './schema';

// Protocol types
export * from './protocol';

// Configuration types
export * from './config';

// Web Worker types
export * from './web-worker';

// Utility functions
export * from './utils';
```

#### 1.20 Update `src/lib/mcp-types.ts` (Temporary Compatibility Layer)

```typescript
/**
 * @file MCP Types (Legacy Compatibility Layer)
 *
 * @deprecated This file is deprecated and will be removed in a future version.
 * Please migrate to the new modular structure:
 *
 * - Schema types: import from '@/lib/mcp/schema'
 * - Protocol types: import from '@/lib/mcp/protocol'
 * - Config types: import from '@/lib/mcp/config'
 * - Web Worker types: import from '@/lib/mcp/web-worker'
 * - Utilities: import from '@/lib/mcp/utils'
 *
 * Or use the barrel export: import from '@/lib/mcp'
 */

// Re-export everything from new modular structure for backward compatibility
export * from './mcp';

// This file can be removed once all imports are migrated
```

---

## 재사용 가능한 연관 코드

### Related Files and Their Roles

#### 1. **High-Priority Migration Targets** (Direct MCP type consumers)

**`src/lib/rust-backend-client.ts`**

- **Role**: Tauri command wrapper, primary MCP bridge
- **Current imports**: MCPResponse, MCPTool, MCPContent, TransportConfig, OAuthConfig
- **Migration priority**: HIGH
- **Key interfaces**:
  - `listMCPTools()` → uses MCPTool[]
  - `callMCPTool()` → uses MCPResponse
  - `createExternalMCPServer()` → uses TransportConfig, OAuthConfig

**`src/models/chat.ts`**

- **Role**: Core data models for chat/session/thread
- **Current imports**: MCPTool, MCPContent, MCPServerConfigV2, LegacyMCPServerConfig
- **Migration priority**: HIGH
- **Key interfaces**:
  - `Message.content` → uses MCPContent[]
  - `Assistant.mcpServers` → uses MCPServerConfigV2
  - `Tool extends MCPTool` → extends MCPTool

**`src/lib/web-mcp/mcp-proxy.ts`**

- **Role**: Web Worker communication proxy
- **Current imports**: WebMCPMessage, WebMCPProxyConfig, MCPTool, MCPResponse
- **Migration priority**: HIGH
- **Key methods**:
  - `listTools()` → returns MCPTool[]
  - `callTool()` → returns MCPResponse

#### 2. **Feature Modules** (Tool providers and contexts)

**`src/features/tools/index.tsx` (BuiltInToolProvider)**

- **Current imports**: MCPResponse, MCPTool
- **Key functionality**: Central tool registry and execution
- **Migration impact**: Medium (affects all tool providers)

**`src/context/WebMCPContext.tsx`**

- **Current imports**: MCPTool
- **Key functionality**: Web Worker MCP state management
- **Migration impact**: Medium

**`src/hooks/use-unified-mcp.ts`**

- **Current imports**: MCPContent, MCPResponse, MCPTool, ServiceInfo
- **Key functionality**: Unified MCP tool execution hook
- **Migration impact**: Medium

#### 3. **Web Worker MCP Servers** (Built-in services)

All located in `src/lib/web-mcp/modules/`:

- `planning-server/` → uses MCPTool, MCPResponse, WebMCPServer
- `playbook-store/` → uses MCPTool, MCPResponse, WebMCPServer, MCPContent
- `bootstrap-server/` → uses MCPTool, MCPResponse, WebMCPServer
- `ui-tools/` → uses MCPTool, MCPResponse, various types

### Reusable Patterns

#### Type Guard Pattern

```typescript
// Current usage in multiple files
if (isMCPError(response)) {
  // Handle error
}

// After refactoring: import from utils
import { isMCPError } from '@/lib/mcp/utils';
```

#### Service Info Extraction Pattern

```typescript
// Current usage in MessageRenderer, chat utils
const serviceInfo = extractServiceInfoFromContent(content);

// After refactoring: import from utils
import { extractServiceInfoFromContent } from '@/lib/mcp/utils';
```

#### Schema Builder Pattern

```typescript
// Current usage in browser tools, Web Worker servers
const inputSchema = createObjectSchema({
  properties: {
    url: createStringSchema({ description: 'URL to navigate to' }),
  },
  required: ['url'],
});

// After refactoring: import from schema builders
import { createObjectSchema, createStringSchema } from '@/lib/mcp/schema';
```

---

## Test Code 추가 및 수정 필요 부분에 대한 가이드 포함

### Testing Strategy

#### Unit Tests for New Modules

**1. Schema Builder Tests** (`src/lib/mcp/schema/__tests__/builders.test.ts`)

```typescript
import { describe, it, expect } from 'vitest';
import {
  createStringSchema,
  createNumberSchema,
  createObjectSchema,
} from '../builders';

describe('Schema Builders', () => {
  it('should create string schema with constraints', () => {
    const schema = createStringSchema({
      description: 'Test string',
      minLength: 1,
      maxLength: 100,
    });

    expect(schema.type).toBe('string');
    expect(schema.minLength).toBe(1);
    expect(schema.maxLength).toBe(100);
  });

  it('should create object schema with properties', () => {
    const schema = createObjectSchema({
      properties: {
        name: createStringSchema(),
        age: createNumberSchema({ minimum: 0 }),
      },
      required: ['name'],
    });

    expect(schema.type).toBe('object');
    expect(schema.required).toContain('name');
  });
});
```

**2. Type Guard Tests** (`src/lib/mcp/utils/__tests__/type-guards.test.ts`)

```typescript
import { describe, it, expect } from 'vitest';
import { isMCPSuccess, isMCPError, hasStructuredContent } from '../type-guards';
import type { MCPResponse } from '../../protocol';

describe('MCP Type Guards', () => {
  it('should identify successful response', () => {
    const response: MCPResponse<unknown> = {
      jsonrpc: '2.0',
      id: '1',
      result: { content: [{ type: 'text', text: 'Success' }] },
    };

    expect(isMCPSuccess(response)).toBe(true);
    expect(isMCPError(response)).toBe(false);
  });

  it('should identify error response', () => {
    const response: MCPResponse<unknown> = {
      jsonrpc: '2.0',
      id: '1',
      error: { code: -1, message: 'Error' },
    };

    expect(isMCPError(response)).toBe(true);
    expect(isMCPSuccess(response)).toBe(false);
  });

  it('should detect structured content', () => {
    const response: MCPResponse<{ data: string }> = {
      jsonrpc: '2.0',
      id: '1',
      result: { structuredContent: { data: 'test' } },
    };

    expect(hasStructuredContent(response)).toBe(true);
  });
});
```

**3. Service Info Tests** (`src/lib/mcp/utils/__tests__/service-info.test.ts`)

```typescript
import { describe, it, expect } from 'vitest';
import { hasServiceInfo, extractServiceInfoFromContent } from '../service-info';
import type { MCPContent } from '../../protocol';

describe('Service Info Utilities', () => {
  it('should detect service info in content', () => {
    const content: MCPContent = {
      type: 'text',
      text: 'Test',
      serviceInfo: {
        serverName: 'test-server',
        toolName: 'test-tool',
        backendType: 'BuiltInWeb',
      },
    };

    expect(hasServiceInfo(content)).toBe(true);
  });

  it('should extract service info from content array', () => {
    const contentArray: MCPContent[] = [
      { type: 'text', text: 'No info' },
      {
        type: 'text',
        text: 'With info',
        serviceInfo: {
          serverName: 'test-server',
          toolName: 'test-tool',
          backendType: 'ExternalMCP',
        },
      },
    ];

    const info = extractServiceInfoFromContent(contentArray);
    expect(info).not.toBeNull();
    expect(info?.serverName).toBe('test-server');
  });
});
```

#### Integration Tests

**Backward Compatibility Test** (`src/lib/mcp/__tests__/backward-compatibility.test.ts`)

```typescript
import { describe, it, expect } from 'vitest';

describe('MCP Types Backward Compatibility', () => {
  it('should support old import path', async () => {
    // Old path should still work
    const oldImport = await import('../../mcp-types');
    expect(oldImport.MCPTool).toBeDefined();
    expect(oldImport.MCPResponse).toBeDefined();
    expect(oldImport.isMCPSuccess).toBeDefined();
  });

  it('should support new import paths', async () => {
    // New paths should work
    const protocolImport = await import('../protocol');
    const schemaImport = await import('../schema');
    const utilsImport = await import('../utils');

    expect(protocolImport.MCPTool).toBeDefined();
    expect(schemaImport.JSONSchema).toBeDefined();
    expect(utilsImport.isMCPSuccess).toBeDefined();
  });

  it('should have identical types from both paths', async () => {
    const oldImport = await import('../../mcp-types');
    const newImport = await import('../index');

    // Constructor names should match
    const oldTool = {} as typeof oldImport.MCPTool;
    const newTool = {} as typeof newImport.MCPTool;

    // TypeScript should treat them as identical
    const testAssignment: typeof oldTool = newTool;
    expect(testAssignment).toBeDefined();
  });
});
```

#### Existing Test Updates

**Files requiring test updates:**

1. `src/lib/web-mcp/modules/__tests__/ui-tools.test.ts`
   - Update imports to use new structure
   - Verify MCPResponse, MCPResult types still work

2. Any tests importing from `mcp-types.ts`
   - Add tests to verify both old and new imports work
   - Gradually migrate to new imports

### Test Execution Plan

```bash
# Phase 1: Verify existing tests still pass
pnpm test

# Phase 2: Run new module tests
pnpm test src/lib/mcp

# Phase 3: Run backward compatibility tests
pnpm test -- --grep "backward compatibility"

# Phase 4: Full test suite
pnpm test -- --coverage
```

---

## 구현 체크리스트

### Phase 1: Structure Creation (Non-Breaking)

- [ ] Create `src/lib/mcp/` directory structure
- [ ] Implement all module files (schema, protocol, config, web-worker, utils)
- [ ] Create barrel exports (`index.ts` files)
- [ ] Create main `src/lib/mcp/index.ts` with full re-exports
- [ ] Update `src/lib/mcp-types.ts` to re-export from new structure
- [ ] Run `pnpm tsc --noEmit` to verify no type errors
- [ ] Run `pnpm refactor:validate` to ensure build works

### Phase 2: Documentation & Testing

- [ ] Add JSDoc comments to all new modules
- [ ] Create unit tests for utils (type-guards, service-info)
- [ ] Create unit tests for schema builders
- [ ] Create backward compatibility integration tests
- [ ] Update main README with new import patterns
- [ ] Run `pnpm test` to verify all tests pass

### Phase 3: Gradual Migration (High-Traffic Files)

- [ ] Update `src/lib/rust-backend-client.ts` imports
- [ ] Update `src/models/chat.ts` imports
- [ ] Update `src/lib/web-mcp/mcp-proxy.ts` imports
- [ ] Update `src/features/tools/index.tsx` imports
- [ ] Run `pnpm refactor:validate` after each file
- [ ] Verify no runtime errors in development

### Phase 4: Feature Module Migration

- [ ] Update `src/context/*.tsx` imports (4 files)
- [ ] Update `src/features/tools/*.tsx` imports (5+ files)
- [ ] Update `src/hooks/*.ts` imports (3 files)
- [ ] Update `src/lib/web-mcp/modules/*/` imports (8+ files)
- [ ] Run full test suite: `pnpm test`
- [ ] Run `pnpm dead-code` to check for unused exports

### Phase 5: Component Migration

- [ ] Update `src/components/MessageRenderer.tsx` imports
- [ ] Update other component imports as needed
- [ ] Run development server and verify UI works
- [ ] Test key workflows (chat, tool execution, MCP server management)

### Phase 6: Final Cleanup

- [ ] Add deprecation notice to `src/lib/mcp-types.ts`
- [ ] Update `.github/copilot-instructions.md` with new patterns
- [ ] Update `agents.md` documentation
- [ ] Remove `src/lib/mcp-types.ts` (only after all migrations complete)
- [ ] Run final validation: `pnpm refactor:validate`
- [ ] Create production build: `pnpm build`
- [ ] Verify bundle size changes

### Phase 7: Documentation Finalization

- [ ] Update architecture documentation in `docs/`
- [ ] Add migration guide for external contributors
- [ ] Update CHANGELOG.md with breaking changes (if any)
- [ ] Create PR with detailed summary

---

## Clarification Q-list

### Questions Requiring User Decision

1. **Migration Timeline**
   - Q: Should we complete the full migration in one PR or split into multiple PRs?
   - Options:
     - A) Single large PR (easier to review holistically, but risky)
     - B) 3 PRs: Structure → Migration → Cleanup (safer, incremental)
     - C) Per-module PRs (very granular, but many PRs)
   - **Recommendation**: Option B (3-phase PR approach)

2. **Deprecation Strategy**
   - Q: How long should we maintain the old `mcp-types.ts` compatibility layer?
   - Options:
     - A) Remove immediately after internal migration (aggressive)
     - B) Keep for 1-2 releases with deprecation warnings (balanced)
     - C) Maintain indefinitely (conservative)
   - **Recommendation**: Option B (1-2 releases)

3. **Bundle Size Verification**
   - Q: Should we add bundle size checks to CI/CD?
   - Context: Tree-shaking benefits should reduce bundle size by 5-10%
   - **Recommendation**: Yes, add bundle size tracking to CI

4. **External Dependencies**
   - Q: Should we move `@mcp-ui/server` UIResource import to a separate adapter file?
   - Context: Currently directly imported in protocol/content.ts
   - Trade-offs:
     - Pro: Better decoupling from external dependencies
     - Con: Additional indirection layer
   - **Recommendation**: Keep as-is for now, revisit if UIResource evolves

5. **Schema Validation**
   - Q: Should we add runtime schema validation using JSON Schema validators?
   - Context: Currently only TypeScript compile-time checks
   - Tools: Ajv, Zod, or json-schema library
   - **Recommendation**: Future enhancement, not in scope for this refactoring

6. **Type Safety for Web Worker Messages**
   - Q: Should we add stricter typing for `WebMCPMessage.args`?
   - Context: Currently `unknown`, could be more specific per message type
   - **Recommendation**: Future enhancement using discriminated unions

---

## 추가 분석 과제

### Areas Requiring Further Investigation

1. **Circular Dependency Analysis**
   - Tool: Use `madge` or `dpdm` to detect circular imports
   - Command: `npx madge --circular --extensions ts,tsx src/lib/mcp`
   - Goal: Ensure new structure doesn't introduce circular dependencies

2. **Bundle Size Impact Measurement**
   - Tool: `webpack-bundle-analyzer` or Vite's rollup-plugin-visualizer
   - Baseline: Measure current bundle size with `mcp-types.ts`
   - Target: Achieve 5-10% reduction through tree-shaking
   - Command: `pnpm build && npx vite-bundle-visualizer`

3. **Import Performance Analysis**
   - Tool: TypeScript's `--traceResolution` and `--extendedDiagnostics`
   - Measure: Time for type checking before/after refactoring
   - Command: `pnpm tsc --noEmit --extendedDiagnostics`

4. **Dead Code Detection**
   - Tool: `unimported` (already configured)
   - Goal: Identify unused exports in old structure that can be removed
   - Command: `pnpm dead-code`

5. **Type Compatibility Verification**
   - Create comprehensive type tests using `expect-type` or `tsd`
   - Verify that old and new exports are structurally identical
   - Example:

     ```typescript
     import { expectType } from 'tsd';
     import type { MCPTool as OldMCPTool } from '@/lib/mcp-types';
     import type { MCPTool as NewMCPTool } from '@/lib/mcp';

     const tool: OldMCPTool = {} as NewMCPTool; // Should compile
     expectType<NewMCPTool>(tool);
     ```

---

## 성공 지표 (Success Metrics)

### Quantitative Metrics

1. **File Size**: Average file size ≤ 150 lines (target: ~80-100 lines)
2. **Bundle Size**: No increase, ideally 5-10% decrease
3. **Build Time**: No significant increase (< 5% acceptable)
4. **Test Coverage**: Maintain or improve current coverage
5. **Import Count**: Reduce by 30% through focused imports

### Qualitative Metrics

1. **Developer Experience**: Easier to locate specific types
2. **Code Review**: Smaller, more focused diffs
3. **Maintainability**: Clear ownership and responsibility per module
4. **Documentation**: Self-documenting structure through file organization

---

## 참고 자료

- [MCP Specification](https://modelcontextprotocol.io/)
- [JSON Schema Draft 7](https://json-schema.org/draft-07/json-schema-release-notes.html)
- [JSON-RPC 2.0 Specification](https://www.jsonrpc.org/specification)
- [TypeScript Module Documentation](https://www.typescriptlang.org/docs/handbook/modules.html)
- [Tree Shaking Best Practices](https://webpack.js.org/guides/tree-shaking/)


---

# refactoring_20251012_2259.md

# Refactoring Plan: Platform-Specific Shell Execution Tool Names

## 작업의 목적

현재 `execute_shell` 도구는 플랫폼에 관계없이 단일 이름으로 제공되지만, Unix 계열(bash/sh)과 Windows(cmd.exe) 시스템에서 서로 다른 셸을 사용합니다. 이로 인해:

1. **명확성 부족**: 도구 이름만으로는 어떤 셸이 사용되는지 명확하지 않음
2. **멀티플랫폼 혼란**: 크로스 플랫폼 환경에서 에이전트가 플랫폼별 동작을 예측하기 어려움
3. **문서화 복잡성**: 하나의 도구 설명에 두 플랫폼의 동작을 모두 기술해야 함

이 리팩토링은 Rust의 `cfg` 속성을 활용해 **플랫폼별로 명확한 도구 이름**을 제공하여 도구의 목적과 동작을 분명히 합니다:

- Unix 계열: `execute_shell` (bash/sh 사용)
- Windows: `execute_windows_cmd` (cmd.exe 사용)

---

## 현재의 상태 / 문제점

### 현재 구조

**도구 정의 위치:**

- `src-tauri/src/mcp/builtin/workspace/tools/code_tools.rs`
  - `create_execute_shell_tool()` 함수가 단일 `MCPTool` 반환
  - 도구 이름: `"execute_shell"`
  - 스키마는 플랫폼 무관

**도구 등록:**

- `src-tauri/src/mcp/builtin/workspace/tools/mod.rs`
  - `code_tools()` 함수에서 `create_execute_shell_tool()` 호출
  - 반환된 도구를 `Vec<MCPTool>`에 추가

**도구 핸들링:**

- `src-tauri/src/mcp/builtin/workspace/mod.rs`
  - `call_tool()` 메서드에서 `"execute_shell"` 문자열 매칭
  - `handle_execute_shell(args)` 호출

**실제 실행 로직:**

- `src-tauri/src/mcp/builtin/workspace/code_execution.rs`
  - `handle_execute_shell()`: 동기/비동기 모드 분기
  - `execute_shell_with_isolation()`: 동기 실행
  - `execute_shell_async()`: 비동기 실행
  - `SessionIsolationManager`에 명령 생성 위임

- `src-tauri/src/session_isolation.rs`
  - `create_isolated_command()`: 격리 수준별 명령 생성
  - `create_basic_isolated_command()`: 기본 격리
  - **플랫폼 분기 지점**: `cfg!(target_os = "windows")` 체크
    - Windows: `cmd /C` 또는 PowerShell 직접 실행
    - Unix: `bash -c` 또는 `sh -c`

### 문제점

1. **도구 이름과 동작의 불일치**
   - 도구 이름은 `execute_shell`로 중립적이나, 실제로는 플랫폼별로 다른 셸 사용
   - Windows에서 "shell"이라는 이름이 혼란스러움 (일반적으로 cmd, PowerShell 등으로 구분)

2. **에이전트의 플랫폼 인식 부족**
   - LLM 에이전트가 도구 발견 시, 플랫폼별 차이를 인지하지 못함
   - Unix 명령어를 Windows에서 실행하거나 그 반대 시도 가능

3. **스키마와 예제의 혼란**
   - 현재 `code_tools.rs`의 예제는 Unix 명령어 중심 (`ls -la`, `grep`, `source`)
   - Windows에서는 이 명령어들이 대부분 작동하지 않음

4. **유지보수 복잡성**
   - 단일 도구 설명에 플랫폼별 동작을 모두 포함해야 함
   - 플랫폼별 테스트 케이스 작성 시 혼란

---

## 관련 코드의 구조 및 동작 방식 Summary (Bird's Eye View)

### 아키텍처 개요

```text
┌─────────────────────────────────────────────────────────────┐
│                   MCP Client (Frontend)                     │
│              Tool Discovery & Invocation                    │
└──────────────────────┬──────────────────────────────────────┘
                       │ call_tool("execute_shell", args)
                       ▼
┌─────────────────────────────────────────────────────────────┐
│        WorkspaceServer::call_tool() [mod.rs:751]            │
│          Route tool name to handler function                │
└──────────────────────┬──────────────────────────────────────┘
                       │ handle_execute_shell(args)
                       ▼
┌─────────────────────────────────────────────────────────────┐
│   WorkspaceServer::handle_execute_shell() [code_exec:500]   │
│   - Parse args (command, run_mode, timeout, isolation)     │
│   - Branch: sync → execute_shell_with_isolation()          │
│            async → execute_shell_async()                   │
└──────────────────────┬──────────────────────────────────────┘
                       │
          ┌────────────┴────────────┐
          ▼                         ▼
┌──────────────────────┐   ┌──────────────────────┐
│ execute_shell_with_  │   │ execute_shell_async()│
│ isolation() [sync]   │   │ [async background]   │
└──────┬───────────────┘   └──────┬───────────────┘
       │                          │
       └──────────┬───────────────┘
                  │ SessionIsolationManager::create_isolated_command()
                  ▼
┌─────────────────────────────────────────────────────────────┐
│    SessionIsolationManager [session_isolation.rs]           │
│    - create_isolated_command(config)                        │
│      → Branch by isolation_level:                           │
│         Basic   → create_basic_isolated_command()           │
│         Medium  → create_medium_isolated_command()          │
│         High    → create_high_isolated_command()            │
└──────────────────────┬──────────────────────────────────────┘
                       │ create_basic_isolated_command()
                       ▼
┌─────────────────────────────────────────────────────────────┐
│    Platform-Specific Command Construction                   │
│    [session_isolation.rs:110-200]                           │
│                                                              │
│    if cfg!(target_os = "windows") {                         │
│        if PowerShell detected:                              │
│            AsyncCommand::new("powershell")                  │
│        else:                                                │
│            AsyncCommand::new("cmd")                         │
│            cmd.args(["/C", command])                        │
│    } else {                                                 │
│        AsyncCommand::new("bash") or "sh"                    │
│        cmd.args(["-c", command])                            │
│    }                                                        │
└─────────────────────────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│    spawn_and_stream_to_files() [code_exec:14]               │
│    - tokio::process::Command::spawn()                       │
│    - Stream stdout/stderr to files                          │
│    - Respect cancellation token                             │
│    - Return (pid, exit_code, stdout, stderr)                │
└─────────────────────────────────────────────────────────────┘
```

### 주요 컴포넌트

#### 1. **도구 정의** (`tools/code_tools.rs`)

- `create_execute_shell_tool()`: MCPTool 스키마 생성
- 현재 단일 함수, 플랫폼 무관

#### 2. **도구 등록** (`tools/mod.rs`)

- `code_tools()`: 도구 벡터 반환
- `WorkspaceServer::list_tools()`에서 사용

#### 3. **도구 라우팅** (`mod.rs`)

- `call_tool()`: 도구 이름으로 핸들러 매칭
- 현재 `"execute_shell"` 하드코딩

#### 4. **실행 로직** (`code_execution.rs`)

- `handle_execute_shell()`: 파라미터 파싱 및 모드 분기
- `execute_shell_with_isolation()`: 동기 실행 + timeout
- `execute_shell_async()`: 비동기 백그라운드 실행
- `spawn_and_stream_to_files()`: 공통 프로세스 spawn/stream 로직

#### 5. **격리 관리** (`session_isolation.rs`)

- `SessionIsolationManager`: 플랫폼별 격리 명령 생성
- **핵심 플랫폼 분기**:
  - Windows: `cmd /C` 또는 PowerShell
  - Unix: `bash -c` 또는 `sh -c`
- 환경변수, 작업 디렉토리, PATH 설정

### 데이터 플로우

1. **도구 발견**: MCP 클라이언트가 `list_tools()` 호출 → `create_execute_shell_tool()` 반환
2. **도구 호출**: 클라이언트가 `call_tool("execute_shell", args)` 호출
3. **라우팅**: `WorkspaceServer::call_tool()`에서 `handle_execute_shell()` 호출
4. **파라미터 파싱**: `command`, `run_mode`, `timeout`, `isolation` 추출
5. **모드 분기**:
   - sync → `execute_shell_with_isolation()` (timeout 적용)
   - async → `execute_shell_async()` (백그라운드 spawn)
6. **격리 명령 생성**: `SessionIsolationManager::create_isolated_command()`
   - 플랫폼 감지 (`cfg!(target_os = "windows")`)
   - 셸 선택 (Windows: cmd/PowerShell, Unix: bash/sh)
7. **프로세스 실행**: `spawn_and_stream_to_files()`
   - `tokio::process::Command::spawn()`
   - stdout/stderr 스트리밍
8. **결과 반환**: MCPResponse (success/error)

---

## 변경 이후의 상태 / 해결 판정 기준

### 목표 상태

1. **플랫폼별 명확한 도구 이름**
   - Unix: `execute_shell` (bash/sh 사용)
   - Windows: `execute_windows_cmd` (cmd.exe 사용)

2. **플랫폼별 최적화된 스키마**
   - Unix: `ls`, `grep`, `bash` 관련 예제
   - Windows: `dir`, `type`, `cmd` 관련 예제

3. **에이전트 경험 향상**
   - 도구 이름만으로 플랫폼과 셸을 즉시 인지
   - 플랫폼별 명령어 예제로 학습 용이

4. **유지보수 개선**
   - 플랫폼별 코드 분리로 이해 용이
   - 테스트 케이스 작성 명확

### 해결 판정 기준

#### ✅ 필수 조건

1. **컴파일 성공**
   - Windows와 Unix 타겟 모두 컴파일 성공
   - `pnpm tauri build` 통과

2. **도구 발견 테스트**
   - Windows 빌드: `list_tools()`가 `execute_windows_cmd` 반환
   - Unix 빌드: `list_tools()`가 `execute_shell` 반환

3. **도구 호출 성공**
   - Windows: `call_tool("execute_windows_cmd", {"command": "dir"})`로 정상 실행
   - Unix: `call_tool("execute_shell", {"command": "ls"})`로 정상 실행

4. **기존 기능 유지**
   - 동기/비동기 모드 정상 작동
   - 격리 수준 (basic/medium/high) 정상 작동
   - 타임아웃, 프로세스 레지스트리, 출력 스트리밍 정상 작동

#### ✅ 검증 항목

1. **단위 테스트**
   - 각 플랫폼별 도구 생성 함수 테스트
   - 도구 이름 검증

2. **통합 테스트**
   - Windows: `execute_windows_cmd`로 `dir`, `echo` 실행
   - Unix: `execute_shell`로 `ls`, `echo` 실행

3. **문서 일관성**
   - 도구 description과 실제 동작 일치
   - 예제 명령어가 플랫폼에서 작동

---

## 수정이 필요한 코드 및 수정 부분

### 1. 도구 정의 수정 (`src-tauri/src/mcp/builtin/workspace/tools/code_tools.rs`)

**목표**: 플랫폼별로 다른 `MCPTool` 반환

**변경 사항**:

- 기존 `create_execute_shell_tool()` 함수를 플랫폼별로 분기
- `#[cfg(unix)]`와 `#[cfg(windows)]` 속성 사용

**수정 코드**:

```rust
// Unix 플랫폼용 도구 (기존 동작 유지, 이름 그대로)
#[cfg(unix)]
pub fn create_execute_shell_tool() -> MCPTool {
    let mut props = HashMap::new();
    props.insert(
        "command".to_string(),
        string_prop_with_examples(
            Some(1),
            Some(1000),
            Some("Shell command to execute (bash/sh)"),
            vec![
                json!("ls -la"),
                json!("grep -r 'pattern' ."),
                json!("source script.sh"),
            ],
        ),
    );
    props.insert(
        "timeout".to_string(),
        integer_prop_with_default(
            Some(1),
            Some(crate::config::max_execution_timeout() as i64),
            crate::config::default_execution_timeout() as i64,
            Some("Timeout in seconds (sync mode only, default: 30)"),
        ),
    );
    props.insert(
        "run_mode".to_string(),
        enum_prop(
            vec!["sync", "async"],
            "sync",
            Some("Execution mode: 'sync' (wait for completion), 'async' (return immediately with process_id)"),
        ),
    );

    MCPTool {
        name: "execute_shell".to_string(),
        title: Some("Execute Shell Command (bash/sh)".to_string()),
        description: "Execute a shell command using bash or sh in a sandboxed environment.\n\n\
                      MODES:\n\
                      - 'sync' (default): Wait for completion, return stdout/stderr immediately\n\
                      - 'async': Run in background, return process_id immediately\n\n\
                      For async mode, use 'poll_process' to check status and retrieve output.\n\n\
                      PLATFORM: Unix (Linux, macOS) - uses bash or sh shell."
            .to_string(),
        input_schema: object_schema(props, vec!["command".to_string()]),
        output_schema: None,
        annotations: None,
    }
}

// Windows 플랫폼용 도구 (cmd.exe 명시)
#[cfg(windows)]
pub fn create_execute_shell_tool() -> MCPTool {
    let mut props = HashMap::new();
    props.insert(
        "command".to_string(),
        string_prop_with_examples(
            Some(1),
            Some(1000),
            Some("Command to execute using cmd.exe"),
            vec![
                json!("dir /b"),
                json!("echo Hello World"),
                json!("type file.txt"),
            ],
        ),
    );
    props.insert(
        "timeout".to_string(),
        integer_prop_with_default(
            Some(1),
            Some(crate::config::max_execution_timeout() as i64),
            crate::config::default_execution_timeout() as i64,
            Some("Timeout in seconds (sync mode only, default: 30)"),
        ),
    );
    props.insert(
        "run_mode".to_string(),
        enum_prop(
            vec!["sync", "async"],
            "sync",
            Some("Execution mode: 'sync' (wait for completion), 'async' (return immediately with process_id)"),
        ),
    );

    MCPTool {
        name: "execute_windows_cmd".to_string(),
        title: Some("Execute Windows Command (cmd.exe)".to_string()),
        description: "Execute a command using Windows cmd.exe in a sandboxed environment.\n\n\
                      MODES:\n\
                      - 'sync' (default): Wait for completion, return stdout/stderr immediately\n\
                      - 'async': Run in background, return process_id immediately\n\n\
                      For async mode, use 'poll_process' to check status and retrieve output.\n\n\
                      PLATFORM: Windows - uses cmd.exe (Command Prompt).\n\
                      NOTE: For PowerShell features, the system may automatically use PowerShell if available."
            .to_string(),
        input_schema: object_schema(props, vec!["command".to_string()]),
        output_schema: None,
        annotations: None,
    }
}
```

### 2. 도구 라우팅 수정 (`src-tauri/src/mcp/builtin/workspace/mod.rs`)

**목표**: 플랫폼별 도구 이름으로 라우팅

**변경 사항**:

- `call_tool()` 메서드의 매칭 로직을 플랫폼별로 분기

**수정 코드** (line 740-760 부근):

```rust
        match tool_name {
            // File operation tools
            "read_file" => self.handle_read_file(args).await,
            "write_file" => self.handle_write_file(args).await,
            "list_directory" => self.handle_list_directory(args).await,
            "replace_lines_in_file" => self.handle_replace_lines_in_file(args).await,
            "import_file" => self.handle_import_file(args).await,
            // Code execution tools
            // Platform-specific shell execution tools
            #[cfg(unix)]
            "execute_shell" => self.handle_execute_shell(args).await,
            #[cfg(windows)]
            "execute_windows_cmd" => self.handle_execute_shell(args).await,
            // Export tools
            "export_file" => self.handle_export_file(args).await,
            "export_zip" => self.handle_export_zip(args).await,
            // Terminal/Process management tools
            "poll_process" => self.handle_poll_process(args).await,
            "read_process_output" => self.handle_read_process_output(args).await,
            "list_processes" => self.handle_list_processes(args).await,
            _ => {
                let request_id = Self::generate_request_id();
                Self::error_response(request_id, -32601, &format!("Tool '{tool_name}' not found"))
            }
        }
```

**주의**: `handle_execute_shell()` 내부 로직은 변경 불필요 (이미 플랫폼 분기 처리됨)

### 3. 문서 업데이트 (`docs/builtin-tools.md`)

**목표**: 플랫폼별 도구 문서 명확화

**변경 사항**:

- `execute_shell` 섹션을 플랫폼별로 분리
- Unix와 Windows 각각 독립된 섹션 작성

**추가 내용**:

````markdown
### execute_shell (Unix only)

**Platform**: Unix (Linux, macOS)  
**Shell**: bash or sh

Execute a shell command in a sandboxed environment using bash or sh.

**Parameters**:

- `command` (required, string): Shell command to execute
- `timeout` (optional, number): Timeout in seconds (default: 30, max: 300)
- `run_mode` (optional, enum): `"sync"` (default) or `"async"`

**Examples**:

```json
{
  "command": "ls -la",
  "run_mode": "sync"
}
```
````

---

### execute_windows_cmd (Windows only)

**Platform**: Windows  
**Shell**: cmd.exe (or PowerShell if available)

Execute a command using Windows cmd.exe in a sandboxed environment.

**Parameters**:

- `command` (required, string): Command to execute
- `timeout` (optional, number): Timeout in seconds (default: 30, max: 300)
- `run_mode` (optional, enum): `"sync"` (default) or `"async"`

**Examples**:

```json
{
  "command": "dir /b",
  "run_mode": "sync"
}
```

**Note**: The system may automatically use PowerShell if it's available and the command benefits from it.

````markdown
---

## 재사용 가능한 연관 코드

### 1. 플랫폼 감지 패턴 (`session_isolation.rs`)

**파일**: `src-tauri/src/session_isolation.rs`
**라인**: 393-415

**용도**: 런타임 플랫폼 감지 및 셸 선택

```rust
/// Get the appropriate shell command for the platform
fn get_shell_command(&self) -> &str {
    if cfg!(target_os = "windows") {
        "cmd"
    } else {
        "bash"
    }
}

async fn is_command_available(&self, command: &str) -> bool {
    let mut cmd = if cfg!(target_os = "windows") {
        AsyncCommand::new("where")
    } else {
        AsyncCommand::new("which")
    };
    cmd.arg(command);
    match cmd.output().await {
        Ok(output) => output.status.success(),
        Err(err) => {
            warn!("Failed to check command availability: {err}");
            false
        }
    }
}
```
````

### 2. 스키마 빌더 유틸리티 (`utils/schema_builder.rs`)

**파일**: `src-tauri/src/mcp/utils/schema_builder.rs`

**용도**: MCPTool 스키마 생성 헬퍼 함수

- `string_prop_with_examples()`: 문자열 프로퍼티 + 예제
- `integer_prop_with_default()`: 정수 프로퍼티 + 기본값
- `enum_prop()`: Enum 프로퍼티 + 기본값
- `object_schema()`: 객체 스키마 생성

### 3. 도구 등록 패턴 (`tools/mod.rs`)

**파일**: `src-tauri/src/mcp/builtin/workspace/tools/mod.rs`  
**라인**: 18-26

**용도**: 도구를 벡터로 묶어서 반환

```rust
pub fn code_tools() -> Vec<MCPTool> {
    vec![
        code_tools::create_execute_shell_tool(),
    ]
}
```

**참고**: 이 함수는 수정 불필요 (cfg에 따라 자동으로 다른 도구 반환)

### 4. 명령 정규화 로직 (`code_execution.rs`)

**파일**: `src-tauri/src/mcp/builtin/workspace/code_execution.rs`  
**라인**: 396-488

**용도**: LLM이 생성한 명령어의 따옴표 자동 보정

```rust
fn normalize_shell_command(raw_command: &str) -> String {
    // ...existing code...
}

fn fix_consecutive_quotes(input: &str) -> String {
    // ...existing code...
}
```

**참고**: 이 로직은 플랫폼 무관하게 재사용 가능

---

## Test Code 추가 및 수정 가이드

### 1. 도구 생성 단위 테스트

**파일**: `src-tauri/src/mcp/builtin/workspace/tools/code_tools.rs` (테스트 모듈 추가)

**목적**: 플랫폼별로 올바른 도구 이름이 생성되는지 검증

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tool_name_platform_specific() {
        let tool = create_execute_shell_tool();

        #[cfg(unix)]
        assert_eq!(tool.name, "execute_shell");

        #[cfg(windows)]
        assert_eq!(tool.name, "execute_windows_cmd");
    }

    #[test]
    fn test_tool_schema_has_required_properties() {
        let tool = create_execute_shell_tool();
        let schema = tool.input_schema;

        assert!(schema.get("properties").is_some());
        let props = schema["properties"].as_object().unwrap();
        assert!(props.contains_key("command"));
        assert!(props.contains_key("timeout"));
        assert!(props.contains_key("run_mode"));
    }

    #[cfg(unix)]
    #[test]
    fn test_unix_tool_has_unix_examples() {
        let tool = create_execute_shell_tool();
        let examples = tool.input_schema["properties"]["command"]["examples"]
            .as_array()
            .unwrap();

        // Unix 명령어 예제 확인
        assert!(examples.iter().any(|e| e.as_str().unwrap().contains("ls")));
        assert!(examples.iter().any(|e| e.as_str().unwrap().contains("grep")));
    }

    #[cfg(windows)]
    #[test]
    fn test_windows_tool_has_windows_examples() {
        let tool = create_execute_shell_tool();
        let examples = tool.input_schema["properties"]["command"]["examples"]
            .as_array()
            .unwrap();

        // Windows 명령어 예제 확인
        assert!(examples.iter().any(|e| e.as_str().unwrap().contains("dir")));
        assert!(examples.iter().any(|e| e.as_str().unwrap().contains("echo")));
    }
}
```

### 2. 도구 라우팅 통합 테스트

**파일**: `src-tauri/src/mcp/builtin/workspace/mod.rs` (테스트 모듈 추가)

**목적**: 플랫폼별 도구 이름으로 핸들러가 호출되는지 검증

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use crate::session::SessionManager;

    #[tokio::test]
    async fn test_platform_specific_tool_routing() {
        let session_manager = Arc::new(SessionManager::new());
        let server = WorkspaceServer::new(session_manager);

        #[cfg(unix)]
        let tool_name = "execute_shell";

        #[cfg(windows)]
        let tool_name = "execute_windows_cmd";

        let args = json!({
            "command": "echo test",
            "run_mode": "sync",
            "timeout": 5
        });

        let response = server.call_tool(tool_name, args).await;

        // 도구가 존재하고 실행됨 (에러가 "Tool not found"가 아님)
        if let Some(error) = response.get("error") {
            let message = error["message"].as_str().unwrap();
            assert!(!message.contains("not found"));
        }
    }

    #[tokio::test]
    async fn test_wrong_platform_tool_name_fails() {
        let session_manager = Arc::new(SessionManager::new());
        let server = WorkspaceServer::new(session_manager);

        // 반대 플랫폼 도구 이름으로 시도
        #[cfg(unix)]
        let wrong_tool_name = "execute_windows_cmd";

        #[cfg(windows)]
        let wrong_tool_name = "execute_shell";

        let args = json!({
            "command": "echo test"
        });

        let response = server.call_tool(wrong_tool_name, args).await;

        // "Tool not found" 에러 확인
        assert!(response.get("error").is_some());
        let message = response["error"]["message"].as_str().unwrap();
        assert!(message.contains("not found"));
    }
}
```

### 3. 도구 목록 테스트

**파일**: `src-tauri/src/mcp/builtin/workspace/tools/mod.rs` (테스트 모듈 추가)

**목적**: `code_tools()` 함수가 올바른 도구를 반환하는지 검증

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_code_tools_returns_platform_tool() {
        let tools = code_tools();
        assert_eq!(tools.len(), 1);

        let tool = &tools[0];

        #[cfg(unix)]
        assert_eq!(tool.name, "execute_shell");

        #[cfg(windows)]
        assert_eq!(tool.name, "execute_windows_cmd");
    }
}
```

### 4. E2E 테스트 (선택사항)

**목적**: 실제 명령 실행 및 결과 검증

```rust
#[cfg(test)]
mod e2e_tests {
    use super::*;

    #[tokio::test]
    #[cfg(unix)]
    async fn test_execute_shell_unix_command() {
        let session_manager = Arc::new(SessionManager::new());
        let server = WorkspaceServer::new(session_manager);

        let args = json!({
            "command": "echo 'Hello Unix'",
            "run_mode": "sync"
        });

        let response = server.call_tool("execute_shell", args).await;

        // 성공 응답 확인
        assert!(response.get("result").is_some());
        let result = response["result"].as_str().unwrap();
        assert!(result.contains("Hello Unix"));
    }

    #[tokio::test]
    #[cfg(windows)]
    async fn test_execute_windows_cmd_command() {
        let session_manager = Arc::new(SessionManager::new());
        let server = WorkspaceServer::new(session_manager);

        let args = json!({
            "command": "echo Hello Windows",
            "run_mode": "sync"
        });

        let response = server.call_tool("execute_windows_cmd", args).await;

        // 성공 응답 확인
        assert!(response.get("result").is_some());
        let result = response["result"].as_str().unwrap();
        assert!(result.contains("Hello Windows"));
    }
}
```

### 테스트 실행 방법

```powershell
# 단위 테스트 실행
cargo test --package libr-agent --lib

# 특정 모듈 테스트
cargo test --package libr-agent code_tools::tests

# Windows 전용 테스트
cargo test --package libr-agent --target x86_64-pc-windows-msvc

# 통합 테스트 (느림, 선택사항)
cargo test --package libr-agent --test '*'
```

---

## 추가 고려 사항

### 1. 하위 호환성

**문제**: 기존 클라이언트가 `execute_shell` 이름을 하드코딩한 경우

**해결 방안**:

- Unix 빌드에서는 기존 이름 유지 (`execute_shell`)
- Windows 빌드에서만 새 이름 (`execute_windows_cmd`) 사용
- 마이그레이션 경고 메시지 (선택사항)

### 2. PowerShell 지원

**현재 상태**: `session_isolation.rs`에서 PowerShell 자동 감지 및 사용

**개선 방향** (이 리팩토링 범위 밖):

- 향후 `execute_powershell` 도구를 별도 추가 가능
- `execute_windows_cmd`는 cmd.exe 전용으로 명확화

### 3. 크로스 플랫폼 에이전트

**시나리오**: 멀티플랫폼 지원 에이전트가 동적으로 도구 발견

**대응**:

- 에이전트는 `list_tools()`로 사용 가능한 도구 확인
- 도구 이름에 플랫폼 정보 포함되어 있어 자동 선택 가능

### 4. 문서 일관성

**필요 작업**:

- `docs/builtin-tools.md`: 플랫폼별 섹션 추가
- `README.md`: 플랫폼별 도구 명시
- `CHANGELOG.md`: Breaking change 기록 (Windows만 해당)

---

## 작업 순서

1. **도구 정의 수정** (`code_tools.rs`)
   - cfg 속성 추가
   - 플랫폼별 함수 분기
   - 예제 및 설명 업데이트

2. **라우팅 로직 수정** (`mod.rs`)
   - `call_tool()` 매칭 로직에 cfg 추가

3. **테스트 추가**
   - 도구 생성 테스트
   - 라우팅 테스트
   - 도구 목록 테스트

4. **문서 업데이트**
   - `docs/builtin-tools.md`
   - `README.md` (필요 시)
   - `CHANGELOG.md`

5. **빌드 및 검증**
   - Windows 빌드: `pnpm tauri build --target x86_64-pc-windows-msvc`
   - Unix 빌드 (선택): `pnpm tauri build --target x86_64-unknown-linux-gnu`
   - 테스트 실행: `cargo test`

6. **통합 테스트**
   - Tauri 개발 모드에서 실제 도구 호출 테스트
   - Windows와 Unix에서 각각 검증

---

## 예상 영향 범위

### 변경 파일

1. ✏️ `src-tauri/src/mcp/builtin/workspace/tools/code_tools.rs`
2. ✏️ `src-tauri/src/mcp/builtin/workspace/mod.rs`
3. ➕ 테스트 코드 (각 파일에 `#[cfg(test)]` 모듈 추가)
4. ✏️ `docs/builtin-tools.md`
5. ✏️ `CHANGELOG.md`

### 영향 없음

- `code_execution.rs`: 내부 로직 변경 불필요
- `session_isolation.rs`: 플랫폼 분기 이미 구현됨
- `terminal_manager.rs`: 프로세스 레지스트리 로직 무관
- 프론트엔드: 도구 발견은 동적이므로 변경 불필요

---

## 참고 자료

- [Rust Conditional Compilation](https://doc.rust-lang.org/reference/conditional-compilation.html)
- [cfg Attribute Reference](https://doc.rust-lang.org/reference/attributes/conditional-compilation.html)
- [MCP Protocol Specification](https://modelcontextprotocol.io/docs/concepts/tools)
- 기존 리팩토링 문서: `docs/history/refactoring_20251010_async_execute_shell.md`


---

# refactoring_20251019_switch_context_removal.md

# Refactoring Plan: Switch Context Removal and Parameter-Based Session Management

**작성일**: 2025-10-19  
**작업 범위**: MCP Tool Context 관리 아키텍처 전환  
**우선순위**: High (동시 요청 처리 안정성 확보)

---

## 1. 작업의 목적

### 1.1 문제 정의

현재 `switch_context` 기반 설계는 **stateful backend operation**으로 다중 요청 처리에 부적합합니다:

- **Race Condition**: 전역 상태(`currentSessionId`, `currentAssistantId`)에 의존하여 동시 요청 시 context 충돌 발생
- **확장성 제약**: Multi-agent, multi-session 시나리오 지원 불가
- **Debugging 어려움**: 요청별 context 추적 불가능
- **Architecture 복잡도**: `switch_context` async operation 필수, 호출 순서 의존성

### 1.2 목표

1. **`switch_context` 완전 제거**: 모든 Web MCP 및 Rust Backend에서 제거
2. **Parameter-based Context 도입**: 각 tool 호출마다 `__sessionId`, `__assistantId`, `__threadId` 파라미터 전달
3. **Tool Definition 분리**: AI에게 노출되는 schema에 context fields 미포함 (middleware 투명 주입)
4. **동시 요청 안전성**: Session/assistant/thread별 state 완전 격리
5. **호환성 유지**: 기존 Tool Definition 변경 없음, 점진적 마이그레이션 가능

---

## 2. 현재의 상태 / 문제점

### 2.1 Web MCP Servers 현황

#### planning-server.ts (`src/lib/web-mcp/modules/planning-server.ts`)

**현재 구조**:

```typescript
class SessionStateManager {
  private sessions = new Map<string, EphemeralState>();
  private currentSessionId: string | null = null; // ⚠️ 전역 상태

  setSession(sessionId: string): void {
    this.currentSessionId = sessionId;
  }

  private getCurrentState(): EphemeralState {
    if (!this.currentSessionId) throw new Error('No session');
    return this.sessions.get(this.currentSessionId)!;
  }
}

const planningServer: WebMCPServer = {
  async switchContext(context: ServiceContextOptions): Promise<void> {
    if (context.sessionId) {
      stateManager.setSession(context.sessionId);
    }
  },

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    // ⚠️ getCurrentState()에 의존 - 전역 상태 사용
    const state = stateManager.getCurrentState();
    // ...
  },
};
```

**문제점**:

- 동시 요청 A (session1) → `switchContext(session2)` → 요청 B 실행 시 B가 session2로 실행됨
- `assistantId`, `threadId` 미지원
- State 격리 불가능

#### playbook-store.ts (`src/lib/web-mcp/modules/playbook-store.ts`)

**현재 구조**:

```typescript
let currentAssistantId: string | null = null; // ⚠️ 전역 변수

const playbookStore: WebMCPServer = {
  async switchContext(context: ServiceContextOptions): Promise<void> {
    currentAssistantId = context.assistantId ?? null;
  },

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    // ⚠️ 권한 검사가 전역 currentAssistantId에 의존
    if (currentAssistantId && existing.agentId !== currentAssistantId) {
      return createMCPTextResponse('Error: Permission denied');
    }
  },
};
```

**문제점**:

- 동시 요청 시 권한 검사가 잘못된 assistant에 대해 수행될 수 있음
- Session 격리 없음

### 2.2 Rust Backend 현황

#### content_store (`src-tauri/src/mcp/builtin/content_store/server.rs`)

**현재 구조**:

```rust
pub struct ContentStoreServer {
    pub(crate) session_manager: Arc<SessionManager>,  // ⚠️ 싱글톤
    pub(crate) storage: Mutex<ContentStoreStorage>,
}

pub async fn switch_context(&self, options: ServiceContextOptions) -> Result<(), String> {
    if let Some(session_id) = &options.session_id {
        self.session_manager.set_current_session(session_id.clone()).await?;
    }
    Ok(())
}

pub async fn handle_add_content(&self, args: Value) -> MCPResponse {
    // ⚠️ 전역 SessionManager에 의존
    let session_id = self.session_manager.get_current_session()?;
    // ...
}
```

**문제점**:

- `SessionManager`는 앱 전체 싱글톤
- 다른 thread에서 `switch_context` 호출 시 race condition
- Tool handler 호출 전 반드시 `switch_context` 호출 필요 (순서 의존성)

#### workspace (`src-tauri/src/mcp/builtin/workspace/mod.rs`)

**현재 구조**:

```rust
pub struct WorkspaceServer {
    session_manager: Arc<SessionManager>,  // ⚠️ 싱글톤
    process_registry: ProcessRegistry,
}

pub async fn handle_poll_process(&self, args: Value) -> MCPResponse {
    let session_id = self.session_manager
        .get_current_session()
        .map_err(|e| format!("No session: {}", e))?;
    // ...
}
```

**문제점**:

- `session_manager.get_current_session()` 의존
- Process registry가 session별로 격리되지 않음

### 2.3 Frontend 현황

#### use-tool-processor.ts (`src/hooks/use-tool-processor.ts`)

**현재**:

```typescript
export const useToolProcessor = ({ submit }: UseToolProcessorConfig) => {
  // Tool 호출 시 sessionId 등을 전달하지 않음
  const response = await executeToolCall({
    id: toolCallId,
    name: toolCall.function.name,
    arguments: JSON.parse(toolCall.function.arguments),
  });
};
```

**문제점**:

- Context 주입 로직 없음
- Backend가 `switch_context`에 의존하도록 강제

---

## 3. 관련 코드의 구조 및 동작 방식 Summary (Bird's Eye View)

### 3.1 Architecture Overview

```text
┌─────────────────────────────────────────────────────────────────┐
│ Frontend Layer                                                   │
├─────────────────────────────────────────────────────────────────┤
│ ChatContext → useAIService → useToolProcessor                   │
│  ├─ AI generates tool calls                                     │
│  ├─ executeToolCall() invokes backend                           │
│  └─ Currently: NO context injection                             │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│ Backend Layer (Current - Stateful)                              │
├─────────────────────────────────────────────────────────────────┤
│ 1. Frontend calls switchContext(sessionId)                      │
│ 2. Backend sets global state (currentSessionId)                 │
│ 3. Frontend calls callTool(name, args)                          │
│ 4. Backend reads global state to get session                    │
│ ⚠️ Problem: Steps 3-4 can be interleaved by concurrent requests │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 Data Flow (Current)

```text
User Input → AI Model → Tool Calls
                          │
                          ▼
                    switchContext(sessionId)
                          │
                          ▼
                    [Global State Update]
                          │
                          ▼
                    callTool(name, args)
                          │
                          ▼
                    [Read Global State] ⚠️ Race condition here!
                          │
                          ▼
                    Tool Execution
```

### 3.3 Critical Design Principle: Tool Definition Separation

**⚠️ Most Important Constraint**:

```text
┌─────────────────────────────────────────────────────────────────┐
│ Layer 1: AI (sees Tool Definition - JSON Schema)                │
├─────────────────────────────────────────────────────────────────┤
│ {                                                                │
│   "name": "create_goal",                                        │
│   "inputSchema": {                                              │
│     "properties": { "goal": { "type": "string" } }              │
│   }                                                             │
│ }                                                               │
│ ✅ NO sessionId, assistantId, threadId                          │
└──────────────────────┬──────────────────────────────────────────┘
                       │ (AI generates args)
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│ Layer 2: Frontend Middleware (use-tool-processor.ts)            │
├─────────────────────────────────────────────────────────────────┤
│ Input:  { "goal": "Learn Rust" }                                │
│ Output: {                                                       │
│   "goal": "Learn Rust",                                         │
│   "__sessionId": "sess_123",     ← Injected transparently       │
│   "__assistantId": "asst_456",   ← Injected transparently       │
│   "__threadId": "thread_789"     ← Injected transparently       │
│ }                                                               │
│ ✅ __ prefix marks infrastructure fields (AI invisible)         │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│ Layer 3: Backend (Web MCP / Rust)                               │
├─────────────────────────────────────────────────────────────────┤
│ 1. Extract: { sessionId, assistantId, threadId } from args      │
│ 2. Remove: Delete __sessionId, __assistantId, __threadId        │
│ 3. Process: Use clean args { "goal": "Learn Rust" }             │
│ 4. Isolate: Use extracted context for state lookup              │
└─────────────────────────────────────────────────────────────────┘
```

**Key Rules**:

1. ✅ **DO**: Inject `__sessionId`, etc. in middleware layer (frontend)
2. ✅ **DO**: Extract and use in backend tool handlers
3. ✅ **DO**: Remove \_\_ fields before processing business logic
4. ❌ **DON'T**: Include in Tool Definition (JSON schema)
5. ❌ **DON'T**: Let AI know about these fields

---

## 4. 변경 이후의 상태 / 해결 판정 기준

### 4.1 목표 아키텍처

```text
User Input → AI Model → Tool Calls
                          │
                          ▼
                    [Middleware: Inject Context]
                          │
                          ▼
                    callTool(name, args + __sessionId + __assistantId)
                          │
                          ▼
                    [Backend: Extract Context from Args]
                          │
                          ▼
                    [State Lookup by Context Key]
                          │
                          ▼
                    Tool Execution (Isolated)
```

### 4.2 성공 판정 기준

#### 기능적 요구사항

- ✅ `switch_context` 완전 제거 (모든 Web MCP, Rust Backend)
- ✅ 동시 요청 처리 시 context 충돌 없음
- ✅ Session/assistant/thread별 state 완전 격리
- ✅ Tool Definition에 context fields 미포함
- ✅ 기존 Tool Definition 변경 없음 (AI 호환성 유지)

#### 비기능적 요구사항

- ✅ 성능 저하 없음 (parameter passing overhead 무시 가능)
- ✅ 메모리 누수 없음 (Web MCP TTL cleanup 동작)
- ✅ Debug 용이성 향상 (각 호출에 context 명시)
- ✅ 코드 복잡도 감소 (`switch_context` 호출 순서 의존성 제거)

#### 테스트 기준

- ✅ 단일 세션 테스트 통과
- ✅ 다중 세션 동시 실행 테스트 통과
- ✅ 동일 세션 동시 요청 테스트 통과
- ✅ Permission check (assistantId 기반) 정상 작동
- ✅ TTL cleanup (Web MCP) 정상 작동
- ✅ `pnpm refactor:validate` 통과 (lint, format, build)

---

## 5. 수정이 필요한 코드 및 수정부분의 코드 스니핏

### 5.1 Phase 1: Type & Interface 검증

#### Frontend: ServiceContextOptions (이미 존재)

**파일**: `src/features/tools/index.tsx`

```typescript
// ✅ 현재 이미 정의되어 있음 - 변경 불필요
export interface ServiceContextOptions {
  sessionId?: string;
  assistantId?: string;
  threadId?: string; // 확인 필요
}
```

**작업**: `threadId` 필드 존재 여부 확인, 없으면 추가

#### Backend Rust: ServiceContextOptions

**파일**: `src-tauri/src/mcp/types.rs`

```rust
// 현재
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceContextOptions {
    pub session_id: Option<String>,
    pub assistant_id: Option<String>,
    // thread_id 확인 필요
}

// 변경 후 (필요시)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceContextOptions {
    pub session_id: Option<String>,
    pub assistant_id: Option<String>,
    pub thread_id: Option<String>,  // ← 추가
}
```

### 5.2 Phase 2: Frontend Middleware

#### use-tool-processor.ts

**파일**: `src/hooks/use-tool-processor.ts`

**Before**:

```typescript
export const useToolProcessor = ({ submit }: UseToolProcessorConfig) => {
  // ...
  const response = await executeToolCall({
    id: toolCallId,
    name: toolCall.function.name,
    arguments: JSON.parse(toolCall.function.arguments),
  });
};
```

**After**:

```typescript
export const useToolProcessor = ({ submit }: UseToolProcessorConfig) => {
  // Context 가져오기 (ChatContext 또는 props에서)
  const sessionId = getCurrentSessionId(); // 구현 필요
  const assistantId = getCurrentAssistantId(); // 구현 필요
  const threadId = getCurrentThreadId(); // Optional

  // AI args에 context 주입
  const aiArgs = JSON.parse(toolCall.function.arguments);
  const argsWithContext = {
    ...aiArgs, // AI 생성 args 보존
    __sessionId: sessionId,
    __assistantId: assistantId,
    __threadId: threadId,
  };

  const response = await executeToolCall({
    id: toolCallId,
    name: toolCall.function.name,
    arguments: argsWithContext, // ← Context 포함
  });
};
```

### 5.3 Phase 3: Web MCP Servers

#### planning-server.ts

**파일**: `src/lib/web-mcp/modules/planning-server.ts`

**Before**:

```typescript
class SessionStateManager {
  private sessions = new Map<string, EphemeralState>();
  private currentSessionId: string | null = null;

  setSession(sessionId: string): void {
    this.currentSessionId = sessionId;
    if (!this.sessions.has(sessionId)) {
      this.sessions.set(sessionId, new EphemeralState());
    }
  }

  private getCurrentState(): EphemeralState {
    if (!this.currentSessionId) {
      throw new Error('No session set');
    }
    return this.sessions.get(this.currentSessionId)!;
  }
}

const stateManager = new SessionStateManager();

const planningServer: WebMCPServer = {
  async switchContext(context: ServiceContextOptions): Promise<void> {
    if (context.sessionId) {
      stateManager.setSession(context.sessionId);
    }
  },

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    const state = stateManager.getCurrentState();
    // ...
  },
};
```

**After**:

```typescript
// ─────────────────────────────────────────────────────────────
// Helper Functions
// ─────────────────────────────────────────────────────────────

function extractContext(args: Record<string, unknown>): {
  sessionId: string;
  assistantId?: string;
  threadId?: string;
} {
  return {
    sessionId: (args.__sessionId as string) || 'default',
    assistantId: args.__assistantId as string | undefined,
    threadId: args.__threadId as string | undefined,
  };
}

function getStateKey(
  sessionId: string,
  assistantId?: string,
  threadId?: string,
): string {
  return `${sessionId}::${assistantId || 'none'}::${threadId || 'default'}`;
}

function cleanArgs(args: Record<string, unknown>): Record<string, unknown> {
  const cleaned = { ...args };
  delete cleaned.__sessionId;
  delete cleaned.__assistantId;
  delete cleaned.__threadId;
  return cleaned;
}

// ─────────────────────────────────────────────────────────────
// State Management
// ─────────────────────────────────────────────────────────────

interface StateWithMetadata {
  state: EphemeralState;
  lastAccessedAt: number;
}

const ephemeralStateMap = new Map<string, StateWithMetadata>();

function getOrCreateState(stateKey: string): EphemeralState {
  const now = Date.now();
  const existing = ephemeralStateMap.get(stateKey);

  if (existing) {
    existing.lastAccessedAt = now;
    return existing.state;
  }

  const newState = new EphemeralState();
  ephemeralStateMap.set(stateKey, {
    state: newState,
    lastAccessedAt: now,
  });
  return newState;
}

// TTL Cleanup (1시간 미접근 상태 제거)
const TTL_MS = 60 * 60 * 1000;
setInterval(
  () => {
    const now = Date.now();
    for (const [key, entry] of ephemeralStateMap.entries()) {
      if (now - entry.lastAccessedAt > TTL_MS) {
        ephemeralStateMap.delete(key);
      }
    }
  },
  5 * 60 * 1000,
); // 5분마다 체크

// ─────────────────────────────────────────────────────────────
// Server Implementation
// ─────────────────────────────────────────────────────────────

const planningServer: WebMCPServer = {
  // ✅ switchContext 제거

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    const typedArgs = args as Record<string, unknown>;

    // Context 추출
    const context = extractContext(typedArgs);
    const stateKey = getStateKey(
      context.sessionId,
      context.assistantId,
      context.threadId,
    );

    // State 조회/생성
    const state = getOrCreateState(stateKey);

    // Args 정제
    const cleanedArgs = cleanArgs(typedArgs);

    // Tool 실행
    switch (name) {
      case 'create_goal': {
        const goal = cleanedArgs.goal as string;
        return state.createGoal(goal);
      }
      // ... other tools
    }
  },
};

export { planningServer };
```

#### playbook-store.ts

**파일**: `src/lib/web-mcp/modules/playbook-store.ts`

**Before**:

```typescript
let currentAssistantId: string | null = null;

const playbookStore: WebMCPServer = {
  async switchContext(context: ServiceContextOptions): Promise<void> {
    currentAssistantId = context.assistantId ?? null;
  },

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    case 'select_playbook': {
      if (currentAssistantId && existing.agentId !== currentAssistantId) {
        return createMCPTextResponse('Error: Permission denied');
      }
    }
  },
};
```

**After**:

```typescript
// currentAssistantId 전역 변수 제거

const playbookStoreMap = new Map<string, PlaybookStoreState>();

const playbookStore: WebMCPServer = {
  // ✅ switchContext 제거

  async callTool(name: string, args: unknown): Promise<MCPResponse<unknown>> {
    const typedArgs = args as Record<string, unknown>;

    // Context 추출
    const context = extractContext(typedArgs);
    const stateKey = getStateKey(
      context.sessionId,
      context.assistantId,
      context.threadId,
    );

    // State 조회/생성
    const store = getOrCreatePlaybookStore(stateKey);

    // Args 정제
    const cleanedArgs = cleanArgs(typedArgs);

    switch (name) {
      case 'select_playbook': {
        const id = cleanedArgs.id as string;
        const existing = store.playbookRecords.get(id);

        // Permission check using context.assistantId
        if (
          context.assistantId &&
          existing &&
          existing.agentId !== context.assistantId
        ) {
          return createMCPTextResponse('Error: Permission denied');
        }

        // ... proceed
      }
    }
  },
};
```

### 5.4 Phase 4: Rust Backend

#### content_store/server.rs

**파일**: `src-tauri/src/mcp/builtin/content_store/server.rs`

**Before**:

```rust
pub struct ContentStoreServer {
    pub(crate) session_manager: Arc<SessionManager>,
    pub(crate) storage: Mutex<ContentStoreStorage>,
}

pub async fn switch_context(&self, options: ServiceContextOptions) -> Result<(), String> {
    if let Some(session_id) = &options.session_id {
        self.session_manager.set_current_session(session_id.clone()).await?;
    }
    Ok(())
}

pub async fn handle_add_content(&self, args: Value) -> MCPResponse {
    let session_id = self.session_manager.get_current_session()?;
    // ...
}
```

**After**:

```rust
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::Mutex;
use serde_json::Value;

// ─────────────────────────────────────────────────────────────
// Context Extraction
// ─────────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct ToolContext {
    pub session_id: String,
    pub assistant_id: Option<String>,
    pub thread_id: Option<String>,
}

impl ToolContext {
    pub fn from_args(args: &Value) -> Self {
        let session_id = args
            .get("__sessionId")
            .and_then(|v| v.as_str())
            .unwrap_or("default")
            .to_string();

        let assistant_id = args
            .get("__assistantId")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string());

        let thread_id = args
            .get("__threadId")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string());

        Self {
            session_id,
            assistant_id,
            thread_id,
        }
    }
}

pub fn clean_args(args: &Value) -> Value {
    let mut cleaned = args.clone();
    if let Some(obj) = cleaned.as_object_mut() {
        obj.remove("__sessionId");
        obj.remove("__assistantId");
        obj.remove("__threadId");
    }
    cleaned
}

// ─────────────────────────────────────────────────────────────
// Session-Scoped Storage
// ─────────────────────────────────────────────────────────────

#[derive(Clone)]
pub struct SessionContentStore {
    pub session_id: String,
    pub contents: Vec<ContentItem>,
    pub bm25_index: BM25Index,
}

pub struct ContentStoreServer {
    // ✅ session_manager 제거
    storage: Arc<Mutex<HashMap<String, SessionContentStore>>>,
}

impl ContentStoreServer {
    pub fn new() -> Self {
        Self {
            storage: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    async fn get_or_create_session_store(
        &self,
        session_id: &str,
    ) -> SessionContentStore {
        let mut storage = self.storage.lock().await;

        storage
            .entry(session_id.to_string())
            .or_insert_with(|| SessionContentStore {
                session_id: session_id.to_string(),
                contents: Vec::new(),
                bm25_index: BM25Index::new(),
            })
            .clone()
    }

    async fn handle_add_content(
        &self,
        context: ToolContext,
        args: &Value,
    ) -> MCPResponse {
        let cleaned = clean_args(args);
        let filename = cleaned.get("filename")
            .and_then(|v| v.as_str())
            .ok_or_else(|| "filename is required".to_string())?;

        // Session store 조회
        let mut store = self.get_or_create_session_store(&context.session_id).await;

        // Content 추가
        store.contents.push(ContentItem {
            filename: filename.to_string(),
            content: /* ... */,
        });

        // Update storage
        let mut storage = self.storage.lock().await;
        storage.insert(context.session_id.clone(), store);

        Ok(/* response */)
    }
}

#[async_trait::async_trait]
impl BuiltinMCPServer for ContentStoreServer {
    fn name(&self) -> &str {
        "content_store"
    }

    fn tools(&self) -> Vec<MCPTool> {
        vec![
            MCPTool {
                name: "add_content".to_string(),
                description: "Add content to store".to_string(),
                inputSchema: json!({
                    "type": "object",
                    "properties": {
                        "filename": { "type": "string" },
                        "content": { "type": "string" }
                        // ✅ NO __sessionId, __assistantId
                    },
                    "required": ["filename", "content"]
                }),
            },
            // ... other tools
        ]
    }

    // ✅ switch_context 제거

    async fn call_tool(&self, tool_name: &str, args: Value) -> MCPResponse {
        // Context 추출
        let context = ToolContext::from_args(&args);

        match tool_name {
            "add_content" => self.handle_add_content(context, &args).await,
            // ... other tools
            _ => Err(format!("Unknown tool: {}", tool_name)),
        }
    }
}
```

#### workspace/mod.rs

**파일**: `src-tauri/src/mcp/builtin/workspace/mod.rs`

**Before**:

```rust
pub struct WorkspaceServer {
    session_manager: Arc<SessionManager>,
    process_registry: ProcessRegistry,
}

pub async fn handle_poll_process(&self, args: Value) -> MCPResponse {
    let session_id = self.session_manager.get_current_session()?;
    // ...
}
```

**After**:

```rust
pub struct WorkspaceServer {
    // ✅ session_manager 제거
    process_registry: Arc<Mutex<HashMap<String, SessionProcesses>>>,
}

struct SessionProcesses {
    session_id: String,
    processes: HashMap<String, ProcessInfo>,
}

impl WorkspaceServer {
    async fn handle_execute_command(
        &self,
        context: ToolContext,
        args: &Value,
    ) -> MCPResponse {
        let cleaned = clean_args(args);
        let command = cleaned.get("command")
            .and_then(|v| v.as_str())
            .ok_or_else(|| "command is required".to_string())?;

        // Session-scoped process registry
        let mut registry = self.process_registry.lock().await;
        let session_processes = registry
            .entry(context.session_id.clone())
            .or_insert_with(|| SessionProcesses {
                session_id: context.session_id.clone(),
                processes: HashMap::new(),
            });

        // Execute and register process
        let process_id = generate_process_id();
        session_processes.processes.insert(process_id.clone(), /* ... */);

        Ok(/* response */)
    }

    async fn handle_poll_process(
        &self,
        context: ToolContext,
        args: &Value,
    ) -> MCPResponse {
        let cleaned = clean_args(args);
        let process_id = cleaned.get("processId")
            .and_then(|v| v.as_str())
            .ok_or_else(|| "processId is required".to_string())?;

        // Session-scoped lookup
        let registry = self.process_registry.lock().await;
        let session_processes = registry
            .get(&context.session_id)
            .ok_or_else(|| "No processes for this session".to_string())?;

        let process = session_processes.processes
            .get(process_id)
            .ok_or_else(|| format!("Process {} not found", process_id))?;

        Ok(/* response */)
    }
}
```

### 5.5 Phase 5: Trait Changes

#### BuiltinMCPServer trait

**파일**: `src-tauri/src/mcp/builtin/mod.rs`

**Before**:

```rust
#[async_trait]
pub trait BuiltinMCPServer: Send + Sync {
    fn name(&self) -> &str;
    fn tools(&self) -> Vec<MCPTool>;

    async fn switch_context(
        &self,
        options: ServiceContextOptions,
    ) -> Result<(), String>;

    async fn call_tool(&self, tool_name: &str, args: Value) -> MCPResponse;
}
```

**After**:

```rust
#[async_trait]
pub trait BuiltinMCPServer: Send + Sync {
    fn name(&self) -> &str;
    fn tools(&self) -> Vec<MCPTool>;

    // ✅ switch_context 제거

    async fn call_tool(&self, tool_name: &str, args: Value) -> MCPResponse;
}
```

---

## 6. 재사용 가능한 연관 코드

### 6.1 공통 Helper Functions (TypeScript)

**위치**: `src/lib/web-mcp/common/context-helpers.ts` (새로 생성)

```typescript
/**
 * Extract context from tool args
 */
export function extractContext(args: Record<string, unknown>): {
  sessionId: string;
  assistantId?: string;
  threadId?: string;
} {
  return {
    sessionId: (args.__sessionId as string) || 'default',
    assistantId: args.__assistantId as string | undefined,
    threadId: args.__threadId as string | undefined,
  };
}

/**
 * Generate state key for session/assistant/thread isolation
 */
export function getStateKey(
  sessionId: string,
  assistantId?: string,
  threadId?: string,
): string {
  return `${sessionId}::${assistantId || 'none'}::${threadId || 'default'}`;
}

/**
 * Remove infrastructure fields from args
 */
export function cleanArgs(
  args: Record<string, unknown>,
): Record<string, unknown> {
  const cleaned = { ...args };
  delete cleaned.__sessionId;
  delete cleaned.__assistantId;
  delete cleaned.__threadId;
  return cleaned;
}

/**
 * TTL-based cleanup for state maps
 */
export function createTTLCleanup<T>(
  stateMap: Map<string, { state: T; lastAccessedAt: number }>,
  ttlMs: number = 60 * 60 * 1000,
  intervalMs: number = 5 * 60 * 1000,
): NodeJS.Timeout {
  return setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of stateMap.entries()) {
      if (now - entry.lastAccessedAt > ttlMs) {
        stateMap.delete(key);
      }
    }
  }, intervalMs);
}
```

### 6.2 공통 Helper Functions (Rust)

**위치**: `src-tauri/src/mcp/builtin/common.rs` (새로 생성)

```rust
use serde_json::Value;

#[derive(Debug, Clone)]
pub struct ToolContext {
    pub session_id: String,
    pub assistant_id: Option<String>,
    pub thread_id: Option<String>,
}

impl ToolContext {
    /// Extract context from tool args
    pub fn from_args(args: &Value) -> Self {
        let session_id = args
            .get("__sessionId")
            .and_then(|v| v.as_str())
            .unwrap_or("default")
            .to_string();

        let assistant_id = args
            .get("__assistantId")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string());

        let thread_id = args
            .get("__threadId")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string());

        Self {
            session_id,
            assistant_id,
            thread_id,
        }
    }
}

/// Remove infrastructure fields from args
pub fn clean_args(args: &Value) -> Value {
    let mut cleaned = args.clone();
    if let Some(obj) = cleaned.as_object_mut() {
        obj.remove("__sessionId");
        obj.remove("__assistantId");
        obj.remove("__threadId");
    }
    cleaned
}
```

### 6.3 재사용 가능한 인터페이스

**파일**: `src/models/mcp-types.ts`

```typescript
export interface ServiceContextOptions {
  sessionId?: string;
  assistantId?: string;
  threadId?: string;
}

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: Record<string, unknown>;
}

export interface MCPResponse<T = unknown> {
  content: Array<{
    type: string;
    text: string;
  }>;
  isError?: boolean;
}
```

**파일**: `src-tauri/src/mcp/types.rs`

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceContextOptions {
    pub session_id: Option<String>,
    pub assistant_id: Option<String>,
    pub thread_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MCPTool {
    pub name: String,
    pub description: String,
    #[serde(rename = "inputSchema")]
    pub input_schema: serde_json::Value,
}
```

---

## 7. Test Code 추가 및 수정 필요 부분에 대한 가이드

### 7.1 Web MCP Tests

**파일**: `src/lib/web-mcp/modules/__tests__/planning-server.test.ts` (새로 생성)

```typescript
import { describe, it, expect } from 'vitest';
import { planningServer } from '../planning-server';

describe('planningServer - Parameter-based Context', () => {
  it('should isolate state by session', async () => {
    // Session 1: Create goal
    const response1 = await planningServer.callTool('create_goal', {
      goal: 'Session 1 Goal',
      __sessionId: 'sess_1',
    });
    expect(response1.isError).toBe(false);

    // Session 2: Create goal
    const response2 = await planningServer.callTool('create_goal', {
      goal: 'Session 2 Goal',
      __sessionId: 'sess_2',
    });
    expect(response2.isError).toBe(false);

    // Session 1: List goals (should only have sess_1 goal)
    const list1 = await planningServer.callTool('list_goals', {
      __sessionId: 'sess_1',
    });
    expect(list1.content[0].text).toContain('Session 1 Goal');
    expect(list1.content[0].text).not.toContain('Session 2 Goal');
  });

  it('should isolate state by assistant within same session', async () => {
    const response1 = await planningServer.callTool('create_goal', {
      goal: 'Assistant 1 Goal',
      __sessionId: 'sess_1',
      __assistantId: 'asst_1',
    });

    const response2 = await planningServer.callTool('create_goal', {
      goal: 'Assistant 2 Goal',
      __sessionId: 'sess_1',
      __assistantId: 'asst_2',
    });

    // Check isolation
    const list1 = await planningServer.callTool('list_goals', {
      __sessionId: 'sess_1',
      __assistantId: 'asst_1',
    });
    expect(list1.content[0].text).toContain('Assistant 1 Goal');
    expect(list1.content[0].text).not.toContain('Assistant 2 Goal');
  });

  it('should handle concurrent requests safely', async () => {
    const promises = [
      planningServer.callTool('create_goal', {
        goal: 'Concurrent 1',
        __sessionId: 'sess_1',
      }),
      planningServer.callTool('create_goal', {
        goal: 'Concurrent 2',
        __sessionId: 'sess_2',
      }),
      planningServer.callTool('create_goal', {
        goal: 'Concurrent 3',
        __sessionId: 'sess_3',
      }),
    ];

    const results = await Promise.all(promises);
    expect(results.every((r) => !r.isError)).toBe(true);

    // Verify each session has only its own goal
    const list1 = await planningServer.callTool('list_goals', {
      __sessionId: 'sess_1',
    });
    const list2 = await planningServer.callTool('list_goals', {
      __sessionId: 'sess_2',
    });
    const list3 = await planningServer.callTool('list_goals', {
      __sessionId: 'sess_3',
    });

    expect(list1.content[0].text).toContain('Concurrent 1');
    expect(list2.content[0].text).toContain('Concurrent 2');
    expect(list3.content[0].text).toContain('Concurrent 3');
  });
});
```

**파일**: `src/lib/web-mcp/modules/__tests__/playbook-store.test.ts`

```typescript
describe('playbookStore - Permission Checks', () => {
  it('should allow access when assistantId matches', async () => {
    // Create playbook with assistant 1
    await playbookStore.callTool('create_playbook', {
      name: 'Test Playbook',
      __sessionId: 'sess_1',
      __assistantId: 'asst_1',
    });

    // Select playbook with same assistant (should succeed)
    const response = await playbookStore.callTool('select_playbook', {
      id: 'pb_123',
      __sessionId: 'sess_1',
      __assistantId: 'asst_1',
    });

    expect(response.isError).toBe(false);
  });

  it('should deny access when assistantId differs', async () => {
    // Create playbook with assistant 1
    await playbookStore.callTool('create_playbook', {
      name: 'Test Playbook',
      __sessionId: 'sess_1',
      __assistantId: 'asst_1',
    });

    // Try to select with different assistant (should fail)
    const response = await playbookStore.callTool('select_playbook', {
      id: 'pb_123',
      __sessionId: 'sess_1',
      __assistantId: 'asst_2',
    });

    expect(response.isError).toBe(true);
    expect(response.content[0].text).toContain('Permission denied');
  });
});
```

### 7.2 Rust Backend Tests

**파일**: `src-tauri/src/mcp/builtin/content_store/tests.rs` (새로 생성)

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[tokio::test]
    async fn test_session_isolation() {
        let server = ContentStoreServer::new();

        // Add content to session 1
        let args1 = json!({
            "filename": "test1.txt",
            "content": "Content 1",
            "__sessionId": "sess_1"
        });
        let result1 = server.call_tool("add_content", args1).await;
        assert!(result1.is_ok());

        // Add content to session 2
        let args2 = json!({
            "filename": "test2.txt",
            "content": "Content 2",
            "__sessionId": "sess_2"
        });
        let result2 = server.call_tool("add_content", args2).await;
        assert!(result2.is_ok());

        // List content in session 1 (should only have test1.txt)
        let list_args1 = json!({ "__sessionId": "sess_1" });
        let list1 = server.call_tool("list_contents", list_args1).await.unwrap();
        let text1 = &list1.content[0].text;
        assert!(text1.contains("test1.txt"));
        assert!(!text1.contains("test2.txt"));

        // List content in session 2 (should only have test2.txt)
        let list_args2 = json!({ "__sessionId": "sess_2" });
        let list2 = server.call_tool("list_contents", list_args2).await.unwrap();
        let text2 = &list2.content[0].text;
        assert!(text2.contains("test2.txt"));
        assert!(!text2.contains("test1.txt"));
    }

    #[tokio::test]
    async fn test_concurrent_requests() {
        let server = Arc::new(ContentStoreServer::new());

        let server1 = server.clone();
        let server2 = server.clone();
        let server3 = server.clone();

        let (result1, result2, result3) = tokio::join!(
            server1.call_tool("add_content", json!({
                "filename": "concurrent1.txt",
                "content": "Content 1",
                "__sessionId": "sess_1"
            })),
            server2.call_tool("add_content", json!({
                "filename": "concurrent2.txt",
                "content": "Content 2",
                "__sessionId": "sess_2"
            })),
            server3.call_tool("add_content", json!({
                "filename": "concurrent3.txt",
                "content": "Content 3",
                "__sessionId": "sess_3"
            }))
        );

        assert!(result1.is_ok());
        assert!(result2.is_ok());
        assert!(result3.is_ok());

        // Verify isolation
        let storage = server.storage.lock().await;
        assert_eq!(storage.get("sess_1").unwrap().contents.len(), 1);
        assert_eq!(storage.get("sess_2").unwrap().contents.len(), 1);
        assert_eq!(storage.get("sess_3").unwrap().contents.len(), 1);
    }
}
```

**파일**: `src-tauri/src/mcp/builtin/workspace/tests.rs`

```rust
#[tokio::test]
async fn test_process_session_isolation() {
    let server = WorkspaceServer::new();

    // Execute command in session 1
    let args1 = json!({
        "command": "echo 'Session 1'",
        "__sessionId": "sess_1"
    });
    let result1 = server.call_tool("execute_command", args1).await.unwrap();
    let process_id_1 = extract_process_id(&result1);

    // Execute command in session 2
    let args2 = json!({
        "command": "echo 'Session 2'",
        "__sessionId": "sess_2"
    });
    let result2 = server.call_tool("execute_command", args2).await.unwrap();
    let process_id_2 = extract_process_id(&result2);

    // Poll process from session 1 (should succeed)
    let poll1 = server.call_tool("poll_process", json!({
        "processId": process_id_1,
        "__sessionId": "sess_1"
    })).await;
    assert!(poll1.is_ok());

    // Try to poll session 1's process from session 2 (should fail)
    let poll_cross = server.call_tool("poll_process", json!({
        "processId": process_id_1,
        "__sessionId": "sess_2"
    })).await;
    assert!(poll_cross.is_err());
}
```

### 7.3 Integration Tests

**파일**: `src/test/integration/context-management.test.ts`

```typescript
describe('End-to-End Context Management', () => {
  it('should maintain context through full chat flow', async () => {
    // 1. Create AI service with sessionId
    const aiService = createAIService({
      sessionId: 'integration_test_session',
      assistantId: 'integration_test_assistant',
    });

    // 2. Send message that triggers tool use
    const response = await aiService.sendMessage('Create a goal: Test E2E');

    // 3. Verify tool was called with correct context
    expect(response.toolCalls).toHaveLength(1);
    expect(response.toolCalls[0].arguments).toMatchObject({
      goal: 'Test E2E',
      __sessionId: 'integration_test_session',
      __assistantId: 'integration_test_assistant',
    });

    // 4. Verify state isolation
    const anotherService = createAIService({
      sessionId: 'another_session',
    });
    const anotherResponse = await anotherService.sendMessage('List my goals');
    expect(anotherResponse.text).not.toContain('Test E2E');
  });
});
```

---

## 8. 추가 분석 과제

### 8.1 현재 미확정 사항

1. **Frontend Context 공급원**:
   - `use-tool-processor`에서 `sessionId`, `assistantId`, `threadId`를 어디서 가져올 것인가?
   - `ChatContext`에서 제공? Props로 전달? Global state?
   - **조사 필요**: `ChatContext.tsx` 구조 분석

2. **Rust SessionManager 의존성**:
   - `content_store`, `workspace` 외에 `SessionManager`를 사용하는 다른 서버 있는지 조사
   - **조사 필요**: `src-tauri/src/mcp/builtin/` 전체 스캔

3. **Memory Management 전략**:
   - Web MCP TTL: 1시간이 적절한가? 사용 패턴 분석 필요
   - Rust: GC가 충분한가? Explicit cleanup 필요한가?
   - **조사 필요**: Production 메모리 사용량 모니터링

4. **Tool Definition 현황**:
   - 현재 어떤 tool들이 정의되어 있는가?
   - Context fields를 실수로 포함한 tool이 있는가?
   - **조사 필요**: 모든 `MCPTool` 정의 검토

### 8.2 Performance 분석 필요 사항

1. **Parameter Passing Overhead**:
   - `__sessionId` 등을 매 호출마다 전달하는 것의 overhead
   - **측정 필요**: Before/After 성능 비교 (tool call latency)

2. **State Lookup Performance**:
   - Map lookup (`ephemeralStateMap.get(stateKey)`) 성능
   - HashMap lookup (Rust) 성능
   - **측정 필요**: Concurrent request scenario에서 latency

3. **Memory Footprint**:
   - Session별 state 유지 시 메모리 사용량
   - **측정 필요**: 100 sessions, 1000 sessions 시뮬레이션

### 8.3 호환성 검증 필요 사항

1. **기존 Tool Calls**:
   - AI가 생성한 기존 tool call arguments가 그대로 작동하는가?
   - **검증 필요**: 프로덕션 로그에서 실제 tool call 샘플 추출하여 테스트

2. **Backward Compatibility**:
   - `switch_context` 제거 후 기존 코드가 graceful degradation 하는가?
   - **검증 필요**: Phase-by-phase rollout 시뮬레이션

3. **Multi-Agent Flow**:
   - Assistant A → Tool → Assistant B 같은 복잡한 flow 지원 가능한가?
   - **검증 필요**: Multi-agent orchestration 시나리오 테스트

---

## 9. 구현 순서 및 마이그레이션 전략

### Phase 1: Preparation (Week 1)

**목표**: Type 정의 검증 및 helper functions 준비

**작업**:

1. ✅ `ServiceContextOptions` interface 검토 (`threadId` 필드 확인)
2. ✅ Rust `ServiceContextOptions` struct 동기화
3. ✅ TypeScript helper functions 작성 (`src/lib/web-mcp/common/context-helpers.ts`)
4. ✅ Rust helper functions 작성 (`src-tauri/src/mcp/builtin/common.rs`)
5. ✅ Unit tests for helpers

**Validation**:

- All helpers have unit tests
- No breaking changes to existing types

### Phase 2: Frontend Middleware (Week 1-2)

**목표**: Context 주입 로직 구현

**작업**:

1. ✅ `use-tool-processor.ts` 분석 (context 공급원 파악)
2. ✅ Context injection 로직 추가
3. ✅ AI args 보존 확인 (untouched)
4. ✅ Integration test 작성

**Validation**:

- Tool calls include `__sessionId`, `__assistantId`
- AI-generated args unchanged
- No Tool Definition modifications

### Phase 3: Web MCP Servers (Week 2-3)

**목표**: `planning-server`, `playbook-store` 리팩토링

**작업**:

1. ✅ `planning-server.ts`:
   - `switchContext` 제거
   - Context 추출 로직 추가
   - State map 변경 (Map<stateKey, State>)
   - TTL cleanup 구현
   - Unit tests

2. ✅ `playbook-store.ts`:
   - `switchContext` 제거
   - `currentAssistantId` 전역 변수 제거
   - Permission check 리팩토링
   - Unit tests

**Validation**:

- All existing tests pass
- New tests for session isolation pass
- Concurrent request tests pass
- Memory cleanup working (manual verification)

### Phase 4: Rust Backend (Week 3-4)

**목표**: `content_store`, `workspace` 리팩토링

**작업**:

1. ✅ `BuiltinMCPServer` trait:
   - `switch_context` 메서드 제거

2. ✅ `content_store/server.rs`:
   - `SessionManager` 의존성 제거
   - Session-scoped storage 구현 (HashMap)
   - `ToolContext::from_args()` 사용
   - Tool handlers 리팩토링
   - Unit tests, integration tests

3. ✅ `workspace/mod.rs`:
   - `SessionManager` 제거
   - Session-scoped process registry 구현
   - Context 기반 process isolation
   - Unit tests

**Validation**:

- `cargo test` 통과
- Session isolation tests 통과
- Concurrent request tests 통과
- No `SessionManager` dependency

### Phase 5: Testing & Deployment (Week 4)

**목표**: 전체 시스템 검증 및 배포

**작업**:

1. ✅ End-to-end integration tests
2. ✅ Performance tests (tool call latency)
3. ✅ Memory leak tests (장시간 실행)
4. ✅ Concurrent request stress tests (100+ concurrent)
5. ✅ `pnpm refactor:validate` 통과
6. ✅ Code review
7. ✅ Staging deployment
8. ✅ Production deployment with monitoring

**Validation**:

- All tests pass
- No performance regression
- No memory leaks
- Production monitoring shows no errors
- Context isolation working in production

---

## 10. Risk Assessment & Mitigation

### 10.1 High Risk

**Risk**: Context injection 누락으로 인한 runtime error

**Mitigation**:

- Frontend middleware에서 default value 제공 (`'default'` session)
- Backend에서 graceful fallback (missing context → default)
- Logging으로 모니터링 (context 없이 호출된 경우 경고)

### 10.2 Medium Risk

**Risk**: Memory leak (Web MCP state 누적)

**Mitigation**:

- TTL cleanup 구현 필수
- Production monitoring으로 메모리 사용량 추적
- LRU cache 대안 고려 (고급)

### 10.3 Low Risk

**Risk**: Tool Definition 실수로 context fields 포함

**Mitigation**:

- Code review checklist에 명시
- Automated test로 검증 (Tool schema에 `__` prefix 필드 없는지 확인)
- Documentation 명확히 (Critical Design Principle 강조)

---

## 11. Success Metrics

### 11.1 Functional Metrics

- ✅ `switch_context` 완전 제거 (모든 서버)
- ✅ 단일 세션 테스트 100% 통과
- ✅ 다중 세션 동시 실행 테스트 100% 통과
- ✅ Permission check (assistantId 기반) 정상 작동

### 11.2 Non-Functional Metrics

- ✅ Tool call latency: Before 대비 5% 이내 (parameter passing overhead)
- ✅ Memory usage: 100 sessions에서 안정적 (누수 없음)
- ✅ Concurrent request: 100+ 동시 요청 처리 가능
- ✅ Code complexity: `switch_context` 제거로 async dependency 제거

### 11.3 Quality Metrics

- ✅ Test coverage: 신규 코드 80% 이상
- ✅ `pnpm refactor:validate` 통과
- ✅ Code review approval
- ✅ Documentation complete

---

## 12. References

### 12.1 관련 문서

- [`docs/refactoring/switch-context-removal-refactoring.md`](../refactoring/switch-context-removal-refactoring.md) - 전략 문서
- [`docs/refactoring/tool-implementation-guide.md`](../refactoring/tool-implementation-guide.md) - 구현 가이드
- [`docs/refactoring/before-after-examples.md`](../refactoring/before-after-examples.md) - 코드 예제
- [`docs/architecture/chat-feature-architecture.md`](../architecture/chat-feature-architecture.md) - Chat 아키텍처

### 12.2 핵심 파일 위치

**Frontend**:

- `src/hooks/use-tool-processor.ts` - Context injection
- `src/features/tools/index.tsx` - ServiceContextOptions interface
- `src/lib/web-mcp/modules/planning-server.ts` - Web MCP 예제
- `src/lib/web-mcp/modules/playbook-store.ts` - Web MCP 예제

**Backend**:

- `src-tauri/src/mcp/builtin/mod.rs` - BuiltinMCPServer trait
- `src-tauri/src/mcp/builtin/content_store/server.rs` - Rust 예제
- `src-tauri/src/mcp/builtin/workspace/mod.rs` - Rust 예제
- `src-tauri/src/mcp/types.rs` - ServiceContextOptions struct

### 12.3 Key Types

**TypeScript**:

```typescript
interface ServiceContextOptions {
  sessionId?: string;
  assistantId?: string;
  threadId?: string;
}
```

**Rust**:

```rust
pub struct ToolContext {
    pub session_id: String,
    pub assistant_id: Option<String>,
    pub thread_id: Option<String>,
}
```

---

**작성자**: AI Architecture Team  
**검토자**: TBD  
**승인자**: TBD  
**최종 수정일**: 2025-10-19


---

# refactoring_20251012_1910.md

# Windows 경로 처리 크로스 플랫폼 호환성 개선 계획

**작성일:** 2025-10-12  
**문서 ID:** refactoring_20251012_1910  
**우선순위:** Critical (P0)  
**예상 작업 기간:** 2-3일

---

## 1. 작업의 목적

### 핵심 목표

Linux/macOS에서 정상 동작하는 파일 관리 기능(특히 `import_file`)이 Windows에서 실패하는 문제를 해결하여, 모든 플랫폼에서 일관된 사용자 경험을 제공한다.

### 배경

- Linux/macOS에서 검증 완료된 workspace 파일 관리 기능이 Windows에서 체계적으로 실패
- 주요 원인: 경로 구분자 차이(Unix `/` vs Windows `\`), 드라이브 문자 처리, 경로 파싱 불일치
- 사용자 보고: Windows에서 파일 드래그 앤 드롭 시 "Windows drive paths not allowed" 에러 발생

### 기대 효과

- Windows 사용자의 파일 import 성공률 100% 달성
- 크로스 플랫폼 경로 처리 표준화
- 에러 메시지 개선으로 디버깅 시간 단축
- 향후 경로 관련 버그 예방

---

## 2. 현재 상태 / 문제점

### 2.1 프론트엔드 경로 파싱 문제 (Critical)

**위치:** `src/features/chat/components/WorkspaceFilesPanel.tsx:256`

**현재 코드:**

```typescript
const fileName = srcPath.split('/').pop() || 'unknown';
```

**문제:**

- Windows 경로 (`C:\Users\user\file.txt`)를 `/`로만 split하여 백슬래시를 인식하지 못함
- 결과적으로 전체 경로가 파일명으로 추출됨
- 예시: `"C:\Users\user\Downloads\test.pdf"` → fileName = `"C:\Users\user\Downloads\test.pdf"` (전체 경로)

**영향:**

- `dest_rel_path`가 절대경로로 백엔드에 전달됨
- 백엔드의 드라이브 문자 검증에서 거부됨

### 2.2 백엔드 경로 검증 정책 문제 (Critical)

**위치:** `src-tauri/src/mcp/builtin/utils.rs:95-98`

**현재 코드:**

```rust
if user_path.len() >= 2 && user_path.chars().nth(1) == Some(':') {
    return Err(SecurityError::PathTraversal(format!(
        "Windows drive paths not allowed: '{user_path}'"
    )));
}
```

**문제:**

- `validate_path`가 Windows 드라이브 문자를 무조건 거부
- 설계상 목적지(dest) 경로만 검증해야 하는데, 여러 곳에서 무차별 사용
- `validate_path_for_read` (읽기 전용, 절대경로 허용)와 혼용

**영향:**

- import_file의 dest_rel_path에 절대경로가 전달되면 즉시 실패
- 일부 읽기 작업에서도 의도치 않게 절대경로 거부 가능

### 2.3 에러 메시지 불친절 (High)

**위치:** `src-tauri/src/mcp/builtin/workspace/file_operations.rs:651-661`

**현재 코드:**

```rust
let src_path = match std::path::Path::new(src_path_str).canonicalize() {
    Ok(path) => path,
    Err(e) => {
        error!("Invalid source path {}: {}", src_path_str, e);
        return Self::error_response(
            request_id,
            -32603,
            &format!("Invalid source path: {e}"),
        );
    }
};
```

**문제:**

- 에러 메시지에 입력값이 포함되지 않아 원인 파악 어려움
- Windows 경로 형식에 대한 힌트 없음
- 프론트엔드 경로 파싱 오류로 인한 실패와 실제 파일 없음을 구분 못함

### 2.4 경로 정규화 부재 (Medium)

**위치:**

- `src-tauri/src/mcp/builtin/workspace/export_operations.rs:160`
- `src-tauri/src/mcp/builtin/workspace/terminal_manager.rs:19-41`
- `src-tauri/src/mcp/builtin/workspace/mod.rs:81, 148, 262, 264, 367, 369`

**문제:**

- 단순 문자열 치환 (`replace("\\", "/")`)으로 혼합 구분자 처리 불완전
- 경로를 String으로 저장 후 PathBuf 변환 시 정규화 없음
- 크로스 플랫폼 호환성 저하

### 2.5 OS별 명령어 변환 없음 (Medium)

**위치:** `src-tauri/src/mcp/builtin/workspace/code_execution.rs:397-451`

**문제:**

- `normalize_shell_command`가 따옴표만 교정
- Unix 명령어(`ls`, `grep`)를 Windows 명령어로 변환하지 않음
- Windows 경로의 백슬래시 이스케이프 미처리

---

## 3. 관련 코드 구조 및 동작 방식 Summary

### 3.1 파일 Import 흐름 (Birdeye View)

```
[사용자 DnD]
    ↓
[Tauri DnD Handler]
    → paths: ["C:\Users\user\file.txt"]
    ↓
[WorkspaceFilesPanel.handleWorkspaceFileDrop]
    → srcPath parsing (문제 발생!)
    → fileName = srcPath.split('/').pop()
    → destRelPath = `${rootPath}/${fileName}`
    ↓
[callBuiltinTool('workspace', 'import_file')]
    → { src_abs_path: "C:\...", dest_rel_path: "C:\..." } (잘못된 dest!)
    ↓
[Rust Backend: handle_import_file]
    → canonicalize(src_abs_path) ✅
    → copy_file_from_external(src, dest)
        ↓
    [SecureFileManager.copy_file_from_external]
        → validate_path(dest_rel_path) ❌ 드라이브 문자 거부!
        ↓
    [SecurityValidator.validate_path]
        → Windows drive check: ':' 감지 → Error!
```

### 3.2 주요 컴포넌트 관계도

```
Frontend:
  WorkspaceFilesPanel.tsx
    ├── handleWorkspaceFileDrop() - 경로 파싱 (수정 필요)
    └── callBuiltinTool() - 백엔드 호출

Backend:
  file_operations.rs
    ├── handle_import_file() - 엔트리포인트 (에러 개선 필요)
    └── validate_path_with_error() - 검증 래퍼

  secure_file_manager.rs
    └── copy_file_from_external() - 실제 복사 로직
        └── validate_path() - dest 검증 (정책 명확화)

  utils.rs (SecurityValidator)
    ├── validate_path() - 쓰기용 (절대경로 금지)
    └── validate_path_for_read() - 읽기용 (절대경로 허용)
```

### 3.3 경로 검증 정책 (설계 의도)

| 함수                     | 용도        | 절대경로 | 드라이브 문자 | 상대경로 |
| ------------------------ | ----------- | -------- | ------------- | -------- |
| `validate_path`          | 쓰기/목적지 | ❌ 거부  | ❌ 거부       | ✅ 허용  |
| `validate_path_for_read` | 읽기/소스   | ✅ 허용  | ✅ 허용       | ✅ 허용  |

**현재 문제:** `validate_path`를 여러 곳에서 무차별 사용 → 용도별 구분 필요

---

## 4. 변경 이후의 상태 / 해결 판정 기준

### 4.1 성공 판정 기준

#### 기능적 요구사항

- [ ] Windows에서 파일 DnD import 성공률 100%
- [ ] Linux/macOS 기존 동작 유지 (regression 없음)
- [ ] 혼합 구분자 경로 (`C:\path/to\file`) 정상 처리
- [ ] ZIP export 시 경로 구조 정확성 유지

#### 비기능적 요구사항

- [ ] 에러 메시지에 입력 경로 표시 및 플랫폼별 힌트 제공
- [ ] 로그에 경로 정규화 전/후 기록
- [ ] 코드 리뷰 통과 (2명 이상 approve)

### 4.2 테스트 시나리오

#### 시나리오 1: Windows 파일 Import (Critical)

```
Given: Windows 환경, 파일 "C:\Users\user\Downloads\test.pdf" 준비
When: 파일을 Workspace Files Panel에 DnD
Then:
  - rootPath "./" 기준으로 "test.pdf" 생성
  - 채팅에 성공 메시지 표시
  - 파일 트리 자동 갱신
```

#### 시나리오 2: Linux 파일 Import (Regression 방지)

```
Given: Linux 환경, 파일 "/home/user/Downloads/test.pdf" 준비
When: 파일을 Workspace Files Panel에 DnD
Then:
  - 기존과 동일하게 동작
  - "test.pdf" 생성 성공
```

#### 시나리오 3: 절대경로 에러 메시지 (UX 개선)

```
Given: dest_rel_path에 절대경로 실수로 전달
When: import_file 호출
Then:
  - 에러 메시지: "Destination path must be relative to workspace. Got: 'C:\...' (absolute path not allowed)"
  - 로그에 입력값 전체 기록
```

#### 시나리오 4: ZIP Export 경로 정규화

```
Given: Windows에서 혼합 구분자 경로 파일들
When: export_zip 호출
Then:
  - ZIP 내부 경로가 모두 "/" 사용
  - 압축 해제 시 디렉토리 구조 정확
```

### 4.3 성능 기준

- 파일 import 시간: 이전 대비 +10% 이내 (경로 정규화 오버헤드)
- 메모리 사용량: 변화 없음

---

## 5. 수정이 필요한 코드 및 수정 부분 코드 스니펫

### 5.1 프론트엔드: 경로 파싱 수정 (P0 - Critical)

**파일:** `src/features/chat/components/WorkspaceFilesPanel.tsx`

**수정 위치:** 라인 256

**현재 코드:**

```typescript
const fileName = srcPath.split('/').pop() || 'unknown';
```

**수정 후 코드:**

```typescript
// OS-agnostic path parsing: support both / and \ separators
const fileName = srcPath.split(/[/\\]/).pop() || 'unknown';
```

**추가 개선 (선택):**

```typescript
// Alternative: normalize path first, then parse
const normalizedPath = srcPath.replace(/\\/g, '/');
const fileName = normalizedPath.split('/').pop() || 'unknown';
```

**영향 범위:**

- `handleWorkspaceFileDrop` 함수 내부
- Windows/Linux/macOS 모두 정상 동작

---

### 5.2 백엔드: 에러 메시지 개선 (P0 - Critical)

**파일:** `src-tauri/src/mcp/builtin/workspace/file_operations.rs`

**수정 위치:** 라인 651-661

**현재 코드:**

```rust
let src_path = match std::path::Path::new(src_path_str).canonicalize() {
    Ok(path) => path,
    Err(e) => {
        error!("Invalid source path {}: {}", src_path_str, e);
        return Self::error_response(
            request_id,
            -32603,
            &format!("Invalid source path: {e}"),
        );
    }
};
```

**수정 후 코드:**

```rust
let src_path = match std::path::Path::new(src_path_str).canonicalize() {
    Ok(path) => path,
    Err(e) => {
        error!("Failed to canonicalize source path '{}': {}", src_path_str, e);
        return Self::error_response(
            request_id,
            -32603,
            &format!(
                "Invalid source path: '{}'. {}. \
                 Please ensure the file exists and the path is correct. \
                 On Windows, use absolute paths like 'C:\\Users\\...'",
                src_path_str,
                e
            ),
        );
    }
};
```

**추가 로깅:**

```rust
tracing::debug!(
    "import_file called: src='{}', dest='{}'",
    src_path_str,
    dest_rel_path
);
```

---

### 5.3 백엔드: validate_path 용도 명확화 (P1 - High)

**파일:** `src-tauri/src/mcp/builtin/workspace/file_operations.rs`

**가이드라인:**

- **읽기 작업** (`handle_read_file`, `handle_grep`): `validate_path_for_read` 사용
- **쓰기 작업** (`handle_write_file`, `handle_replace_lines_in_file`): `validate_path` 사용
- **디렉토리 작업** (`handle_list_directory`, `handle_search_files`): 상황에 따라 선택

**수정 예시 (handle_grep, 라인 564):**

**현재 코드:**

```rust
match file_manager
    .get_security_validator()
    .validate_path(path_str)
{
    Ok(safe_path) => match tokio::fs::read_to_string(safe_path).await {
        // ...
    }
}
```

**수정 후 코드:**

```rust
match file_manager
    .get_security_validator()
    .validate_path_for_read(path_str)  // 읽기 전용이므로 변경
{
    Ok(safe_path) => match tokio::fs::read_to_string(safe_path).await {
        // ...
    }
}
```

**체크리스트:**

- [ ] handle_read_file (라인 66) - validate_path_for_read 적용 검토
- [ ] handle_grep (라인 564) - validate_path_for_read 적용
- [ ] handle_list_directory (라인 214) - 현재 상태 유지 (디렉토리는 워크스페이스 내부만)
- [ ] handle_search_files (라인 310) - 현재 상태 유지

---

### 5.4 백엔드: 경로 정규화 유틸리티 추가 (P1 - High)

**파일:** `src-tauri/src/mcp/builtin/workspace/utils.rs` (새로운 함수 추가)

**추가 코드:**

```rust
impl SecurityValidator {
    /// Normalize path separators to forward slashes for cross-platform compatibility.
    /// This is useful for storing paths in databases or ZIP archives.
    pub fn normalize_path_separators(path: &str) -> String {
        path.replace('\\', "/")
    }

    /// Extract filename from a path, supporting both / and \ separators.
    pub fn extract_filename(path: &str) -> Option<String> {
        let normalized = Self::normalize_path_separators(path);
        normalized.split('/').last().map(|s| s.to_string())
    }
}
```

**사용 예시:**

```rust
// In export_operations.rs:160
let archive_path = SecurityValidator::normalize_path_separators(&file_path);

// In terminal_manager.rs (if needed)
let filename = SecurityValidator::extract_filename(&stdout_path)
    .unwrap_or_else(|| "output".to_string());
```

---

### 5.5 백엔드: export_operations.rs 경로 정규화 (P2 - Medium)

**파일:** `src-tauri/src/mcp/builtin/workspace/export_operations.rs`

**수정 위치:** 라인 160

**현재 코드:**

```rust
let archive_path = file_path.replace("\\", "/");
```

**수정 후 코드:**

```rust
use crate::mcp::builtin::utils::SecurityValidator;

let archive_path = SecurityValidator::normalize_path_separators(file_path);
```

**또는 (Path API 사용):**

```rust
let archive_path = std::path::Path::new(file_path)
    .components()
    .filter_map(|c| match c {
        std::path::Component::Normal(s) => s.to_str(),
        _ => None,
    })
    .collect::<Vec<_>>()
    .join("/");
```

---

### 5.6 백엔드: SecurityError 메시지 개선 (P2 - Medium)

**파일:** `src-tauri/src/mcp/builtin/utils.rs`

**수정 위치:** 라인 95-98

**현재 코드:**

```rust
if user_path.len() >= 2 && user_path.chars().nth(1) == Some(':') {
    return Err(SecurityError::PathTraversal(format!(
        "Windows drive paths not allowed: '{user_path}'"
    )));
}
```

**수정 후 코드:**

```rust
if user_path.len() >= 2 && user_path.chars().nth(1) == Some(':') {
    return Err(SecurityError::PathTraversal(format!(
        "Absolute paths with drive letters are not allowed for destination paths: '{}'. \
         Please use relative paths like 'folder/file.txt'. \
         The file will be placed inside the workspace directory.",
        user_path
    )));
}
```

---

## 6. 재사용 가능한 연관 코드

### 6.1 경로 정규화 유틸리티

**위치:** `src-tauri/src/mcp/builtin/utils.rs`

**주요 기능:**

- `normalize_path_separators(path: &str) -> String` - 백슬래시를 슬래시로 변환
- `extract_filename(path: &str) -> Option<String>` - 플랫폼 무관 파일명 추출

**사용 예시:**

```rust
use crate::mcp::builtin::utils::SecurityValidator;

// ZIP archive paths
let archive_path = SecurityValidator::normalize_path_separators(&file_path);

// Filename extraction
let filename = SecurityValidator::extract_filename(&full_path)
    .unwrap_or_else(|| "unknown".to_string());
```

### 6.2 경로 검증 래퍼

**위치:** `src-tauri/src/mcp/builtin/workspace/file_operations.rs`

**기존 함수:**

```rust
fn validate_path_with_error(
    &self,
    path_str: &str,
    request_id: &Value,
) -> Result<std::path::PathBuf, Box<MCPResponse>>
```

**용도별 래퍼 추가 권장:**

```rust
fn validate_read_path_with_error(
    &self,
    path_str: &str,
    request_id: &Value,
) -> Result<std::path::PathBuf, Box<MCPResponse>> {
    let file_manager = self.get_file_manager();
    match file_manager
        .get_security_validator()
        .validate_path_for_read(path_str)  // 읽기용
    {
        Ok(path) => Ok(path),
        Err(e) => {
            error!("Read path validation failed: {}", e);
            Err(Box::new(Self::error_response(
                request_id.clone(),
                -32603,
                &format!("Security error: {e}"),
            )))
        }
    }
}
```

### 6.3 프론트엔드 경로 유틸리티 (선택적 추가)

**위치:** `src/lib/path-utils.ts` (신규 파일)

**제안 코드:**

```typescript
/**
 * Extract filename from a path, supporting both Unix and Windows separators.
 * @param path - Full file path
 * @returns Filename without directory path
 */
export function extractFilename(path: string): string {
  return path.split(/[/\\]/).pop() || 'unknown';
}

/**
 * Normalize path separators to forward slashes for cross-platform compatibility.
 * @param path - Path with mixed separators
 * @returns Path with forward slashes only
 */
export function normalizePath(path: string): string {
  return path.replace(/\\/g, '/');
}

/**
 * Check if a path is absolute (Windows or Unix style).
 * @param path - Path to check
 * @returns True if absolute path
 */
export function isAbsolutePath(path: string): boolean {
  // Windows: C:\ or \\server\share
  if (/^[A-Za-z]:[/\\]/.test(path) || /^\\\\/.test(path)) {
    return true;
  }
  // Unix: /path
  return path.startsWith('/');
}
```

**사용 예시:**

```typescript
import { extractFilename, normalizePath } from '@/lib/path-utils';

const fileName = extractFilename(srcPath);
const normalizedSrc = normalizePath(srcPath);
```

---

## 7. Test Code 추가 및 수정 가이드

### 7.1 프론트엔드 테스트

**파일:** `src/features/chat/components/WorkspaceFilesPanel.test.tsx` (신규)

**테스트 케이스:**

```typescript
describe('WorkspaceFilesPanel - Path Handling', () => {
  describe('handleWorkspaceFileDrop', () => {
    it('should extract filename from Windows path', () => {
      const windowsPath = 'C:\\Users\\user\\Downloads\\test.pdf';
      const fileName = windowsPath.split(/[/\\]/).pop();
      expect(fileName).toBe('test.pdf');
    });

    it('should extract filename from Unix path', () => {
      const unixPath = '/home/user/downloads/test.pdf';
      const fileName = unixPath.split(/[/\\]/).pop();
      expect(fileName).toBe('test.pdf');
    });

    it('should extract filename from mixed path', () => {
      const mixedPath = 'C:/Users/user\\Downloads\\test.pdf';
      const fileName = mixedPath.split(/[/\\]/).pop();
      expect(fileName).toBe('test.pdf');
    });

    it('should generate relative dest path correctly', () => {
      const rootPath = './';
      const fileName = 'test.pdf';
      const destPath = `${rootPath}/${fileName}`.replace(/\/+/g, '/');
      const destRelPath = destPath.startsWith('./')
        ? destPath.slice(2)
        : destPath;

      expect(destRelPath).toBe('test.pdf');
    });
  });
});
```

### 7.2 백엔드 테스트

**파일:** `src-tauri/src/mcp/builtin/workspace/file_operations.rs` (테스트 섹션)

**테스트 케이스:**

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_import_file_windows_absolute_src() {
        // Windows 절대경로 src는 허용되어야 함
        let src_path = "C:\\Users\\user\\test.pdf";
        let result = std::path::Path::new(src_path).is_absolute();
        assert!(result);
    }

    #[test]
    fn test_import_file_relative_dest() {
        // dest는 상대경로만 허용
        let dest_path = "imported/test.pdf";
        assert!(!dest_path.contains(':'));
        assert!(!std::path::Path::new(dest_path).is_absolute());
    }

    #[tokio::test]
    async fn test_validate_path_rejects_absolute_dest() {
        // Windows 절대경로는 dest에서 거부되어야 함
        let validator = SecurityValidator::new();
        let result = validator.validate_path("C:\\Users\\test.pdf");
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn test_validate_path_for_read_allows_absolute() {
        // 읽기용 검증은 절대경로 허용
        let validator = SecurityValidator::new();
        let result = validator.validate_path_for_read("/tmp/test.pdf");
        assert!(result.is_ok());
    }
}
```

**파일:** `src-tauri/src/mcp/builtin/utils.rs` (테스트 섹션)

**테스트 케이스 추가:**

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normalize_path_separators() {
        let windows_path = "C:\\Users\\user\\file.txt";
        let normalized = SecurityValidator::normalize_path_separators(windows_path);
        assert_eq!(normalized, "C:/Users/user/file.txt");
    }

    #[test]
    fn test_extract_filename_windows() {
        let path = "C:\\Users\\user\\Downloads\\test.pdf";
        let filename = SecurityValidator::extract_filename(path);
        assert_eq!(filename, Some("test.pdf".to_string()));
    }

    #[test]
    fn test_extract_filename_unix() {
        let path = "/home/user/downloads/test.pdf";
        let filename = SecurityValidator::extract_filename(path);
        assert_eq!(filename, Some("test.pdf".to_string()));
    }

    #[test]
    fn test_extract_filename_mixed() {
        let path = "C:/Users/user\\Downloads\\test.pdf";
        let filename = SecurityValidator::extract_filename(path);
        assert_eq!(filename, Some("test.pdf".to_string()));
    }
}
```

### 7.3 통합 테스트

**파일:** `src-tauri/tests/import_file_integration.rs` (신규)

**테스트 시나리오:**

```rust
#[cfg(test)]
mod import_file_tests {
    use std::fs;
    use std::path::PathBuf;
    use tempfile::TempDir;

    #[tokio::test]
    async fn test_import_file_windows_to_workspace() {
        // Setup
        let temp_dir = TempDir::new().unwrap();
        let src_file = temp_dir.path().join("source.txt");
        fs::write(&src_file, "test content").unwrap();

        // Simulate Windows absolute path
        let src_abs = src_file.to_string_lossy().to_string();
        let dest_rel = "imported/source.txt";

        // Execute
        // (Call actual import_file function via MCP tool)

        // Assert
        // - File copied successfully
        // - dest_rel_path is relative
        // - Source file still exists
    }

    #[tokio::test]
    async fn test_import_file_rejects_absolute_dest() {
        // Setup
        let temp_dir = TempDir::new().unwrap();
        let src_file = temp_dir.path().join("source.txt");
        fs::write(&src_file, "test content").unwrap();

        let src_abs = src_file.to_string_lossy().to_string();

        #[cfg(target_os = "windows")]
        let dest_abs = "C:\\workspace\\imported.txt";

        #[cfg(not(target_os = "windows"))]
        let dest_abs = "/workspace/imported.txt";

        // Execute & Assert
        // (Should return error about absolute dest path)
    }
}
```

### 7.4 수동 테스트 체크리스트

#### Windows 환경

- [ ] 파일 DnD (Downloads → Workspace) - 성공
- [ ] 혼합 구분자 경로 처리 - 성공
- [ ] 한글 파일명 처리 - 성공
- [ ] 공백 포함 경로 처리 - 성공
- [ ] 에러 메시지 확인 - 명확함

#### Linux/macOS 환경

- [ ] 파일 DnD (기존 동작) - 성공
- [ ] 심볼릭 링크 처리 - 성공
- [ ] Regression 테스트 - 이상 없음

#### 크로스 플랫폼

- [ ] ZIP export 경로 구조 - 일관성 유지
- [ ] 로그 가독성 - 개선됨
- [ ] 성능 영향 - 허용 범위 내

---

## 8. 작업 우선순위 및 의존성

### Phase 1: Critical Path (P0) - 1일차

**목표:** Windows import 기능 복구

1. **프론트엔드 경로 파싱 수정** (30분)
   - `WorkspaceFilesPanel.tsx:256` 수정
   - 즉시 테스트 가능
   - 의존성: 없음

2. **백엔드 에러 메시지 개선** (1시간)
   - `file_operations.rs:651-661` 수정
   - 로깅 추가
   - 의존성: 없음

3. **수동 테스트 (Windows)** (2시간)
   - 실제 파일 import 시나리오
   - 에러 케이스 확인
   - 의존성: 1, 2 완료

### Phase 2: Path Validation Refactoring (P1) - 2일차

**목표:** 경로 검증 정책 명확화 및 정규화 유틸리티 추가

4. **경로 정규화 유틸리티 추가** (2시간)
   - `utils.rs`에 함수 추가
   - 단위 테스트 작성
   - 의존성: 없음

5. **validate_path 용도별 분리** (3시간)
   - `file_operations.rs` 읽기 작업 수정
   - `validate_read_path_with_error` 추가
   - 의존성: 4 완료

6. **export_operations.rs 경로 정규화** (1시간)
   - 유틸리티 함수 활용
   - 의존성: 4 완료

### Phase 3: Testing & Documentation (P2) - 3일차

**목표:** 테스트 커버리지 및 문서화

7. **단위 테스트 작성** (3시간)
   - 프론트엔드 테스트
   - 백엔드 테스트
   - 의존성: 1-6 완료

8. **통합 테스트 및 회귀 테스트** (2시간)
   - Linux/macOS 검증
   - 의존성: 7 완료

9. **문서 업데이트** (1시간)
   - README 수정
   - API 문서 업데이트
   - 의존성: 8 완료

---

## 9. 추가 분석 과제

### 9.1 경로 관련 추가 조사 필요 사항

1. **Tauri DnD 경로 형식 확인**
   - Tauri의 `FileDrop` 이벤트가 반환하는 경로 형식 검증
   - Windows/Linux/macOS별 실제 반환값 샘플링
   - 문서: `@tauri-apps/api/event` FileDrop 타입

2. **워크스페이스 경로 정책 재검토**
   - 현재 base_dir 설정 방식 (`SecurityValidator::new()`)
   - 세션별 워크스페이스 격리 정책
   - 심볼릭 링크 처리 방침

3. **code_execution 명령어 변환 전략**
   - Unix → Windows 명령어 매핑 테이블 작성
   - PowerShell vs CMD 선택 기준
   - LLM 프롬프트 수정 가능성 검토

### 9.2 성능 영향 분석

1. **경로 정규화 오버헤드 측정**
   - 대량 파일 import 시나리오 (100+ files)
   - 경로 정규화 전/후 시간 측정
   - 병목 지점 식별

2. **메모리 사용량 분석**
   - String 복사 vs 참조 사용
   - PathBuf 변환 최적화 여부

### 9.3 보안 영향 평가

1. **절대경로 허용 시 보안 리스크**
   - `validate_path_for_read`의 절대경로 허용 범위
   - 심볼릭 링크를 통한 경로 탐색 공격 가능성
   - Sandbox 환경에서의 제약사항

2. **경로 정규화 취약점**
   - 정규화 우회 시도 (예: `C:/Users/..\..\..\..\Windows`)
   - Unicode/특수문자 처리

---

## 10. 롤백 계획

### 10.1 롤백 트리거 조건

다음 중 하나라도 발생 시 즉시 롤백:

- [ ] Linux/macOS에서 기존 동작 실패 (regression)
- [ ] Windows 성공률 70% 미만
- [ ] 성능 저하 30% 이상
- [ ] 보안 취약점 발견

### 10.2 롤백 절차

1. **Git revert** (5분)

   ```bash
   git revert <commit-hash>
   git push origin main
   ```

2. **긴급 핫픽스 브랜치** (필요 시)

   ```bash
   git checkout -b hotfix/path-handling-rollback
   # 최소한의 수정으로 긴급 수정
   ```

3. **사용자 공지** (즉시)
   - Discord/Slack 공지
   - GitHub Issue 생성 및 상황 설명

---

## 11. 참고 자료

### 내부 문서

- [Chat Feature Architecture](../architecture/chat-feature-architecture.md)
- [Built-in Tools Documentation](../builtin-tools.md)
- [Tauri Commands API](../api/tauri-commands.md)

### 외부 참조

- [Rust std::path Documentation](https://doc.rust-lang.org/std/path/)
- [Tauri FileDrop Event](https://tauri.app/v1/api/js/event/#filedropevent)
- [Windows Path Formats](https://learn.microsoft.com/en-us/dotnet/standard/io/file-path-formats)

### 관련 Issue/PR

- (추가 예정: 실제 issue 번호로 교체)
- #XXX - Windows 파일 import 실패 보고
- #YYY - 경로 처리 표준화 제안

---

## 12. 작업자 체크리스트

### 시작 전

- [ ] 프로젝트 빌드 성공 확인 (`pnpm tauri build`)
- [ ] 기존 테스트 통과 확인 (`pnpm test`)
- [ ] Windows 개발 환경 준비 (또는 VM/CI)
- [ ] 작업 브랜치 생성 (`git checkout -b fix/windows-path-handling`)

### 개발 중

- [ ] Phase 1 완료 후 Windows 테스트
- [ ] Phase 2 완료 후 Linux/macOS regression 테스트
- [ ] 각 단계별 커밋 (atomic commits)
- [ ] 로그 메시지 확인 (경로 정규화 전/후)

### 완료 후

- [ ] 모든 테스트 통과 (`pnpm refactor:validate`)
- [ ] 코드 리뷰 요청 (2명 이상)
- [ ] 문서 업데이트 확인
- [ ] CHANGELOG 업데이트
- [ ] 릴리스 노트 작성

---

**작성자:** GitHub Copilot  
**검토자:** (할당 예정)  
**승인자:** (할당 예정)

**변경 이력:**

- 2025-10-12 19:10 - 초안 작성


---

# refactoring_20251011_1954.md

# Refactoring Plan: Process Polling State Management Enhancement

**작성일**: 2025-10-11  
**작업자**: Development Team  
**관련 이슈**: Excessive polling detection and user guidance

---

## 작업의 목적

Async process 실행 시 AI 에이전트가 `poll_process` 도구를 과도하게 자주 호출하는 문제를 해결하기 위해, 연속적인 polling 패턴을 감지하고 적절한 가이드를 제공하는 메커니즘을 구축한다. 이를 통해:

1. **불필요한 시스템 부하 감소**: 과도한 polling으로 인한 I/O 및 CPU 오버헤드 최소화
2. **에이전트 행동 개선**: AI 에이전트에게 더 효율적인 polling 전략 유도
3. **사용자 경험 향상**: 명확한 피드백을 통해 프로세스 모니터링 방식 개선

---

## 현재의 상태 / 문제점

### 현재 구조

- **ProcessEntry**: 프로세스 메타데이터만 저장 (상태, PID, 시작/종료 시간, 출력 파일 경로 등)
- **handle_poll_process**: 단순한 읽기 전용 조회 기능만 제공
- **상태 관리**: 백그라운드 모니터링 태스크에서만 프로세스 상태 업데이트
- **Poll 추적 부재**: Poll 호출 자체를 기록하거나 분석하는 메커니즘 없음

### 핵심 문제점

1. **과도한 Polling 미감지**: 에이전트가 1-2초 간격으로 수십 번 polling해도 시스템이 인지하지 못함
2. **피드백 부재**: 비효율적인 polling 패턴에 대한 경고나 가이드 없음
3. **학습 기회 상실**: 에이전트가 더 나은 polling 전략을 학습할 수 없음
4. **리소스 낭비**: 불필요한 파일 I/O 및 락 경합 발생

### 관찰된 패턴

```text
[시간: 10:00:00] poll_process(process_id: "abc123") -> status: "running"
[시간: 10:00:02] poll_process(process_id: "abc123") -> status: "running"
[시간: 10:00:04] poll_process(process_id: "abc123") -> status: "running"
[시간: 10:00:06] poll_process(process_id: "abc123") -> status: "running"
[시간: 10:00:08] poll_process(process_id: "abc123") -> status: "running"
...
(30초 동안 15회 이상 반복)
```

---

## 관련 코드의 구조 및 동작 방식 Summary

### 1. Process Registry Architecture

```
WorkspaceServer
    └── process_registry: Arc<RwLock<ProcessRegistryData>>
            ├── entries: HashMap<String, ProcessEntry>
            └── cancellation_tokens: HashMap<String, CancellationToken>
```

**ProcessEntry (terminal_manager.rs)**

```rust
pub struct ProcessEntry {
    pub id: String,
    pub session_id: String,
    pub command: String,
    pub status: ProcessStatus,
    pub pid: Option<u32>,
    pub exit_code: Option<i32>,
    pub started_at: DateTime<Utc>,
    pub finished_at: Option<DateTime<Utc>>,
    pub stdout_path: String,
    pub stderr_path: String,
    pub stdout_size: u64,
    pub stderr_size: u64,
}
```

### 2. Async Process Execution Flow

```
execute_shell(run_mode: "async")
    ↓
1. 동시 실행 제한 확인 (최대 20개/세션)
    ↓
2. 프로세스 ID 생성 및 임시 디렉토리 생성
    ↓
3. ProcessEntry 등록 (status: Starting)
    ↓
4. 백그라운드 모니터링 태스크 시작
    ├── spawn_and_stream_to_files() 실행
    ├── stdout/stderr를 파일로 스트리밍
    └── 완료 시 status 업데이트 (Finished/Failed)
    ↓
5. 즉시 응답 반환 (process_id 포함)
```

### 3. Poll Process Flow

```
poll_process(process_id)
    ↓
1. 파라미터 검증 (process_id 필수)
    ↓
2. 세션 권한 확인
    ↓
3. Registry에서 ProcessEntry 조회 (읽기 전용)
    ↓
4. 선택적 tail 처리 (stdout/stderr 마지막 N줄)
    ↓
5. JSON 응답 구성 및 반환
```

**Key Insight**: Poll은 현재 **완전한 읽기 전용**으로 설계되어 있으며, 호출 자체를 추적하지 않음.

### 4. State Management Pattern

- **Write**: 백그라운드 태스크만 프로세스 상태 변경 가능
- **Read**: Poll은 관측(observation)만 수행
- **Lock Strategy**: RwLock 사용으로 다중 읽기 동시 지원
- **Session Isolation**: 세션별로 프로세스 격리

---

## 변경 이후의 상태 / 해결 판정 기준

### 목표 상태

1. **Poll 추적 메커니즘 활성화**
   - 각 프로세스에 대한 poll 호출 횟수, 시간, 패턴 기록
   - Running 상태에서의 연속 poll 특별 추적

2. **적응형 가이드 시스템**
   - 임계값 초과 시 자동으로 일반적인 가이드 메시지 추가
   - 구체적인 도구명 없이 행동 패턴 권장

3. **성능 저하 최소화**
   - Poll 추적으로 인한 락 경합 최소화
   - 메모리 오버헤드 최소화 (프로세스당 ~100 bytes 추가)

### 해결 판정 기준

#### 기능적 기준

- [ ] 연속 5회 이상 running 상태 poll 시 가이드 메시지 자동 추가
- [ ] 가이드 메시지에 구체적 도구명 미포함 (일반적 권장사항만)
- [ ] 세션 격리 유지 (다른 세션의 poll에 영향 없음)
- [ ] 프로세스 상태 변경 시 poll 카운터 자동 리셋

#### 성능 기준

- [ ] Poll 응답 시간 증가 < 5ms
- [ ] 메모리 오버헤드 < 200 bytes per process
- [ ] 기존 동기/비동기 실행 로직 정상 작동

#### 코드 품질 기준

- [ ] Rust 컴파일러 경고 없음
- [ ] `pnpm refactor:validate` 통과
- [ ] 기존 테스트 코드 모두 통과

---

## 수정이 필요한 코드 및 수정부분의 코드 스니핏

### 1. ProcessEntry 구조체 확장 (terminal_manager.rs)

**파일 경로**: `src-tauri/src/mcp/builtin/workspace/terminal_manager.rs`

**수정 위치**: 19-33행

**Before**:

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessEntry {
    pub id: String,
    pub session_id: String,
    pub command: String,
    pub status: ProcessStatus,
    pub pid: Option<u32>,
    pub exit_code: Option<i32>,
    pub started_at: DateTime<Utc>,
    pub finished_at: Option<DateTime<Utc>>,
    pub stdout_path: String,
    pub stderr_path: String,
    pub stdout_size: u64,
    pub stderr_size: u64,
}
```

**After**:

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessEntry {
    pub id: String,
    pub session_id: String,
    pub command: String,
    pub status: ProcessStatus,
    pub pid: Option<u32>,
    pub exit_code: Option<i32>,
    pub started_at: DateTime<Utc>,
    pub finished_at: Option<DateTime<Utc>>,
    pub stdout_path: String,
    pub stderr_path: String,
    pub stdout_size: u64,
    pub stderr_size: u64,

    // Poll tracking fields
    pub last_poll_at: Option<DateTime<Utc>>,
    pub poll_count: u32,
    pub consecutive_running_polls: u32,
    pub first_running_poll_at: Option<DateTime<Utc>>,
}
```

**변경 이유**: Poll 추적을 위한 메타데이터 필드 추가. 총 poll 횟수, 연속 running poll, 타임스탬프를 기록하여 패턴 분석 가능하게 함.

---

### 2. ProcessEntry 초기화 로직 업데이트 (code_execution.rs)

**파일 경로**: `src-tauri/src/mcp/builtin/workspace/code_execution.rs`

**수정 위치**: 다음 두 곳에서 ProcessEntry 생성 시

- 275-289행 (sync 모드)
- 609-623행 (async 모드)

**수정 내용**:

```rust
let entry = terminal_manager::ProcessEntry {
    id: process_id.clone(),
    session_id: session_id.clone(),
    command: command.to_string(),
    status: terminal_manager::ProcessStatus::Starting,
    pid: None,
    exit_code: None,
    started_at: chrono::Utc::now(),
    finished_at: None,
    stdout_path: stdout_path.to_string_lossy().to_string(),
    stderr_path: stderr_path.to_string_lossy().to_string(),
    stdout_size: 0,
    stderr_size: 0,

    // Initialize poll tracking fields
    last_poll_at: None,
    poll_count: 0,
    consecutive_running_polls: 0,
    first_running_poll_at: None,
};
```

---

### 3. handle_poll_process 로직 확장 (mod.rs)

**파일 경로**: `src-tauri/src/mcp/builtin/workspace/mod.rs`

**수정 위치**: 160-245행

**추가할 로직**:

```rust
pub async fn handle_poll_process(&self, args: Value) -> MCPResponse {
    let request_id = Self::generate_request_id();

    // ... 기존 파라미터 검증 및 권한 확인 로직 ...

    // === 추가: Poll 추적 및 Detect 로직 ===
    const MAX_CONSECUTIVE_RUNNING_POLLS: u32 = 5;

    let (should_show_guidance, entry_for_response) = {
        let mut registry = self.process_registry.write().await;
        if let Some(entry) = registry.entries.get_mut(process_id) {
            let now = chrono::Utc::now();

            // Update poll metadata
            entry.last_poll_at = Some(now);
            entry.poll_count += 1;

            // Track consecutive running polls
            let is_running = matches!(entry.status, terminal_manager::ProcessStatus::Running);
            if is_running {
                if entry.first_running_poll_at.is_none() {
                    entry.first_running_poll_at = Some(now);
                }
                entry.consecutive_running_polls += 1;
            } else {
                // Reset counters when status changes
                entry.consecutive_running_polls = 0;
                entry.first_running_poll_at = None;
            }

            let should_guide = is_running && entry.consecutive_running_polls >= MAX_CONSECUTIVE_RUNNING_POLLS;
            (should_guide, entry.clone())
        } else {
            return Self::error_response(
                request_id,
                -32603,
                "Process not found or access denied",
            );
        }
    };

    // Verify session access
    if entry_for_response.session_id != session_id {
        return Self::error_response(request_id, -32603, "Process not found or access denied");
    }

    // Build response
    let mut response = serde_json::json!({
        "process_id": entry_for_response.id,
        "status": format!("{:?}", entry_for_response.status).to_lowercase(),
        "command": entry_for_response.command,
        "pid": entry_for_response.pid,
        "exit_code": entry_for_response.exit_code,
        "started_at": entry_for_response.started_at.to_rfc3339(),
        "finished_at": entry_for_response.finished_at.map(|t| t.to_rfc3339()),
        "stdout_size": entry_for_response.stdout_size,
        "stderr_size": entry_for_response.stderr_size,
    });

    // Optional tail (기존 로직 유지)
    if let Some(tail_obj) = args.get("tail").and_then(|v| v.as_object()) {
        // ... 기존 tail 처리 로직 ...
    }

    // === 추가: 가이드 메시지 생성 ===
    let response_text = if should_show_guidance {
        let guidance = format!(
            "\n\n⚠️  Polling Efficiency Notice\n\
            This process has been polled {} times while running.\n\n\
            Consider more efficient monitoring strategies:\n\
            • Increase polling intervals (e.g., wait 10-30 seconds between checks)\n\
            • Wait longer before checking status again\n\
            • Use longer intervals for long-running processes\n\n\
            Frequent polling may impact system performance without providing additional value.",
            entry_for_response.consecutive_running_polls
        );

        format!(
            "{}\n{}",
            serde_json::to_string_pretty(&response).unwrap_or_default(),
            guidance
        )
    } else {
        serde_json::to_string_pretty(&response).unwrap_or_default()
    };

    Self::success_response(request_id, &response_text)
}
```

---

## 재사용 가능한 연관 코드

### 1. 상수 정의 (config.rs 또는 mod.rs)

```rust
// Polling behavior constants
pub const MAX_CONSECUTIVE_RUNNING_POLLS: u32 = 5;
pub const POLL_GUIDANCE_COOLDOWN_SECS: u64 = 60; // 가이드 재표시 간격
```

### 2. Tail 처리 로직 (terminal_manager.rs)

**파일 경로**: `src-tauri/src/mcp/builtin/workspace/terminal_manager.rs:54-149`

**기능**: 큰 파일 최적화 처리

- 1MB 미만: 전체 파일 읽기
- 1MB 이상: 청크 단위 역방향 탐색

**재사용 가능**: 변경 없이 그대로 사용

### 3. Session 격리 검증 (mod.rs)

```rust
// Get current session
let session_id = self
    .session_manager
    .get_current_session()
    .unwrap_or_else(|| "default".to_string());

// Verify session access
if entry.session_id != session_id {
    return Self::error_response(request_id, -32603, "Process not found or access denied");
}
```

**재사용 가능**: 세션 검증 패턴은 모든 poll 관련 핸들러에서 동일

### 4. 응답 생성 유틸리티 (utils.rs)

**파일 경로**: `src-tauri/src/mcp/builtin/workspace/utils.rs:10-20`

```rust
pub fn create_success_response(request_id: Value, message: &str) -> MCPResponse {
    MCPResponse::success(
        request_id,
        json!({
            "content": [{
                "type": "text",
                "text": message
            }]
        }),
    )
}
```

**재사용 가능**: 가이드 메시지 포함 응답 생성 시 사용

---

## Test Code 추가 및 수정 필요 부분 가이드

### 1. Unit Tests (terminal_manager.rs)

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_process_entry_initialization() {
        let entry = ProcessEntry {
            id: "test-123".to_string(),
            session_id: "session-1".to_string(),
            command: "test command".to_string(),
            status: ProcessStatus::Starting,
            pid: None,
            exit_code: None,
            started_at: Utc::now(),
            finished_at: None,
            stdout_path: "/tmp/stdout".to_string(),
            stderr_path: "/tmp/stderr".to_string(),
            stdout_size: 0,
            stderr_size: 0,
            last_poll_at: None,
            poll_count: 0,
            consecutive_running_polls: 0,
            first_running_poll_at: None,
        };

        assert_eq!(entry.poll_count, 0);
        assert_eq!(entry.consecutive_running_polls, 0);
        assert!(entry.last_poll_at.is_none());
    }

    #[test]
    fn test_poll_counter_increment() {
        // Poll 카운터 증가 로직 테스트
    }

    #[test]
    fn test_consecutive_running_poll_reset() {
        // 상태 변경 시 카운터 리셋 검증
    }
}
```

### 2. Integration Tests (mod.rs)

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;

    #[tokio::test]
    async fn test_excessive_polling_guidance() {
        // 1. Async 프로세스 시작
        // 2. 5회 이상 poll 호출
        // 3. 가이드 메시지 포함 여부 확인
    }

    #[tokio::test]
    async fn test_poll_tracking_across_status_changes() {
        // 1. Running 상태에서 5회 poll
        // 2. 프로세스 완료 (Finished)
        // 3. 다시 poll 시 카운터 리셋 확인
    }

    #[tokio::test]
    async fn test_session_isolation_in_poll_tracking() {
        // 1. 두 개의 서로 다른 세션 생성
        // 2. 각 세션에서 독립적인 poll 추적 확인
    }

    #[tokio::test]
    async fn test_poll_performance_impact() {
        // 1. Poll 추적 활성화 전후 응답 시간 측정
        // 2. 5ms 이내 증가 확인
    }
}
```

### 3. Serialization Tests

```rust
#[test]
fn test_process_entry_serialization() {
    let entry = ProcessEntry { /* ... */ };

    // JSON serialization
    let json = serde_json::to_string(&entry).unwrap();
    let deserialized: ProcessEntry = serde_json::from_str(&json).unwrap();

    assert_eq!(entry.id, deserialized.id);
    assert_eq!(entry.poll_count, deserialized.poll_count);
}
```

### 4. Mock 테스트를 위한 헬퍼

```rust
#[cfg(test)]
pub fn create_test_process_entry(id: &str, status: ProcessStatus) -> ProcessEntry {
    ProcessEntry {
        id: id.to_string(),
        session_id: "test-session".to_string(),
        command: "test command".to_string(),
        status,
        pid: Some(12345),
        exit_code: None,
        started_at: Utc::now(),
        finished_at: None,
        stdout_path: format!("/tmp/{}/stdout", id),
        stderr_path: format!("/tmp/{}/stderr", id),
        stdout_size: 0,
        stderr_size: 0,
        last_poll_at: None,
        poll_count: 0,
        consecutive_running_polls: 0,
        first_running_poll_at: None,
    }
}
```

---

## 추가 분석 과제

### 1. 가이드 메시지 최적화

- **현재 상태**: 영어 메시지만 제공
- **분석 필요**:
  - 다국어 지원 필요성 검토
  - 메시지 길이가 응답 크기에 미치는 영향 측정
  - 에이전트의 가이드 메시지 해석 능력 평가

### 2. 임계값 동적 조정

- **현재 상태**: 하드코딩된 임계값 (5회)
- **분석 필요**:
  - 프로세스 실행 시간에 따른 적정 임계값 연구
  - 세션별 또는 사용자별 설정 가능성 검토
  - 환경 변수를 통한 설정 가능성

### 3. Poll 패턴 분석 고도화

- **현재 상태**: 연속 횟수만 추적
- **분석 필요**:
  - Poll 간격(time delta) 추적 및 분석
  - 비정상적으로 짧은 간격(< 1초) 특별 처리
  - 통계 데이터 수집 (평균 간격, 표준편차 등)

### 4. 메모리 오버헤드 측정

- **현재 추정**: ProcessEntry당 ~100 bytes 추가
- **측정 필요**:
  - 실제 메모리 사용량 프로파일링
  - 대량 프로세스(100+) 시나리오 테스트
  - 메모리 누수 가능성 검증

### 5. 가이드 효과성 검증

- **현재 상태**: 가이드 제공 후 행동 변화 미추적
- **분석 필요**:
  - 가이드 표시 후 실제 polling 간격 변화 측정
  - A/B 테스트 (가이드 있음/없음)
  - 에이전트 학습 효과 장기 추적

---

## 구현 순서 권장사항

### Phase 1: 기본 인프라 구축 (1-2일)

1. ProcessEntry 구조체 확장
2. 초기화 로직 업데이트
3. 기본 테스트 작성 및 컴파일 확인

### Phase 2: Poll 추적 로직 구현 (2-3일)

1. handle_poll_process 수정
2. 카운터 증가/리셋 로직 구현
3. 세션 격리 검증

### Phase 3: 가이드 시스템 구현 (1-2일)

1. 가이드 메시지 생성 로직
2. 임계값 기반 트리거
3. 응답 형식 통합

### Phase 4: 테스트 및 검증 (2-3일)

1. Unit/Integration 테스트 작성
2. 성능 측정 및 최적화
3. `pnpm refactor:validate` 통과 확인

### Phase 5: 문서화 및 배포 (1일)

1. 코드 주석 보완
2. 사용자 문서 업데이트
3. 변경 사항 로깅

**총 예상 기간**: 7-11일

---

## 위험 요소 및 완화 전략

### 위험 1: 락 경합 증가

- **위험도**: 중간
- **완화**:
  - Write 락을 최소 시간만 보유
  - 필요한 데이터만 clone하여 락 외부에서 처리
  - 성능 테스트로 검증

### 위험 2: 기존 기능 회귀

- **위험도**: 낮음
- **완화**:
  - 필드 추가만으로 기존 로직 변경 최소화
  - 광범위한 테스트 커버리지
  - 단계적 배포 (feature flag 고려)

### 위험 3: 가이드 메시지 무시

- **위험도**: 높음
- **완화**:
  - 명확하고 실행 가능한 권장사항 제공
  - 에이전트 프롬프트에 가이드 준수 강조
  - 효과성 모니터링 및 개선

### 위험 4: 메모리 누수

- **위험도**: 낮음
- **완화**:
  - 24시간 자동 cleanup 메커니즘 활용
  - 메모리 프로파일링
  - 오래된 프로세스 정기 정리

---

## 성공 지표

1. **기술적 지표**
   - Poll 추적 정확도 99.9%
   - 응답 시간 증가 < 5ms
   - 메모리 오버헤드 < 200 bytes/process

2. **사용성 지표**
   - 가이드 표시 후 평균 polling 간격 증가율 > 50%
   - 과도한 polling (>10회) 발생 빈도 감소 > 70%

3. **시스템 안정성**
   - 기존 테스트 100% 통과
   - 새로운 크래시 또는 메모리 누수 0건
   - `refactor:validate` 통과

---

## 참고 자료

- **관련 파일**:
  - `src-tauri/src/mcp/builtin/workspace/terminal_manager.rs`
  - `src-tauri/src/mcp/builtin/workspace/mod.rs`
  - `src-tauri/src/mcp/builtin/workspace/code_execution.rs`
  - `src-tauri/src/mcp/builtin/workspace/utils.rs`

- **관련 문서**:
  - Async Process Execution Design
  - Session Isolation Architecture
  - MCP Tool Response Format Specification

- **참고 구현**:
  - Cleanup task (mod.rs:44-85)
  - Tail optimization (terminal_manager.rs:54-149)
  - Session-based isolation pattern

---

**작성 완료일**: 2025-10-11  
**최종 검토자**: [작업자명]  
**승인 상태**: 검토 대기


---

# refactoring_20251009_1645.md

---
title: 'Refactor: History 페이지 — 전역 메시지 검색 및 정렬 개선'
date: 2025-10-09
author: libr-agent/dev
---

# Refactor: History 페이지 — 전역 메시지 검색 및 정렬 개선

## 목적 (Purpose)

`History` 화면에 전역 메시지 검색 기능을 도입하고, 검색 결과를 세션별로 집계하여 "참조(검색 히트) 많은 세션 우선"으로 정렬해 보여준다. 검색이 비어있을 경우 기존 날짜 기준 정렬(오름/내림)을 유지하며, 사용자에게 정렬 기준(시간 오름/내림)을 선택할 수 있는 간단한 UX를 제공한다.

### 핵심 목표 (Key Goals)

- 전역 메시지 검색(이미 구현된 `searchMessages` 호출)을 활용
- 검색 결과로부터 sessionId별 집계(count, latest timestamp, snippet)를 생성하여 세션 정렬에 사용
- query가 비어있을 때는 날짜 기준 기본 정렬(asc/desc) 적용
- SWR을 사용해 검색 결과를 캐싱하고, query/정렬/페이지 사이즈를 SWR key에 포함
- 입력 디바운스와 작은 UX(정렬 토글, 검색 상태 표시)를 추가

---

## 현재 상태 / 문제점 (Current State / Problems)

### 기존 구현

- `History.tsx`는 현재 `useSessionContext()`에서 제공하는 세션 페이지를 단순히 펼쳐서(`flatMap`) `SessionList`에 전달한다.
- 세션 목록은 날짜 기준으로만 정렬되며, 메시지 내용 기반 검색 기능이 없다.
- `rust-backend-client.ts`에 `searchMessages` 구현이 추가되어 있음(메시지 수준 결과 반환).
- 현재 `searchMessages`는 `sessionId`를 필수 인자로 받아 특정 세션 내 검색만 지원.

### 문제점

- 사용자가 과거 대화 내용을 검색할 수 없어 특정 세션을 찾기 어려움
- 많은 세션이 누적될 경우 원하는 대화를 찾기 위해 수동으로 스크롤 필요
- 전역 검색 기능이 백엔드에 구현되어 있으나 UI에서 활용되지 않음

---

## 변경 이후 상태 / 성공 판정 기준 (Target State / Success Criteria)

### 기대 결과

1. **검색 기능**: 사용자가 검색어를 입력하면 SWR로 검색이 수행되고, 세션 목록이 검색 히트 수 기준으로 정렬되어 표시된다.
2. **캐싱 성능**: SWR 캐시가 동작하고, 동일 쿼리에 대해서는 재요청을 줄여 응답성이 향상된다.
3. **정렬 옵션**: 검색어가 없을 때 사용자가 날짜 오름차순/내림차순을 선택할 수 있다.
4. **UX 개선**: 검색 상태(로딩, 결과 없음)가 명확히 표시되고, 각 세션에 검색 히트 수가 배지로 표시된다.

### 성공 판정 기준

- ✅ 검색어 입력 시 전역 메시지 검색이 수행되고 결과가 세션별로 집계됨
- ✅ 검색 결과가 히트 수 기준으로 정렬되어 표시됨
- ✅ 검색어가 없을 때 날짜 기준 정렬(asc/desc)이 정상 작동
- ✅ SWR 캐시가 동작하여 동일 쿼리에 대한 중복 요청 방지
- ✅ 로딩 상태와 에러 상태가 적절히 표시됨
- ✅ 모든 TypeScript 타입이 명시적으로 정의되고 `any` 사용 없음
- ✅ 코드 주석이 모두 영어로 작성됨

---

## 관련 파일 (Related Files - Birdseye View)

- `src/features/history/History.tsx` — 검색 UI, SWR 통합, 집계 로직 및 정렬 구현
- `src/lib/rust-backend-client.ts` — `searchMessages` wrapper (sessionId를 optional로 변경하여 전역 검색 허용)
- `src/context/SessionContext.tsx` — 기존 세션 페치/페이지네이션 로직 (변경 없음, 재사용)
- `src/features/session/SessionList.tsx` — 세션 목록 렌더링 (히트 배지 표시 추가)
- `src/components/ui/*` — shadcn/ui 컴포넌트 (Input, Badge, Spinner, ToggleGroup 등)

---

## 설계 및 구현 계획 (Design & Implementation Plan)

### 1. 검색 UX

- **검색 입력**: shadcn/ui `<Input>` 컴포넌트 사용, 검색 아이콘 포함
- **디바운스**: 입력값은 300ms 디바운스 후 SWR에 반영
- **정렬 토글**: shadcn/ui `<ToggleGroup>` 사용하여 날짜 오름차순/내림차순 선택
- **검색 상태 표시**: shadcn/ui `<Spinner>` 또는 `<Progress>` 사용, "Searching..." 또는 "No results" 표시
- **히트 배지**: shadcn/ui `<Badge>` 사용하여 각 세션의 검색 히트 수 표시

### 2. SWR 캐싱 전략

- **SWR key**: `['historySearch', normalizedQuery, sortMode, pageSize]` (query가 비었을 때는 `null`)
- **fetcher**: `searchMessages(query, undefined, 1, pageSize)` — 전역 검색을 위해 `sessionId`를 전달하지 않음
- **디바운스**: 입력값은 250~350ms 디바운스 후 SWR에 반영
- **캐시 설정**: `revalidateOnFocus: false`, `dedupingInterval: 5000ms`
- **에러 처리**: SWR의 `onError` 콜백과 centralized logger 사용

### 3. 데이터 흐름 (검색 모드)

1. 사용자가 검색어 입력
2. 디바운스된 검색어로 SWR이 `searchMessages` 호출
3. 반환된 message-level 결과에서 sessionId별 집계: `{ sessionId, count, latestCreatedAt, snippet }`
4. 집계 결과를 기반으로 세션 정렬 (count desc, 동일 시 latestCreatedAt desc)
5. 세션 메타는 먼저 로컬 `sessionPages`에서 조회, 없으면 placeholder 생성
6. `SessionList`에는 정렬된 session 배열과 hitMap 전달

### 4. 데이터 흐름 (기본 모드 - 검색어 비어있음)

1. 기존 `useSessionContext()`에서 반환하는 `sessionPages`를 펼쳐 사용
2. 사용자가 토글한 시간 정렬(asc/desc) 적용하여 정렬
3. `SessionList`에는 정렬된 session 배열 전달 (hitMap 없음)

### 5. 성능/정확도 고려사항

- **페이지 크기**: 단일 `searchMessages` 호출에서 pageSize를 200으로 설정하여 충분한 검색 결과 확보
- **클라이언트 집계**: 빠른 도입을 위해 frontend-side aggregation 사용
- **장기 개선**: 대규모 환경에서는 서버사이드 집계 API(`messages_search_aggregate`) 도입 권장
- **로깅**: 모든 검색 작업에 centralized logger 사용하여 디버깅 및 성능 모니터링

---

## 구체적 코드 스니펫 (Detailed Code Snippets)

### 1. TypeScript 인터페이스 정의

```typescript
// src/models/search.ts
/**
 * Aggregated search result for a single session
 */
interface SearchAggregation {
  sessionId: string;
  count: number;
  latest: number;
  snippet?: string;
}

/**
 * Session extended with search hit count
 */
interface SessionWithHits extends Session {
  searchHits?: number;
}

/**
 * Sort mode for session list
 */
type SortMode = 'asc' | 'desc';

/**
 * Search state for UI rendering
 */
interface SearchState {
  isSearching: boolean;
  hasResults: boolean;
  error: Error | null;
}
```

### 2. 디바운스 훅

```typescript
// src/hooks/useDebounced.ts
import { useState, useEffect } from 'react';

/**
 * Debounces a value by the specified delay
 * @param value - The value to debounce
 * @param delay - Delay in milliseconds (default: 300)
 * @returns Debounced value
 */
export function useDebounced<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);

  return debounced;
}
```

### 3. SWR 사용 예 (History.tsx)

```typescript
import useSWR from 'swr';
import { getLogger } from '@/lib/logger';
import { searchMessages } from '@/lib/rust-backend-client';
import { useDebounced } from '@/hooks/useDebounced';

const logger = getLogger('History');

function History() {
  const [query, setQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('desc');
  const debouncedQuery = useDebounced(query, 300);
  const pageSize = 200;

  // Build SWR key only when query is non-empty
  const swrKey = debouncedQuery?.trim()
    ? ['historySearch', debouncedQuery.trim(), sortMode, pageSize]
    : null;

  const {
    data: searchPage,
    error,
    isValidating,
  } = useSWR(
    swrKey,
    async () => {
      logger.debug('Fetching search results', {
        query: debouncedQuery,
        pageSize,
      });
      // Call searchMessages without sessionId for global search
      return await searchMessages(
        debouncedQuery!.trim(),
        undefined,
        1,
        pageSize,
      );
    },
    {
      revalidateOnFocus: false,
      dedupingInterval: 5000,
      onError: (err: Error) => {
        logger.error('Search failed', err);
      },
    },
  );

  // ... rest of component
}
```

### 4. 집계 및 정렬 로직 (useMemo)

```typescript
import { useMemo } from 'react';

// Aggregate search results by sessionId
const aggregated = useMemo((): SearchAggregation[] => {
  if (!searchPage?.items) {
    logger.debug('No search results to aggregate');
    return [];
  }

  const map = new Map<string, SearchAggregation>();

  for (const item of searchPage.items) {
    const sid = item.sessionId;
    const entry = map.get(sid) ?? {
      sessionId: sid,
      count: 0,
      latest: 0,
    };

    entry.count += 1;
    const ts = item.createdAt?.getTime() ?? 0;

    // Keep the latest timestamp and snippet
    if (ts > entry.latest) {
      entry.latest = ts;
      if (item.snippet) {
        entry.snippet = item.snippet;
      }
    }

    map.set(sid, entry);
  }

  // Convert to array and sort by count (desc), then by latest timestamp (desc)
  const arr = Array.from(map.values());
  arr.sort((a, b) => {
    const countDiff = b.count - a.count;
    if (countDiff !== 0) return countDiff;
    return b.latest - a.latest;
  });

  logger.debug('Aggregated search results', {
    totalSessions: arr.length,
    totalHits: arr.reduce((sum, a) => sum + a.count, 0),
  });

  return arr;
}, [searchPage]);
```

### 5. 세션 목록 구성

```typescript
// Create a map for quick session lookup
const sessionsById = useMemo(() => {
  const m = new Map<string, Session>();
  sessions.forEach((s) => m.set(s.id, s));
  return m;
}, [sessions]);

// Build ordered session list based on search or date sorting
const orderedSessions = useMemo((): SessionWithHits[] => {
  if (!debouncedQuery?.trim()) {
    // Default mode: sort by date
    logger.debug('Using date-based sorting', { sortMode });
    return sessions.slice().sort((a, b) => {
      const aT = new Date(a.createdAt).getTime();
      const bT = new Date(b.createdAt).getTime();
      return sortMode === 'asc' ? aT - bT : bT - aT;
    });
  }

  // Search mode: use aggregation-based sorting
  logger.debug('Using search-based sorting', {
    query: debouncedQuery,
    resultCount: aggregated.length,
  });

  return aggregated.map((agg): SessionWithHits => {
    const local = sessionsById.get(agg.sessionId);

    if (local) {
      // Attach search hit count to existing session
      return { ...local, searchHits: agg.count };
    }

    // Create placeholder session for sessions not in current page
    logger.warn('Session not found locally, creating placeholder', {
      sessionId: agg.sessionId,
    });

    return {
      id: agg.sessionId,
      name: `Session ${agg.sessionId.slice(0, 6)}`,
      createdAt: new Date(agg.latest).toISOString(),
      updatedAt: new Date(agg.latest).toISOString(),
      assistants: [],
      description: agg.snippet ?? '',
      type: 'chat',
      searchHits: agg.count,
    } as SessionWithHits;
  });
}, [debouncedQuery, sessions, aggregated, sessionsById, sortMode]);
```

### 6. UI 컴포넌트 구성 (History.tsx)

```typescript
import { Input } from '@/components/ui/input';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Spinner } from '@/components/ui/spinner';
import { Badge } from '@/components/ui/badge';
import { Search, ArrowUp, ArrowDown } from 'lucide-react';

function History() {
  // ... state and hooks from above

  const searchState: SearchState = {
    isSearching: isValidating,
    hasResults: !!searchPage?.items.length,
    error: error ?? null,
  };

  return (
    <div className="flex flex-col h-full">
      {/* Search Header */}
      <div className="p-4 border-b space-y-4">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search messages across all sessions..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Sort Toggle (only visible when no search query) */}
        {!debouncedQuery?.trim() && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Sort by date:</span>
            <ToggleGroup
              type="single"
              value={sortMode}
              onValueChange={(value) => value && setSortMode(value as SortMode)}
            >
              <ToggleGroupItem value="asc" aria-label="Ascending">
                <ArrowUp className="h-4 w-4" />
                <span className="ml-1">Oldest first</span>
              </ToggleGroupItem>
              <ToggleGroupItem value="desc" aria-label="Descending">
                <ArrowDown className="h-4 w-4" />
                <span className="ml-1">Newest first</span>
              </ToggleGroupItem>
            </ToggleGroup>
          </div>
        )}

        {/* Search Status */}
        {searchState.isSearching && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Spinner className="h-4 w-4" />
            <span>Searching...</span>
          </div>
        )}

        {searchState.error && (
          <div className="text-sm text-destructive">
            Search failed. Please try again.
          </div>
        )}

        {debouncedQuery?.trim() && !searchState.isSearching && !searchState.hasResults && (
          <div className="text-sm text-muted-foreground">
            No results found for "{debouncedQuery}"
          </div>
        )}
      </div>

      {/* Session List */}
      <SessionList
        sessions={orderedSessions}
        onSessionClick={handleSessionClick}
      />
    </div>
  );
}
```

### 7. SessionList 히트 배지 표시

```typescript
// src/features/session/SessionList.tsx
import { Badge } from '@/components/ui/badge';

interface SessionListProps {
  sessions: SessionWithHits[];
  onSessionClick: (sessionId: string) => void;
}

function SessionList({ sessions, onSessionClick }: SessionListProps) {
  return (
    <div className="divide-y">
      {sessions.map((session) => (
        <div
          key={session.id}
          onClick={() => onSessionClick(session.id)}
          className="p-4 hover:bg-accent cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h3 className="font-medium">{session.name}</h3>
              <p className="text-sm text-muted-foreground line-clamp-1">
                {session.description}
              </p>
            </div>

            {/* Display search hit count if available */}
            {session.searchHits !== undefined && session.searchHits > 0 && (
              <Badge variant="secondary" className="ml-2">
                {session.searchHits} {session.searchHits === 1 ? 'hit' : 'hits'}
              </Badge>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
```

---

## 필요한 변경 파일 목록 (Files to Modify)

### 필수 변경

1. **Update**: `src/lib/rust-backend-client.ts`
   - `searchMessages`의 `sessionId` 파라미터를 optional로 변경하여 전역 검색 허용

   ```typescript
   export async function searchMessages(
     query: string,
     sessionId?: string, // Make optional
     page?: number,
     pageSize?: number,
   ): Promise<MessageSearchPage> {
     // ... implementation
   }
   ```

2. **Update**: `src/features/history/History.tsx`
   - 검색 UI 추가 (Input, ToggleGroup, Spinner)
   - SWR 통합 및 디바운스 로직 구현
   - 세션별 집계 및 정렬 로직 추가
   - Centralized logger 통합

3. **Update**: `src/features/session/SessionList.tsx`
   - `SessionWithHits` 인터페이스 지원
   - 히트 배지 표시 로직 추가

### 새 파일 추가

4. **Create**: `src/models/search.ts`
   - TypeScript 인터페이스 정의 (SearchAggregation, SessionWithHits, SortMode, SearchState)

5. **Create**: `src/hooks/useDebounced.ts`
   - 디바운스 훅 구현

### 선택적 변경 (향후 개선)

6. **Optional**: 백엔드에 `messages_search_aggregate` 명령 추가
   - 서버사이드 집계로 성능 개선
   - 대규모 데이터 처리 최적화

---

## 테스트 계획 (Testing Plan)

### 유닛 테스트 (Frontend)

1. **Aggregation Logic Test**

   ```typescript
   describe('Search Aggregation', () => {
     it('should aggregate messages by sessionId', () => {
       const mockMessages = [
         { sessionId: 'A', createdAt: new Date('2025-01-01') },
         { sessionId: 'A', createdAt: new Date('2025-01-02') },
         { sessionId: 'B', createdAt: new Date('2025-01-03') },
       ];

       const result = aggregateSearchResults(mockMessages);

       expect(result).toHaveLength(2);
       expect(result[0]).toMatchObject({ sessionId: 'A', count: 2 });
       expect(result[1]).toMatchObject({ sessionId: 'B', count: 1 });
     });

     it('should sort by count descending, then by timestamp descending', () => {
       // Test implementation
     });
   });
   ```

2. **Sorting Logic Test**

   ```typescript
   describe('Session Sorting', () => {
     it('should sort by date ascending when query is empty and sortMode is asc', () => {
       // Test implementation
     });

     it('should sort by date descending when query is empty and sortMode is desc', () => {
       // Test implementation
     });

     it('should sort by search hits when query is present', () => {
       // Test implementation
     });
   });
   ```

3. **Debounce Hook Test**

   ```typescript
   describe('useDebounced', () => {
     it('should debounce value by specified delay', async () => {
       // Use fake timers to test debouncing behavior
     });
   });
   ```

### 통합/수동 테스트

1. **검색 기능 테스트**
   - 검색어 입력 시 전역 검색이 수행되는지 확인
   - 검색 결과가 히트 수 기준으로 정렬되는지 확인
   - 검색어 변경 시 디바운스가 동작하는지 확인

2. **정렬 기능 테스트**
   - 검색어가 없을 때 날짜 정렬(asc/desc)이 동작하는지 확인
   - 정렬 토글 UI가 올바르게 표시되는지 확인

3. **UX 테스트**
   - 로딩 상태가 적절히 표시되는지 확인
   - 에러 상태가 적절히 표시되는지 확인
   - "No results" 메시지가 올바르게 표시되는지 확인
   - 히트 배지가 각 세션에 올바르게 표시되는지 확인

4. **성능 테스트**
   - SWR 캐시가 동작하여 중복 요청을 방지하는지 확인
   - 대량의 검색 결과에서도 UI가 반응성을 유지하는지 확인

### 검증 명령

```bash
# Run all tests
pnpm test

# Run full validation pipeline
pnpm refactor:validate

# Check TypeScript compilation
pnpm tsc --noEmit

# Run linter
pnpm lint

# Format code
pnpm format
```

---

## 롤아웃 및 운영 고려사항 (Rollout & Operations)

### 사용자 커뮤니케이션

- 검색 인덱스의 범위(최근 N개 메시지만)을 UI에 명확히 표시하여 사용자 기대를 관리한다.
- 검색 기능 도입 시 릴리스 노트에 사용법과 제한사항을 명시한다.

### 성능 모니터링

- Centralized logger를 통해 검색 쿼리, 응답 시간, 에러율을 모니터링한다.
- SWR 캐시 히트율을 추적하여 캐싱 효과를 측정한다.
- 검색 결과가 200개 이상 필요한 경우를 식별하여 향후 페이지네이션 도입을 고려한다.

### 점진적 개선 계획

1. **Phase 1 (Current)**: Frontend-side aggregation으로 빠른 가치 제공
2. **Phase 2**: 사용 패턴 분석 후 서버사이드 집계 API 도입 검토
3. **Phase 3**: 검색 결과 하이라이팅 및 컨텍스트 표시 추가
4. **Phase 4**: 고급 검색 필터 (날짜 범위, assistant 타입 등) 추가

### 에러 처리 및 복구

- 검색 실패 시 자동으로 기본 날짜 정렬 모드로 폴백
- 네트워크 오류 시 재시도 로직 (SWR 자동 재시도 활용)
- 에러 발생 시 사용자에게 명확한 메시지와 복구 방법 제시

---

## 작업 우선순위 체크리스트 (Task Priority Checklist)

### Priority 1: Core Functionality (필수)

- [ ] 1. `src/models/search.ts`: TypeScript 인터페이스 정의 추가
- [ ] 2. `src/hooks/useDebounced.ts`: 디바운스 훅 구현
- [ ] 3. `src/lib/rust-backend-client.ts`: `sessionId`를 optional로 변경 (non-breaking change)
- [ ] 4. `src/features/history/History.tsx`: 검색 UI + SWR + aggregation + orderedSessions 구현
- [ ] 5. `src/features/session/SessionList.tsx`: 히트 배지 prop 및 렌더링 추가

### Priority 2: Testing & Validation (필수)

- [ ] 6. 유닛 테스트 작성 (aggregation, sorting, debounce)
- [ ] 7. `pnpm refactor:validate` 실행 및 모든 검증 통과
- [ ] 8. 수동 통합 테스트 수행

### Priority 3: Documentation (권장)

- [ ] 9. 코드 주석을 영어로 작성 (CLAUDE.md 가이드라인 준수)
- [ ] 10. README 또는 CHANGELOG에 새 기능 문서화

### Priority 4: Future Improvements (선택)

- [ ] 11. Backend: `messages_search_aggregate` API 추가 (서버사이드 집계)
- [ ] 12. 검색 결과 하이라이팅 기능 추가
- [ ] 13. 고급 검색 필터 (날짜 범위, assistant 타입) 추가

---

## 작성자 노트 (Author's Note)

빠른 가치 제공을 위해 우선 프론트엔드 집계(frontend-side aggregation)를 먼저 적용하고, 실제 사용량과 성능을 측정한 후 백엔드 집계(backend-side aggregation)를 도입하는 흐름을 권장합니다.

현재 접근 방식의 장점:

- ✅ 빠른 구현 및 배포
- ✅ 기존 백엔드 API 활용
- ✅ 클라이언트 캐싱(SWR)으로 성능 최적화
- ✅ 점진적 개선 가능

향후 개선 시 고려사항:

- 서버사이드 집계로 대규모 데이터 처리 최적화
- 검색 인덱싱 전략 개선 (Full-text search engine 도입 검토)
- 실시간 검색 제안 (autocomplete) 추가

---

**Document Version**: 1.1
**Last Updated**: 2025-10-09
**Status**: Ready for Implementation


---

